#include <stdio.h>
#include "common.h"
#include "application/HCMqttSubProcess.h"
int main()
{
    HC_PRINT("Start to the Application\r\n!");
    HC_Init();
    while (1)
    {

      sleep(1);
    }

}
