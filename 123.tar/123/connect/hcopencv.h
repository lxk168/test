#ifndef HCOPENCV_H
#define HCOPENCV_H

#ifdef __cplusplus
extern "C"
{
#endif

  int HCOpencvDraw(char *fromPath,char *toPath,char *text,int xmin,int ymin,int length,int wideth);

#ifdef __cplusplus
}
#endif

#endif // HCOPENCV_H
