﻿
#ifndef HMACSHA_H
#define HMACSHA_H
#include "common.h"


extern  char * pr_sha(unsigned char* s, int t);
extern void truncate1
(
    char* d1,
    char* d2,
    int len
);

extern void hmac_sha256
(
 const char* k,
 int lk,
 const char* d,
 int ld,
 char* out,
 int* t
 );
extern  char * hmac_sha256_out(char *data,char* key);



#endif



