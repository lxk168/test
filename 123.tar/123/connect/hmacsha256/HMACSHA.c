
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hcbase64.h"
#include "HMACSHA.h"
#include "sha256.h"
#include"hcsha1.h"
#include "common.h"
char * pr_sha(unsigned char* s, int t)
{
    int i ;
    char buf[512]={0};
    for(i=0;i<t;i++)
    {

        sprintf(&buf[i*2],"%02x",s[i]);
    }

    char *temp=buf;
    return temp;
}

void truncate1
(
        char* d1, /* data to be truncated */
        char* d2, /* truncated data */
        int len /* length in bytes to keep */
        )
{
    int i ;
    for (i = 0 ; i < len ; i++)
    {
        d2[i] = d1[i];
    }
}



void hmac_sha256
(
        const char* k, /* secret key */
        int lk, /* length of the key in bytes */
        const char* d, /* data */
        int ld, /* length of data in bytes */
        char* out, /* output buffer, at least "t" bytes */
        int* t
        )
{
    SHA256Context ictx, octx ;
    char isha[SHA256_HASH_SIZE], osha[SHA256_HASH_SIZE] ;
    char key[SHA256_HASH_SIZE] ;
    char buf[SHA_BLOCKSIZE] ;
    int i ;

    if (lk > SHA_BLOCKSIZE) {

        SHA256Context tctx ;

        SHA256Init(&tctx) ;
        SHA256Update(&tctx, k, lk) ;
        SHA256Final(&tctx, key) ;

        k = key ;
        lk = SHA256_HASH_SIZE ;
    }



    SHA256Init(&ictx) ;


    for (i = 0 ; i < lk ; ++i) buf[i] = k[i] ^ 0x36 ;
    for (i = lk ; i < SHA_BLOCKSIZE ; ++i) buf[i] = 0x36 ;

    SHA256Update(&ictx, buf, SHA_BLOCKSIZE) ;
    SHA256Update(&ictx, d, ld) ;

    SHA256Final(&ictx, isha) ;



    SHA256Init(&octx) ;



    for (i = 0 ; i < lk ; ++i) buf[i] = k[i] ^ 0x5C ;
    for (i = lk ; i < SHA_BLOCKSIZE ; ++i) buf[i] = 0x5C ;

    SHA256Update(&octx, buf, SHA_BLOCKSIZE);
    SHA256Update(&octx, isha, SHA256_HASH_SIZE);
    SHA256Final(&octx, osha) ;


    *t = *t > SHA256_HASH_SIZE ? SHA256_HASH_SIZE : *t;
    truncate1(osha, out, *t);
}
char * hmac_sha256_out(char *data,char* key)
{
    char keybuf[64]={0}, databuf[1024]={0}, out[512]={0};
    char tempbuf[256]={0};
    int lenKey, lenData, lenOut;
    strcpy(databuf,data);
    strcpy(keybuf,key);
    lenKey=(int)strlen(key);
    lenData=(int)strlen(data);
    lenOut = 32;
    hmac_sha256(key, lenKey, data, lenData, out, &lenOut);
    strcat(tempbuf,pr_sha(out, lenOut));
    char *temp=tempbuf;
    return temp;
}

