﻿
#ifndef INIT_H
#define INIT_H
#include "common.h"
#include "application/HCAppStart.h"




extern void  HC_Init(void);

#endif



