﻿
#ifndef HCEVENTVIDEOSAVEPROCESS_H
#define HCEVENTVIDEOSAVEPROCESS_H
#include "common.h"
#include "application/HCBusinessInterface.h"
extern void *HCEventVideoSaveProcess_Thread(void);
extern int HCEventVideoCJsonAnalysis(char *id,char *cjsonbuf);
extern void *HCEventVideoSaveProcess_Thread_1(void);
extern void *HCEventVideoSaveProcess_Thread_2(void);
#endif



