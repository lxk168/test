﻿#ifndef HCMODBUSPROCESS_H
#define HCMODBUSPROCESS_H
#include "common.h"
#include "public/HCModbus.h"
#include "HCBusinessInterface.h"
extern void *HCModbusProcess_Thread(void);
extern void *HCModbusSoundProcess_Thread(void);

#endif
