﻿
#ifndef HCTCPNETPROCESS_H
#define HCTCPNETPROCESS_H
#include "common.h"
extern void *HC_ClientProcess_Thread(void);
#endif



