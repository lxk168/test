﻿
#ifndef HCDATARECORD_H
#define HCDATARECORD_H
#include "common.h"
#define DEV_NAME	"/dev/ioctrl"

#pragma pack (1)
// json拆解后的结构体
typedef struct
{
    int xmin;
    int ymin;
    int xmax;
    int ymax;
    char info_person[20];
    char info[20];
    char info_door[20];
}ST_AnalysisData;

typedef struct {
     int JPG_size;
    unsigned char JPG_Data[409600];
}St_Result_JPG;
typedef struct
{

    ST_AnalysisData Bbox;
}ST_AnalysisDataBbox;
typedef struct
{
  ST_AnalysisDataBbox AnalysisDataBbox[3];//3个任务
}ST_AnalysisResult;

typedef enum GPIO_LIST{     //GPIO 外设定义

    RED_LED = 0,    	//面板红色LED  Active low
    BLUE_LED = 1,		//面板蓝色LED  Active low
    WIFI_PWR = 2,		//wifi电源控制，Active high
    M4G_PWR = 3,		//4G电源控制，Active low
    USB2_HOST_PWR = 4,	//USB电源控制，Active high
    ALARM_OUT1 = 6,		//报警输出,高电平12V
    ALARM_OUT2 = 7,		//报警输出,高电平12V
    USB2_HUB_RESET = 8, //HUB RESET，Active low

    ALARM_INPUT = 9,    //报警输入3.3~12V
    GPIO_MAX,

}GPIO_LIST_E;


typedef struct GpioCtrl{

    int gpiox;	   //外设
    int level;     //电平

}GpioCtrl_S;
typedef struct
{
    int doorflag;  // 0开 1关
    int opencount; //开门次数
    int closecount;//关门次数
    int allcount;//总的次数

}ST_DoorEvent;
typedef struct
{
    int personflag;  // 0无人 1有人
    int personcount; //检测到人的次数
    int allcount;//总的次数

}ST_PersonEvent;
typedef struct
{
    int flag;  // 0无人 1有人


}ST_eventFlag;
typedef struct
{
  ST_eventFlag eventFlag[3];
}ST_EventFlag;
typedef struct
{
    int flag;  // 0无人 1有人


}ST_fileSaveFlag;
typedef struct
{
    int flag;
}ST_EventVideoSaveFlag;
#pragma pack()

//extern ST_AnalysisResult AnalysisResult;
extern ST_fileSaveFlag  FileSaveFlag[3];
extern ST_AnalysisResult AnalysisResult;
extern GpioCtrl_S    gpiodtrl_s;
extern St_Result_JPG  Result_JPG[3];

extern char AnalysisSendsingle[2048];
extern int Analysiscount;
extern ST_PersonEvent PersonEvent;
extern ST_DoorEvent DoorEvent;
extern ST_eventFlag  EventFlag[3];
extern ST_EventVideoSaveFlag EventVideoSaveFlag[3];
#endif



