﻿#include "HCDataProcess.h"
#include "application/HCModbusProcess.h"
#include "stdlib.h"
#include "stdio.h"
#include "zmq/czmq.h"
#define  DEBUGKEY  //上传调试开关
ST_Mmapfd Mmapfd[MAXTaskNum];
ST_AnalysisResult AnalysisResult;
St_Result_JPG  Result_JPG[3];
GpioCtrl_S    gpiodtrl_s;
ST_PersonEvent PersonEvent;
ST_DoorEvent DoorEvent;
ST_eventFlag  EventFlag[3];
ST_fileSaveFlag  FileSaveFlag[3];
ST_EventVideoSaveFlag EventVideoSaveFlag[3];
int videosaveflag=ERR_COMMON_FAILED;

//内存映射线程
void *HC_DataProcess_Thread(void)
{


    int i=0;
    char  cmp1[MAXTaskNum][BUFSIZE]={{0}};
    char  cmp2[MAXTaskNum][BUFSIZE]={{0}};
    char  Analysisbuf[MAXTaskNum][BUFSIZE]={{0}};
    char  Picturebuf[MAXTaskNum][PICBUFSIZ]={{0}};

    char filename[256]={0};
    int ReadFd = 0;
    int WriteFd=0;
    int piclength=0;
    char filenamePath[512]={0};
    char Send_task_info[512]={0};
    memset(Send_task_info,0x0,sizeof (Send_task_info));

    memset(&PersonEvent,0x0,sizeof (ST_PersonEvent));
    memset(&DoorEvent,0x0,sizeof (ST_DoorEvent));
    memset( &EventFlag,0x0,sizeof (ST_EventFlag));
    int idfd=0;
    int idfd1=0;
    int idfd2=0;
    key_t key = ftok("example",64);
    idfd = msgget(key,IPC_CREAT | 0666);
    if(idfd == -1)
    {
        HC_PRINT("create msg error \n");
        //return ERR_COMMON_FAILED;
    }
    key_t key1 = ftok("example1",65);
    idfd1 = msgget(key1,IPC_CREAT | 0666);
    if(idfd1 == -1)
    {
        HC_PRINT("create msg error \n");
        //return ERR_COMMON_FAILED;
    }
    key_t key2 = ftok("example2",66);
    idfd2 = msgget(key2,IPC_CREAT | 0666);
    if(idfd2 == -1)
    {
        HC_PRINT("create msg error \n");
        //return ERR_COMMON_FAILED;
    }
    for (i=0;i<HCTaskNumCount(MAXTaskNum);i++) {


        if(strlen(mmapadresstol.MmapAdressNum[i].MmapAdress)!=0)
        {
            memset(filename,0x0,sizeof (filename));
            sprintf(filename,"/userdata/usr/local/%s",mmapadresstol.MmapAdressNum[i].MmapAdress);
            ReadFd = open(filename, O_RDWR);
            if (ReadFd < 0)
            {
                HC_fileOpen(&WriteFd, filename, O_RDWR | O_CREAT);
                lseek(WriteFd, MAPLEN-1, SEEK_SET);
                write(WriteFd, "\0", 1);
                //申请映射
                Mmapfd[i].mmapfd = mmap(NULL, (size_t)MAPLEN, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
                if ( Mmapfd[i].mmapfd == MAP_FAILED)
                {
                    HC_PRINT("mmap error\n");

                    HCMsgSend(__FILE__,__LINE__,idbuf[i],"mmap error");
                }
                close(WriteFd);
                memset(& Mmapfd[i].mmapfd, 0x0, sizeof(ST_GetData));
                munmap( Mmapfd[i].mmapfd, MAPLEN);
                ReadFd = open(filename, O_RDWR);

            }
            Mmapfd[i].mmapfd = mmap(NULL, MAPLEN, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
            if ( Mmapfd[i].mmapfd == MAP_FAILED)
            {
                HC_PRINT("mmap error\n");
                HCMsgSend(__FILE__,__LINE__,idbuf[i],"mmap error");
            }
            close(ReadFd);
        }
    }
    while(1)
    {

        memset(filenamePath,0x0,sizeof (filenamePath));
        for (i=0;i<HCTaskNumCount(MAXTaskNum);i++) {


            if(strlen(mmapadresstol.MmapAdressNum[i].MmapAdress)!=0){
                memset(cmp2[i],0x0,sizeof (cmp2[i]));
                memset(&Analysisbuf[i][0],0x0,BUFSIZE);
                memset(&Picturebuf[i][0],0x0,PICBUFSIZ);
                memcpy(cmp2[i],&Mmapfd[i].mmapfd->result[0],(unsigned long)Mmapfd[i].mmapfd->json_len);
                memcpy(&Analysisbuf[i][0],&Mmapfd[i].mmapfd->result[0],(unsigned long)Mmapfd[i].mmapfd->json_len);
                if(strcmp(cmp1[i],cmp2[i])!=0&&PVFlag==ERR_COMMON_SUCCESS)
                {
                    memset(cmp1[i],0x0,sizeof (cmp1[i]));
                    strcpy(cmp1[i],cmp2[i]);
                    HC_PRINT("number=%d,%s\n",i,cmp2[i]);
                    memset(&AnalysisResult.AnalysisDataBbox[i],0x0,sizeof (ST_AnalysisDataBbox));
                    memset(&Result_JPG[i],0x0,sizeof (St_Result_JPG));

                    if(HCJsonAnalysis(&Analysisbuf[i][0])!=NULL)
                    {
                        memcpy(&AnalysisResult.AnalysisDataBbox[i].Bbox,HCJsonAnalysis(&Analysisbuf[i][0]),sizeof (ST_AnalysisData));
                    }
                    else {

                    }

                    piclength=Mmapfd[i].mmapfd->pic_length;
                    Result_JPG[i].JPG_size=piclength;
                    memcpy(&Result_JPG[i].JPG_Data,&Mmapfd[i].mmapfd->start[0],piclength);
                    if(strlen(AnalysisResult.AnalysisDataBbox[i].Bbox.info)!=0){
                        char analysistemp[30]={0};
                        FileSaveFlag[i].flag=ERR_COMMON_FAILED;
                        memcpy(analysistemp,&AnalysisResult.AnalysisDataBbox[i].Bbox.info[1],strlen(AnalysisResult.AnalysisDataBbox[i].Bbox.info)-2);
                        if(EventFlag[i].flag==0)
                        {
                            EventFlag[i].flag=1;
                            HCModbusWriteOUT(i,&AnalysisResult.AnalysisDataBbox[i].Bbox.info[1],NULL,NULL);//警告输出
                        }
                        if(EventVideoSaveFlag[i].flag==0)
                        {
#ifdef FTPOPEN

                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info,idbuf[i],FTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存
#endif

#ifdef HTTPOPEN

                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info,idbuf[i],HTTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存

#endif
#ifdef HTTPFTPOPEN

                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info,idstrbuf[i],HTTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存
                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info,idstrbuf[i],FTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存

#endif
                        }
                        if(i==0)
                        {
                            if(EventVideoSaveFlag[0].flag==0)
                            {
                                EventVideoSaveFlag[0].flag=1;
                                sprintf(Send_task_info,\
                                        "{\"rtsp_adress\":\"%s\",\"ID\":\"%s\",\"analysis_result\":\"%s\"}",\
                                        mmapadresstol.MmapAdressNum[0].rtspadress,idbuf[0],analysistemp);


                                ST_mymesg mymesg;
                                memset(&mymesg,0x0,sizeof (ST_mymesg));
                                mymesg.mtype=1;
                                strcpy(mymesg.mtext,Send_task_info);
                                if(msgsnd(idfd,(void *)&mymesg,sizeof (mymesg.mtext),0) < 0)
                                {
                                    HC_PRINT("send msg error \n");

                                }

                                memset(Send_task_info,0x0,sizeof (Send_task_info));
                            }
                        }
                        else if(i==1)
                        {
                            if(EventVideoSaveFlag[1].flag==0)
                            {
                                EventVideoSaveFlag[1].flag=1;
                                sprintf(Send_task_info,\
                                        "{\"rtsp_adress\":\"%s\",\"ID\":\"%s\",\"analysis_result\":\"%s\"}",\
                                        mmapadresstol.MmapAdressNum[1].rtspadress,idbuf[1],analysistemp);


                                ST_mymesg mymesg;
                                memset(&mymesg,0x0,sizeof (ST_mymesg));
                                mymesg.mtype=1;
                                strcpy(mymesg.mtext,Send_task_info);
                                if(msgsnd(idfd1,(void *)&mymesg,sizeof (mymesg.mtext),0) < 0)
                                {
                                    HC_PRINT("send msg error \n");
                                    //return ERR_COMMON_FAILED;
                                }

                                memset(Send_task_info,0x0,sizeof (Send_task_info));
                            }
                        }
                        else if(i==2)
                        {
                            if(EventVideoSaveFlag[2].flag==0)
                            {
                                EventVideoSaveFlag[2].flag=1;
                                sprintf(Send_task_info,\
                                        "{\"rtsp_adress\":\"%s\",\"ID\":\"%s\",\"analysis_result\":\"%s\"}",\
                                        mmapadresstol.MmapAdressNum[2].rtspadress,idbuf[2],analysistemp);

                                //HC_PRINT("json: %s\n", Send_task_info);
                                ST_mymesg mymesg;
                                memset(&mymesg,0x0,sizeof (ST_mymesg));
                                mymesg.mtype=1;
                                strcpy(mymesg.mtext,Send_task_info);
                                if(msgsnd(idfd2,(void *)&mymesg,sizeof (mymesg.mtext),0) < 0)
                                {
                                    HC_PRINT("send msg error \n");
                                    //return ERR_COMMON_FAILED;
                                }

                                memset(Send_task_info,0x0,sizeof (Send_task_info));
                            }
                        }



                        // HCFileTimeSave(PicturePath,idstrbuf[i],10,filenamePath);//保存本地文件


                    }

#ifdef DEBUGKEY
                    if(strlen(AnalysisResult.AnalysisDataBbox[i].Bbox.info_door)!=0){


                        FileSaveFlag[i].flag=ERR_COMMON_FAILED;
                        char analysistemp[30]={0};
                        memcpy(analysistemp,&AnalysisResult.AnalysisDataBbox[i].Bbox.info_door[1],strlen(AnalysisResult.AnalysisDataBbox[i].Bbox.info_door)-2);
                        if(EventFlag[i].flag==0)
                        {
                            EventFlag[i].flag=1;
                            HCModbusWriteOUT(i,&AnalysisResult.AnalysisDataBbox[i].Bbox.info[1],NULL,NULL);//警告输出

                        }
                        if(EventVideoSaveFlag[i].flag==0)
                        {
#ifdef FTPOPEN

                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info_door,idbuf[i],FTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存
#endif

#ifdef HTTPOPEN

                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info_door,idbuf[i],HTTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存

#endif
#ifdef HTTPFTPOPEN

                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info,idstrbuf[i],HTTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存
                            HCUploadDataSave(i,Result_JPG[i],AnalysisResult.AnalysisDataBbox[i].Bbox.info,idstrbuf[i],FTPUploadPath,AnalysisResult.AnalysisDataBbox[i].Bbox.xmin,AnalysisResult.AnalysisDataBbox[i].Bbox.ymin,AnalysisResult.AnalysisDataBbox[i].Bbox.xmax,AnalysisResult.AnalysisDataBbox[i].Bbox.ymax); //本地保存

#endif
                        }
                        if(i==0)
                        {
                            if(EventVideoSaveFlag[0].flag==0)
                            {
                                EventVideoSaveFlag[0].flag=1;
                                sprintf(Send_task_info,\
                                        "{\"rtsp_adress\":\"%s\",\"ID\":\"%s\",\"analysis_result\":\"%s\"}",\
                                        mmapadresstol.MmapAdressNum[0].rtspadress,idbuf[0],analysistemp);

                                HC_PRINT("json: %s\n", Send_task_info);

                                ST_mymesg mymesg;
                                memset(&mymesg,0x0,sizeof (ST_mymesg));
                                mymesg.mtype=1;
                                strcpy(mymesg.mtext,Send_task_info);
                                if(msgsnd(idfd,(void *)&mymesg,sizeof (mymesg.mtext),0) < 0)
                                {
                                    HC_PRINT("send msg error \n");
                                    //return ERR_COMMON_FAILED;
                                }
                                memset(Send_task_info,0x0,sizeof (Send_task_info));
                            }
                        }
                        else if(i==1)
                        {
                            if(EventVideoSaveFlag[1].flag==0)
                            {
                                EventVideoSaveFlag[1].flag=1;
                                sprintf(Send_task_info,\
                                        "{\"rtsp_adress\":\"%s\",\"ID\":\"%s\",\"analysis_result\":\"%s\"}",\
                                        mmapadresstol.MmapAdressNum[1].rtspadress,idbuf[1],analysistemp);

                                HC_PRINT("json: %s\n", Send_task_info);

                                ST_mymesg mymesg;
                                memset(&mymesg,0x0,sizeof (ST_mymesg));
                                mymesg.mtype=1;
                                strcpy(mymesg.mtext,Send_task_info);
                                if(msgsnd(idfd1,(void *)&mymesg,sizeof (mymesg.mtext),0) < 0)
                                {
                                    HC_PRINT("send msg error \n");
                                    //return ERR_COMMON_FAILED;
                                }
                                memset(Send_task_info,0x0,sizeof (Send_task_info));
                            }
                        }
                        else if(i==2)
                        {
                            if(EventVideoSaveFlag[2].flag==0)
                            {
                                EventVideoSaveFlag[2].flag=1;
                                sprintf(Send_task_info,\
                                        "{\"rtsp_adress\":\"%s\",\"ID\":\"%s\",\"analysis_result\":\"%s\"}",\
                                        mmapadresstol.MmapAdressNum[2].rtspadress,idbuf[2],analysistemp);

                                HC_PRINT("json: %s\n", Send_task_info);

                                ST_mymesg mymesg;
                                memset(&mymesg,0x0,sizeof (ST_mymesg));
                                mymesg.mtype=1;
                                strcpy(mymesg.mtext,Send_task_info);
                                if(msgsnd(idfd2,(void *)&mymesg,sizeof (mymesg.mtext),0) < 0)
                                {
                                    HC_PRINT("send msg error \n");
                                    //return ERR_COMMON_FAILED;
                                }
                                memset(Send_task_info,0x0,sizeof (Send_task_info));
                            }
                        }


                        //  HCFileTimeSave(PicturePath,idstrbuf[i],10,filenamePath);//保存本地文件


                    }
#endif
                    FileSaveFlag[i].flag=ERR_COMMON_SUCCESS;
                }

            }

        }

        usleep(300000);

    }
    return ERR_COMMON_SUCCESS;
}


void *HCSoundOutPut_0()
{
    while(1)
    {
        if(EventFlag[0].flag==1)
        {
            sleep(4);
            EventFlag[0].flag=0;
        }
        usleep(200000);
    }
    return ERR_COMMON_SUCCESS;
}
void *HCSoundOutPut_1()
{
    while(1)
    {
        if(EventFlag[1].flag==1)
        {
            sleep(4);
            EventFlag[1].flag=0;
        }
        usleep(200000);
    }
    return ERR_COMMON_SUCCESS;
}
void *HCSoundOutPut_2()
{
    while(1)
    {
        if(EventFlag[2].flag==1)
        {
            sleep(10);
            EventFlag[2].flag=0;
        }
        usleep(200000);
    }
    return ERR_COMMON_SUCCESS;
}



//// 定时器1
//int HCTimerStart_1(int second, struct itimerval new_value,struct itimerval old_value)
//{
//    signal(SIGALRM, signal_timer_handler_1);
//    //    new_value.it_value.tv_sec = second; //秒
//    //    new_value.it_value.tv_usec = 1;//微妙 不能为零
//    setitimer(ITIMER_REAL, &new_value, &old_value);
//    printf("sucess!");
//    return ERR_COMMON_SUCCESS;
//}
//// 定时器1回调
//void signal_timer_handler_1(int signo)
//{
//    switch (signo){
//    case SIGALRM:
//        printf("timer1 count!");
//        break;
//    }
//}
