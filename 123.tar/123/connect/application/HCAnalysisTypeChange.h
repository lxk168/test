﻿#ifndef HCANALYSISTYPECHANGE_H
#define HCANALYSISTYPECHANGE_H
#include "common.h"

typedef  struct
{
    int task_id;
    char *analysis_type;

}ST_FrameworkArgs;

extern int HCZmqSendTask(ST_FrameworkArgs* cmd);
#endif



