﻿
#ifndef HCMQTTSUBPROCESS_H
#define HCMQTTSUBPROCESS_H
#include "common.h"
#define MQTTLENG 0x10000 //最大映射大小
#pragma pack(1)
typedef  struct{
    long time;
    int finishflag;
    char topic[1024];
    char mqttdata[1024*50];
}ST_MqttMmapInfo;
#pragma pack()
extern ST_MqttMmapInfo mqttMmapInfo;
extern void *HC_MQTTSubProcess_Thread(void);
extern  int HCMQttMsgSend(char *pubtopic,char *MqttSendBuf);
#endif



