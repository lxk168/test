﻿
#ifndef HCDATAPROCESS_H
#define HCDATAPROCESS_H
#include "common.h"
#include"stddef.h"
#include "public/HCFileOperation.h"
#include "public/HCJson.h"
#include "application/HCDataRecord.h"
#include "public/HCHttp.h"
#include "public/HCModbus.h"
#include "HCBusinessInterface.h"
#include "public/HCPublicStruct.h"
#define MAPLEN 0x80000   //最大映射大小
#define PICBUFSIZ  409600
#define BUFSIZE 4096
#define MAXTaskNum   3    //同时跑的最大任务数
#define OPEN 0      //开门标志
#define CLOSE 1     //关门标志
#pragma pack (1)
// 视觉分析的结构体

typedef struct
{
    int json_len;
    int pic_length;      //图片数据长度
    char result[BUFSIZE];    //json数据字符串
    char start[PICBUFSIZ];     //图片数据
}ST_GetData;
typedef struct
{
    ST_GetData * mmapfd;
}ST_Mmapfd;

typedef struct
{
    int x;
    int y;
    int w;
    int h;
}SC_RECT;

#pragma pack()


extern ST_Mmapfd Mmapfd[MAXTaskNum];
//extern ST_AnalysisDataBbox *  HCJsonAnalysis(char *Analysisbuf);
extern void *HC_DataProcess_Thread(void);
extern void *HCSoundOutPut_0();
extern void *HCSoundOutPut_1();
extern void *HCSoundOutPut_2();
#endif



