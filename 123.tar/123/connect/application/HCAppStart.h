﻿#ifndef HCAPPSTART_H
#define HCAPPSTART_H
#include "common.h"
#include "public/HCFileOperation.h"
#include "public/HCPulicAPI.h"
#include"public/HCSocket.h"
#include "HCDataProcess.h"
#include "HCTcpNetProcess.h"
#include "HCMqttSubProcess.h"
#include "public/HCSqlite.h"
#include "public/HCPublicStruct.h"

#include "HCFTPUploadProcess.h"
#include "HCHTTPUploadProcess.h"
#include "HCPersonProcess.h"
//#define FTPOPEN //ftp 和http 切换开关
//#define HTTPFTPOPEN
#define HTTPOPEN
//#define NOTDRAW  // 无画宽上传开关

extern void HCApppStart_Init(void);
extern void HCStartTask(void);
extern int HCAnalysisStart(void);
extern int HCTaskStart(int id);
extern int HCTaskStop(int id);
extern void HCDeleteAnalysis(void );
extern void *HC_ProcessMonitor_Thread(void);
extern int HCFTPDownLoad(void);
extern int sehngjiceshi(void);
extern int HCRemoveAdress(char *address);
extern int acquire_recive();
extern char*strrpc(char*str,char*oldstr,char*newstr);
extern int HCTaskNumCount(int TaskNum);
#endif
