﻿#include "application/HCEventVideoSaveProcess.h"

void *HCEventVideoSaveProcess_Thread(void)
{
    char cjsonbuf[512]={0};
    memset(cjsonbuf,0x0,sizeof (cjsonbuf));
    int id = 0;
    ST_mymesg mymesg;
    memset(&mymesg,0x0,sizeof (ST_mymesg));
    key_t key = ftok("/example",64);
    id = msgget(key,0666|IPC_CREAT);
    if(id == -1)
    {
        HC_PRINT("open msg error \n");
        return 0;
    }

    while (1) {
        memset(mymesg.mtext,0x0,sizeof (mymesg.mtext));
        if(msgrcv(id,(void *)&mymesg,sizeof (mymesg.mtext),0,0) < 0)
        {
            HC_PRINT("receive msg error \n");
            continue;
        }
        HC_PRINT("receive msg  sucessful \n");

        if( strlen(mymesg.mtext)!=0)
        {
           if( EventVideoSaveFlag[0].flag==1)
           {
                HCEventVideoCJsonAnalysis(idbuf[0],mymesg.mtext);
                EventVideoSaveFlag[0].flag=0;
           }
        }
        else
        {
            continue;
        }
        memset(mymesg.mtext,0x0,sizeof (mymesg.mtext));
        usleep(300000);
    }

}
void *HCEventVideoSaveProcess_Thread_1(void)
{
    char cjsonbuf[512]={0};
    memset(cjsonbuf,0x0,sizeof (cjsonbuf));
    int id = 0;
    ST_mymesg mymesg;
    memset(&mymesg,0x0,sizeof (ST_mymesg));
    key_t key = ftok("/example1",65);
    id = msgget(key,0666|IPC_CREAT);
    if(id == -1)
    {
        HC_PRINT("open msg error \n");
        return 0;
    }
    while (1) {
 memset(mymesg.mtext,0x0,sizeof (mymesg.mtext));
        if(msgrcv(id,(void *)&mymesg,sizeof (mymesg.mtext),0,0) < 0)
        {
            HC_PRINT("receive msg error \n");
            continue;
        }
        HC_PRINT("receive msg  sucessful \n");

        if( strlen(mymesg.mtext)!=0)
        {
            if( EventVideoSaveFlag[1].flag==1)
            {
                HCEventVideoCJsonAnalysis(idbuf[0],mymesg.mtext);
                EventVideoSaveFlag[1].flag=0;
            }
        }
        else
        {
            continue;
        }
       memset(mymesg.mtext,0x0,sizeof (mymesg.mtext));
        usleep(300000);
    }

}
void *HCEventVideoSaveProcess_Thread_2(void)
{
    char cjsonbuf[512]={0};
    memset(cjsonbuf,0x0,sizeof (cjsonbuf));
    int id = 0;
    ST_mymesg mymesg;
    memset(&mymesg,0x0,sizeof (ST_mymesg));
    key_t key = ftok("/example2",66);
    id = msgget(key,0666|IPC_CREAT);
    if(id == -1)
    {
        HC_PRINT("open msg error \n");
        return 0;
    }
    while (1) {
 memset(mymesg.mtext,0x0,sizeof (mymesg.mtext));
        if(msgrcv(id,(void *)&mymesg,sizeof (mymesg.mtext),0,0) < 0)
        {
            HC_PRINT("receive msg error \n");
            continue;
        }
        HC_PRINT("receive msg  sucessful \n");

        if( strlen(mymesg.mtext)!=0)
        {
            if( EventVideoSaveFlag[2].flag==1)
            {
                HCEventVideoCJsonAnalysis(idbuf[0],mymesg.mtext);
                EventVideoSaveFlag[2].flag=0;
           }
        }
        else
        {
            continue;
        }
        memset(mymesg.mtext,0x0,sizeof (mymesg.mtext));
        usleep(300000);
    }

}
int HCEventVideoCJsonAnalysis(char *id,char *cjsonbuf)
{
    char rtpsadress[256]={0};
    char analysisResult[100]={0};
    char IDbuf[512]={0};
    char rtpsadressbuf[256]={0};
    char analysisResultbuf[100]={0};
    char IDbufbuf[512]={0};

    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(cjsonbuf);
    //判断是否打包成功
    if(cjson == NULL){
        HC_PRINT("cjson error…\n");
        HCMsgSend(__FILE__,__LINE__,id,"cjson error…");
        return ERR_COMMON_FAILED;
    }
    char *json_data = NULL;
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"rtsp_adress"));
    if(json_data!=NULL)
    {
        sprintf(rtpsadress,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"ID"));
    if(json_data!=NULL)
    {
        sprintf(IDbuf,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"analysis_result"));
    if(json_data!=NULL)
    {
        sprintf(analysisResult,"%s",json_data);

    }
    free(json_data);
    //这里只需要释放cjson即可，因为其它的都指向它
    cJSON_Delete(cjson);
    memcpy(rtpsadressbuf,&rtpsadress[1],strlen(rtpsadress)-2);
    memcpy(IDbufbuf,&IDbuf[1],strlen(IDbuf)-2);
    memcpy(analysisResultbuf,&analysisResult[1],strlen(analysisResult)-2);
    if(HCEventVideoSave(rtpsadressbuf,VideoPath,IDbufbuf,analysisResultbuf,5)==ERR_COMMON_FAILED)
    {
        HCMsgSend(__FILE__,__LINE__,id,"视频保存失败");
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}
