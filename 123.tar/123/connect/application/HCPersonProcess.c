﻿#include "HCPersonProcess.h"

static int doorcloseflag=0;
void *HC_PersonEvent_Thread(void)
{
      char filenamePath[512]={0};
    int beforetime=0,nowtime=0,othertime=0;
    float uc=0;
    while (1) {


//        if(DoorEvent.doorflag==CLOSE)
//        {
//            if(doorcloseflag==0)
//            {
//                beforetime=HC_LocalTimeGet();
//                doorcloseflag=1;
//            }
//            nowtime=HC_LocalTimeGet();
//            othertime=nowtime-beforetime;
//        }
//        else {
//            othertime=0;
//        }
//        if(othertime>=100)
//        {
//            uc=(float)PersonEvent.personcount/(float)PersonEvent.allcount;
//            if(uc>=(float)0.3)
//            {

//                if(HCSoundFlag==0)
//                {
//                    HCSoundFlag=1;
//                    HCModbusWriteOUT(NULL,"person",NULL);//警告输出
//                }
//                memcpy(&CjsonUpload,HCjsonUploadData("person"),sizeof (ST_CjsonUpload));
//                // HC_MqttDataWrite( HCjsonUploadGenerate(CjsonUpload),1);
//                HCFileTimeSave(PicturePath,"person",10,filenamePath);//保存本地文件
//                HCUploadDataSave(Result_JPG,"person","person",PicturePath); //本地保存
//#ifdef FTPOPEN
//                HCUploadDataSave(Result_JPG,"person","person",FTPUploadPath); //FTP待上传保存
//#else
//                HCUploadDataSave(Result_JPG,"person","123",HTTPUploadPath);//HTTP待上传保存
//#endif
//                HCJournalDataUpdate("person","person",10,10); //日志保存
//                HCWarningSoundOutput(NULL,"person",NULL);//警告输出

//            }
//        doorcloseflag=0;
//        othertime=0;
//        memset(&PersonEvent,0x0,sizeof (ST_PersonEvent));
//    }


    usleep(500000);
}
}


