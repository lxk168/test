﻿
#ifndef HCBUSINESSCJSON_H
#define HCBUSINESSCJSON_H
#include "common.h"

#include "public/HCPublicStruct.h"
#include "application/HCMqttSubProcess.h"

#define MaxButtonNum   (200)   //最大按钮个数
typedef struct
{
    int thick; //动作次数
}ST_FloorNum;
typedef struct
{
    int allNum; //总的有效按钮
    ST_FloorNum FloorNum[MaxButtonNum];//按钮号
}ST_ButtonEvent;
//轿内视觉
typedef struct
{
    char bucket[512];
    char path[512];
}ST_BasePropertys;
typedef struct
{
    ST_BasePropertys video;
    ST_BasePropertys image;
}ST_VisionData;
typedef struct
{
    char HCEbikeTopic_Pub[512];//电瓶车
    char HCSmokeTopic_Pub[512]; //烟雾
    char HCFallTopic_Pub[512];//摔倒
    char HCPullTopic_Pub[512];//扒门
    char HCTrappedTopic_Pub[512];//困人
    char HCPersonTopic_Pub[512];//人员技术
}ST_Event_Pub_Topic;

typedef struct
{
    ST_Event_Pub_Topic Event_Pub_Topic[3];
}ST_Topic_InforMation;

extern char * HCFrontDoorHallUpCallButtonActionsNumberEvent(ST_ButtonEvent ButtonEvent,int ack);
extern char * HCJsonPublic(char*method,char*value,int ack);
extern char* HCVisionElectricVehicle(ST_VisionData  visionElectricVehicle, int ack);
extern char* HCVisionPryingDoor(ST_VisionData  visionPryingDoor, int ack);
extern char* HCVisionSmoke(ST_VisionData  visionSmoke, int ack);
extern char* HCVisionTrapped(ST_VisionData  visionTrapped, int ack);
extern char* HCVisionFall(ST_VisionData  visionFall, int ack);
extern char* HCVisionPerson(int visionPerson, int ack);
extern int HCVisionElectricVehicleUpload(char *analysis,char *picture,char*video,char*bucket);
extern void HCSubTopicInit(void);
extern ST_Topic_InforMation Topic_InforMation;
#endif



