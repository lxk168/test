﻿#include "application/HCAnalysisTypeChange.h"
#include "zmq/czmq.h"

int HCZmqSendTask(ST_FrameworkArgs* cmd)
{//修改一个任务的分析类型
    char Send_task_info[512];

    /*task_id---正在运行的任务id
    *analysis_type--修改后需要运行的任务类型
    *例如：原来运行的类型为2176 task_id=1 需要修改成2022,则json如下
    *{"cmd":"reviseTask","task_id":1,"analysis_type":"2022"}
    *注意事项：最初未启动的任务不可再修改后启动
    *如：原本启动任务为2024 不可修改为2011 原因是2024中不包含 2010与2001这两个算法*/
    sprintf(Send_task_info,\
    "{\"cmd\":\"reviseTask\",\"task_id\":%d,\"analysis_type\":\"%s\"}",\
    cmd->task_id,cmd->analysis_type);

    printf("json: %s\n", Send_task_info);
    zsock_t* push = zsock_new_push("@tcp://127.0.0.1:5555");
    zstr_send(push, Send_task_info);
    zsock_destroy(&push);
    return 0;
}
