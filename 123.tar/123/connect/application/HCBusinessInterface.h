﻿
#ifndef HCBUSINESSINTERFACE_H
#define HCBUSINESSINTERFACE_H
#include "common.h"
#include "public/HCPublicStruct.h"
#include "public/HCProfileUtil.h"
#pragma pack (1)
typedef struct
{
   char UserNamebuf[1024];
   char ThingCategoryKeybuf[1024];
   char DeviceName[1024];
}ST_MqttUsrData;
#pragma pack ()
extern int eventflag;//事件标志位
extern int HCSoundFlag;
extern ST_MqttUsrData MqttUsrData;
extern ST_AnalysisDataBbox *  HCJsonAnalysis(char *Analysisbuf);
extern void HCEbikeWarinPut(void);
extern void HCSmokeWarinPut(void);
extern void HCPullWarinPut(void);
extern void HCFallWarinPut(void);
extern void HCFallPersonPut(void);
extern void HCWarningSoundOutput(char *infor,char *personinfo,char *door);
extern int HCGpioOutput_1(int w_level);
extern int HCGpioOutput_2(int w_level);
extern void HCJpgFileName(int tasknum,char*tempbuf);
extern void HCModbusWriteOUT(int taskid,char *infor,char *personinfo,char *door);
extern int HCUploadDataSave(int tasknum,St_Result_JPG  result_JPG,char *result,const char* id,const char *localpath,int xmin,int ymin,int xmax,int ymax);
extern int HCReNameFile(char *source ,char *dist);
extern int HCJournalDataUpdate(char *Analysisresult,char *ID,int frequency,int postion);
extern char * HCPictureDataSave(int i,St_Result_JPG  result_JPG,char *result,const char* id,const char *localpath,int xmin,int ymin,int xmax,int ymax);
extern int HCEventVideoSave(char *rtspadress,const char*path,char*ID,char *Analysisresult,int second);
extern ST_MqttUsrData HCReadUserData();
extern ST_EventCjsonInfo* HC_EventCjsonData(char*bucket,char*imagepath,char*videopath);
#endif



