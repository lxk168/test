﻿#include "application/HCModbusProcess.h"
char AnalysisSendsingle[2048]={0};
int Analysiscount=0;

void *HCModbusProcess_Thread(void)
{

    while(1)
    {
        HCModbusOutput("/dev/ttyS5",0x3600,0x00);
        sleep(15);
    }
}
void *HCModbusSoundProcess_Thread(void)
{
    while(1)
    {

        usleep(200000);
    }
}
