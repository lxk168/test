﻿#ifndef HCHTTPUPLOADPROCESS_H
#define HCHTTPUPLOADPROCESS_H
#include "common.h"
#include"public/HCHttp.h"
#include"public/HCPulicAPI.h"
#include"public/HCPublicStruct.h"
#include "public/HCSqlite.h"

extern void *HCHTTPUploadProcess_Thread(void);
extern char picturepathbuf[512];
#endif
