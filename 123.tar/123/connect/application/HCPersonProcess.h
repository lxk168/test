﻿
#ifndef HCPERSONPROCESS_H
#define HCPERSONPROCESS_H
#include "common.h"
#include "HCDataRecord.h"
#include "HCBusinessInterface.h"
#include "public/HCPulicAPI.h"
extern void *HC_PersonEvent_Thread(void);

#endif



