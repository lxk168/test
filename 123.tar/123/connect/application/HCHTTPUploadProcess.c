﻿#include"HCHTTPUploadProcess.h"
#include "hcopencv.h"
#include"application/HCBusinessCJson.h"
#include"hmacsha256/HMACSHA.h"
static int HCLocalHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath);
static int HCSqliteHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath);
static int HCVIDEOHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath);
static  int HCNotDrawHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath);
static int timecount=0;

char picturepathbuf[512]={0};
void *HCHTTPUploadProcess_Thread(void)
{
    ST_HTTPInfo HTTPInfo;
    char RemoteUrlPAth[256]={0};
    strcat(RemoteUrlPAth,"https://elevtest.inovance.com:6004/iotfs/hardware/upload");
    HTTPInfo.port=6004;
    HTTPInfo.RemoteUrl=(char *)RemoteUrlPAth;
    char UserNamebuf[1024]={0};
    char Passwordbuf[1024]={0};
    char databuf[1024]={0};
    char clientIDbuf[1024]={0};
    char keybuf[1024]={0};
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
     HCGetProfileString(file_path, app_name, (char*)"MqttClientID", clientIDbuf);
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    HCGetProfileString(file_path, app_name, (char*)"MqttPassWord", keybuf);
    char *ptr=NULL;
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};

    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    strcat(databuf,"clientid");
    strcat(databuf,clientIDbuf);
    strcat(databuf,"DeviceName");
    strcat(databuf,DeviceName);
    strcat(databuf,"ThingCategoryKey");
    strcat(databuf,ThingCategoryKeybuf);
    strcat(Passwordbuf,hmac_sha256_out(databuf,keybuf));
    HTTPInfo.Usrname=UserNamebuf;
    HTTPInfo.PassWord=Passwordbuf;

    while(1)
    {
        for (int i=0;i<HCTaskNumCount(MAXTaskNum);i++) {
            if(FileSaveFlag[i].flag!=ERR_COMMON_FAILED)
            {
#ifdef NOTDRAW
                HCNotDrawHTTPUpload(HTTPInfo,idbuf[i],HTTPUploadPath);
#endif
                HCLocalHTTPUpload(HTTPInfo,idbuf[i],HTTPUploadPath);
                if(EventVideoSaveFlag[i].flag==0)
                {
                    HCVIDEOHTTPUpload(HTTPInfo,idbuf[i],VideoPath);
                }
            }

        }


        //        timecount++;
        //        if(timecount>3600)
        //        {
        //            for (int i=0;i<HCTaskNumCount(MAXTaskNum);i++) {
        //                if(strlen(idbuf[i])!=0){
        //                    HCSqliteHTTPUpload(HTTPInfo,idbuf[i],JPURNAL_PATH);
        //                    usleep(500000);
        //                    // HCSqliteHTTPUpload(HTTPInfo,idstrbuf[i],SMART_PATH);
        //                }
        //            }

        //            timecount=0;
        //        }
        usleep(500000);
    }
}

//HTTPS图片数据上传
static int HCLocalHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[512] = {0};
    char textFileName[512]={0};
    char buf[512]={0};
    int xmin=0,ymin=0,length=0,wideth=0;
    char fileName[100]={0};
    int PathLength=0,fileLength=0;;
    int  ReadFd=0;
    int  WriteFd=0;
    char current[20]={0};
    char eventname[20]={0};
    char eventnametemp[20]={0};
    char *ret=NULL;
    char pathname[256]={0};
    char pathload[100]={0};
    strcat(pathload,pDataRootPath);

    strcat(pathload,ID);
    strcat(pathload,"/");
    HC_ASSERT(pathload);
    PathLength=(int)strlen(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ERR_COMMON_FAILED;
        }
    }
    res = HC_findFile(pathload, szFileName, ".jpg");
    if (ERR_COMMON_SUCCESS == res)
    {


        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        HTTPInfo.filename=(char *)fileName;
        HTTPInfo.UploadPath=(char *)szFileName;

        sprintf(current, "%s", "event/picture");
        ret=strchr(HTTPInfo.filename,'_');
        sprintf(eventname,"%s",ret);
        ret=strrchr(eventname,'.');
        memcpy(eventnametemp,&eventname[1],strlen(eventname)-1-strlen(ret));
        strcat(pathname,"/");
        strcat(pathname,ID);
        strcat(pathname,"/");
        strcat(pathname,current);
        strcat(pathname,"/");
        strcat(pathname,eventnametemp);
        strcat(pathname,"/");
        strcat(pathname,HTTPInfo.filename);
        memcpy(textFileName,szFileName,strlen(szFileName)-strlen(".jpg"));
        strcat(textFileName,".txt");
        if(HC_fileRead( textFileName, buf , O_RDONLY | O_CREAT | O_APPEND==ERR_COMMON_SUCCESS)){

            //第一步打包JSON字符串
            cJSON* cjson = cJSON_Parse(buf);
            //判断是否打包成功
            if(cjson == NULL){
                HC_PRINT("cjson error…\n");
                return ERR_COMMON_FAILED;
            }
            char *json_data = NULL;
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"xmin"));
            if(json_data!=NULL)
            {
                xmin=atoi(json_data);
            }
            free(json_data);
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"ymin"));
            if(json_data!=NULL)
            {
                ymin=atoi(json_data);
            }
            free(json_data);
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"length"));
            if(json_data!=NULL)
            {
                length=atoi(json_data);
            }
            free(json_data);
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"wideth"));
            if(json_data!=NULL)
            {
                wideth=atoi(json_data);
            }
            free(json_data);
            //这里只需要释放cjson即可，因为其它的都指向它
            cJSON_Delete(cjson);
            char openname[100]={0};
            if(strcmp(eventname,"ebike")==0)
            {
                strcat(openname,"electromobile ");
            }else if (strcmp(eventname,"smoke")==0) {
                strcat(openname,"smoke");
            }
            if(HCOpencvDraw(szFileName,szFileName,openname,xmin,ymin,length,wideth)==ERR_COMMON_SUCCESS)
            {
                char path[500]={0};
                char localfimename[100]={0};
                strcat(path,PicturePath);
                substr(szFileName,(int)strlen(pDataRootPath),(int)strlen(szFileName)-(int)strlen(pDataRootPath),localfimename);


                strcat(path,localfimename);

#ifdef LOACLPICTURESAVE
                HCFileCopy(szFileName,path);
#endif
                usleep(100000);


                if(HCHttpUpLoad(HTTPInfo,pathname,"key")==ERR_COMMON_FAILED){
                    HC_RemoveFile(szFileName);
                    HC_RemoveFile(textFileName);
                    close(ReadFd);
                    close(WriteFd);
                    HC_PRINT("HTTP图片上传失败\n\r");

                    HCMsgSend(__FILE__,__LINE__,ID,"HTTP图片上传失败");
                    return ERR_COMMON_FAILED;
                }
                else {
                    HC_RemoveFile(szFileName);
                    HC_RemoveFile(textFileName);
                }
            }
            else
            {
                HC_RemoveFile(szFileName);
                HC_RemoveFile(textFileName);
                close(ReadFd);
                close(WriteFd);
                HC_PRINT("OPENCV画图失败\n\r");
                HCMsgSend(__FILE__,__LINE__,ID,"OPENCV画图失败");
                return ERR_COMMON_FAILED;
            }


        }
        else
        {
            HC_RemoveFile(szFileName);
            HC_RemoveFile(textFileName);
            close(ReadFd);
            close(WriteFd);
            HCMsgSend(__FILE__,__LINE__,ID,"OPENCV 描述文件读取失败");
            return ERR_COMMON_FAILED;
        }

    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    memset(picturepathbuf,0x0,sizeof (picturepathbuf));
    strcat(picturepathbuf,pathname);
    HCVisionElectricVehicleUpload(eventnametemp,picturepathbuf,NULL,"key");
    return ERR_COMMON_SUCCESS;
}
//HTTPS图片数据上传
static int HCNotDrawHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[512] = {0};
    char fileName[100]={0};
    int PathLength=0,fileLength=0;;
    int  ReadFd=0;
    int  WriteFd=0;
    char current[20]={0};
    char eventname[20]={0};
    char eventnametemp[20]={0};
    char *ret=NULL;
    char pathname[256]={0};
    char pathload[100]={0};
    strcat(pathload,pDataRootPath);

    strcat(pathload,ID);
    strcat(pathload,"/");

    PathLength=(int)strlen(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ERR_COMMON_FAILED;
        }
    }
    res = HC_findFile(pathload, szFileName, ".jpg");
    if (ERR_COMMON_SUCCESS == res)
    {
        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        HTTPInfo.filename=(char *)fileName;
        HTTPInfo.UploadPath=(char *)szFileName;
        sprintf(current, "%s", "event/test");
        ret=strchr(HTTPInfo.filename,'_');
        sprintf(eventname,"%s",ret);
        ret=strrchr(eventname,'.');
        memcpy(eventnametemp,&eventname[1],strlen(eventname)-1-strlen(ret));
        strcat(pathname,"/");
        strcat(pathname,ID);
        strcat(pathname,"/");
        strcat(pathname,current);
        strcat(pathname,"/");
        strcat(pathname,eventnametemp);
        strcat(pathname,"/");
        strcat(pathname,HTTPInfo.filename);


        if(HCHttpUpLoad(HTTPInfo,pathname,"key")==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            HC_PRINT("HTTP图片上传失败\n\r");
            HCMsgSend(__FILE__,__LINE__,ID,"HTTP图片上传失败");
            return ERR_COMMON_FAILED;
        }

    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}
//HTTPS视频数据上传
static int HCVIDEOHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[128] = {0};
    char fileName[100]={0};
    int PathLength=0,fileLength=0;;
    int  ReadFd=0;
    int  WriteFd=0;
    char current[20]={0};
    char eventname[20]={0};
    char eventnametemp[20]={0};
    char *ret=NULL;
    char pathname[256]={0};
    char pathload[100]={0};
    strcat(pathload,pDataRootPath);

    strcat(pathload,ID);
    strcat(pathload,"/");
    HC_ASSERT(pathload);
    PathLength=(int)strlen(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ERR_COMMON_FAILED;
        }
    }
    res = HC_findFile(pathload, szFileName, ".mp4");
    if (ERR_COMMON_SUCCESS == res)
    {

        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        HTTPInfo.filename=(char *)fileName;
        HTTPInfo.UploadPath=(char *)szFileName;

        sprintf(current, "%s", "event/video");
        ret=strchr(HTTPInfo.filename,'_');
        sprintf(eventname,"%s",ret);
        ret=strrchr(eventname,'.');
        memcpy(eventnametemp,&eventname[1],strlen(eventname)-1-strlen(ret));
        strcat(pathname,"/");
        strcat(pathname,ID);
        strcat(pathname,"/");
        strcat(pathname,current);
        strcat(pathname,"/");
        strcat(pathname,eventnametemp);
        strcat(pathname,"/");
        strcat(pathname,HTTPInfo.filename);

        if(HCHttpUpLoad(HTTPInfo,pathname,"key")==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            HC_PRINT("HTTP视频上传失败\n\r");
            HCMsgSend(__FILE__,__LINE__,ID,"HTTP视频上传失败");
            return ERR_COMMON_FAILED;
        }
        else {
            HC_RemoveFile(szFileName);
        }
    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    // HCVisionElectricVehicleUpload(eventnametemp,picturepathbuf,pathname,"key");
    return ERR_COMMON_SUCCESS;
}


//HTTPS数据库上传
static int HCSqliteHTTPUpload(ST_HTTPInfo HTTPInfo,const char* ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[128] = {0};

    char fileName[100]={0};
    int PathLength=0,fileLength=0;;
    int  ReadFd=0;
    int  WriteFd=0;
    char Machineidentification[30]={0};
    strcat(Machineidentification,"/");
    strcat(Machineidentification,ID);
    strcat(Machineidentification,"/");
    strcat(Machineidentification,"sqlite");
    strcat(Machineidentification,"/");
    char pathload[100]={0};
    strcat(pathload,pDataRootPath);
    strcat(pathload,"/");
    strcat(pathload,ID);
    strcat(pathload,"/");
    PathLength=(int)strlen(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ERR_COMMON_FAILED;
        }
    }
    res = HC_findFile(pathload, szFileName, ".db");
    if (ERR_COMMON_SUCCESS == res)
    {

        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        HTTPInfo.filename=(char *)fileName;
        HTTPInfo.UploadPath=(char *)szFileName;
        strcat(Machineidentification, HTTPInfo.filename);
        if(HCHttpUpLoad(HTTPInfo,Machineidentification,"key")==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            HCMsgSend(__FILE__,__LINE__,ID,"视觉数据库上传失败");
            return ERR_COMMON_FAILED;
        }
        //        else {
        //            HC_RemoveFile(szFileName);
        //        }
    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}
