
#include "HCMqttSubProcess.h"

void *HC_MQTTSubProcess_Thread(void )

{
    ST_MqttMmapInfo *mmapfd;
    int ReadFd= 0,WriteFd=0;
    long cmp1=0;
    long cmp2=0;
    char *pcFileName="/userdata/usr/local/connect_mqtt_client.mmap";
    HCRemoveAdress("connect_mqtt_client.mmap");
    ReadFd = open(pcFileName, O_RDWR);
    if (ReadFd < 0)
    {
        HC_fileOpen(&WriteFd, pcFileName, O_RDWR | O_CREAT);
        lseek(WriteFd, MQTTLENG-1, SEEK_SET);
        write(WriteFd, "\0", 1);
        //申请映射
        mmapfd = mmap(NULL, (size_t)MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
        if ( mmapfd == MAP_FAILED)
        {
            HC_PRINT("mmap error\n");

            HCMsgSend(__FILE__,__LINE__,"all","mmap error");
            close(ReadFd);
            close(WriteFd);
        }
        close(ReadFd);
        close(WriteFd);

        munmap( mmapfd, MQTTLENG);
        ReadFd = open(pcFileName, O_RDWR);

    }
    mmapfd = mmap(NULL, MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
    if ( mmapfd == MAP_FAILED)
    {
        HC_PRINT("mmap error\n");
        HCMsgSend(__FILE__,__LINE__,"all","mmap error");
        close(ReadFd);
        close(WriteFd);
    }
    close(ReadFd);
    close(WriteFd);
    cmp2=mmapfd->time;
    cmp1=cmp2;

    while (1){
        cmp2=mmapfd->time;

        if(cmp1!=cmp2)
        {
            HC_PRINT("topic=%s \n json=%s",mmapfd->topic,mmapfd->mqttdata);
            cmp1=cmp2;
        }
        usleep(200000);
    }
}
int HCMQttMsgSend(char *pubtopic,char *MqttSendBuf)
{
    ST_MqttMmapInfo *mmapfd;
    int writefd = 0;
    const char * pcFileName="/userdata/usr/local/connect_mqtt_server.mmap";
    //打开文件，失败则创建
    if (-1 == HC_fileOpen(&writefd, pcFileName, O_RDWR | O_CREAT)) {
        return -1;
    }
    //对齐
    if (lseek(writefd, MQTTLENG-1, SEEK_SET) < 0)
        perror("lseek");
    if (write(writefd, "\0", 1) < 0)
        perror("write");
    //申请映射
    mmapfd = mmap(NULL, MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED,writefd, 0);

    if (mmapfd == MAP_FAILED)
        perror("mmap");

    mmapfd->time=HC_LocalTimeGet();
    strcpy(mmapfd->topic,pubtopic);
    strcpy(mmapfd->mqttdata,MqttSendBuf);
    close(writefd);
    munmap(mmapfd, MQTTLENG);
    return ERR_COMMON_SUCCESS;
}
