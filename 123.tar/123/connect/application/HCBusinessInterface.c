﻿#include "HCBusinessInterface.h"
#include "hcopencv.h"
int eventflag=0;//事件标志位
int HCSoundFlag=0;
ST_EventCjsonInfo *HC_EventCjsonData(char*bucket,char*imagepath,char*videopath)
{
    ST_EventCjsonInfo*eventCjsonInfo=&EventCjsonInfo;
    sprintf(eventCjsonInfo->bucket,"%s",bucket);
    sprintf(eventCjsonInfo->imagepath,"%s",imagepath);
    sprintf(eventCjsonInfo->videopath,"%s",videopath);
    return eventCjsonInfo;
}
ST_MqttUsrData HCReadUserData()
{
    ST_MqttUsrData MqttUsrData;
    char *ptr=NULL;
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    memset(&MqttUsrData,0x0,sizeof (ST_MqttUsrData));
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", MqttUsrData.UserNamebuf);
    ptr=strchr(MqttUsrData.UserNamebuf,'&');
    strcat(MqttUsrData.ThingCategoryKeybuf,ptr+1);
    memcpy(MqttUsrData.DeviceName,MqttUsrData.UserNamebuf,strlen(MqttUsrData.UserNamebuf)-strlen(MqttUsrData.ThingCategoryKeybuf)-1);
    return MqttUsrData;
}
//Cjson解析
ST_AnalysisDataBbox *  HCJsonAnalysis(char *Analysisbuf)
{
    char buf[1024]={0};
    ST_AnalysisDataBbox *AnalysisDataBbox=(ST_AnalysisDataBbox *)buf;
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);

    //判断是否打包成功
    if(cjson == NULL){
        HC_PRINT("cjson error…\n");
        HCMsgSend(__FILE__,__LINE__,"all","cjson error…");
        return NULL;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"other");

    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"info"));
    if(json_data!=NULL)
    {
        sprintf(AnalysisDataBbox->Bbox.info,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"info_person"));
    if(json_data!=NULL)
    {
        sprintf(AnalysisDataBbox->Bbox.info_person,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"info_door"));
    if(json_data!=NULL)
    {
        sprintf(AnalysisDataBbox->Bbox.info_door,"%s",json_data);

    }
    free(json_data);
    //获取数组对象
    cJSON* test_bbox = cJSON_GetObjectItem(cjson,"bbox");
    //获取数组对象个数便于循环
    int bbox_size = cJSON_GetArraySize(test_bbox);//return arr_size 2
    HC_PRINT("bbox_size=%d",bbox_size);
    //获取test_arr数组对象孩子节点
    cJSON* arr_item = test_bbox->child;//子对象
    //循环获取数组下每个字段的值
    for(int i = 0;i <=(bbox_size-1)/*0*/;++i){


        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"xmin"));
        AnalysisDataBbox->Bbox.xmin=atoi(json_data);
        free(json_data);
        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"ymin"));
        AnalysisDataBbox->Bbox.ymin=atoi(json_data);
        free(json_data);
        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"xmax"));
        AnalysisDataBbox->Bbox.xmax=atoi(json_data);
        free(json_data);
        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"ymax"));
        AnalysisDataBbox->Bbox.ymax=atoi(json_data);
        free(json_data);
        arr_item = arr_item->next;//下一个子对象

    }
    //这里只需要释放cjson即可，因为其它的都指向它
    cJSON_Delete(cjson);

    return AnalysisDataBbox;
}
//modus信号输出
void HCModbusWriteOUT(int taskid,char *infor,char *personinfo,char *door)
{
    if(personinfo!=NULL)
    {
        if(strncmp(personinfo,"person",6)==0){

            if(taskid==0)
                HCModbusOutput("/dev/ttyS5",0x3600,0x08);

            else if (taskid==1) {
                HCModbusOutput("/dev/ttyS6",0x3600,0x08);
            }

        }

    }

    if(infor!=NULL){
        if(strncmp(infor,"ebike",5)==0){

            if(taskid==0)
                HCModbusOutput("/dev/ttyS5",0x3600,0x01);

            else if (taskid==1) {
                HCModbusOutput("/dev/ttyS6",0x3600,0x01);
            }

        }

        if(strncmp(infor,"smoke",5)==0){

            if(taskid==0)
                HCModbusOutput("/dev/ttyS5",0x3600,0x10);

            else if (taskid==1) {
                HCModbusOutput("/dev/ttyS6",0x3600,0x10);
            }

        }
        if(strncmp(infor,"pull",4)==0){

            if(taskid==0)
                HCModbusOutput("/dev/ttyS5",0x3600,0x02);

            else if (taskid==1) {
                HCModbusOutput("/dev/ttyS6",0x3600,0x02);
            }

        }
        if(strncmp(infor,"fall",4)==0){

            if(taskid==0)
                HCModbusOutput("/dev/ttyS5",0x3600,0x04);

            else if (taskid==1) {
                HCModbusOutput("/dev/ttyS6",0x3600,0x04);
            }

        }
    }
    if(door!=NULL)
    {

    }

}
//警告报警声输出
void HCWarningSoundOutput(char *infor,char *personinfo,char *door)
{
    if(infor!=NULL){
        if(strncmp(infor,"ebike",5)==0){
            //HCGpioOutput_1(0);
            HCEbikeWarinPut();
        }
        else {
            //HCGpioOutput_1(1);
        }
        if(strncmp(infor,"smoke",5)==0){
            HCSmokeWarinPut();
        }
        if(strncmp(infor,"pull",4)==0){
            HCPullWarinPut();
        }
        if(strncmp(infor,"fall",4)==0){
            HCFallWarinPut();
        }
    }
    if(personinfo!=NULL){
        if(strncmp(personinfo,"person",6)==0){
            HCFallPersonPut();
        }
    }
    if(door!=NULL)
    {

    }

}
void HCEbikeWarinPut(void)
{
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"aplay  /userdata/usr/local/sound/motorbike.wav");
    HC_LinuxSystem(pcCmdbuf,backbuf);

}
void HCSmokeWarinPut(void)
{
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"aplay  /userdata/usr/local/sound/smoke.wav");
    HC_LinuxSystem(pcCmdbuf,backbuf);

}
void HCPullWarinPut(void)
{

    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"aplay  /userdata/usr/local/sound/pull.wav");
    HC_LinuxSystem(pcCmdbuf,backbuf);

}
void HCFallWarinPut(void)
{

    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"aplay  /userdata/usr/local/sound/fall.wav");
    HC_LinuxSystem(pcCmdbuf,backbuf);

}
void HCFallPersonPut(void)
{

    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"aplay  /userdata/usr/local/sound/person.wav");
    HC_LinuxSystem(pcCmdbuf,backbuf);

}
int HCGpioOutput_1(int w_level)
{
    int fd;
    fd = open(DEV_NAME, O_RDWR);
    if(ERR_COMMON_FAILED == fd)
    {
        HC_PRINT("open gpiopin driver failed\n");
        return ERR_COMMON_FAILED;
    }
    gpiodtrl_s.gpiox = ALARM_OUT1;
    gpiodtrl_s.level = w_level;
    if(ERR_COMMON_FAILED==write(fd, &gpiodtrl_s, sizeof(GpioCtrl_S)))
    {
        HC_PRINT("write gpiopin level failed\n");
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}
int HCGpioOutput_2(int w_level)
{
    int fd;
    fd = open(DEV_NAME, O_RDWR);
    if(ERR_COMMON_FAILED == fd)
    {
        HC_PRINT("open gpiopin driver failed\n");
        return ERR_COMMON_FAILED;
    }
    gpiodtrl_s.gpiox = ALARM_OUT2;
    gpiodtrl_s.level = w_level;
    if(ERR_COMMON_FAILED==write(fd, &gpiodtrl_s, sizeof(GpioCtrl_S)))
    {
        HC_PRINT("write gpiopin level failed\n");
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}
//图片名字命名
static char cmpbuf[3][50]={{0}};
void HCJpgFileName(int tasknum,char*tempbuf)

{  char current[50]={0};

    while(1)
    {
        memset(current,0x0,sizeof (current));
        St_SystemTime SystemTime;
        memcpy(&SystemTime,HCGetTime(),sizeof (St_SystemTime));
        sprintf(current, "%04d%02d%02d%02d%02d%02d", SystemTime.tm_year, SystemTime.tm_mon, SystemTime.tm_mday,
                SystemTime.tm_hour, SystemTime.tm_min, SystemTime.tm_sec);
        if(strlen(cmpbuf[tasknum])==0)
        {
            strcpy(cmpbuf[tasknum],current);
        }
        if(strcmp(current,cmpbuf[tasknum])!=0){
            memset(cmpbuf[tasknum],0x0,sizeof (cmpbuf[tasknum]));
            strcpy(cmpbuf[tasknum],current);
        }
        break;

    }
    memcpy(tempbuf,current,strlen(current));


    return ;
}

//上传数据本地缓存
char * HCPictureDataSave(int i,St_Result_JPG  result_JPG,char *result,const char* id,const char *localpath,int xmin,int ymin,int xmax,int ymax)
{
    char  szFileName[100]={0};
    char szTempName[20]={0};
    char bufName[20]={0};
    char FileWritePath[256]={0};
    int  ReadFd=0;
    int  WriteFd=0;
    int length=xmax-xmin;
    int wideth=ymax-ymin;
    char pathload[100]={0};
    strcat(pathload,localpath);
    strcat(pathload,"/");
    strcat(pathload,id);
    strcat(pathload,"/");
    HC_ASSERT(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return NULL;
        }
    }
    if(strlen(result)==0)
    {
        HC_PRINT("analysisresult is null\n");
        HCMsgSend(__FILE__,__LINE__,id,"分析结果是空");
        close(ReadFd);
        close(WriteFd);
        return NULL;
    }
    if(result_JPG.JPG_size==0)
    {
        HC_PRINT("JPGData is null\n");
        HCMsgSend(__FILE__,__LINE__,id,"图片数据是空");
        close(ReadFd);
        close(WriteFd);
        return NULL;
    }
    HCJpgFileName(i,szFileName);
    strcat(szFileName,"_");
    strcpy(szTempName,result);
    memcpy(bufName,&szTempName[1],strlen(szTempName)-2);
    strcat(szFileName,bufName);

    strcat(szFileName,".jpg");
    memcpy(FileWritePath,pathload,strlen(pathload));
    strcat(FileWritePath,szFileName);

    if(HC_fileWrite(FileWritePath,(char *)result_JPG.JPG_Data,(unsigned int)result_JPG.JPG_size,O_WRONLY | O_CREAT | O_APPEND)==ERR_COMMON_FAILED)
    {
        HC_PRINT("write picture data faild\n");
        HCMsgSend(__FILE__,__LINE__,id,"写入图片数据失败");
        close(ReadFd);
        close(WriteFd);
        return NULL;
    }
    HCOpencvDraw(FileWritePath,FileWritePath,bufName,xmin,ymin,length,wideth);
    close(ReadFd);
    close(WriteFd);
    char *JPGName=szFileName;
    return  JPGName;
}
//上传数据本地缓存
int HCUploadDataSave(int tasknum,St_Result_JPG  result_JPG,char *result,const char* id,const char *localpath,int xmin,int ymin,int xmax,int ymax)
{
    char  szFileName[100]={0};
    char  sztextName[100]={0};
    char szTempName[20]={0};
    char bufName[20]={0};
    char FileWritePath[256]={0};
    char textWritePath[256]={0};
    int  ReadFd=0;
    int  WriteFd=0;
    char pathload[100]={0};

    strcat(pathload,localpath);
    strcat(pathload,id);
    strcat(pathload,"/");
    int length=xmax-xmin;
    int wideth=ymax-ymin;
    HC_ASSERT(pathload);
    ReadFd = open(pathload, O_RDWR);
    char Send_task_info[50]={0};
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ERR_COMMON_FAILED;
        }
    }
    if(strlen(result)==0)
    {
        HC_PRINT("analysisresult is null\n");
        HCMsgSend(__FILE__,__LINE__,id,"analysisresult is null");
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    if(result_JPG.JPG_size==0)
    {
        HC_PRINT("JPGData is null\n");
        HCMsgSend(__FILE__,__LINE__,id,"JPGData is null");
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    HCJpgFileName(tasknum,szFileName);
    strcat(szFileName,"_");
    strcpy(szTempName,result);
    memcpy(bufName,&szTempName[1],strlen(szTempName)-2);
    strcat(szFileName,bufName);
    strcat(sztextName,szFileName);
    sprintf(Send_task_info,
            "{\"xmin\":%d,\"ymin\":%d,\"length\":%d,\"wideth\":%d}",xmin,ymin,length,wideth);
    strcat(sztextName,".txt");
    strcat(szFileName,".jpg");
    memcpy(FileWritePath,pathload,strlen(pathload));
    strcat(FileWritePath,szFileName);
    memcpy(textWritePath,pathload,strlen(pathload));
    strcat(textWritePath,sztextName);
    if(HC_fileWrite(FileWritePath,(char *)result_JPG.JPG_Data,(unsigned int)result_JPG.JPG_size,O_WRONLY | O_CREAT | O_APPEND)==ERR_COMMON_FAILED)
    {
        HC_PRINT("write picture data faild\n");
        HCMsgSend(__FILE__,__LINE__,id,"write picture data faild");
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    if(HC_fileWrite(textWritePath,Send_task_info,(unsigned int)strlen(Send_task_info),O_WRONLY | O_CREAT | O_APPEND)==ERR_COMMON_FAILED)
    {
        HC_PRINT("write picture text faild\n");
        HCMsgSend(__FILE__,__LINE__,id,"write picture text faild");
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    return  ERR_COMMON_SUCCESS;
}
//重命名文件名
int HCReNameFile(char *source ,char *dist)
{
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"mv %s  %s",source,dist);
    if(HC_LinuxSystem(pcCmdbuf,backbuf)==ERR_COMMON_FAILED)
        return ERR_COMMON_FAILED;
    return ERR_COMMON_SUCCESS;
}
//日志数据更新
int HCJournalDataUpdate(char *Analysisresult,char*ID,int frequency,int postion)
{
    char pathload[100]={0};
    strcat(pathload,JPURNAL_PATH);
    strcat(pathload,ID);
    strcat(pathload,"/");
    strcat(pathload,"journal.db");
    char Time[30]={0};     //时间
    // char EventLevel[20]={0};  //事件等级
    char EventDescription[256]={0}; //事件描述
    char analysistemp[30]={0};
    ST_Journal  Journal;
    St_SystemTime SystemTime;
    memcpy(&SystemTime,HCGetTime(),sizeof (St_SystemTime));
    sprintf(EventDescription,"当前轿厢最大抖动频率存在%dHz最大抖动存在在%dm层最高位置",frequency,postion);
    sprintf(Time, "%04d-%02d-%02d %02d:%02d:%02d", SystemTime.tm_year, SystemTime.tm_mon, SystemTime.tm_mday,
            SystemTime.tm_hour, SystemTime.tm_min, SystemTime.tm_sec);
    Journal.Time=Time;
    Journal.EventDescription=EventDescription;
    memcpy(analysistemp,&Analysisresult[1],strlen(Analysisresult)-2);
    if(strcmp(analysistemp,"ebike")==0){
        Journal.EventType="电瓶车识别";
        Journal.EventLevel="一级";
    }else if(strcmp(analysistemp,"smoke")==0){
        Journal.EventType="抽烟识别";
        Journal.EventLevel="二级";
    }else if(strcmp(analysistemp,"pull")==0){
        Journal.EventType="扒门识别";
        Journal.EventLevel="三级";
    }else if(strcmp(analysistemp,"fall")==0){
        Journal.EventType="摔倒识别";
        Journal.EventLevel="一级";
    } else if(strcmp(analysistemp,"person")==0){
        Journal.EventType="有人识别";
        Journal.EventLevel="四级";
    } else{
        Journal.EventType="空";
        Journal.EventLevel="空";
    }
    if(HCAddJournal(pathload,Journal)!=ERR_COMMON_SUCCESS)
    {
        HC_PRINT("日志信息写入失败/n/r");
        HCMsgSend(__FILE__,__LINE__,ID,"日志信息写入失败");
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}
/*
 *      事件视频本地保存功能
 *      输入视频地址 char *rtspadress
 *      保存路径  const char*path
        电梯ID    char*ID
        事件结果  char *Analysisresult
        保存的秒数 int second
        错误返回-1
 */
int HCEventVideoSave(char *rtspadress,const char*path,char*ID,char *Analysisresult,int second)
{
    char  pathload[256]={0};
    char videoname[256]={0};
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    int  ReadFd=0;
    int  WriteFd=0;
    sprintf(pathload,"%s%s/",path,ID);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    St_SystemTime SystemTime;
    memcpy(&SystemTime,HCGetTime(),sizeof (St_SystemTime));
    sprintf(videoname, "%04d%02d%02d%02d%02d%02d_%s.mp4", SystemTime.tm_year, SystemTime.tm_mon, SystemTime.tm_mday,
            SystemTime.tm_hour, SystemTime.tm_min, SystemTime.tm_sec,Analysisresult);
    strcat(pathload,videoname);
    sprintf(pcCmdbuf,"cd %s  &&./media_tool -rtsp_transport tcp -i %s -t %d -vcodec copy %s ",LocalPath,rtspadress,second,pathload);
    if(HC_LinuxSystem(pcCmdbuf,backbuf)==ERR_COMMON_FAILED)
    {

        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    //HC_PRINT("VIDEO SAVE SUCESS");
    return ERR_COMMON_SUCCESS;
}
