﻿#ifndef HCFTPUPLOADPROCESS_H
#define HCFTPUPLOADPROCESS_H
#include "common.h"
#include "public/HCFTP.h"
#include "public/HCPulicAPI.h"
#include "public/HCPublicStruct.h"
extern void *HCFTPUploadProcess_Thread(void);

#endif
