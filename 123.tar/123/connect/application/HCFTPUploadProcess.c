﻿#include "HCFTPUploadProcess.h"
#include"hcopencv.h"
#include"application/HCBusinessCJson.h"
static int HCLocalFTPUpload(ST_FTPInfo FTPInfo, const char *ID,const char *pDataRootPath);
static int HCMP4FTPUpload(ST_FTPInfo FTPInfo, const char *ID,const char *pDataRootPath);
static int HCNotOpencvFTPUpload(ST_FTPInfo FTPInfo, const char *ID,const char *pDataRootPath);
void *HCFTPUploadProcess_Thread(void)
{
    ST_FTPInfo FTPInfo;
    FTPInfo.Usrname="123";
    FTPInfo .port=21;
    FTPInfo.PassWord="123456";
    FTPInfo.RemoteUrl="ftp://192.168.250.123/";
    while(1)
    {
        for (int i=0;i<3;i++) {

            if(FileSaveFlag[i].flag!=ERR_COMMON_FAILED)
            {
#ifdef NOTDRAW
                HCNotOpencvFTPUpload(FTPInfo,idbuf[i],FTPUploadPath);
#endif
                HCLocalFTPUpload(FTPInfo,idbuf[i],FTPUploadPath);
                if(EventVideoSaveFlag[i].flag==0)
                {
                    HCMP4FTPUpload(FTPInfo,idbuf[i],VideoPath);
                }
                // FileSaveFlag[i].flag=ERR_COMMON_SUCCESS;
            }

        }


        usleep(500000);
    }
}

//FTP数据上传
static int HCLocalFTPUpload(ST_FTPInfo FTPInfo, const char *ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[256] = {0};
    char textFileName[256] = {0};
    char fileName[100]={0};
    char TempName[100]={0};
    char RemoteUrl[512]={0};
    char pathload[100]={0};
    int PathLength=0,fileLength=0;
    int  ReadFd=0;
    int  WriteFd=0;
    char buf[512]={0};
    int xmin=0,ymin=0,length=0,wideth=0;
    char current[20]={0};
    char eventname[20]={0};
    char eventnametemp[20]={0};
    char *ret=NULL;
    sprintf(current, "%s", "event/picture");
    strcat(pathload,pDataRootPath);

    strcat(pathload,ID);
    strcat(pathload,"/");
    HC_ASSERT(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    PathLength=(int)strlen(pathload);
    res = HC_findFile(pathload, szFileName, ".jpg");
    if (ERR_COMMON_SUCCESS == res)
    {

        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        ret=strchr(fileName,'_');
        sprintf(eventname,"%s",ret);
        ret=strrchr(eventname,'.');
        memcpy(eventnametemp,&eventname[1],strlen(eventname)-1-strlen(ret));
        strcpy(TempName,fileName);
        strcat(TempName,".temp");
        strcpy(RemoteUrl,FTPInfo.RemoteUrl);
        FTPInfo.tempname=(char *)TempName;
        FTPInfo.filename=(char *)fileName;
        FTPInfo.UploadPath=(char *)szFileName;

        strcat(RemoteUrl,ID);
        strcat(RemoteUrl,"/");
        strcat(RemoteUrl,current);
        strcat(RemoteUrl,"/");
        strcat(RemoteUrl,eventnametemp);
        strcat(RemoteUrl,"/");

        FTPInfo.RemoteUrl=(char *)RemoteUrl;
        memcpy(textFileName,szFileName,strlen(szFileName)-strlen(".jpg"));
        strcat(textFileName,".txt");

        if(HC_fileRead( textFileName, buf , O_RDONLY | O_CREAT | O_APPEND==ERR_COMMON_SUCCESS)){

            //第一步打包JSON字符串
            cJSON* cjson = cJSON_Parse(buf);
            //判断是否打包成功
            if(cjson == NULL){
                HC_PRINT("cjson error…\n\r");
                HCMsgSend(__FILE__,__LINE__,ID,"cjson error…");
                return ERR_COMMON_FAILED;
            }
            char *json_data = NULL;
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"xmin"));
            if(json_data!=NULL)
            {
                xmin=atoi(json_data);
            }
            free(json_data);
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"ymin"));
            if(json_data!=NULL)
            {
                ymin=atoi(json_data);
            }
            free(json_data);
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"length"));
            if(json_data!=NULL)
            {
                length=atoi(json_data);
            }
            free(json_data);
            json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"wideth"));
            if(json_data!=NULL)
            {
                wideth=atoi(json_data);
            }
            free(json_data);
            //这里只需要释放cjson即可，因为其它的都指向它
            cJSON_Delete(cjson);
            if(HCOpencvDraw(szFileName,szFileName,eventnametemp,xmin,ymin,length,wideth)==ERR_COMMON_SUCCESS)
            {
                char path[500]={0};
                char localfimename[100]={0};
                strcat(path,PicturePath);
                substr(szFileName,(int)strlen(pDataRootPath),(int)strlen(szFileName)-(int)strlen(pDataRootPath),localfimename);
                 strcat(path,localfimename);
#ifdef LOACLPICTURESAVE
               HCFileCopy(szFileName,path);
#endif

                usleep(100000);
                if(HCFtpUpload(FTPInfo)==ERR_COMMON_FAILED){
                    HC_RemoveFile(szFileName);
                    HC_RemoveFile(textFileName);
                    close(ReadFd);
                    close(WriteFd);
                    HC_PRINT("图片FTP上传失败\n\r");
                    HCMsgSend(__FILE__,__LINE__,ID,"图片FTP上传失败");
                    return ERR_COMMON_FAILED;
                }
                else {
                    HC_RemoveFile(szFileName);
                    HC_RemoveFile(textFileName);
                }
            }
            else
            {
                HC_RemoveFile(szFileName);
                HC_RemoveFile(textFileName);
                close(ReadFd);
                close(WriteFd);
                HC_PRINT("OPENCV画图失败\n\r");
                HCMsgSend(__FILE__,__LINE__,ID,"OPENCV画图失败");
                return ERR_COMMON_FAILED;
            }


        }
        else
        {
            HC_RemoveFile(szFileName);
            HC_RemoveFile(textFileName);
            close(ReadFd);
            close(WriteFd);
            HCMsgSend(__FILE__,__LINE__,ID,"OPENCV 描述文件读取失败");
            return ERR_COMMON_FAILED;
        }

    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}

int HCMP4FTPUpload(ST_FTPInfo FTPInfo, const char *ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[128] = {0};
    char fileName[100]={0};
    char TempName[100]={0};
    char RemoteUrl[512]={0};
    char pathload[100]={0};
    int PathLength=0,fileLength=0;
    int  ReadFd=0;
    int  WriteFd=0;

    char current[20]={0};
    char eventname[20]={0};
    char eventnametemp[20]={0};
    char *ret=NULL;
    sprintf(current, "%s", "event/video");
    strcat(pathload,pDataRootPath);
    strcat(pathload,"/");
    strcat(pathload,ID);
    strcat(pathload,"/");
    HC_ASSERT(pathload);
    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ERR_COMMON_FAILED;
        }
    }
    PathLength=(int)strlen(pathload);
    res = HC_findFile(pathload, szFileName, ".mp4");
    if (ERR_COMMON_SUCCESS == res)
    {
        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        ret=strchr(fileName,'_');
        sprintf(eventname,"%s",ret);
        ret=strrchr(eventname,'.');
        memcpy(eventnametemp,&eventname[1],strlen(eventname)-1-strlen(ret));
        strcpy(TempName,fileName);
        strcat(TempName,".temp");
        strcpy(RemoteUrl,FTPInfo.RemoteUrl);
        FTPInfo.tempname=(char *)TempName;
        FTPInfo.filename=(char *)fileName;
        FTPInfo.UploadPath=(char *)szFileName;

        strcat(RemoteUrl,ID);
        strcat(RemoteUrl,"/");
        strcat(RemoteUrl,current);
        strcat(RemoteUrl,"/");
        strcat(RemoteUrl,eventnametemp);
        strcat(RemoteUrl,"/");

        FTPInfo.RemoteUrl=(char *)RemoteUrl;
        if(HCFtpUpload(FTPInfo)==ERR_COMMON_FAILED){
            HC_RemoveFile(szFileName);
            close(ReadFd);
            close(WriteFd);
            HC_PRINT("视频FTP上传失败\n\r");
            HCMsgSend(__FILE__,__LINE__,ID,"视频FTP上传失败");
            return ERR_COMMON_FAILED;
        }
        else {
            HC_RemoveFile(szFileName);
        }
    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);

    return ERR_COMMON_SUCCESS;
}

//无画框FTP数据上传
static int HCNotOpencvFTPUpload(ST_FTPInfo FTPInfo, const char *ID,const char *pDataRootPath)
{
    int res = ERR_COMMON_SUCCESS;
    char szFileName[256] = {0};
    char fileName[100]={0};
    char TempName[100]={0};
    char RemoteUrl[512]={0};
    char pathload[100]={0};
    int PathLength=0,fileLength=0;
    int  ReadFd=0;
    int  WriteFd=0;
    char current[20]={0};
    char eventname[20]={0};
    char eventnametemp[20]={0};
    char *ret=NULL;
    sprintf(current, "%s", "event/test");
    strcat(pathload,pDataRootPath);

    strcat(pathload,ID);
    strcat(pathload,"/");

    ReadFd = open(pathload, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pathload, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    PathLength=(int)strlen(pathload);
    res = HC_findFile(pathload, szFileName, ".jpg");
    if (ERR_COMMON_SUCCESS == res)
    {

        fileLength=(int)strlen(szFileName)-PathLength;
        substr(szFileName,PathLength,fileLength,fileName);
        ret=strchr(fileName,'_');
        sprintf(eventname,"%s",ret);
        ret=strrchr(eventname,'.');
        memcpy(eventnametemp,&eventname[1],strlen(eventname)-1-strlen(ret));
        strcpy(TempName,fileName);
        strcat(TempName,".temp");
        strcpy(RemoteUrl,FTPInfo.RemoteUrl);
        FTPInfo.tempname=(char *)TempName;
        FTPInfo.filename=(char *)fileName;
        FTPInfo.UploadPath=(char *)szFileName;

        strcat(RemoteUrl,ID);
        strcat(RemoteUrl,"/");
        strcat(RemoteUrl,current);
        strcat(RemoteUrl,"/");
        strcat(RemoteUrl,eventnametemp);
        strcat(RemoteUrl,"/");
        FTPInfo.RemoteUrl=(char *)RemoteUrl;
        if(HCFtpUpload(FTPInfo)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            HC_PRINT("无画框图片FTP上传失败\n\r");
            HCMsgSend(__FILE__,__LINE__,ID,"无画框图片FTP上传失败");
            return ERR_COMMON_FAILED;
        }

    }
    else
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}
