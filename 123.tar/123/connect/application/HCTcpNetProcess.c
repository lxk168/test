﻿#include "HCTcpNetProcess.h"
#include "public/HCSocket.h"
//创建与PC通信线程
void *HC_ClientProcess_Thread(void)
{
    int res=ERR_COMMON_SUCCESS;
    int serverSock = 0;
    int clientSock = 0;
    unsigned int clientLen;
    struct sockaddr_in stClientAddr;//客户端网络信息集
    fd_set writeset;
    FD_ZERO(&writeset);

    struct timeval stTimeout;
    stTimeout.tv_sec=5;//超时时间
    stTimeout.tv_usec=0;

    if(ERR_COMMON_SUCCESS == HCTCPServer_Init(0,1234, &serverSock, 30, 10))
    {
        while(1){
            HC_PRINT("waiting for new connection...\n");
            clientLen = sizeof(stClientAddr);
            if ((clientSock = accept(serverSock, (struct sockaddr *) &stClientAddr,&clientLen)) < 0)
            {
                perror("Failed to accept client connection");
            }
            HC_PRINT("A new connection occurs! IP: %s\n", inet_ntoa(stClientAddr.sin_addr));
            FD_SET(clientSock,&writeset);
            while(1)
            {
                // 以秒为单位
                int   keepAlive = 1;       //设定KeepAlive
                int   keepIdle = 5;        //首次探测开始前的tcp无数据收发空闲时间
                int   keepInterval = 3;  //每次探测的间隔时间
                int   keepCount = 2;     //探测次数

                if(setsockopt(clientSock,SOL_SOCKET,SO_KEEPALIVE,(void*)&keepAlive,sizeof(keepAlive)) == -1)
                    break;



                if(setsockopt(clientSock,SOL_TCP,TCP_KEEPIDLE,(void   *)&keepIdle,sizeof(keepIdle)) == -1)
                    break;


                if(setsockopt(clientSock,SOL_TCP,TCP_KEEPINTVL,(void   *)&keepInterval,sizeof(keepInterval)) == -1)
                    break;


                if(setsockopt(clientSock,SOL_TCP,TCP_KEEPCNT,(void   *)&keepCount,sizeof(keepCount)) == -1)
                    break;

                res =select(clientSock+1,NULL,&writeset,NULL,&stTimeout);
                if(res<0)
                {
                    close(clientSock);
                    break;
                }
                else if(res>0) {
                    if(SendFlag==ERR_COMMON_SUCCESS)
                    {
                        if(clientSock!=ERR_COMMON_FAILED){
                            int sendlength= send(clientSock, &AnalysisResult, sizeof (ST_AnalysisResult), 0);
                            if(sendlength<0)

                            {
                                break;
                            }
                            SendFlag=ERR_COMMON_FAILED;
                        }
                    }
                }
              usleep(10000);
            }
        }

    }
    return ERR_COMMON_SUCCESS;
}
