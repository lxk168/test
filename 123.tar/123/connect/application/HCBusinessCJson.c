﻿#include "application/HCBusinessCJson.h"
#include"application/HCMqttSubProcess.h"
ST_EventCjsonInfo EventCjsonInfo;
ST_MqttMmapInfo mqttMmapInfo;
#define MAXCJSONLENG (1024*50)
ST_Topic_InforMation Topic_InforMation;


char * HCJsonPublic(char*method,char*value,int ack)
{
    char tempbuf[1024*10]={0};
    char timebuf[100]={0};
    char idbuf[100]={0};
    sprintf(timebuf,"%ld",HC_LocalTimeGet());
    sprintf(idbuf,"%ld",HC_LocalTimeGet());
    sprintf(tempbuf,"{\"id\":\"%s\",\"method\":\"%s\",\"params\":{\"time\":\"%s\",\"value\":{%s}},\"sys\":{\"ack\":%d}",idbuf,method,timebuf,value,ack);
    char *temp=tempbuf;
    return temp;
}
/***============================================(15)轿厢-轿内-电瓶车识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-电瓶车识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionElectricVehicle/post
 */
char* HCVisionElectricVehicle(ST_VisionData  visionElectricVehicle, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionElectricVehicle.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(1,2294967295), method, HC_LocalTimeGet(),visionElectricVehicle.image.bucket,visionElectricVehicle.image.path,visionElectricVehicle.video.bucket,visionElectricVehicle.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(16)轿厢-轿内-扒门识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-电瓶车识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionPryingDoor/post
 */
char* HCVisionPryingDoor(ST_VisionData  visionPryingDoor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionPryingDoor.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(1,2294967295), method, HC_LocalTimeGet(),visionPryingDoor.image.bucket,visionPryingDoor.image.path,visionPryingDoor.video.bucket,visionPryingDoor.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(17)轿厢-轿内-烟雾识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-电瓶车识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionSmoke/post
 */
char* HCVisionSmoke(ST_VisionData  visionSmoke, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionSmoke.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(1,2294967295), method, HC_LocalTimeGet(),visionSmoke.image.bucket,visionSmoke.image.path,visionSmoke.video.bucket,visionSmoke.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(18)轿厢-轿内-困人识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-困人识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionTrapped/post
 */
char* HCVisionTrapped(ST_VisionData  visionTrapped, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionTrapped.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(1,2294967295), method, HC_LocalTimeGet(),visionTrapped.image.bucket,visionTrapped.image.path,visionTrapped.video.bucket,visionTrapped.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(19)轿厢-轿内-倒地识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-倒地识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionFall/post
 */
char* HCVisionFall(ST_VisionData  visionFall, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionFall.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(1,2294967295), method, HC_LocalTimeGet(),visionFall.image.bucket,visionFall.image.path,visionFall.video.bucket,visionFall.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(20)轿厢-轿内-人员计数=====================================================****/
/*
 * 函数功能：轿厢-轿内-人员计数
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionPerson/post
 */
char* HCVisionPerson(int visionPerson, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionPerson.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"visionPerson\":%d}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(1,2294967295), method, HC_LocalTimeGet(),visionPerson , ack);
    char* temp = tempbuf;
    return temp;
}
int HCVisionElectricVehicleUpload(char *analysis,char *picture,char*video,char*bucket)
{
    char MqttSendBuf[1024]={0};
    ST_VisionData VisionData;
    memset(&VisionData,0x0,sizeof (ST_VisionData));
    if(picture==NULL)
    {
        strcat(VisionData.image.path,"");
        strcat(VisionData.image.bucket,bucket);
    }
    else {
        strcat(VisionData.image.path,picture);
        strcat(VisionData.image.bucket,bucket);
    }
    if(video==NULL)
    {
        strcat(VisionData.video.path,"");
        strcat(VisionData.video.bucket,bucket);
    }
    else {
        strcat(VisionData.video.path,video);
        strcat(VisionData.video.bucket,bucket);
    }
    if(strcmp(analysis,"ebike")==0)
    {
        sprintf(MqttSendBuf,"%s",HCVisionElectricVehicle(VisionData,0));
        HC_MmapProcess_Server_Send(Topic_InforMation.Event_Pub_Topic[0].HCEbikeTopic_Pub,MqttSendBuf);
    }else if (strcmp(analysis,"fall")==0) {
        sprintf(MqttSendBuf,"%s",HCVisionPryingDoor(VisionData,0));
        HC_MmapProcess_Server_Send(Topic_InforMation.Event_Pub_Topic[0].HCFallTopic_Pub,MqttSendBuf);
    }else if (strcmp(analysis,"pull")==0) {
        sprintf(MqttSendBuf,"%s",HCVisionElectricVehicle(VisionData,0));
        HC_MmapProcess_Server_Send(Topic_InforMation.Event_Pub_Topic[0].HCPullTopic_Pub,MqttSendBuf);
    }else if (strcmp(analysis,"smoke")==0) {
        sprintf(MqttSendBuf,"%s",HCVisionSmoke(VisionData,0));
        HC_MmapProcess_Server_Send(Topic_InforMation.Event_Pub_Topic[0].HCSmokeTopic_Pub,MqttSendBuf);
    }

    return ERR_COMMON_SUCCESS;
}
void HCSubTopicInit(void)
{

    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* topic_path = (char*)"/userdata/usr/local/subtopic.conf";
    char* app_name = (char*)"mqtt_userdata";
    char* topic_name = (char*)"mqtt_subtopic";
    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    int ReadFd=0,WriteFd=0;
    char valuebuf[10]={0};

    ReadFd = open(topic_path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, topic_path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

        }
    }
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    write_profile_string(topic_name,valuebuf,"",topic_path);
    memset(&Topic_InforMation,0x0,sizeof (ST_Topic_InforMation));
    for (int i=0;i<3;i++) {
        sprintf(Topic_InforMation.Event_Pub_Topic[i].HCEbikeTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.visionElectricVehicle/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_InforMation.Event_Pub_Topic[i].HCSmokeTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.visionSmoke/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_InforMation.Event_Pub_Topic[i].HCFallTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.visionFall/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_InforMation.Event_Pub_Topic[i].HCPullTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.visionPryingDoor/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_InforMation.Event_Pub_Topic[i].HCTrappedTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.visionTrapped/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_InforMation.Event_Pub_Topic[i].HCPersonTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.visionPerson/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
    }

    close(ReadFd);
    close(WriteFd);
    return ;
}
