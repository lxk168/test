#include"public/HCSocket.h"

/*
  函数功能: 服务器初始化
  参数说明:

            int uServerIP //本地IP
            unsigned short unPort  端口
            int *pSockFd  网络套接子
            int timeout   超时发送时间
            char listenNum 监听个数
*/
int HCTCPServer_Init( __attribute__((unused)) unsigned int uServerIP,  unsigned short unPort,  int *pSockFd,  __attribute__((unused)) int timeout,  char listenNum)
{
    int on = 1;
    int res = 0;
    int serverSockFd = 0;
    struct sockaddr_in stServerAddr;

    if(NULL == pSockFd)
        HC_PRINT("pSockFd is null,ERR");

   //创建网络套接字
    serverSockFd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == serverSockFd){
        HC_PRINT("sockeTCP_Server_Initt creat ERR");
        return ERR_COMMON_FAILED;
    }

    //本地IP和端口
    bzero(&stServerAddr, sizeof(stServerAddr));
    stServerAddr.sin_family = AF_INET;
    stServerAddr.sin_port = htons(unPort);
    stServerAddr.sin_addr.s_addr = INADDR_ANY;   //INADDR_ANY


    if (setsockopt(serverSockFd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on)) < 0) {
        HC_PRINT("setsockopt  ERR");
        return ERR_COMMON_FAILED;
    }

    //
    res = bind(serverSockFd, (struct sockaddr *)(&stServerAddr), sizeof(struct sockaddr));
    if (-1 == res){
        HC_PRINT("socket bind  ERR");
        return ERR_COMMON_FAILED;
    }
    //监听
    res = listen(serverSockFd, listenNum);
    if (-1 == res){
        HC_PRINT("socket listen  ERR");
        return ERR_COMMON_FAILED;
    }

    *pSockFd = serverSockFd;
    return ERR_COMMON_SUCCESS;
}
