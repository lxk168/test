﻿#include "public/HCModbus.h"

#define  SERVER_ID 1		//从设备地址
int HCModbusInRead(int adress,int nq,uint16_t* tab_rq_bit)
{
    modbus_t* ctx = NULL;
    int ret = -1;
    uint16_t* tab_rq_bits = NULL;

    //1. 创建一个RTU类型的变量
    //设置串口设备  波特率 奇偶校验 数据位 停止位
    ctx = modbus_new_rtu("/dev/ttyS5", 38400, 'N', 8, 1);
    if (NULL == ctx)
    {
        fprintf(stderr, "Error: %s\n", modbus_strerror(errno));
        return -1;
    }
    else
    {
        HC_PRINT("设置串口信息成功\n");
    }


    //2. 设置从机地址
    ret = modbus_set_slave(ctx, SERVER_ID);
    if (-1 == ret)
    {
         HC_PRINT("设置从机地址失败\n");
        fprintf(stderr, "Error: 设置从机地址失败\n");

        modbus_free(ctx);

        return -1;
    }

    //3. 设置Debug模式
    ret = modbus_set_debug(ctx, TRUE);
    if (-1 == ret)
    {
        fprintf(stderr, "Error: 设置Debug模式失败");
        modbus_free(ctx);
        return -1;
    }


        modbus_set_response_timeout(ctx,0,50000);
    //4. 在RTU模式下打开串口
    ret = modbus_connect(ctx);
    if (-1 == ret)
    {
        fprintf(stderr, "Connection failed: %s\n", modbus_strerror(errno));
        modbus_free(ctx);
        return -1;
    }



    //6. 申请内存 保存发送和接收的数据
    tab_rq_bits = (uint16_t*)malloc(sizeof(uint16_t));
    if (NULL == tab_rq_bits)
    {
        fprintf(stderr, "malloc failed\n");
        modbus_free(ctx);
        return -1;
    }
    else
    {
        memset(tab_rq_bits, 0, sizeof(uint16_t));
    }



    ret = modbus_read_registers(ctx, adress, nq,tab_rq_bits);
    if (1 != ret)
    {
        HC_PRINT("Error modbus_write_bit: %d\n", ret);
        return -1;
    }

    //8. 释放内存
    tab_rq_bit=tab_rq_bits;
    free(tab_rq_bits);

    //9. 断开连接
    modbus_close(ctx);
    modbus_free(ctx);

    return 0;
}
int HCModbusOutput(char * equipment,int adress,uint16_t signle)

{
    modbus_t* ctx = NULL;
    int ret = -1;
    uint16_t* tab_wq_bits = NULL;

    //1. 创建一个RTU类型的变量
    //设置串口设备  波特率 奇偶校验 数据位 停止位
    // modbus1 /dev/ttyS5
    ctx = modbus_new_rtu(equipment, 38400, 'N', 8, 1);
    if (NULL == ctx)
    {
        fprintf(stderr, "Error: %s\n", modbus_strerror(errno));
        HCMsgSend(__FILE__,__LINE__,equipment,"设置串口信息失败");
        modbus_close(ctx);
        modbus_free(ctx);
        return 1;
    }
    else
    {
        HC_PRINT("设置串口信息成功\n");
    }


    //2. 设置从机地址
    ret = modbus_set_slave(ctx, SERVER_ID);
    if (-1 == ret)
    {
         HC_PRINT("设置从机地址失败\n");
         fprintf(stderr, "Error: 设置从机地址失败\n");
          HCMsgSend(__FILE__,__LINE__,equipment,"设置从机地址失败");
          modbus_close(ctx);
          modbus_free(ctx);

        return 1;
    }

    //3. 设置Debug模式
    ret = modbus_set_debug(ctx, TRUE);
    if (-1 == ret)
    {
        fprintf(stderr, "Error: 设置Debug模式失败");
           modbus_close(ctx);
        modbus_free(ctx);
        return 1;
    }


        modbus_set_response_timeout(ctx,0,50000);
    //4. 在RTU模式下打开串口
    ret = modbus_connect(ctx);
    if (-1 == ret)
    {
        fprintf(stderr, "Connection failed: %s\n", modbus_strerror(errno));
        HCMsgSend(__FILE__,__LINE__,equipment,"modbus串口连接失败");
        modbus_close(ctx);
        modbus_free(ctx);
        return 1;
    }



    //6. 申请内存 保存发送和接收的数据
    tab_wq_bits = (uint16_t*)malloc(sizeof(uint16_t));
    if (NULL == tab_wq_bits)
    {
        fprintf(stderr, "malloc failed\n");
           modbus_close(ctx);
        modbus_free(ctx);
         free(tab_wq_bits);
        return 1;
    }
    else
    {
        memset(tab_wq_bits, 0, sizeof(uint16_t));
    }

    tab_wq_bits[0] =signle;

    ret = modbus_write_register(ctx, adress, tab_wq_bits[0]);
    if (1 != ret)
    {
        HC_PRINT("Error modbus_write_bit: %d\n", ret);
        HC_PRINT("Address: %d value: %d\n", adress, tab_wq_bits[0]);
        HCMsgSend(__FILE__,__LINE__,equipment,"modbuss数据写入失败");
    }

    //8. 释放内存

    free(tab_wq_bits);

    //9. 断开连接
    modbus_close(ctx);
    modbus_free(ctx);

    return 0;
}
