﻿#ifndef HCSOCKET_H
#define HCSOCKET_H
#include "common.h"




extern int HCTCPServer_Init( __attribute__((unused)) unsigned int uServerIP,  unsigned short unPort,  int *pSockFd,  __attribute__((unused)) int timeout,  char listenNum);
#endif
