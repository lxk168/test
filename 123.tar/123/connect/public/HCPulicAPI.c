﻿#include "HCPulicAPI.h"
char Mmap_Serveradress[256]={"/userdata/usr/local/connect_mqtt_server.mmap"};
int HC_PthreadCreate(pthread_t ThreadID,void *Process_Thread)
{
    int res = ERR_COMMON_SUCCESS;
    //创建线程
    if(Process_Thread == NULL)
    { }
    else
    {
        res = pthread_create(&ThreadID, NULL, Process_Thread, NULL);
        if (0 != res)
        {
            HC_PRINT("创建线程失败");
            return ERR_COMMON_FAILED;
        }
        pthread_detach(ThreadID);
    }
    return res;
}


/*
  函数功能: Linux 系统指令
  参数说明:

            char* pcCommand 命令内容
            char *pcBackBuf 指令返回内容

*/
int HC_LinuxSystem( const char* pcCommand,  char *pcBackBuf)
{
    FILE *fpRead;
    char buf[1025];
    memset(buf,'\0',sizeof(buf));
    memset(pcBackBuf,0x0,512);
    fpRead = popen(pcCommand, "r");
    if(fpRead==NULL)
        return ERR_COMMON_FAILED;
    while(fgets(buf,1024-1,fpRead)!=NULL)
    {
        memcpy(pcBackBuf, buf, strlen(buf) > 1024 ? 1024 : strlen(buf));
    }
    if(fpRead!=NULL)
        pclose(fpRead);
    return ERR_COMMON_SUCCESS;
}

/*
  函数功能: 关闭指定进程
  参数说明:
          char* pcProcessName  //进程名称
*/

int HC_LinuxKillProcess( const char* pcProcessName)
{
    char pcCommand[512]={0};
    char killCommand[128]={0};
    char ProcessPid[8]={0};
    char pcBackBuf[256]={0};
    FILE *fpRead;
    int i=0;
    int j=0; char buf[1025];
    sprintf(pcCommand,"ps -ef|grep   %s",pcProcessName);
    fpRead = popen(pcCommand, "r");
    if(fpRead==NULL)
        return ERR_COMMON_FAILED;

    memset(buf,'\0',sizeof(buf));
    while(fgets(buf,1024-1,fpRead)!=NULL)
    {
        memset(killCommand,'\0',sizeof(killCommand));
        memset(ProcessPid,'\0',sizeof(ProcessPid));
        while(i<(int)strlen(buf))
        {
            if(strcmp(&buf[0],"")==0)
            {
                j=i+1;
            }
            else {
                j=i;
            }
            memcpy(&ProcessPid[i],&buf[j],1);

            i++;
            if(buf[j]=='r'||buf[j]==' ')
            {
                if(buf[j]=='r')
                {
                    if (strncmp(&buf[j],"root",4)==0) {
                        i=0;
                        break;
                    }
                }
                else if(buf[j]==' ') {
                    if (strncmp(&buf[j+1],"root",4)==0) {
                        i=0;
                        break;
                    }
                }

            }
        }
        memset(buf,'\0',sizeof(buf));
        sprintf(killCommand,"kill -9  %s",ProcessPid);
        if(ERR_COMMON_FAILED==HC_LinuxSystem(killCommand,pcBackBuf))
        {

            return ERR_COMMON_FAILED;
        }


    }
    if(fpRead!=NULL)
        pclose(fpRead);
    return ERR_COMMON_SUCCESS;
}
//进程监控函数
int HC_ProcessMointor( const char* pcProcessName)
{
    char pcCommand[512]={0};

    FILE *fpRead;
    char buf[1025];
    sprintf(pcCommand,"ps -fe|grep   %s  |grep -v grep",pcProcessName);
    fpRead = popen(pcCommand, "r");
    if(fpRead==NULL)
        return ERR_COMMON_FAILED;

    memset(buf,'\0',sizeof(buf));
    if(fgets(buf,1024-1,fpRead)==NULL)
    {
        //if(strlen(buf)==0)
        return ERR_COMMON_FAILED;
    }
    if(fpRead!=NULL)
        pclose(fpRead);
    return ERR_COMMON_SUCCESS;
}
//内存清理释放函数
void  HC_FreeMemory(void)
{
    char pcCommand[512]={0};
    FILE *fpRead;
    char buf[1025];
    sprintf(pcCommand,"echo 3 > /proc/sys/vm/drop_caches");
    fpRead = popen(pcCommand, "r");
    if(fpRead==NULL)
        return ;

    memset(buf,'\0',sizeof(buf));
    fgets(buf,1024-1,fpRead);
    if(fpRead!=NULL)
        pclose(fpRead);
    return ;
}
//获取系统时间函数
// 返回时间结构体
St_SystemTime * HCGetTime(void)
{
    char timenuf[256]={0};
    struct timespec time;
    clock_gettime(CLOCK_REALTIME, &time);  //获取相对于1970到现在的秒数
    struct tm nowTime;
    localtime_r(&time.tv_sec, &nowTime);
    St_SystemTime *SystemTime=(St_SystemTime *)timenuf;
    SystemTime->tm_year=nowTime.tm_year + 1900;
    SystemTime->tm_mon=nowTime.tm_mon+1;
    SystemTime->tm_mday=nowTime.tm_mday;
    SystemTime->tm_hour=nowTime.tm_hour;
    SystemTime->tm_min=nowTime.tm_min;
    SystemTime->tm_sec=nowTime.tm_sec;
    return SystemTime;
}

//设置文件保存时间函数
//输入文件保存路径,和保存的时间
//输出保存本地文件名的路径
//成功返回0，失败返回-1
int HCFileTimeSave(char *path,char *ID,int min,char *pcBackBuf)
{
    char LocalFilePath[128]={0};
    char DeleteFilePath[128]={0};
    char LocalTime[128]={0};
    char backbuf[512]={0};
    char pcCmdbuf[512]={0};
    char Filename[512]={0};
    int  TimeBefor=0,TimeNow=0;
    int ReadFd=0,WriteFd=0;
    memset(pcBackBuf,0x0,512);
    time_t transmit_timestamp;
    strcpy(LocalFilePath,path);
    strcat(LocalFilePath,ID);
    strcat(LocalFilePath,"/");
    strcpy(DeleteFilePath,path);
    strcat(DeleteFilePath,ID);
    strcat(DeleteFilePath,"/");
    /**********获取本地时间戳**********/
    struct tm *p;
    time(&transmit_timestamp);
    p=localtime(&transmit_timestamp);
    transmit_timestamp= mktime(p);
    ReadFd = open(LocalFilePath, O_RDWR);
    if (ReadFd < 0)
    {

        if(HC_fileOpen(&WriteFd, LocalFilePath, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }

    /**********检查文件存不存在，不存在则创建**********/
    sprintf(pcCmdbuf,"ls -S %s ",LocalFilePath);
    if(HC_LinuxSystem(pcCmdbuf,backbuf)!=ERR_COMMON_SUCCESS){
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    if(strlen(backbuf)!=0){
        memcpy(Filename,backbuf,strlen(backbuf)-1);
        TimeBefor=atoi(Filename);
        strcat(DeleteFilePath,Filename);
        strcat(DeleteFilePath,"/");
        /**********文件夹保存时间**********/
        sprintf(LocalTime,"%ld",transmit_timestamp);
        TimeNow=atoi(LocalTime);

        if((TimeNow-TimeBefor>min*60)&&(TimeBefor!=0))
        {
            memset(pcCmdbuf,0x0,strlen(pcCmdbuf));
            memset(backbuf,0x0,strlen(backbuf));
            sprintf(pcCmdbuf,"rm -rf  %s ",DeleteFilePath);
            if(HC_LinuxSystem(pcCmdbuf,backbuf)!=ERR_COMMON_SUCCESS){
                close(ReadFd);
                close(WriteFd);
                return ERR_COMMON_FAILED;
            }
            goto mkdirfile;
        }
        else {
            memcpy(pcBackBuf,DeleteFilePath,strlen(DeleteFilePath));
            close(ReadFd);
            close(WriteFd);
        }
    }
    else
    {
        goto mkdirfile;
    }
mkdirfile:
    memset(pcCmdbuf,0x0,strlen(pcCmdbuf));
    memset(backbuf,0x0,strlen(backbuf));
    sprintf(pcCmdbuf,"ls -S %s ",LocalFilePath);
    if(HC_LinuxSystem(pcCmdbuf,backbuf)!=ERR_COMMON_SUCCESS){
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    if(strlen(backbuf)==0)
    {
        memset(pcCmdbuf,0x0,strlen(pcCmdbuf));
        memset(backbuf,0x0,strlen(backbuf));
        memset(Filename,0x0,strlen(Filename));
        sprintf(pcCmdbuf,"mkdir  %s%ld ",LocalFilePath,transmit_timestamp);
        sprintf(Filename,"%s%ld/",LocalFilePath,transmit_timestamp);
        if(HC_LinuxSystem(pcCmdbuf,backbuf)!=ERR_COMMON_SUCCESS){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
        memcpy(pcBackBuf,Filename,strlen(Filename));
    }
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;

}
//字符截取函数
void substr(char *source,int start,int length,char *dest)
{
    int i;
    int j=0;
    char *p;
    p = source;
    for(i=start;i<start+length;i++)//从第n-1位置开始，截取m个字符
        dest[j++] = *(p+i);
    dest[j] = '\0';
}
// 获取时间戳函数 直接返回时间戳
long HC_LocalTimeGet()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    long time=tv.tv_sec*1000 + tv.tv_usec/1000;
    return time;
}
// 文件拷贝函数
int HCFileCopy(char *source,char *dist)
{
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    int ReadFd=0,WriteFd=0;
    HC_ASSERT(dist);
    ReadFd = open(dist, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, dist, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    sprintf(pcCmdbuf,"cp -r %s  %s",source,dist);
    if(HC_LinuxSystem(pcCmdbuf,backbuf)==ERR_COMMON_FAILED)
    {
        close(ReadFd);
        close(WriteFd);
        return ERR_COMMON_FAILED;
    }
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}
int HCOpencvPictureDraw(char *frompath,char *topath,char *text,int xmin,int ymin,int length,int wideth)
{

    char pcCmdbuf[512]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"nohup ./userdata/usr/local/draw -f %s -t %s -s %s -x %d -y %d -l %d -w %d &",frompath,topath,text,xmin,ymin,length,wideth);
    if(HC_LinuxSystem(pcCmdbuf,backbuf)==ERR_COMMON_FAILED)
        return ERR_COMMON_FAILED;
    return ERR_COMMON_SUCCESS;
}

int HCMsgSend(char *file,int line,char *idbuf,char *sendbuf)
{
    STU *mmapfd;
    int writefd = 0;
    char buf[1800]={0};
    memset(buf,0x0,sizeof (buf));
    sprintf(buf,"[HC_PRINT]%s (Line %d):%s",file,line,sendbuf);
    const char * pcFileName="/userdata/usr/local/test.txt";
    //打开文件，失败则创建
    if (-1 == HC_fileOpen(&writefd, pcFileName, O_RDWR | O_CREAT)) {
        return -1;
    }
    //对齐
    if (lseek(writefd, MAPLEN-1, SEEK_SET) < 0)
        perror("lseek");
    if (write(writefd, "\0", 1) < 0)
        perror("write");
    //申请映射
    mmapfd = mmap(NULL, MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED,writefd, 0);

    if (mmapfd == MAP_FAILED)
        perror("mmap");
    char Send_task_info[2048]={0};
    memset(Send_task_info,0x0,sizeof (Send_task_info));
    if(strlen(sendbuf)>sizeof (Send_task_info))
    {
        HC_PRINT("sendbuf is too larger \n");
        return ERR_COMMON_FAILED;
    }
    sprintf(Send_task_info,\
            "{\"idnum\":\"%s\",\"logstring\":\"%s\"}",idbuf,buf);
    close(writefd);
    strncpy(&mmapfd->name[0], Send_task_info, sizeof(Send_task_info));

    munmap(mmapfd, MAPLENG);
    return ERR_COMMON_SUCCESS;
}

char * HCStingOut(char *intbuf)
{
    char buf[2048]={0};
    char temp[2048]={0};
    strcat(buf,intbuf);
    memcpy(temp,&buf[1],strlen(buf)-2);
    char *outbuf=temp;
    return outbuf;
}
static int num=1;
static ST_MqttMmapInfo *mmapfdsend;
void HC_MmapProcess_Server_Init(void)
{


    int ReadFd= 0,WriteFd=0;

    if(strlen(Mmap_Serveradress)!=0)
    {
        //HCRemoveAdress(Mmap_Serveradress[i].filename);
        ReadFd = open(Mmap_Serveradress, O_RDWR);
        if (ReadFd < 0)
        {
            HC_fileOpen(&WriteFd, Mmap_Serveradress, O_RDWR | O_CREAT);
            lseek(WriteFd, MAPLENG-1, SEEK_SET);
            write(WriteFd, "\0", 1);
            //申请映射
            mmapfdsend = mmap(NULL, (size_t)MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
            if ( mmapfdsend == MAP_FAILED)
            {
                HC_PRINT("mmap error\n");

                HCMsgSend(__FILE__,__LINE__,"mqttprocess","mmap error");
                close(ReadFd);
                close(WriteFd);
            }
            close(ReadFd);
            close(WriteFd);

            munmap( mmapfdsend, MAPLENG);
            ReadFd = open(Mmap_Serveradress, O_RDWR);

        }
        mmapfdsend = mmap(NULL, MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
        if ( mmapfdsend == MAP_FAILED)
        {
            HC_PRINT("mmap error\n");
            HCMsgSend(__FILE__,__LINE__,"mqttprocess","mmap error");
            close(ReadFd);
            close(WriteFd);
        }
        close(ReadFd);
        close(WriteFd);
    }
    mmapfdsend->finishflag=0;
    mmapfdsend->time=0;
    memset(mmapfdsend->topic,0x0,sizeof (mmapfdsend->topic));
    memset(mmapfdsend->mqttdata,0x0,sizeof (mmapfdsend->mqttdata));

}
void InitTimer(Timer* timer)
{
    timer->end_time = (struct timeval){0, 0};
}
void countdown_ms(Timer* timer, unsigned int timeout)
{
    struct timeval now;
    gettimeofday(&now, NULL);
    struct timeval interval = {timeout / 1000, (timeout % 1000) * 1000};
    timeradd(&now, &interval, &timer->end_time);
}
char expired(Timer* timer)
{
    struct timeval now, res;
    gettimeofday(&now, NULL);
    timersub(&timer->end_time, &now, &res);
    return res.tv_sec < 0 || (res.tv_sec == 0 && res.tv_usec <= 0);
}
void HC_MmapProcess_Server_Send(char *topic ,char*sendbuf)
{

    Timer timer;
    InitTimer(&timer);
    countdown_ms(&timer, 1000);
    do{

        if(mmapfdsend->finishflag==0)
            break;
    }while(!expired(&timer));
    mmapfdsend->time=num;
    mmapfdsend->finishflag=1;
    sprintf(mmapfdsend->topic,"%s",topic);
    HC_PRINT("topic=%s",mmapfdsend->topic);
    sprintf(mmapfdsend->mqttdata,"%s",sendbuf);
    HC_PRINT("sendbuf=%s",mmapfdsend->mqttdata);
    num++;
    if(num>65530)
    {
        num=1;
    }

}
static  unsigned int thick=0;
unsigned int HC_MQttIdGet( unsigned int start, unsigned int stop)
{
    if(thick<start||thick==start||thick>stop)
    {
        thick= start;
    }
    thick++;
    return thick;

}
