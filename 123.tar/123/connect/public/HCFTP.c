﻿#include "HCFTP.h"
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>


static size_t read_callback(void *ptr, size_t size, size_t nmemb, void *stream)
{
    curl_off_t nread;

    size_t retcode = fread(ptr, size, nmemb, stream);

    nread = (curl_off_t)retcode;

    fprintf(stderr, " We read %" CURL_FORMAT_CURL_OFF_T
            " bytes from file\n", nread);
    return retcode;
}
//FTP数据上传接口
int HCFtpUpload(ST_FTPInfo FTPInfo)
{

    char buf_1 [256]={0};
    char buf_2 [256]={0};
    CURL *curl;
    CURLcode res;
    FILE *hd_src;
    struct stat file_info;
    curl_off_t fsize;
    struct curl_slist *headerlist = NULL;
    char usrpassword[60]={0};
    sprintf(usrpassword,"%s:%s",FTPInfo.Usrname,FTPInfo.PassWord);
    sprintf(buf_1,"RNFR %s",FTPInfo.tempname);
    sprintf(buf_2,"RNTO %s",FTPInfo.filename);
    char remote[512]={0};
    sprintf(remote,"%s%s",FTPInfo.RemoteUrl,FTPInfo.tempname);
    if(stat(FTPInfo.UploadPath, &file_info)) {
        HC_PRINT("Couldn't open '%s': %s\n", FTPInfo.UploadPath, strerror(errno));
        return 1;
    }
    fsize = (curl_off_t)file_info.st_size;

    hd_src = fopen(FTPInfo.UploadPath, "rb");
    /* 初始化 */
    curl_global_init(CURL_GLOBAL_ALL);
    /* 获得curl操作符 */
    curl = curl_easy_init();
    if(curl) {
        /*建立一个传递给libcurl的命令列表 */
        headerlist = curl_slist_append(headerlist, buf_1);
        headerlist = curl_slist_append(headerlist, buf_2);
        curl_easy_setopt(curl, CURLOPT_USERPWD,usrpassword);
        curl_easy_setopt(curl, CURLOPT_PORT, FTPInfo.port);
        /* 使用curl提供的Read功能 */
        curl_easy_setopt(curl, CURLOPT_READFUNCTION, read_callback);
        /* 上传使能 */
        curl_easy_setopt(curl, CURLOPT_UPLOAD, 1L);
        /* 设置特定目标 */
        curl_easy_setopt(curl, CURLOPT_URL, remote);
        /* 传递最后一个FTP命令以在传输后运行 */
        curl_easy_setopt(curl, CURLOPT_POSTQUOTE, headerlist);
        /*指定上传文件 */
        curl_easy_setopt(curl, CURLOPT_READDATA, hd_src);
        /*设置要上传的文件的大小（可选） */
        curl_easy_setopt(curl, CURLOPT_INFILESIZE_LARGE,
                         (curl_off_t)fsize);
        curl_easy_setopt(curl, CURLOPT_FTP_CREATE_MISSING_DIRS, 1L);
        /* 运行 */
        res = curl_easy_perform(curl);
        /* 容错处理 */
        if(res != CURLE_OK){
            fprintf(stderr, "curl_easy_perform() failed: %s\n",
                    curl_easy_strerror(res));
            HCFtpdelete(FTPInfo);
           //  HCMsgSend(66,"/errorupload","all",HCDebugInformation(stderr->_IO_buf_base));
            return -1;
        }

        /* 清除FTP命令列表 */
        curl_slist_free_all(headerlist);
        /*释放所有curl资源 */
        curl_easy_cleanup(curl);
    }
    fclose(hd_src); /*关闭本地文件 */

    /*释放所有curl资源 */
    curl_global_cleanup();
    return 0;
}
struct FtpFile {
    const char *filename;
    FILE *stream;
};

static size_t my_fwrite(void *buffer, size_t size, size_t nmemb, void *stream)
{
    struct FtpFile *out = (struct FtpFile *)stream;
    if(out && !out->stream) {
        /* 打开文件以进行写操作 */
        out->stream = fopen(out->filename, "wb");
        if(!out->stream)
            return -1; /* failure, can't open file to write */
    }
    return fwrite(buffer, size, nmemb, out->stream);
}
char  HCFtpdelete(ST_FTPInfo FTPInfo)
{
    CURL *curl;
    CURLcode res;
    struct curl_slist *headerlist = NULL;
     char buf_2 [256] = {0};
    sprintf(buf_2,"rm  %s",FTPInfo.tempname);
    char usrpassword[60]={0};
    sprintf(usrpassword,"%s:%s",FTPInfo.Usrname,FTPInfo.PassWord);
    curl = curl_easy_init();
    if(curl) {
     /*建立一个传递给libcurl的命令列表 */
    headerlist = curl_slist_append(headerlist, buf_2);
    curl_easy_setopt(curl, CURLOPT_URL, FTPInfo.RemoteUrl );
    curl_easy_setopt(curl, CURLOPT_PORT, FTPInfo.port);
    curl_easy_setopt(curl, CURLOPT_USERPWD,usrpassword);
    /* 传递最后一个FTP命 */
    curl_easy_setopt(curl, CURLOPT_POSTQUOTE, headerlist);

    curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
    res = curl_easy_perform(curl);
    /* 容错处理 */
    if(res != CURLE_OK)
   {
         fprintf(stderr, "curl_easy_perform() failed: %s\n\r", curl_easy_strerror(res));

         fprintf(stderr, "curl told us %d\n\r", res);
   }

    /* 清除FTP命令列表 */
    curl_slist_free_all(headerlist);
    curl_easy_cleanup(curl);
   }
   return res;
}
//FTP数据下载接口
int HCFtpDownLoad(ST_FTPInfo FTPInfo)
{

    CURL *curl;
    CURLcode res;
    struct FtpFile ftpfile = {
        FTPInfo.DownLoadPath,
                NULL
    };
    char usrpassword[60]={0};
    sprintf(usrpassword,"%s:%s",FTPInfo.Usrname,FTPInfo.PassWord);
    curl_global_init(CURL_GLOBAL_DEFAULT);

    curl = curl_easy_init();
    if(curl) {
        curl_easy_setopt(curl, CURLOPT_USERPWD,usrpassword);
        curl_easy_setopt(curl, CURLOPT_PORT, FTPInfo.port);
        curl_easy_setopt(curl, CURLOPT_URL,  FTPInfo.RemoteUrl);//下载指定的文件
        /* 定义回调函数，以便在需要写入数据时进行调用 */
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, my_fwrite);
        /*设置一个指向我们的结构的指针传递给回调函数*/
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &ftpfile);
        /* 打开完整的协议/调试输出*/
        curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
        res = curl_easy_perform(curl);
        /* 释放所有curl资源*/
        curl_easy_cleanup(curl);

        if(CURLE_OK != res) {
            /*容错处理 */
            fprintf(stderr, "curl told us %d\n", res);
        }
    }

    if(ftpfile.stream)
        fclose(ftpfile.stream); /* 关闭本地文件 */
    /*释放所有curl资源*/
    curl_global_cleanup();

    return 0;
}
