﻿#ifndef HCFTP_H
#define HCFTP_H
#include "common.h"

#pragma pack (1)

typedef struct
{
  char * filename;  //文件名
  char * tempname;  //缓存文件名
  char *UploadPath;  //本地上传文件地址
  char *RemoteUrl;   //远程文件地址
  char *DownLoadPath; //本地文件下载地址
  char *Usrname;   //登陆用户名
  char *PassWord; //登录密码
  int   port ;//端口

}ST_FTPInfo;
#pragma pack ()

extern int HCFtpUpload(ST_FTPInfo FTPInfo);
extern int HCFtpDownLoad(ST_FTPInfo FTPInfo);
extern char  HCFtpdelete(ST_FTPInfo FTPInfo);
#endif
