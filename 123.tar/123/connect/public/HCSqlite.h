﻿
#ifndef HCSQLITE_H
#define HCSQLITE_H
#include "common.h"
#include <sqlite3.h>
#define DATABASE_PATH   "/oem/config/"
#define DATABASE_NAME    DATABASE_PATH "ultwiz.db"  //数据库文件所在的绝对地址
#define JPURNAL_PATH     "/mnt/sdcard/journal/"
//#define JOURNAL_NAME     JPURNAL_PATH "journal.db" //日志文件所在的绝对地址
#define JOURNAL_TABLE_NAME "journal"
#define VIDEO_TABLE_NAME "video"
#define TASK_TABLE_NAME "task"
#define SQL_SIZE 2048           //sql语句最大字节长度
#define MAXTaskNum   3    //同时跑的最大任务数
#define MAXVideoNum   20    //最大视频通道数
#pragma pack (1)
//视频表格结构体
typedef struct
{
    short id; //视频id
    char rtsp[512]; //视频流地址
    char codec_name[10];//视频码流格式
    short width; //视频长度
    short heght; //视频宽度
    short pic_fmt;
    short bitrate;
    char name[50];  //视频名称
}ST_TransVideo;

typedef struct
{
    ST_TransVideo VideoNum[MAXVideoNum];//最大视频通道数
}ST_TransVideoTotal;
//任务表格结构体
typedef struct
{
    short id; //任务id
    short video_id; //视频id
    char analysisType[6];//分析类型
    char interal[6];
    char name[50]; //任务名
    short xmin;//画宽起始位置x轴最小值
    short ymin;//画框起使位置Y轴最小值
    short width;//宽度
    short height;//长度
    char filter[6];
    short status;//状态

}ST_TransTask;
typedef struct
{
    ST_TransTask TaskNum[MAXTaskNum];//最大支持3个任务
}ST_TransTaskToal;

typedef struct
{
    short video_id; //视频id
    char  MmapAdress[100]; //映射地址（视频名_mmap.hc）格式
    char rtspadress[256];
}ST_MmapAdress;
typedef struct
{
    ST_MmapAdress MmapAdressNum[MAXTaskNum];//最大支持3个任务
}ST_MmapAdressToal;
//日志管理信息
typedef struct
{
    char *EventType;// 事件类型
    char *Time;     //时间
    char *EventLevel;  //事件等级
    char *EventDescription; //事件描述
}ST_Journal;
//远程升级信息
typedef struct
{
    char *FileName; //升级文件名
    char *UpgradeFlag; //升级标志位
    char *NetWork; //网络传输方式
    char *UserName; //用户名
    char *Password;  //密码
    int  S_PortNum;//端口
    char *RemFilePath; //远程路径


}ST_Remoteupgrade;

#pragma pack()

extern ST_TransVideoTotal transvideototal;
extern ST_TransTaskToal transtasktotal;
extern ST_MmapAdressToal mmapadresstol;
extern sqlite3 *db;
extern sqlite3 *db2;
extern sqlite3 *db3;
extern ST_Journal  Journal;
extern ST_Remoteupgrade Remoteupgrade;
extern int HCReadInfor(char* tablename,int opt,int id);
extern int HCVideoCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, char** columnName);
extern int HCTaskCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, char** columnName);
extern int HCDatabaseInit(const char *path);
extern int HCTableInit(const char *path,char* tablename);
extern int HCDataisExists(const char* path,char *tablename,int id);
extern int HCTable_is_exists(char * tablename);
extern int HCAddJournal(const char* path,ST_Journal  Journal);

#endif



