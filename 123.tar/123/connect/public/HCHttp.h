﻿#ifndef HCHTTP_H
#define HCHTTP_H
#include "common.h"
#pragma pack (1)
typedef struct
{
    char *filename;    //上传的文件名
    char *UploadPath;  //本地上传文件地址
    char *RemoteUrl;   //远程文件地址
    char *DownLoadPath; //本地文件下载地址
    char *Usrname;   //登陆用户名
    char *PassWord; //登录密码
    int   port ;//端口
}ST_HTTPInfo;
#pragma pack()
extern int HCHttpUpLoad(ST_HTTPInfo HTTPInfo, char *pspathname,char *bucket);
extern int HCHttpDownLoad(ST_HTTPInfo HTTPInfo);
//extern ST_HTTPInfo HTTPInfo;
#endif
