﻿#ifndef HCMODBUS_H
#define HCMODBUS_H
#include "common.h"
#include "modbus/modbus.h"

extern int HCModbusOutput(char * equipment,int adress,uint16_t signle);
extern int HCModbusInRead(int adress,int nq,uint16_t* tab_rq_bit);
#endif
