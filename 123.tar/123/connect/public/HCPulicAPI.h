﻿#ifndef HCPULICAPI_H
#define HCPULICAPI_H
#include "common.h"
#include <pthread.h>
#include"public/HCPublicStruct.h"

#define MAPLENG  0x10000  //日志上传映射大小
#pragma pack(1)
typedef  struct
{
    char name[20000];
}STU;
typedef struct Timer Timer;

struct Timer {
    struct timeval end_time;
};
#pragma pack()
extern int HC_LinuxSystem( const char* pcCommand,  char *pcBackBuf);
extern int HC_LinuxKillProcess( const char* pcProcessName);
extern  int HC_ProcessMointor( const char* pcProcessName);
extern void  HC_FreeMemory(void);
extern int HC_PthreadCreate(pthread_t ThreadID,void *Process_Thread);
extern int HC_MQTTPthreadCreate(pthread_t ThreadID,void *Process_Thread);
extern St_SystemTime * HCGetTime(void);
extern int HCFileTimeSave(char *path,char *ID,int min,char *pcBackBuf);
extern void substr(char *source,int start,int length,char *dest);
extern long HC_LocalTimeGet();
extern int HCFileCopy(char *source,char *dist);
extern int HCOpencvPictureDraw(char *frompath,char *topath,char *text,int xmin,int ymin,int length,int wideth);
extern int HCMsgSend(char *file,int line,char *idbuf,char *sendbuf);
extern char * HCStingOut(char *intbuf);
extern void HC_MmapProcess_Server_Init(void);
extern void InitTimer(Timer* timer);
extern void countdown_ms(Timer* timer, unsigned int timeout);
extern char expired(Timer* timer);
extern void HC_MmapProcess_Server_Send(char *topic ,char*sendbuf);
extern char Mmap_Serveradress[256];
extern unsigned int HC_MQttIdGet( unsigned int start, unsigned int stop);
#endif
