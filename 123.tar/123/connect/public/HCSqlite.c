﻿#include"public/HCSqlite.h"
static int VideoNum=0;
static int TaskNum=0;
ST_TransVideoTotal transvideototal;
ST_TransTaskToal transtasktotal;
ST_MmapAdressToal mmapadresstol;
sqlite3 *db;
sqlite3 *db2;

//查看视频数据库回调函数
int HCVideoCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    if(VideoNum>MAXVideoNum)
        return ERR_COMMON_FAILED;
    transvideototal.VideoNum[VideoNum].id = (short)atoi(columnValue[0]);
    strcpy(transvideototal.VideoNum[VideoNum].rtsp, columnValue[1]);
    strcpy(transvideototal.VideoNum[VideoNum].codec_name, columnValue[2]);

    transvideototal.VideoNum[VideoNum].width =  (short)atoi(columnValue[3]);
    transvideototal.VideoNum[VideoNum].heght =  (short)atoi(columnValue[4]);
    transvideototal.VideoNum[VideoNum].pic_fmt =  (short)atoi(columnValue[5]);
    transvideototal.VideoNum[VideoNum].bitrate =  (short)atoi(columnValue[6]);
    strcpy(transvideototal.VideoNum[VideoNum].name, columnValue[7]);

    VideoNum++;

    return ERR_COMMON_SUCCESS;
}
//查看任务数据库回调函数
int HCTaskCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    if(TaskNum>MAXTaskNum)
        return ERR_COMMON_FAILED;
    transtasktotal.TaskNum[TaskNum].id = (short) atoi(columnValue[0]);
    transtasktotal.TaskNum[TaskNum].video_id=  (short)atoi(columnValue[1]);
    strcpy(transtasktotal.TaskNum[TaskNum].analysisType, columnValue[2]);
    strcpy(transtasktotal.TaskNum[TaskNum].interal, columnValue[3]);
    strcpy(transtasktotal.TaskNum[TaskNum].name, columnValue[4]);
    transtasktotal.TaskNum[TaskNum].xmin= (short)atoi(columnValue[5]);
    transtasktotal.TaskNum[TaskNum].ymin= (short)atoi(columnValue[6]);
    transtasktotal.TaskNum[TaskNum].width= (short)atoi(columnValue[7]);
    transtasktotal.TaskNum[TaskNum].height= (short)atoi(columnValue[8]);
    strcpy(transtasktotal.TaskNum[TaskNum].filter, columnValue[9]);
    transtasktotal.TaskNum[TaskNum].status= (short)atoi(columnValue[10]);
    TaskNum++;

    return ERR_COMMON_SUCCESS;
}


/*****************************************************************************
* @input   : tablename 想要查看的表格名                                      *
* @output  :  0 成功显示所有信息                                             *
*            -1 表格不存在                                                   *                                  *
* @brief   : 完整或部分显示（打印）表格内容                                  *
*****************************************************************************/
int HCReadInfor(char* tablename,int opt,int id)
{//根据传入的表名显示表格内容
    char* errmsg;
    int rc;
    char sql[SQL_SIZE];

    rc = sqlite3_open(DATABASE_NAME, &db);
    if (rc) {

        sqlite3_close(db);
        return ERR_COMMON_FAILED;
    }
    if (opt == 0) {//正常查询
        sprintf(sql, "select * from '%s';", tablename);
    }
    else if (opt == 1) {//最新添加
        sprintf(sql, "select * from '%s' where id = ( select max(id) from '%s');", tablename, tablename);
    }
    else if (opt == 2){//更新内容
        sprintf(sql, "select * from '%s' where id = %d;", tablename,id);
    }
    if(strcmp(tablename,VIDEO_TABLE_NAME)==0){
        rc = sqlite3_exec(db, sql, HCVideoCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {
            VideoNum=0;
            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    else if(strcmp(tablename,TASK_TABLE_NAME)==0) {
        rc = sqlite3_exec(db, sql, HCTaskCallback, NULL, &errmsg);

        if(rc != SQLITE_OK)
        {
            TaskNum=0;
            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    VideoNum=0;
    TaskNum=0;
    sqlite3_close(db);
    return ERR_COMMON_SUCCESS;
}
int HCDatabaseInit(const char *path)
{//判断数据库是否存在，不存在时则创建
    int rc;
    HC_ASSERT(path);
    if(path==NULL)
        return -1;
    int ReadFd=0;
    int WriteFd=0;
    ReadFd = open(path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    rc = sqlite3_open(path, &db2);
    if (rc) {
        //printf("open database failed\n");
        sqlite3_close(db2);
        close(ReadFd);
        close(WriteFd);
        return -1;
    }
    else {
        //printf("open database successed\n");
    }
    sqlite3_close(db2);
    close(ReadFd);
    close(WriteFd);
    return 0;
}

int HCTableInit(const char *path,char* tablename)
{//判断表是否存在，不存在则创建
    char* errmsg;
    int rc;
    char sql[SQL_SIZE];
    HC_ASSERT(path);
    if(path==NULL)
        return -1;
    int ReadFd=0;
    int WriteFd=0;
    ReadFd = open(path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    if(strlen(tablename)==0)
    {
        close(ReadFd);
        close(WriteFd);
        return -1;
    }

    rc = sqlite3_open(path, &db2);
    if (rc) {
        //printf("open failed\n");
        sqlite3_close(db2);
        close(ReadFd);
        close(WriteFd);
        return -1;
    }
    sqlite3_limit(db2, SQLITE_LIMIT_COLUMN,20);
    if (strcmp(tablename, JOURNAL_TABLE_NAME) == 0){
        sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(事件类型 varchar, 时间 varchar, 事件等级 varchar,  事件描述 varchar);", JOURNAL_TABLE_NAME);

        rc = sqlite3_exec(db2, sql, NULL, NULL, &errmsg);
        sqlite3_close(db2);
        close(ReadFd);
        close(WriteFd);
        return 0;
    }


    sqlite3_close(db2);
    close(ReadFd);
    close(WriteFd);
    return -1;
}


int HCTable_is_exists(char * tablename)
{//根据tablename判断某一张表格是否存在
    char* errmsg;
    int rc;
    char** dbResult; //是 char ** 类型，两个*号
    int nRow = 0, nColumn = 0;
    char sql[SQL_SIZE];
    rc = sqlite3_open(DATABASE_NAME, &db2);
    if (rc) {
        //printf("open database failed\n");
        sqlite3_close(db2);
        return -2;
    }

    sprintf(sql, "select * from sqlite_master where name = '%s';", tablename);
    rc = sqlite3_get_table(db2, sql, &dbResult, &nRow, &nColumn, &errmsg);
    if (nRow > 0)
    {
        //printf("查询到结果\n");
        sqlite3_free_table(dbResult);
        sqlite3_close(db2);
        return 0;
    }
    else
    {
        //printf("数据库中没有name为%s的记录\n",tablename);
        sqlite3_free_table(dbResult);
        sqlite3_close(db2);

        return -1;
    }
}
int HCAddJournal(const char* path,ST_Journal  Journal)
{
    char* errmsg;
    int rc;
    char sql[SQL_SIZE];
    HC_ASSERT(path);
    if(path==NULL)
        return -1;
    int ReadFd=0;
    int WriteFd=0;
    ReadFd = open(path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }

    rc = sqlite3_open(path, &db2);
    if (rc) {
        //printf("open databade failed\n");
        sqlite3_close(db2);
        close(ReadFd);
        close(WriteFd);
        return -2;
    }
    sprintf(sql,"insert into %s values( \"%s\" , \"%s\" , \"%s\" , \"%s\");", JOURNAL_TABLE_NAME, Journal.EventType,Journal.Time,Journal.EventLevel,Journal.EventDescription);
    rc = sqlite3_exec(db2, sql, NULL, NULL, &errmsg);
    if (!rc)
    {

        sqlite3_close(db2);
        close(ReadFd);
        close(WriteFd);
        return 0;
    }
    sqlite3_close(db2);
    close(ReadFd);
    close(WriteFd);
    return -1;
}
int HCDataisExists(const char* path,char *tablename,int id)
{//判断某一条记录是否存在

    char* errmsg;
    int rc;
    char** dbResult; //是 char ** 类型，两个*号
    int nRow = 0, nColumn = 0;
    char sql[2048];
    HC_ASSERT(path);
    int ReadFd=0;
    int WriteFd=0;
    ReadFd = open(path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    if(path==NULL)
    {
        HC_PRINT("path is null\n");
        close(ReadFd);
        close(WriteFd);
        return -1;
    }
    sprintf(sql, "select * from %s where id = %d;", tablename, id);
    rc = sqlite3_open(path, &db);
    if (rc) {
        //printf("open database failed\n");
        sqlite3_close(db);
        close(ReadFd);
        close(WriteFd);
        return -2;
    }
    rc = sqlite3_get_table(db, sql, &dbResult, &nRow, &nColumn, &errmsg);
    if(nRow > 0)
    {
        HC_PRINT("查询到结果\n");
        sqlite3_free_table(dbResult);
        sqlite3_close(db);
        close(ReadFd);
        close(WriteFd);
        return 0;
    }
    else
    {
        HC_PRINT("表格中没有id为的记录\n");
        sqlite3_free_table(dbResult);
        sqlite3_close(db);
        close(ReadFd);
        close(WriteFd);
        return -1;
    }
}
