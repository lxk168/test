﻿#include "init.h"


void  HC_Init(void)
{
    HCApppStart_Init();
}
