﻿#include "HCAppStart.h"
#include "public/HCHttp.h"
#include "application/HCBusiness.h"
#include "public/HCProfileUtil.h"
#include "hmacsha256/HMACSHA.h"
ST_RemoteupgradeTopic RemoteupgradeTopic;

//初始化
void HCAppStart_Init(void)
{

    pthread_t t0=0,t1=0;
    HC_MmapProcess_Server_Init();
    HCMqtttopicGenerate();
    HC_PthreadCreate(t0,HC_MQTTSubProcess_Thread);
    // HC_PthreadCreate(t1,HCTimethickProcess);
    usleep(500000);
    HC_UpLoadVersion("application",APPLICATION_VERSION);
    usleep(100000);
    HC_UpLoadVersion("algorithm",ALGORITHM_VERSION);
    usleep(100000);
    HC_UpLoadVersion("library",LIBRARY_VERSION);

}

void *HCTimethickProcess(void)
{

    while (1) {
        sleep(1);

    }
}
void HCMqtttopicGenerate()
{
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    char topicbuf[2000]={0};
    char *ptr=NULL;
    int num=0;
    char valuebuf[20]={0};
    int ReadFd=0,WriteFd=0;
    ST_RemoteupgradeTopic remoteupgradeTopic;
    remoteupgradeTopic.informtopic=(char *)malloc(1024*sizeof (char));
    remoteupgradeTopic.upgradetopic_reply=(char *)malloc(1024*sizeof (char));
    remoteupgradeTopic.processtopic=(char *)malloc(1024*sizeof (char));
    remoteupgradeTopic.firwaregettopic=(char *)malloc(1024*sizeof (char));
    remoteupgradeTopic.firewareget_reply=(char *)malloc(1024*sizeof (char));
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);

    sprintf(topicbuf,"/ota/device/inform/%s/%s",ThingCategoryKeybuf,DeviceName);
    strcpy(remoteupgradeTopic.informtopic,topicbuf);
    sprintf(topicbuf,"/ota/device/upgrade/%s/%s",ThingCategoryKeybuf,DeviceName);
    strcpy(remoteupgradeTopic.upgradetopic_reply,topicbuf);
    sprintf(topicbuf,"/ota/device/progress/%s/%s",ThingCategoryKeybuf,DeviceName);
    strcpy(remoteupgradeTopic.processtopic,topicbuf);
    sprintf(topicbuf,"/ota/%s/%s/firmware/get",ThingCategoryKeybuf,DeviceName);
    strcpy(remoteupgradeTopic.firwaregettopic,topicbuf);
    sprintf(topicbuf,"/ota/%s/%s/firmware/get_reply",ThingCategoryKeybuf,DeviceName);
    strcpy(remoteupgradeTopic.firewareget_reply,topicbuf);

    memcpy(&RemoteupgradeTopic,&remoteupgradeTopic,sizeof (ST_RemoteupgradeTopic));
    char* topic_path = (char*)"/userdata/usr/local/subtopic.conf";
    char* topic_name = (char*)"mqtt_subtopic";

    ReadFd = open(topic_path, O_RDWR);

    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, topic_path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            system("reboot");
        }
    }
    write_profile_string(topic_name,"","",topic_path);

    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,remoteupgradeTopic.upgradetopic_reply,topic_path);
    num++;
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,remoteupgradeTopic.firewareget_reply,topic_path);
    num++;
    remoteupgradeTopic.informtopic=NULL;

    remoteupgradeTopic.upgradetopic_reply=NULL;
    remoteupgradeTopic.processtopic=NULL;
    remoteupgradeTopic.firwaregettopic=NULL;
    remoteupgradeTopic.firewareget_reply=NULL;
    free(remoteupgradeTopic.informtopic);

    free (remoteupgradeTopic.upgradetopic_reply);
    free (remoteupgradeTopic.processtopic);
    free (remoteupgradeTopic.firwaregettopic);
    free (remoteupgradeTopic.firewareget_reply);
}
int HC_UpLoadVersion(char *module,char *path)
{
    char idbuf[20]={0};
    //请求升级包
    sprintf(idbuf,"%ld",HC_LocalTimeGet());
    char version[20]={0};
    char upcjson[1024]={0};
    strcat(version,HC_VersionGet(path));
    strcat(upcjson,HCVersionReportJson(idbuf,module,version));

    if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.informtopic,upcjson)==ERR_COMMON_FAILED)
    {
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}

void *HC_MQTTSubProcess_Thread(void )
{
    ST_MqttMmapInfo *mmapfd;
    long cmp1=0;
    long cmp2=0;
    int ReadFd= 0,WriteFd=0;
    char *pcFileName="/userdata/usr/local/remoteupgrade_mqtt_client.mmap";
    char version[20]={0};
    char getversion[20]={0};
    //HCRemoveAdress("remoteupgrade_mqtt_client.mmap");
    ReadFd = open(pcFileName, O_RDWR);
    if (ReadFd < 0)
    {
        HC_fileOpen(&WriteFd, pcFileName, O_RDWR | O_CREAT);
        lseek(WriteFd, MAPLENG-1, SEEK_SET);
        write(WriteFd, "\0", 1);
        //申请映射
        mmapfd = mmap(NULL, (size_t)MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
        if ( mmapfd == MAP_FAILED)
        {
            HC_PRINT("mmap error\n");

            //HCMsgSend(__FILE__,__LINE__,"upgrade","mmap error");
            close(ReadFd);
            close(WriteFd);
        }
        close(ReadFd);
        close(WriteFd);

        munmap( mmapfd, MAPLENG);
        ReadFd = open(pcFileName, O_RDWR);

    }


    mmapfd = mmap(NULL, MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
    if ( mmapfd == MAP_FAILED)
    {
        HC_PRINT("mmap error\n");
        // HCMsgSend(__FILE__,__LINE__,"all","mmap error");
        close(ReadFd);
        close(WriteFd);
    }
    close(ReadFd);
    close(WriteFd);
    mmapfd->finishflag=0;
    mmapfd->time=0;


    while (1){

        cmp2=mmapfd->time;

        if(cmp1!=cmp2)
        {
            HC_PRINT("topic=%s\n",mmapfd->topic);
            HC_PRINT("data=%s\n",mmapfd->mqttdata);
            cmp1=cmp2;
            if(strlen(mmapfd->topic)!=0)
            {
                if(strcmp(mmapfd->topic,RemoteupgradeTopic.upgradetopic_reply)==0)
                {


                    RemoteupgradeInfo=RemoteupgradeCjsonAnalysis(mmapfd->mqttdata);
                    if(strcmp(RemoteupgradeInfo.message,"success")==0)
                    {
                        if(strcmp(RemoteupgradeInfo.module,"se.gateway.application")==0)
                        {
                            memset(version,0x0,sizeof (version));
                            memset(getversion,0x0,sizeof (getversion));
                            strcat(version,HC_VersionGet(APPLICATION_VERSION));
                            strcat(getversion,RemoteupgradeInfo.version);
                            ST_Version VersionNow;
                            memset(&VersionNow,0x0,sizeof (ST_Version));
                            VersionNow.hight=atoi(&version[0]);
                            VersionNow.medium=atoi(&version[2]);
                            VersionNow.low=atoi(&version[4]);
                            ST_Version VersionGet;
                            memset(&VersionGet,0x0,sizeof (ST_Version));
                            VersionGet.hight=atoi(&getversion[0]);
                            VersionGet.medium=atoi(&getversion[2]);
                            VersionGet.low=atoi(&getversion[4]);
                            if(VersionGet.hight>VersionNow.hight)
                            {
                                HCRemoteApplication();
                            }
                            else if (VersionGet.medium>VersionNow.medium) {
                                HCRemoteApplication();
                            }
                            else if (VersionGet.low>VersionNow.low) {
                                HCRemoteApplication();
                            }
                            else {
                                HCVersionErrorInfo();
                                usleep(100000);
                                HC_UpLoadVersion("application",APPLICATION_VERSION);


                            }

                        }
                        else if(strcmp(RemoteupgradeInfo.module,"se.gateway.algorithm")==0)
                        {
                            memset(version,0x0,sizeof (version));
                            memset(getversion,0x0,sizeof (getversion));
                            strcat(version,HC_VersionGet(ALGORITHM_VERSION));
                            strcat(getversion,RemoteupgradeInfo.version);
                            ST_Version VersionNow;
                            memset(&VersionNow,0x0,sizeof (ST_Version));
                            VersionNow.hight=atoi(&version[0]);
                            VersionNow.medium=atoi(&version[2]);
                            VersionNow.low=atoi(&version[4]);
                            ST_Version VersionGet;
                            memset(&VersionGet,0x0,sizeof (ST_Version));
                            VersionGet.hight=atoi(&getversion[0]);
                            VersionGet.medium=atoi(&getversion[2]);
                            VersionGet.low=atoi(&getversion[4]);
                            if(VersionGet.hight>VersionNow.hight)
                            {
                                Remotealgorithm();
                            }
                            else if (VersionGet.medium>VersionNow.medium) {
                                Remotealgorithm();
                            }
                            else if (VersionGet.low>VersionNow.low) {
                                Remotealgorithm();
                            }
                            else {
                                HCVersionErrorInfo();
                                usleep(100000);
                                HC_UpLoadVersion("algorithm",ALGORITHM_VERSION);

                            }

                        }
                        else if(strcmp(RemoteupgradeInfo.module,"se.gateway.library")==0)
                        {
                            memset(version,0x0,sizeof (version));
                            memset(getversion,0x0,sizeof (getversion));
                            strcat(version,HC_VersionGet(LIBRARY_VERSION));
                            strcat(getversion,RemoteupgradeInfo.version);
                            ST_Version VersionNow;
                            memset(&VersionNow,0x0,sizeof (ST_Version));
                            VersionNow.hight=atoi(&version[0]);
                            VersionNow.medium=atoi(&version[2]);
                            VersionNow.low=atoi(&version[4]);
                            ST_Version VersionGet;
                            memset(&VersionGet,0x0,sizeof (ST_Version));
                            VersionGet.hight=atoi(&getversion[0]);
                            VersionGet.medium=atoi(&getversion[2]);
                            VersionGet.low=atoi(&getversion[4]);
                            if(VersionGet.hight>VersionNow.hight)
                            {
                                HCRemoteuplibrary();
                            }
                            else if (VersionGet.medium>VersionNow.medium) {
                                HCRemoteuplibrary();
                            }
                            else if (VersionGet.low>VersionNow.low) {
                                HCRemoteuplibrary();
                            }
                            else {
                                HCVersionErrorInfo();
                                usleep(100000);
                                HC_UpLoadVersion("library",LIBRARY_VERSION);

                            }

                        }
                        else {
                            char upcjson[1024]={0};
                            char idprocessbuf[20]={0};
                            sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
                            strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"软件编码错误，请设置正确软件编码！用户程序:se.gateway.application,算法:se.gateway.alogrithm,驱动:se.gateway.library",RemoteupgradeInfo.module,"-1"));
                            if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
                            {
                                HC_PRINT("映射失败");
                            }
                        }
                    }
                }
            }
            else {
                continue;
            }

            mmapfd->finishflag=0;
        }

        usleep(200000);
    }
}
int HCVersionErrorInfo(void)
{
    char upcjson[1024]={0};
    char idprocessbuf[20]={0};
    sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
    strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"软件版本过低",RemoteupgradeInfo.module,"-1"));
    if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
    {
        HC_PRINT("映射失败");
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}
int HCRemoteApplication(void)
{
    if(HCRemoteupgrade(RemoteupgradeInfo)==ERR_COMMON_SUCCESS)
    {

        char idprocessbuf[20]={0};
        char upcjson[1024]={0};
        if((HC_VersionWrite(APPLICATION_VERSION,RemoteupgradeInfo.version))==ERR_COMMON_FAILED)
        {
            HC_PRINT("应用版本写入错误");

        }
        else {
            sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
            strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"application 升级完成",RemoteupgradeInfo.module,"100"));
            if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
            {
                HC_PRINT("映射失败");
            }
            usleep(300000);
            HC_UpLoadVersion("application",APPLICATION_VERSION);
            HCRemoteupgradeAndReboot();

        }
    }
    return ERR_COMMON_SUCCESS;
}
int Remotealgorithm(void)
{
    if(HCRemoteupgrade(RemoteupgradeInfo)==ERR_COMMON_SUCCESS)
    {

        char idprocessbuf[20]={0};
        char upcjson[1024]={0};
        if((HC_VersionWrite(ALGORITHM_VERSION,RemoteupgradeInfo.version))==ERR_COMMON_FAILED)
        {
            HC_PRINT("应用版本写入错误");

        }
        else {
            sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
            strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"algorithm 升级完成",RemoteupgradeInfo.module,"100"));
            if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
            {
                HC_PRINT("映射失败");
            }
            usleep(300000);
            HC_UpLoadVersion("algorithm",ALGORITHM_VERSION);
            HCRemoteupgradeAndReboot();

        }
    }
    return ERR_COMMON_SUCCESS;
}
int HCRemoteuplibrary(void)
{
    if(HCRemoteupgrade(RemoteupgradeInfo)==ERR_COMMON_SUCCESS)
    {

        char idprocessbuf[20]={0};
        char upcjson[1024]={0};
        if((HC_VersionWrite(LIBRARY_VERSION,RemoteupgradeInfo.version))==ERR_COMMON_FAILED)
        {
            HC_PRINT("应用版本写入错误");

        }
        else {
            sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
            strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"library 升级完成",RemoteupgradeInfo.module,"100"));
            if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
            {
                HC_PRINT("映射失败");
            }
            usleep(300000);
            HC_UpLoadVersion("library",LIBRARY_VERSION);
            HCRemoteupgradeAndReboot();

        }
    }
    return ERR_COMMON_SUCCESS;
}
int HCRemoteupgradeAndReboot()
{
    char tarFileName[256]={0};
    char shFileName[256]={0};
    memset(tarFileName,0x0,sizeof (tarFileName));
    strcpy(tarFileName,HCRemoteupgradeFileget(REMOTEUPGRADE_PATH));
    while (strlen(tarFileName)!=0) {
        if(HCRemoteupgradeFile(REMOTEUPGRADE_PATH,tarFileName)==ERR_COMMON_FAILED)
        {

            HC_PRINT("tar  %s is failed ",tarFileName);
            break;
        }
        memset(tarFileName,0x0,sizeof (tarFileName));
        strcpy(tarFileName,HCRemoteupgradeFileget(REMOTEUPGRADE_PATH));
        usleep(500000);
    }
    memset(shFileName,0x0,sizeof (shFileName));
    strcpy(shFileName,HCRemoteupgradeshFileget(REMOTEUPGRADE_PATH));
    while (strlen(shFileName)!=0) {
        if(HCshFileRemoteUpgrade(shFileName)==ERR_COMMON_FAILED)
        {

            HC_PRINT("shfile  %s is failed ",shFileName);
            break;
        }
        memset(shFileName,0x0,sizeof (shFileName));
        strcpy(shFileName,HCRemoteupgradeshFileget(REMOTEUPGRADE_PATH));
        usleep(500000);
    }
    usleep(500000);
    HCChmod_777("/userdata/usr/");
    HCChmod_777("/userdata/model/");
    system("reboot");
    return ERR_COMMON_SUCCESS;
}
//下载远程文件并且更新
int HCRemoteupgrade( ST_RemoteupgradeInfo RemoteupgradeInfo)
{
    int ReadFd=0,WriteFd=0;
    ST_TransInfo HTTPInfo;
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    char upcjson[1024]={0};
    char downloadpath[256]={0};
    char clientIDbuf[512]={0};
    char UserNamebuf[1024]={0};
    char Passwordbuf[1024]={0};
    char keybuf[1024]={0};
    char databuf[1024]={0};
    HCDeleteFileName(REMOTEUPGRADE_PATH);
    ReadFd = open(REMOTEUPGRADE_PATH, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, REMOTEUPGRADE_PATH, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    HCGetProfileString(file_path, app_name, (char*)"MqttClientID", clientIDbuf);
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    HCGetProfileString(file_path, app_name, (char*)"MqttPassWord", keybuf);
    char *ptr=NULL;
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};

    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    strcat(databuf,"clientid");
    strcat(databuf,clientIDbuf);
    strcat(databuf,"DeviceName");
    strcat(databuf,DeviceName);
    strcat(databuf,"ThingCategoryKey");
    strcat(databuf,ThingCategoryKeybuf);
    strcat(Passwordbuf,hmac_sha256_out(databuf,keybuf));
    HTTPInfo.Usrname=UserNamebuf;
    HTTPInfo.PassWord=Passwordbuf;
    HTTPInfo.RemoteUrl=RemoteupgradeInfo.url;

    sprintf(downloadpath,"%s%s.tar",REMOTEUPGRADE_PATH,RemoteupgradeInfo.module);
    HTTPInfo.DownLoadPath=downloadpath;
    if(HCHttpDownLoad( HTTPInfo)==ERR_COMMON_FAILED)
    {
        close(ReadFd);
        close(WriteFd);
        HC_PRINT("download file failed\n");
        //HC_UploadFailed(RemoteupgradeInfo.module);
        return ERR_COMMON_FAILED;
    }
    else
    {
        if(HCChmod_777(downloadpath)==ERR_COMMON_FAILED)
        {
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
        if(strcmp(RemoteupgradeInfo.signMethod,"MD5")==0){
            if(HCFileMD5Check(RemoteupgradeInfo.module,RemoteupgradeInfo.md5)==ERR_COMMON_FAILED)
            {
                close(ReadFd);
                close(WriteFd);
                HC_PRINT("Remoteupgrade  %s is failed ",RemoteupgradeInfo.module);
                return ERR_COMMON_FAILED;
            }
            else
            {
                char idprocessbuf[10]={0};
                sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
                strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"程序解压中",RemoteupgradeInfo.module,"98"));
                if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
                {
                    return ERR_COMMON_FAILED;
                }


            }
        }
        else {
            HC_PRINT("签名方式有误");
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_SUCCESS;
        }

    }

    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}
// MD5检查
int HCFileMD5Check(char *filename,char*md5value)
{
    char md5filename[512]={0};
    char md5buf[1024]={0};
    strcat(md5filename,REMOTEUPGRADE_PATH);
    strcat(md5filename,filename);
    strcat(md5filename,".md5");
    int ReadFd=0;
    int WriteFd=0;
    FILE *udiskfd;
    ReadFd = open(md5filename, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, md5filename, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    udiskfd=fopen(md5filename ,"w");
    sprintf(md5buf,"%s  %s.tar",md5value,filename);

    fprintf(udiskfd,"%s",md5buf);
    fclose(udiskfd);
    char buf[1025]={0};
    char CmdName[256]={0};
    sprintf(CmdName," cd %s && md5sum -c %s.md5 &&echo \"yes\"||echo \"no\"",REMOTEUPGRADE_PATH,filename);
    HC_LinuxSystem(CmdName,buf);
    if(strncmp(buf,"yes",3)==0) {
        HC_PRINT("MD5校正成功!");
    }
    else
    {
        HC_PRINT("MD5校正失败!");
        close(ReadFd);
        close(WriteFd);

        return ERR_COMMON_FAILED;
    }


    close(WriteFd);
    close(ReadFd);
    return ERR_COMMON_SUCCESS;
}
//解压文件
int HCUnzipFileName(char *filename)
{

    char buf[1025]={0};
    char CmdName[256]={0};
    sprintf(CmdName,"cd  %s  && tar xvf %s.tar ",REMOTEUPGRADE_PATH,filename);
    HC_LinuxSystem(CmdName,buf);
    return ERR_COMMON_SUCCESS;
}
//删除文件
int HCDeleteFileName(char *filename)
{
    char buf[1025]={0};
    char CmdName[256]={0};
    sprintf(CmdName,"rm -rf %s",filename);
    HC_LinuxSystem(CmdName,buf);
    return ERR_COMMON_SUCCESS;
}
//获取权限
int HCChmod_777(char *filename)
{
    char buf[1025]={0};
    char CmdName[256]={0};
    sprintf(CmdName,"chmod -R 777 %s",filename);
    HC_LinuxSystem(CmdName,buf);
    return ERR_COMMON_SUCCESS;
}
//解压升级文件
int HCRemoteupgradeFile(char *pathname,char *filename)
{
    char buf[1025]={0};
    char CmdName[512]={0};
    char DeleteName[512]={0};
    char DeleteMD5Name[512]={0};
    if(pathname==NULL)
    {
        return ERR_COMMON_FAILED;
    }
    sprintf(CmdName,"tar xvf  %s%s -C %s ",pathname,filename,pathname);
    HC_LinuxSystem(CmdName,buf);
    if(strcmp(filename,"se.gateway.application.tar")==0)
    {
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"cd %s && cp -r application/* /userdata/usr/local/",pathname);
        HC_LinuxSystem(CmdName,buf);
        memset(DeleteName,0x0,sizeof (DeleteName));
        sprintf(DeleteName,"%s%s/",pathname,"application");
        HCDeleteFileName(DeleteName);
    }
    else if(strcmp(filename,"se.gateway.alogrithm.tar")==0)
    {
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"cd %s && cp -r alogrithm/* /userdata/model/",pathname);
        HC_LinuxSystem(CmdName,buf);
        memset(DeleteName,0x0,sizeof (DeleteName));
        sprintf(DeleteName,"%s%s/",pathname,"alogrithm");
        HCDeleteFileName(DeleteName);
    }
    else if(strcmp(filename,"se.gateway.library.tar")==0){
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"cd %s && cp -r library/* /userdata/usr/lib/",pathname);
        HC_LinuxSystem(CmdName,buf);
        memset(DeleteName,0x0,sizeof (DeleteName));
        sprintf(DeleteName,"%s%s/",pathname,"library");
        HCDeleteFileName(DeleteName);

    }
    memset(DeleteName,0x0,sizeof (DeleteName));
    sprintf(DeleteName,"%s%s",pathname,filename);
    memset(DeleteMD5Name,0x0,sizeof (DeleteMD5Name));
    memcpy(DeleteMD5Name,DeleteName,strlen(DeleteName)-4);
    strcat(DeleteMD5Name,".md5");
    HCDeleteFileName(DeleteName);
    HCDeleteFileName(DeleteMD5Name);
    return ERR_COMMON_SUCCESS;
}
int HCshFileRemoteUpgrade(char*shfilename)
{
    char buf[1025]={0};
    char shfilenamebuf[512]={0};

    char CmdName[512]={0};
    char DeleteName[512]={0};
    strcat(shfilenamebuf,shfilename);

    if(strcmp(shfilenamebuf,"RkEnv.sh")==0)
    {
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"cd %s && cp  RkEnv.sh /etc/profile.d/",REMOTEUPGRADE_PATH);
        HC_LinuxSystem(CmdName,buf);
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"source /etc/profile.d/RkEnv.sh");
        HC_LinuxSystem(CmdName,buf);
        memset(DeleteName,0x0,sizeof (DeleteName));
        sprintf(DeleteName,"%s%s/",REMOTEUPGRADE_PATH," RkEnv.sh");
        HCDeleteFileName(DeleteName);
    }
    else if (strcmp(shfilenamebuf,"S98_auto_boot.sh")==0) {
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"cd %s && cp  S98_auto_boot.sh /etc/init.d/",REMOTEUPGRADE_PATH);
        HC_LinuxSystem(CmdName,buf);
        memset(CmdName,0x0,sizeof (CmdName));
        sprintf(CmdName,"source /etc/init.d/S98_auto_boot.sh");
        HC_LinuxSystem(CmdName,buf);
        memset(DeleteName,0x0,sizeof (DeleteName));
        sprintf(DeleteName,"%s%s/",REMOTEUPGRADE_PATH," S98_auto_boot.sh");
        HCDeleteFileName(DeleteName);
    }
    return ERR_COMMON_SUCCESS;
}
char * HCRemoteupgradeshFileget(const char *pDataRootPath)
{
    char szFileName[128] = {0};
    char tempFileName[128]={0};
    int  ReadFd=0;
    int  WriteFd=0;
    char *ret=tempFileName;
    int res;
    ReadFd = open(pDataRootPath, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pDataRootPath, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ret;
        }
    }
    res = HC_findFile(pDataRootPath, szFileName, ".sh");
    if (ERR_COMMON_FAILED == res)
    {
        close(ReadFd);
        close(WriteFd);
        return ret;
    }

    close(ReadFd);
    close(WriteFd);
    memcpy(tempFileName,&szFileName[strlen(pDataRootPath)],strlen(szFileName)-strlen(pDataRootPath));
    char *temp=tempFileName;
    return temp;
}
char * HCRemoteupgradeFileget(const char *pDataRootPath)
{
    char szFileName[128] = {0};
    char tempFileName[128]={0};
    int  ReadFd=0;
    int  WriteFd=0;
    char *ret=tempFileName;
    int res;
    ReadFd = open(pDataRootPath, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, pDataRootPath, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

            return ret;
        }
    }
    res = HC_findFile(pDataRootPath, szFileName, ".tar");
    if (ERR_COMMON_FAILED == res)
    {
        close(ReadFd);
        close(WriteFd);
        return ret;
    }

    close(ReadFd);
    close(WriteFd);
    memcpy(tempFileName,&szFileName[strlen(pDataRootPath)],strlen(szFileName)-strlen(pDataRootPath));
    char *temp=tempFileName;
    return temp;
}
