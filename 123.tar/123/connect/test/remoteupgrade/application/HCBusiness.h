﻿
#ifndef HCBUSINESS_H
#define HCBUSINESS_H
#include "common.h"
#include "application/HCAppStart.h"
#include "cjson/cJSON.h"
#include "public/HCPublicStruct.h"

extern char *HCVersionReportJson(char *id,char *module ,char *version );
extern char *HCVersionSpeedJson(char *id,char * desc,char *module ,char *progress );
extern char *HCUpgradeFileGetJson(char *id,char *module ,char *method );
extern char *HC_VersionRead(char *vesionFilePath);
extern int HC_VersionWrite(char *vesionFilePath,char *version);
extern ST_RemoteupgradeInfo RemoteupgradeCjsonAnalysis(char *cjsoninput);
extern ST_MqttMmapInfo MqttMmapCjsonAnalysis(char *cjsonbuf);
extern int HC_UploadFailed(char *module);
extern void InitTimer(Timer* timer);
extern void countdown_ms(Timer* timer, unsigned int timeout);
extern char expired(Timer* timer);
extern int HCMQttMsgRead(void);
extern char *HC_VersionGet(char *vesionFilePath);
#endif



