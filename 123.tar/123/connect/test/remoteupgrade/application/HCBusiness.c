﻿#include "application/HCBusiness.h"

ST_RemoteupgradeInfo RemoteupgradeInfo;
//上报版本cjson
char *HCVersionReportJson(char *id,char *module ,char *version )
{

    char Cjsonbuf[1024]={0};
    char *CjsonTemp=NULL;
    if(strlen(id)==0)
    {
        id="";
        HC_PRINT("上报ID是空\n");
    }
    if(strlen(module)==0)
    {
        module="";
        HC_PRINT("上报升级模块是空\n");
    }
    if(strlen(version)==0)
    {
        version="";
        HC_PRINT("上报软件版本是空\n");
    }
    sprintf(Cjsonbuf, "{\"id\":\"%s\",\"params\":{\"module\":\"se.gateway.%s\",\"version\":\"%s\"},\"sys\":{\"foward\":%d}}",id,module,version,1);
    CjsonTemp=Cjsonbuf;

    return CjsonTemp;
}
//上报升级进度
char *HCVersionSpeedJson(char *id,char * desc,char *module ,char *progress )
{
    char Cjsonbuf[1024]={0};
    char *CjsonTemp=NULL;
    sprintf(Cjsonbuf, "{\"id\":\"%s\",\"params\":{\"desc\":\"%s\",\"module\":\"%s\",\"progress\":\"%s\"},\"sys\":{\"foward\":%d}}",id,desc,module,progress,1);
    CjsonTemp=Cjsonbuf;
    return CjsonTemp;
}
//设备请求升级包
char *HCUpgradeFileGetJson(char *id,char *module ,char *method )
{
    char Cjsonbuf[1024]={0};
    char *CjsonTemp=NULL;
    sprintf(Cjsonbuf, "{\"id\":\"%s\",\"params\":{\"module\":\"%s\"},\"method\":\"%s\"}",id,module,method);
    CjsonTemp=Cjsonbuf;
    return CjsonTemp;
}
//版本读取
char *HC_VersionRead(char *vesionFilePath)
{
    char VersionFile[256]={0};
    char version[100]={0};
    char *versiontemp="";
    long len=0;
    int ReadFd=0,WriteFd=0;
    strcat(VersionFile,vesionFilePath);
    ReadFd = open(vesionFilePath, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, vesionFilePath, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return versiontemp;
        }
    }
    FILE *udiskfd;
    udiskfd=fopen(vesionFilePath ,"r");
    if( udiskfd == NULL )
    {
        perror ("打开文件错误");
        fclose(udiskfd);
        close(ReadFd);
        close(WriteFd);
        return versiontemp;
    }
    fseek(udiskfd, 0, SEEK_END);

    len = ftell(udiskfd);
    fseek(udiskfd, 0, SEEK_SET);
    /* 读取并显示数据 */
    fread(version, (unsigned long )len, 1, udiskfd);

    fclose(udiskfd);
    close(ReadFd);
    close(WriteFd);
    versiontemp=version;
    return versiontemp;
}
char *HC_VersionGet(char *vesionFilePath)
{
    char VersionFile[256]={0};
    char version[100]={0};
    char *versiontemp="";
    strcat(VersionFile,vesionFilePath);
    strcat(version, HC_VersionRead(VersionFile));

    if(strlen(version)==0)
    {
        if(HC_VersionWrite(VersionFile,"1.0.0")!=ERR_COMMON_SUCCESS)
        {

            return versiontemp;
        }
        else {
            strcat(version, HC_VersionRead(VersionFile));
        }
    }
    versiontemp=version;
    return versiontemp;
}
//版本写入
int HC_VersionWrite(char *vesionFilePath,char *version)
{
    int ReadFd=0,WriteFd=0;
    ReadFd = open(vesionFilePath, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, vesionFilePath, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){

            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    FILE *udiskfd;
    udiskfd=fopen(vesionFilePath ,"w");
    if( udiskfd == NULL )
    {
        fclose(udiskfd);
        close(ReadFd);
        close(WriteFd);
        perror ("打开文件错误");
        return ERR_COMMON_FAILED;
    }
    fprintf(udiskfd,"%s",version);
    fclose(udiskfd);
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}


ST_RemoteupgradeInfo RemoteupgradeCjsonAnalysis(char *cjsoninput)
{

    cJSON* cjson = cJSON_Parse(cjsoninput);
    ST_RemoteupgradeInfo RemoteupgradeInfo;
    ST_RemoteupgradeInfo remoteupgradeInfo;
    RemoteupgradeInfo.md5=(char *)malloc(1024*sizeof (char));
    RemoteupgradeInfo.module=(char *)malloc(100*sizeof (char));
    RemoteupgradeInfo.sign=(char *)malloc(1024*sizeof (char));
    RemoteupgradeInfo.signMethod=(char *)malloc(1024*sizeof (char));
    RemoteupgradeInfo.url=(char *)malloc(1024*sizeof (char));
    RemoteupgradeInfo.version=(char *)malloc(100*sizeof (char));
    RemoteupgradeInfo.message=(char *)malloc(100*sizeof (char));
    //判断是否打包成功
    if(cjson == NULL){
        HC_PRINT("cjson error…\n");
        //  HCMsgSend(__FILE__,__LINE__,"remote","cjson error…");
        return remoteupgradeInfo;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"data");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"md5"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.md5,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"module"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.module,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"sign"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.sign,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"signMethod"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.signMethod,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"size"));
    if(json_data!=NULL)
    {
        RemoteupgradeInfo.size=atoi(json_data);
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"url"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.url,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"version"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.version,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"message"));
    if(json_data!=NULL)
    {
        strcpy(RemoteupgradeInfo.message,HCStingOut(json_data));
    }
    free(json_data);
    //这里只需要释放cjson即可，因为其它的都指向它
    cJSON_Delete(cjson);
    memcpy(&remoteupgradeInfo,&RemoteupgradeInfo,sizeof (ST_RemoteupgradeInfo));
    RemoteupgradeInfo.md5=NULL;
    RemoteupgradeInfo.module=NULL;
    RemoteupgradeInfo.sign=NULL;
    RemoteupgradeInfo.signMethod=NULL;
    RemoteupgradeInfo.url=NULL;
    RemoteupgradeInfo.version=NULL;
    RemoteupgradeInfo.message=NULL;
    free(RemoteupgradeInfo.md5);
    free(RemoteupgradeInfo.module);
    free( RemoteupgradeInfo.sign);
    free( RemoteupgradeInfo.signMethod);
    free( RemoteupgradeInfo.url);
    free( RemoteupgradeInfo.version);
    free( RemoteupgradeInfo.message);
    return remoteupgradeInfo;

}
ST_MqttMmapInfo MqttMmapCjsonAnalysis(char *cjsonbuf)
{
    ST_MqttMmapInfo  mqttMmapInfo;
    ST_MqttMmapInfo  MqttMmapInfo;
    memset(&mqttMmapInfo,0x0,sizeof (ST_MqttMmapInfo));

    cJSON* cjson = cJSON_Parse(cjsonbuf);
    //判断是否打包成功
    if(cjson == NULL){
        HC_PRINT("cjson error…\n");
        //  HCMsgSend(__FILE__,__LINE__,"remote","cjson error…");
        return mqttMmapInfo;
    }
    char *json_data = NULL;
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"subtopic"));
    if(json_data!=NULL)
    {
        strcpy( MqttMmapInfo.topic,HCStingOut(json_data));
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"mqttsend"));
    if(json_data!=NULL)
    {
        strcpy(MqttMmapInfo.mqttdata,HCStingOut(json_data));
    }
    free(json_data);
    //这里只需要释放cjson即可，因为其它的都指向它
    cJSON_Delete(cjson);
    memcpy(&mqttMmapInfo,&MqttMmapInfo,sizeof (ST_MqttMmapInfo));

    return mqttMmapInfo;
}

