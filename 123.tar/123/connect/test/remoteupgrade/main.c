#include <stdio.h>
#include "application/HCAppStart.h"
int main()
{

    HCAppStart_Init();
    while (1)
    {
      sleep(1);
    }

}
