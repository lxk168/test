﻿
#include "HCHttp.h"
#include <stdio.h>
#include <string.h>
#include <curl/curl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include"public/HCPublicStruct.h"
#include"application/HCBusiness.h"
static int count=0;

static int my_progress_func(void *ptr, double totalToDownload, double nowDownloaded, double totalToUpLoad, double nowUpLoaded)

{

    int processnum=0;
    char upcjson[1024]={0};
    char idprocessbuf[10]={0};
    sprintf(idprocessbuf,"%ld",HC_LocalTimeGet());
    processnum=(int)(nowDownloaded/RemoteupgradeInfo.size*100);
    count++;
    char processbuf[10]={0};
    if(count>40)
    {

        memset(processbuf,0x0,sizeof (processbuf));
        sprintf(processbuf,"%d",processnum);
        strcat(upcjson,HCVersionSpeedJson(idprocessbuf,"程序下载中",RemoteupgradeInfo.module,processbuf));
        if(HC_MmapProcess_Server_Send(RemoteupgradeTopic.processtopic,upcjson)==ERR_COMMON_FAILED)
        {
            return ERR_COMMON_FAILED;
        }
        HC_PRINT("%d\n",processnum);
        count=0;
    }
    return 0;
}
//回调函数，将接收到的数据保存到本地文件中，同时显示在控制台上。
//size的值始终为1,buf为返回数据的首地址,nmemb为返回数据的长度,userp为用户定义的变量
static size_t write_data(void *buf, size_t size, size_t nmemb, void *userp){

    int *fd = (int*)userp;
    size_t realSize = size*nmemb;
    size_t file_return_size = write(*fd, buf,realSize);
    if (file_return_size <= 0 ){
        return ERR_COMMON_FAILED;
    }
    //size_t return_size = fwrite(buf, size, nmemb, fp);

    //HC_PRINT("receive_data_nmemb: %ld, file_return_size: %ld\n", nmemb,file_return_size);
    //必须返回实际写进文件的大小,否则將導致傳輸中止,会向库发出错误状态信号。
    //close(*fd);
    return file_return_size;
}

//Get请求(默认)
static int HChttpClientInit(CURL **handle, ST_TransInfo HTTPInfo, void *userp){

    CURLcode res;
    char userpwd[2048]={0};
    memset(userpwd,0x0,sizeof (userpwd));
    strcat(userpwd,HTTPInfo.Usrname);
    strcat(userpwd,":");
    strcat(userpwd,HTTPInfo.PassWord);
    if (!HTTPInfo.RemoteUrl) {
        return ERR_COMMON_FAILED;
    }

    //1 初始化libcurl，设置默认参数
    CURLcode return_code;
    return_code= curl_global_init(CURL_GLOBAL_ALL);
    if (CURLE_OK != return_code) {
        HC_PRINT("curl_global_init failed.\n");
        return ERR_COMMON_FAILED;
    }
    //2 获取easy handle
    *handle = curl_easy_init();
    if (!(*handle)) {
        HC_PRINT("curl_easy_init failed.\n");
        return ERR_COMMON_FAILED;
    }
    //3 通过CURLOPT_URL属性设置url
    curl_easy_setopt(*handle,CURLOPT_URL, HTTPInfo.RemoteUrl);

    //注册回调函数write_cb，回调函数将会在接收到数据的时候被调用
    curl_easy_setopt(*handle, CURLOPT_WRITEFUNCTION, write_data);
    //设置写数据的变量
    if (userp) {
        curl_easy_setopt(*handle, CURLOPT_WRITEDATA, userp);
    }
    curl_easy_setopt(*handle, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    //通过CURLOPT_USERPWD属性来设置用户名与密码。参数是”user:password “的字符串
    curl_easy_setopt(*handle,CURLOPT_USERPWD, userpwd);
    curl_easy_setopt(*handle, CURLOPT_VERBOSE, 1L);//调试信息打开
    curl_easy_setopt(*handle, CURLOPT_NOPROGRESS, false);
    curl_easy_setopt(*handle, CURLOPT_PROGRESSFUNCTION, my_progress_func);
    curl_easy_setopt(*handle, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(*handle, CURLOPT_SSL_VERIFYHOST, 0L);
    res= curl_easy_perform(*handle);
    //4 使用curl_easy_perform执行上传数据
    if(res!=CURLE_OK) {
        fprintf(stderr, "curl_easy_perform() failed: %s\n",
                curl_easy_strerror(res));
        return ERR_COMMON_FAILED;
    }
    //5 任务执行结束使用curl_easy_cleanup把内存释放
    curl_easy_cleanup(*handle);
    //6 释放libcurl
    curl_global_cleanup();

    return ERR_COMMON_SUCCESS;
}
//HTTP下载到本地目录下
int HCHttpDownLoad(ST_TransInfo HTTPInfo){

    CURL *handle;
    int fd;
    fd = open(HTTPInfo.DownLoadPath , O_RDWR|O_CREAT);
    if(fd == ERR_COMMON_FAILED){
        HC_PRINT("open file failed.\n");
        return -2;
    }
    int ret = HChttpClientInit(&handle, HTTPInfo, (void*)&fd);
    if(ret == ERR_COMMON_FAILED){
        HC_PRINT("init client falied.\n");
        close(fd);
        return ERR_COMMON_FAILED;
    }
    close(fd);
    return ERR_COMMON_SUCCESS;
}


