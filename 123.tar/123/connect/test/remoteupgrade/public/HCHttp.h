﻿#ifndef HCHTTP_H
#define HCHTTP_H
#include "common.h"
#include "public/HCPublicStruct.h"
#define UPLOADPATH    "/userdata/usr/local/123.txt" //要上传的文件
#define REMOTE_URL      "http://192.168.10.123/"
#define DOWNLOADPATH   "/userdata/usr/local/456.txt" //要下载的文件
#pragma pack (1)

#pragma pack()
extern int HCHttpDownLoad(ST_TransInfo HTTPInfo);

#endif
