﻿#include "HCPulicAPI.h"
#include "application/HCAppStart.h"
char Mmap_Serveradress[256]={"/userdata/usr/local/remoteupgrade_mqtt_server.mmap"};
int HC_PthreadCreate(pthread_t ThreadID,void *Process_Thread)
{
    int res = ERR_COMMON_SUCCESS;
    //创建线程
    if(Process_Thread == NULL)
    { }
    else
    {
        res = pthread_create(&ThreadID, NULL, Process_Thread, NULL);
        if (0 != res)
        {
            HC_PRINT("创建线程失败");
            return ERR_COMMON_FAILED;
        }
        pthread_detach(ThreadID);
    }
    return res;
}
/*
  函数功能: Linux 系统指令
  参数说明:

            char* pcCommand 命令内容
            char *pcBackBuf 指令返回内容

*/
int HC_LinuxSystem( const char* pcCommand,  char *pcBackBuf)
{
    FILE *fpRead;
    char buf[1025];
    memset(buf,'\0',sizeof(buf));
    memset(pcBackBuf,0x0,512);
    fpRead = popen(pcCommand, "r");
    if(fpRead==NULL)
        return ERR_COMMON_FAILED;
    while(fgets(buf,1024-1,fpRead)!=NULL)
    {
        memcpy(pcBackBuf, buf, strlen(buf) > 1024 ? 1024 : strlen(buf));
    }
    if(fpRead!=NULL)
        pclose(fpRead);
    return ERR_COMMON_SUCCESS;
}

int HC_fileOpen( int *fp,  const char *pcPath,  int oflag)
{
    unsigned int i = 0;
    unsigned int len=0;
    len = (unsigned int)strlen(pcPath);

    char dirPath[len+1];
    dirPath[len] = '\0';
    strncpy(dirPath, pcPath, len);

    do
    {
        if (dirPath[i] == '/' && i > 0)
        {
            dirPath[i]='\0';
            if(access(dirPath, F_OK) < 0 )
            {
                if (mkdir(dirPath, 0666) < 0 )
                {
                    HC_ERROR("mkdir=%s:msg=%s\n", dirPath, strerror(errno));
                    return ERR_COMMON_FAILED;
                }
            }
            dirPath[i]='/';
        }
        else if(('\0' == dirPath[i]) && ( i > 0))      /*&&('/' != dirPath[i]))*/
        {
            *fp = open(dirPath, oflag, 0666);
            if (NULL == fp)
            {
                HC_ERROR("fopen =%s:msg=%s\n",dirPath, strerror(errno));
                return ERR_COMMON_FAILED;
            }
            return ERR_COMMON_SUCCESS;
        }
    }while(i++ < len);

    return ERR_COMMON_SUCCESS;
}

//获取系统时间函数
// 返回时间结构体
St_SystemTime * HCGetTime(void)
{
    char timenuf[256]={0};
    struct timespec time;
    clock_gettime(CLOCK_REALTIME, &time);  //获取相对于1970到现在的秒数
    struct tm nowTime;
    localtime_r(&time.tv_sec, &nowTime);
    St_SystemTime *SystemTime=(St_SystemTime *)timenuf;
    SystemTime->tm_year=nowTime.tm_year + 1900;
    SystemTime->tm_mon=nowTime.tm_mon+1;
    SystemTime->tm_mday=nowTime.tm_mday;
    SystemTime->tm_hour=nowTime.tm_hour;
    SystemTime->tm_min=nowTime.tm_min;
    SystemTime->tm_sec=nowTime.tm_sec;
    return SystemTime;
}
void HCTimeGet(char *tempbuf)
{

    St_SystemTime SystemTime;
    memcpy(&SystemTime,HCGetTime(),sizeof (St_SystemTime));
    char current[100]={0};
    sprintf(current, "%04d年%02d月%02d日%02d时%02d分%02d秒", SystemTime.tm_year, SystemTime.tm_mon, SystemTime.tm_mday,
            SystemTime.tm_hour, SystemTime.tm_min, SystemTime.tm_sec);
    // HC_PRINT("time=%s",current);
    memcpy(tempbuf,current,strlen(current));

}
int HCRemoveAdress(char *address)
{
    int rec=ERR_COMMON_SUCCESS;
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"cd %s && rm -rf  %s",LocalPath,address);
    HC_LinuxSystem(pcCmdbuf,backbuf);
    return rec;
}
// 获取时间戳函数 直接返回时间戳
long HC_LocalTimeGet()
{
    struct timeval tv;
    gettimeofday(&tv, NULL);
    long time=tv.tv_sec*1000 + tv.tv_usec/1000;
    return time;
}

char * HCStingOut(char *intbuf)
{

    char *outbuf=NULL;
    char buf[2048]={0};
    char temp[2048]={0};
    strcat(buf,intbuf);
    memcpy(temp,&buf[1],strlen(buf)-2);
    outbuf=temp;
    return outbuf;
}
/*
  函数功能: 在给定目录下查找指定类型的文件是否存在,若存在，则返回文件完整路径
  参数说明:
            char *pcDir 目录名
            char *pcFileName 用于保存文件完整路径
            char *pcType 文件类型(后缀)
*/
int HC_findFile( const char *pcDir,  char *pcFileName,  char *pcType)
{
    char szType[10] = {0};
    DIR *pstDir = NULL;
    char cDir_temp[128] = {0};
    struct dirent *pstDirContent = NULL;

    if(access(pcDir, F_OK) < 0 )
    {
        HC_ERROR("pcDir");
        return ERR_COMMON_FAILED;
    }
    //检查文件类型(后缀名)长度
    if (strlen(pcType) > 6)
    {
        HC_PRINT("文件类型错误,文件类型最多为6个字节!\n");
        return ERR_COMMON_FAILED;
    }

    memcpy(cDir_temp, pcDir, strlen(pcDir));

    //打开目录
    pstDir = opendir(pcDir);
    if (NULL == pstDir)
    {
        HC_ERROR("opendir");
        return ERR_COMMON_FAILED;
    }

    //循环读取目录内容
    while (NULL != (pstDirContent = readdir(pstDir)))
    {
        //文件的d_type值为8, 目录的d_type值为4
        if (4 == pstDirContent->d_type && pstDirContent->d_name[0] != 0x2e)
        {
            memcpy(&cDir_temp[strlen(cDir_temp)], pstDirContent->d_name, strlen(pstDirContent->d_name));
            cDir_temp[strlen(cDir_temp)] = '/';
            closedir(pstDir);
            pstDir = opendir(cDir_temp);
            continue;
        }

        if (8 == pstDirContent->d_type)
        {
            //获取文件类型
            memcpy(szType, &pstDirContent->d_name[strlen(pstDirContent->d_name) - strlen(pcType)], strlen(pcType));
            if (0 == strncmp(szType, pcType, strlen(pcType)))
            {
                memcpy(pcFileName, cDir_temp, strlen(cDir_temp));
                //若给定目录非'/'结尾, 则需手动添加'/'
                if (pcFileName[strlen(pcFileName) - 1] != '/')
                {
                    pcFileName[strlen(pcFileName)] = '/';
                }
                memcpy(&pcFileName[strlen(pcFileName)], pstDirContent->d_name, strlen(pstDirContent->d_name));
                break;
            }
        }
    }
    //关闭目录
    closedir(pstDir);
    //获取指定类型文件失败
    if (pcFileName[0] == 0x00)
    {
        //HC_ERROR("find the special file failed\n");
        fflush(stdout);
        return ERR_COMMON_FAILED;
    }

    return ERR_COMMON_SUCCESS;
}
//获取时区函数
int HC_GeTimeZone()
{
    int TimeZone=0;
    struct timeval tv ;
    struct timezone tz ;
    gettimeofday(&tv,&tz);
    TimeZone=(-1)*tz.tz_minuteswest/60;
    return TimeZone;
}
static int num=1;
static ST_MqttMmapInfo *mmapfdsend;
void HC_MmapProcess_Server_Init(void)
{


    int ReadFd= 0,WriteFd=0;

    if(strlen(Mmap_Serveradress)!=0)
    {
        //HCRemoveAdress(Mmap_Serveradress[i].filename);
        ReadFd = open(Mmap_Serveradress, O_RDWR);
        if (ReadFd < 0)
        {
            HC_fileOpen(&WriteFd, Mmap_Serveradress, O_RDWR | O_CREAT);
            lseek(WriteFd, MAPLENG-1, SEEK_SET);
            write(WriteFd, "\0", 1);
            //申请映射
            mmapfdsend = mmap(NULL, (size_t)MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
            if ( mmapfdsend == MAP_FAILED)
            {
                HC_PRINT("mmap error\n");
                close(ReadFd);
                close(WriteFd);
                return ;
            }
            close(ReadFd);
            close(WriteFd);

            munmap( mmapfdsend, MAPLENG);
            ReadFd = open(Mmap_Serveradress, O_RDWR);

        }
        mmapfdsend = mmap(NULL, MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
        if ( mmapfdsend == MAP_FAILED)
        {
            HC_PRINT("mmap error\n");

            close(ReadFd);
            close(WriteFd);
            return ;
        }
        close(ReadFd);
        close(WriteFd);
    }
    mmapfdsend->finishflag=0;
    mmapfdsend->time=0;
    memset(mmapfdsend->topic,0x0,sizeof (mmapfdsend->topic));
    memset(mmapfdsend->mqttdata,0x0,sizeof (mmapfdsend->mqttdata));
    num=rand();
    return ;
}
void InitTimer(Timer* timer)
{
    timer->end_time = (struct timeval){0, 0};
}
void countdown_ms(Timer* timer, unsigned int timeout)
{
    struct timeval now;
    gettimeofday(&now, NULL);
    struct timeval interval = {timeout / 1000, (timeout % 1000) * 1000};
    timeradd(&now, &interval, &timer->end_time);
}
char expired(Timer* timer)
{
    struct timeval now, res;
    gettimeofday(&now, NULL);
    timersub(&timer->end_time, &now, &res);
    return res.tv_sec < 0 || (res.tv_sec == 0 && res.tv_usec <= 0);
}
int HC_MmapProcess_Server_Send(char *topic ,char*sendbuf)
{
    int ret=ERR_COMMON_FAILED;
    Timer timer;
    InitTimer(&timer);
    countdown_ms(&timer, 1000);
    do{

        if(mmapfdsend->finishflag==0)
            break;
    }while(!expired(&timer));
    mmapfdsend->time=num;
    mmapfdsend->finishflag=1;
    sprintf(mmapfdsend->topic,"%s",topic);
    sprintf(mmapfdsend->mqttdata,"%s",sendbuf);
    num++;
//    if(num>65530)
//    {
//        num=1;
//    }
    ret=ERR_COMMON_SUCCESS;
    return ret;
}
