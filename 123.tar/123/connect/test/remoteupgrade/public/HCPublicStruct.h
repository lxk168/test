#ifndef HCPUBLICSTRUCT_H
#define HCPUBLICSTRUCT_H
typedef struct
{
  char * filename;  //本地文件名
  char * tempname;  //缓存文件名
  char *UploadPath;  //本地上传文件地址
  char *RemoteUrl;   //远程文件地址
  char *DownLoadPath; //本地文件下载地址
  char *Usrname;   //登陆用户名
  char *PassWord; //登录密码
  int   port ;//端口

}ST_TransInfo;
typedef struct
{
    int tm_sec;            /* seconds */
    int tm_min;           /* minutes */
    int tm_hour;         /* hours */
    int tm_mday;        /* day of the month */
    int tm_mon;         /* month */
    int tm_year;          /* year */
} St_SystemTime;
typedef  struct{

    long time;
    int finishflag;
    char topic[1024];
    char mqttdata[1024*500];
}ST_MqttMmapInfo;
typedef struct{
    long cmp1;
    long cmp2;
}ST_Cmp;

typedef struct
{
  char *informtopic;  //设备上报 OTA模板版本
  char *upgradetopic_reply;  //平台推送升级包信息
  char *processtopic;  //设备上报升级进度
  char *firwaregettopic; //设备请求升 级包信息-请 求
  char *firewareget_reply; //设备请求升 级包信息-响 应
}ST_RemoteupgradeTopic;
typedef  struct{
    char *md5;
    char *module;       //升级的模块
    char  *sign;        //签名
    char  *signMethod; // 签名方法
    char * url;         //远程升级路径
    char *version;      //版本信息
    char * message;     //结果信息
    int size;          //升级包大小
}ST_RemoteupgradeInfo;
typedef  struct{
    int hight;
    int medium;
    int low;
}ST_Version;

extern ST_RemoteupgradeInfo RemoteupgradeInfo;
//extern ST_MqttMmapInfo MqttMmapInfo;
extern ST_RemoteupgradeTopic RemoteupgradeTopic;
#endif // HCPUBLICSTRUCT_H
