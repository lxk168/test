﻿#ifndef HCPULICAPI_H
#define HCPULICAPI_H
#include "common.h"
#include <pthread.h>
#include<public/HCPublicStruct.h>
#pragma pack(1)
typedef struct Timer Timer;

struct Timer {
    struct timeval end_time;
};
#pragma pack()
extern int HC_PthreadCreate(pthread_t ThreadID,void *Process_Thread);
extern int HC_LinuxSystem( const char* pcCommand,  char *pcBackBuf);
extern int HC_fileOpen( int *fp,  const char *pcPath,  int oflag);
extern St_SystemTime * HCGetTime(void);
extern void HCTimeGet(char *tempbuf);
extern int HCRemoveAdress(char *address);
extern long HC_LocalTimeGet(void);
extern char * HCStingOut(char *intbuf);
extern int HC_findFile( const char *pcDir,  char *pcFileName,  char *pcType);
extern int HC_GeTimeZone(void);
extern void HC_MmapProcess_Server_Init(void);
extern void InitTimer(Timer* timer);
extern void countdown_ms(Timer* timer, unsigned int timeout);
extern char expired(Timer* timer);
extern int HC_MmapProcess_Server_Send(char *topic ,char*sendbuf);
extern char Mmap_Serveradress[256];
#endif
