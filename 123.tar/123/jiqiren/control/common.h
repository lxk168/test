﻿#ifndef COMMON_H
#define COMMON_H

#include "string.h"
#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include "errno.h"
#include <assert.h>
#include <dirent.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <dirent.h>
#include <time.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <semaphore.h>
#include <linux/if.h>
#include <linux/sockios.h>
#include <linux/ethtool.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <semaphore.h>
#include "sys/stat.h"
#include "sys/types.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include <time.h>
#include <zmq/zmq.h>
#include <math.h>
#include<sys/msg.h>
#include<sys/ipc.h>
#include<stdbool.h>
#include <sys/mman.h>
#include <sys/stat.h>

#define ERR_COMMON_SUCCESS 0
#define ERR_COMMON_FAILED  -1

#define   IN
#define   OUT
#define   INOUT

//#define  bool	_Bool
#define  false  0
#define  true   1

#define  __u8       unsigned char
#define  __u16     unsigned short
#define  __u32     unsigned int
#define LocalPath   "/userdata/usr/local/"   //本地目录
#define SdcardPath  "/mnt/sdcard/"  // sd卡目录
#define HC_ASSERT(bResult) assert(bResult)

#define HC_ERROR(format, args...)	do {fprintf(stderr, " [HC_ERROR]%s %s(Line %d): (errno=%d) ",  __FILE__, __func__, __LINE__, errno);perror("reason");} while(0)

#define HC_DEBUG(format, args...)	do {fprintf(stdout, " [HC_DEBUG]%s (Line %d):", __FILE__, __LINE__);fprintf(stdout, format, ##args);fprintf(stdout, "\n");} while(0)

#define HC_PRINT(format, args...) do {fprintf(stdout, " [HC_PRINT]%s (Line %d):", __FILE__, __LINE__);fprintf(stdout, format, ##args);fprintf(stdout, "\n");fflush(stdout);} while(0)
#define MQTTLENG 0x4000 //最大映射大小
//internal call: ("%s,%d,%d\n", "internal_call", slave, floor)

//   outer call: ("%s,%d,%d,%d\n", "outer_call", slave, floor, direction)    // dynamic
//   -- @direction 1: up, 2: down

//   disability outer call: ("%s,%d,%d,%d\n", "disability_outer_call", slave, floor, direction)  // specified
//   -- @direction 1: up, 2: down

//   open door: ("%s,%d,%d\n", "open_door", slave, door, secs)
//   -- @door 1: front door, 2: back door

//   close door: ("%s,%d,%d\n", "close_door", slave, door)
//   -- @door 1: front door, 2: back door
#define ZMQ_ENDPOINT_RPC                "tcp://*:6000"
#define ELEVATOR_TOPIC_RPC              "elevator topic rpc"
#define RPC_INTERNAL_CALL               "internal_call"
#define RPC_OUTER_CALL                  "outer_call"
#define RPC_OPEN_DOOR                   "open_door"
#define RPC_CLOSE_DOOR                  "close_door"
#define RPC_DISABILITY_OUTER_CALL       "disability_outer_call"

#define SHARED_OBJ_DISPLAY_PARAM            "/smart_shared_display_param"
#define SHARED_OBJ_COMMON_DATA              "/smart_shared_common_data"
#define SEM_OBJ_ELEVATOR_DATA               "/smart_sem_elevator_data"
#define TOPICLENG (1024)
#define MSGBUFLENG (1024*2)
#pragma pack(1)
typedef  struct{

    long time;
    int finishflag;
    char topic[1024];
    char mqttdata[1024*10];
}ST_MqttMmapInfo;

struct ST_elevator_display_param_t
{
    int slave;
    short floor_display[40];                /* floor 1 to 40 display parameters, ascii value */
};

struct ST_elevator_common_data_t
{
    int slave;
    char sn[8];                             /* ascii */
    unsigned short car_status;              /* 1: up, 2: down, 3: stop */
    unsigned short current_floor;
    unsigned short service_mode;            /* nice3000+ p196 */
    unsigned short load;                    /* 1: fullload, 2: overload,  3: lightload, 4: halfload */
    unsigned short door_status;             /* 1: opening, 2: open, 3: closing, 4: close */
    unsigned short fault_code;              /* 0: normal, other: fault*/
    unsigned char inner_call[48];           /* 1-48 floor */
    unsigned char up_call[48];              /* 1-48 floor */
    unsigned char down_call[48];            /* 1-48 floor */
};
typedef  struct
{
    int id;
    char topic[TOPICLENG];
    char msgbuf[MSGBUFLENG];
}ST_MqttInfo;

typedef  struct
{
    int id;
}ST_CMP;
#pragma pack()
extern char idbuf[3][100];
extern ST_MqttMmapInfo mqttMmapInfo;
extern ST_MqttInfo MqttInfo[3];

extern int MQTTSendFlag;
extern pthread_mutex_t mutex; //互斥锁;
extern char Mmap_Serveradress[256];
#endif
