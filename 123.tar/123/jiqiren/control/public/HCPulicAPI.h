﻿#ifndef HCPULICAPI_H
#define HCPULICAPI_H
#include "common.h"
#include <pthread.h>
#include"public/HCPublicStruct.h"
#define MQTTLENG 0x40000 //MQTT最大映射大小
#define MAPLENG  0x8000  //日志上传映射大小
typedef  struct
{
    char name[20000];
}STU;
typedef struct Timer Timer;

struct Timer {
    struct timeval end_time;
};
extern int HC_LinuxSystem( const char* pcCommand,  char *pcBackBuf);
extern int HC_LinuxKillProcess( const char* pcProcessName);
extern  int HC_ProcessMointor( const char* pcProcessName);
extern void  HC_FreeMemory(void);
extern int HC_PthreadCreate(pthread_t ThreadID,void *Process_Thread);
extern St_SystemTime * HCGetTime(void);
extern void substr(char *source,int start,int length,char *dest);
extern long HC_LocalTimeGet(void);
extern int HCFileCopy(char *source,char *dist);
extern int HCMsgSend(char *file,int line,char *idbuf,char *sendbuf);
extern char * HCStingOut(char *intbuf);
extern int HCRemoveAdress(char *address);
extern unsigned int HC_MQttIdGet(unsigned int start,unsigned int stop);
extern int HCMQttMsgSend(char *pubFileName,char *pubtopic,char *MqttSendBuf);
extern int HCMQttMsgRead(char *subFileName);
extern int HCZmqInit(void );
extern int HC_IdGet(void);
extern void HC_MmapProcess_Server_Init(void);
extern void HC_MmapProcess_Server_Send(char *topic ,char*sendbuf);
extern void InitTimer(Timer* timer);
extern void countdown_ms(Timer* timer, unsigned int timeout);
extern char expired(Timer* timer);
#endif
