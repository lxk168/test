﻿
#ifndef HCMQTTPUBPROCESS_H
#define HCMQTTPUBPROCESS_H
#include "common.h"
#include "public/HCFileOperation.h"
#include"public/HCPulicAPI.h"

extern void *HCMqttPubProcess_Thread(void);

#endif



