﻿
#ifndef HCBUSINESSTOPIC_H
#define HCBUSINESSTOPIC_H
#include"common.h"
extern char *HCBusinessTopicBulid(char *method);
extern void HCSubTopicInit(void);
extern char HCfrontDoorOpenKeepCommandTopic_Sub[3][512];
extern char HCouterCallLiftTopic_Sub[3][512];
extern char HCinnerCallLiftTopic_Sub[3][512];
extern char HCfrontDoorCloseCommand_Sub[3][512];//机器人关门响应TOPIC
extern char HCagvInformationEventTopic_Pub[3][512];
extern char HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[3][512];
extern char HCfrontDoorOpenKeepCommandTopic_Pub[3][512];
extern char HCouterCallLiftTopic_Pub[3][512];
extern char HCinnerCallLiftTopic_Pub[3][512];
extern char HCfrontDoorCloseCommand_Pub[3][512];//机器人关门响应TOPIC
#endif



