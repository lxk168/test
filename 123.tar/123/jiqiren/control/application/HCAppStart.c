﻿#include "HCAppStart.h"
#include "application/HCBusinessCJson.h"
#include "application/HCMqttPubProcess.h"
#include"application/HCMqttSubProcess.h"
#include "application/HCBusinessTopic.h"
#include"application/HCBusinessCjsonAnalysis.h"
#include"application/HCBusinessCode.h"

 char Mmap_Serveradress[256]={"/userdata/usr/local/control_mqtt_server.mmap"};

ST_MqttInfo MqttInfo[3];
 pthread_mutex_t mutex; //互斥锁
void HCStartTask(void)
{

    pthread_t S1=1,S2=2;
    HCZmqInit();
    sleep(2);
    HCSubTopicInit();
    pthread_mutex_init(&mutex, NULL); //初始化互斥锁
    HC_MmapProcess_Server_Init();

    pthread_create(&S1, NULL, HCMqttPubProcess_Thread, NULL); //创建一个线程执
    pthread_detach(S1);  //设置线程结束收尸
    pthread_create(&S2, NULL, HC_MQTTSubProcess_Thread, NULL); //创建一个线程执
    pthread_detach(S2);  //设置线程结束收尸
  // HC_internal_call(2,InnerCallLift.floor+1);
//      HC_PRINT("1W21212");
    //pthread_mutex_destroy(&mutex); //销毁互斥锁

}

int HCCollectionProcessStart(void )
{

    char pcCmdbuf[256]={0};
    sprintf(pcCmdbuf,"cd %s && nohup ./smart.exe 1 0 0 &",LocalPath);
    system(pcCmdbuf);
    return ERR_COMMON_SUCCESS;
}


