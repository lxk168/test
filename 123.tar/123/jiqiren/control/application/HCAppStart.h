﻿#ifndef HCAPPSTART_H
#define HCAPPSTART_H
#include "common.h"
#include "public/HCFileOperation.h"
#include "public/HCPulicAPI.h"

#include "public/HCSqlite.h"
#include "public/HCPublicStruct.h"

extern void HCStartTask(void);
extern int HCCollectionProcessStart(void );
extern int HC_ProcessCount(int Processnum);

#endif
