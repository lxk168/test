﻿#include "application/HCBusinessCode.h"
#include "application/HCBusinessCJson.h"
#include"application/HCBusinessTopic.h"
#include"application/HCBusinessCjsonAnalysis.h"
#include "application/HCAppStart.h"
char idbuf[3][100]={
    "665644970029875200",
    "665646714336051200",
    "665647683455156224"
};
int HC_agvInformationEvent_Upload(int id,struct ST_elevator_common_data_t elevator_common_data_t)
{
    char MqttSendBuf[1024*2]={0};
    ST_AGVInformationEvent AGVInformationEvent;
    memset(&AGVInformationEvent,0x0,sizeof (ST_AGVInformationEvent));
    if(elevator_common_data_t.fault_code==0)
    {
        AGVInformationEvent .runingStatus=true; //运行状态正常
    }else {
        AGVInformationEvent .runingStatus=false; //运行状态异常
    }
    if(elevator_common_data_t.service_mode==0)
    {
        AGVInformationEvent .overhaulStatus=true; //检修状态
    }else {
        AGVInformationEvent .overhaulStatus=false; //检修状态
    }

    if(elevator_common_data_t.load==1)
    {
        AGVInformationEvent .carOverloadSignal=false; //轿厢超载信号
        AGVInformationEvent .carFullLoadSignal=true; //轿厢满载信号
    }
    else if(elevator_common_data_t.load==2){
        AGVInformationEvent .carOverloadSignal=true; //轿厢超载信号
        AGVInformationEvent .carFullLoadSignal=true; //轿厢满载信号
    }
    else {
        AGVInformationEvent .carOverloadSignal=false; //轿厢超载信号
        AGVInformationEvent .carFullLoadSignal=false; //轿厢满载信号
    }

    if(elevator_common_data_t.car_status==1)
    {
        AGVInformationEvent .runningDirection=true; //上行
        AGVInformationEvent .downStatus=0; //轿门开关门状态上行
    }else if(elevator_common_data_t.car_status==2){
        AGVInformationEvent .runningDirection=false; //下行
        AGVInformationEvent .downStatus=1; //轿门开关门状态下行
    }else if(elevator_common_data_t.car_status==3) {
        AGVInformationEvent .downStatus=2; //轿门开关门状态停止
    }
    int up_callNum=0,down_callNum=0;
    for (int i=0;i<48;i++) {

        if(elevator_common_data_t.up_call[i]==1)
        {
            up_callNum++;
            AGVInformationEvent.UpStopFloor[i].upStopFloor=i+1;
            AGVInformationEvent.upStopThick=up_callNum;
        }
        if(elevator_common_data_t.down_call[i]==1)
        {
            down_callNum++;
            AGVInformationEvent.DownStopFloor[i].downStopFloor=i+1;
            AGVInformationEvent.downStopThick=down_callNum;


        }
    }
    AGVInformationEvent .carDoorOpeningClosingStatus=elevator_common_data_t.door_status; //轿门开关门状态
    AGVInformationEvent .person=0;
    AGVInformationEvent .serialCommunicationStatus=true; //串口通讯状态
    AGVInformationEvent .floor=elevator_common_data_t.current_floor;//轿厢当前楼层
    sprintf(MqttSendBuf,"%s",HCAGVInformationEvent(AGVInformationEvent,0));
    HC_MmapProcess_Server_Send(HCagvInformationEventTopic_Pub[id],MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}
int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload(int id,struct ST_elevator_display_param_t elevator_display_param_t)
{
    char MqttSendBuf[1024*2]={0};

    ST_ComparisonTable ComparisonTable;
    memset(&ComparisonTable,0x0,sizeof (ST_ComparisonTable));
    int num=1;
    int num1=2;
    for (int i=0;i<30;i++) {

        sprintf(ComparisonTable.FloorNum[i].showFloor,"%d",num);

        ComparisonTable.FloorNum[i].physicalFloor=num1;
        num++;
        num1++;
        ComparisonTable.floorThick=i+1;
    }

    sprintf(MqttSendBuf,"%s",HCComparisonTableOfFloorAndPhysicalFloorEvent(ComparisonTable,1));
    HC_MmapProcess_Server_Send(HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[id],MqttSendBuf);
    HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}
int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload2(int id,struct ST_elevator_display_param_t elevator_display_param_t)
{
    char MqttSendBuf[1024*2]={0};

    ST_ComparisonTable ComparisonTable;
    memset(&ComparisonTable,0x0,sizeof (ST_ComparisonTable));
    int num=1;
    int count=0;
    for (int i=0;i<31;i++) {
        if( i==0)
        {
            sprintf(ComparisonTable.FloorNum[i].showFloor,"%d",-1);
              ComparisonTable.FloorNum[i].physicalFloor=1;

        }
        else {
             sprintf(ComparisonTable.FloorNum[i].showFloor,"%d",count);
               ComparisonTable.FloorNum[i].physicalFloor=num;
        }


        num++;count++;
        ComparisonTable.floorThick=i+1;
    }

    sprintf(MqttSendBuf,"%s",HCComparisonTableOfFloorAndPhysicalFloorEvent(ComparisonTable,1));
    HC_MmapProcess_Server_Send(HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[id],MqttSendBuf);
    HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}


int HCmethodReply_Upload(char * topic,long id ,bool flag)
{
    char TopicBuf[512]={0};
    char MqttSendBuf[512]={0};
    strcat(TopicBuf,topic);
    sprintf(MqttSendBuf,"%s",HCmethodReply(id,flag));
    HC_MmapProcess_Server_Send(topic,MqttSendBuf);
    HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}
int HC_internal_call(int slave,int floor)
{
     char buf[100]={0};
    sprintf(buf,"%s,%d,%d\n", "internal_call", slave, floor);
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_outer_call(int slave,int floor,int direction)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d,%d\n", "outer_call", slave, floor, direction);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_open_door(int slave,int door,int sec)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d,%d\n", "open_door", slave, door, sec);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_close_door(int slave,int door)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d\n", "close_door", slave, door);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_disability_outer_call(int slave, int floor, int direction)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d,%d\n", "disability_outer_call", slave, floor, direction);
    zmq_send(zmq_pub, buf,strlen(buf), 0);

   return ERR_COMMON_SUCCESS;
}
