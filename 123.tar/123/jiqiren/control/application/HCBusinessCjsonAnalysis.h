﻿
#ifndef HCBUSINESSCJSONANALYSIS_H
#define HCBUSINESSCJSONANALYSIS_H
#include "HCBusinessCjsonAnalysis.h"
#include "common.h"
#include "public/HCJson.h"
typedef struct{
    int floor;
    int direction;
    int optType;
    long id;
}ST_OuterCallLift;
typedef struct{
    int floor;
    long id;
}ST_InnerCallLift;
typedef struct{
    int delay;
    int frontDoorOpenKeepFunction;
    long id;
}ST_frontDoorOpenKeepCommand;
typedef struct{
    bool flag; //
    long id;
}ST_frontDoorCloseCommand;
extern ST_frontDoorOpenKeepCommand * HC_frontDoorOpenKeepCommand_Cjson_Analysis(char *Analysisbuf);//开门保持
extern ST_OuterCallLift * HC_outerCallLift_Cjson_Analysis(char *Analysisbuf);//外昭
extern ST_InnerCallLift * HCinnerCallLift_Cjson_Analysis(char *Analysisbuf);//内昭
extern ST_frontDoorCloseCommand * HCfrontDoorCloseCommand(char *Analysisbuf);//关门
#endif



