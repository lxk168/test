﻿#include"application/HCBusinessTopic.h"
#include"public/HCProfileUtil.h"
#include"public/HCFileOperation.h"
char HCfrontDoorOpenKeepCommandTopic_Sub[3][512]={{0}};//机器人乘梯前门开关门响应Topic
char HCouterCallLiftTopic_Sub[3][512]={{0}};//机器人乘梯外呼响应Topic
char HCinnerCallLiftTopic_Sub[3][512]={{0}};//机器人乘梯内呼响应Topic
char HCfrontDoorCloseCommand_Sub[3][512]={{0}};//机器人关门响应TOPIC
char HCagvInformationEventTopic_Pub[3][512]={{0}};//机器人乘梯实时数据
char HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[3][512]={{0}};//机器人乘梯楼层对照数据
char HCfrontDoorOpenKeepCommandTopic_Pub[3][512]={{0}};//开关门响应
char HCouterCallLiftTopic_Pub[3][512]={{0}};//外呼响应
char HCinnerCallLiftTopic_Pub[3][512]={{0}};//内呼响应
char HCfrontDoorCloseCommand_Pub[3][512]={{0}};//机器人关门响应TOPIC
char *HCBusinessTopicBulid(char *method)
{
    char Topicbuf[2048]={0};
    char* file_path = (char*)"/usr/local/jiqiren/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";

    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);

    sprintf(Topicbuf,"/tsl/%s/%s/%s",ThingCategoryKeybuf,DeviceName,method);

    char *temp=Topicbuf;
    return temp;
}
void HCSubTopicInit(void)
{

    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* topic_path = (char*)"/userdata/usr/local/subtopic.conf";
    char* app_name = (char*)"mqtt_userdata";
    char* topic_name = (char*)"mqtt_subtopic";
    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    int ReadFd=0,WriteFd=0;
    char valuebuf[10]={0};
    int num=0;
    ReadFd = open(topic_path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, topic_path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

        }
    }
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    write_profile_string(topic_name,valuebuf,"",topic_path);
    // 发布
    sprintf(HCagvInformationEventTopic_Pub[0],"/tls/%s/%s/thing/event/elevator.%s.agvInformationEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    sprintf(HCagvInformationEventTopic_Pub[1],"/tls/%s/%s/thing/event/elevator.%s.agvInformationEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    sprintf(HCagvInformationEventTopic_Pub[2],"/tls/%s/%s/thing/event/elevator.%s.agvInformationEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    sprintf(HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[0],"/tls/%s/%s/thing/event/elevator.%s.comparisonTableOfFloorAndPhysicalFloorEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    sprintf(HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[1],"/tls/%s/%s/thing/event/elevator.%s.comparisonTableOfFloorAndPhysicalFloorEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    sprintf(HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[2],"/tls/%s/%s/thing/event/elevator.%s.comparisonTableOfFloorAndPhysicalFloorEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    sprintf(HCfrontDoorOpenKeepCommandTopic_Pub[0],"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    sprintf(HCfrontDoorOpenKeepCommandTopic_Pub[1],"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    sprintf(HCfrontDoorOpenKeepCommandTopic_Pub[2],"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    sprintf(HCouterCallLiftTopic_Pub[0],"/tls/%s/%s/thing/method/elevator.%s.outerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    sprintf(HCouterCallLiftTopic_Pub[1],"/tls/%s/%s/thing/method/elevator.%s.outerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    sprintf(HCouterCallLiftTopic_Pub[2],"/tls/%s/%s/thing/method/elevator.%s.outerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    sprintf(HCinnerCallLiftTopic_Pub[0],"/tls/%s/%s/thing/method/elevator.%s.innerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    sprintf(HCinnerCallLiftTopic_Pub[1],"/tls/%s/%s/thing/method/elevator.%s.innerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    sprintf(HCinnerCallLiftTopic_Pub[2],"/tls/%s/%s/thing/method/elevator.%s.innerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[2]);

    sprintf(HCfrontDoorCloseCommand_Pub[0],"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    sprintf(HCfrontDoorCloseCommand_Pub[1],"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    sprintf(HCfrontDoorCloseCommand_Pub[2],"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[2]);


    // 订阅
    sprintf(HCfrontDoorOpenKeepCommandTopic_Sub[0],"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCfrontDoorOpenKeepCommandTopic_Sub[0],topic_path);
    num++;
    sprintf(HCfrontDoorOpenKeepCommandTopic_Sub[1],"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCfrontDoorOpenKeepCommandTopic_Sub[1],topic_path);
    num++;
    sprintf(HCfrontDoorOpenKeepCommandTopic_Sub[2],"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCfrontDoorOpenKeepCommandTopic_Sub[2],topic_path);
    num++;

   //外乎回复
    sprintf(HCouterCallLiftTopic_Sub[0],"/tls/%s/%s/thing/method/elevator.%s.outerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCouterCallLiftTopic_Sub[0],topic_path);
    num++;
    sprintf(HCouterCallLiftTopic_Sub[1],"/tls/%s/%s/thing/method/elevator.%s.outerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCouterCallLiftTopic_Sub[1],topic_path);
    num++;
    sprintf(HCouterCallLiftTopic_Sub[2],"/tls/%s/%s/thing/method/elevator.%s.outerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCouterCallLiftTopic_Sub[2],topic_path);
    num++;

    //内呼回复
    sprintf(HCinnerCallLiftTopic_Sub[0],"/tls/%s/%s/thing/method/elevator.%s.innerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCinnerCallLiftTopic_Sub[0],topic_path);
    num++;
    sprintf(HCinnerCallLiftTopic_Sub[1],"/tls/%s/%s/thing/method/elevator.%s.innerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCinnerCallLiftTopic_Sub[1],topic_path);
    num++;
    sprintf(HCinnerCallLiftTopic_Sub[2],"/tls/%s/%s/thing/method/elevator.%s.innerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCinnerCallLiftTopic_Sub[2],topic_path);
    num++;

    //关门
    sprintf(HCfrontDoorCloseCommand_Sub[0],"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand",ThingCategoryKeybuf,DeviceName,idbuf[0]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCfrontDoorCloseCommand_Sub[0],topic_path);
    num++;
    sprintf(HCfrontDoorCloseCommand_Sub[1],"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand",ThingCategoryKeybuf,DeviceName,idbuf[1]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCfrontDoorCloseCommand_Sub[1],topic_path);
    num++;
    sprintf(HCfrontDoorCloseCommand_Sub[2],"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand",ThingCategoryKeybuf,DeviceName,idbuf[2]);
    memset(valuebuf,0x0,sizeof (valuebuf));
    sprintf(valuebuf,"%dtopic",num);
    write_profile_string(topic_name,valuebuf,HCfrontDoorCloseCommand_Sub[2],topic_path);
    num++;

    close(ReadFd);
    close(WriteFd);
    return ;
}
