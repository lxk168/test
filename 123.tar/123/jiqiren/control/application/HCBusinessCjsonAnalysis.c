﻿#include "application/HCBusinessCjsonAnalysis.h"
#include"public/HCPulicAPI.h"
//前门开门保持指令-方法请求
ST_frontDoorOpenKeepCommand * HC_frontDoorOpenKeepCommand_Cjson_Analysis(char *Analysisbuf)
{

    char flag[10]={0};
    int buf[100]={0};
    char IDbuf[20]={0};
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);
    ST_frontDoorOpenKeepCommand*frontDoorOpenKeepCommand=(ST_frontDoorOpenKeepCommand*)buf;
    //判断是否打包成功
    if(cjson == NULL){

        return NULL;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"params");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"delay"));
    if(json_data!=NULL)
    {
        frontDoorOpenKeepCommand->delay=atoi(json_data);
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"frontDoorOpenKeepFunction"));
    if(json_data!=NULL)
    {
        sprintf(flag,"%s",json_data);
        if(strcmp(HCStingOut(flag),"true")!=0)
        {
            frontDoorOpenKeepCommand->frontDoorOpenKeepFunction=1;
        }
        else {
            frontDoorOpenKeepCommand->frontDoorOpenKeepFunction=0;
        }
    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"id"));
    if(json_data!=NULL)
    {
        sprintf(IDbuf,"%s",json_data);
        frontDoorOpenKeepCommand->id=atol(HCStingOut(IDbuf));

    }
    cJSON_Delete(cjson);
    return frontDoorOpenKeepCommand;
}
//后门开门保持指令-方法请求
int HC_backDoorOpenKeepCommand_Cjson_Analysis(char *Analysisbuf)
{
    int flag=0;
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);

    //判断是否打包成功
    if(cjson == NULL){

        return -1;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"params");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"backDoorOpenKeepFunction"));
    if(json_data!=NULL)
    {
        flag=atoi(json_data);

    }
    free(json_data);
    cJSON_Delete(cjson);
    return flag;
}
//乘梯外召-方法请求
ST_OuterCallLift * HC_outerCallLift_Cjson_Analysis(char *Analysisbuf)
{
    int buf[100]={0};
    char IDbuf[20]={0};
    ST_OuterCallLift *OuterCallLift=(ST_OuterCallLift *)buf;

    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);

    //判断是否打包成功
    if(cjson == NULL){

        return OuterCallLift;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"params");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"floor"));
    if(json_data!=NULL)
    {
        OuterCallLift->floor=atoi(json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"direction"));
    if(json_data!=NULL)
    {
        OuterCallLift->direction=atoi(json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"optType"));
    if(json_data!=NULL)
    {
        OuterCallLift->optType=atoi(json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"id"));
    if(json_data!=NULL)
    {
        sprintf(IDbuf,"%s",json_data);
        OuterCallLift->id=atol(HCStingOut(IDbuf));

    }
    free(json_data);
    cJSON_Delete(cjson);
    return OuterCallLift;
}

ST_InnerCallLift * HCinnerCallLift_Cjson_Analysis(char *Analysisbuf)
{
    int buf[100]={0};
    char IDbuf[20]={0};
    char Floorbuf[10]={0};
    ST_InnerCallLift *InnerCallLift=( ST_InnerCallLift *)buf;

    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);
    //判断是否打包成功
    if(cjson == NULL){

        return NULL;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"params");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"floor"));
    if(json_data!=NULL)
    {
        sprintf(Floorbuf,"%s",json_data);
        InnerCallLift->floor=atoi(HCStingOut(Floorbuf));

    }
    free(json_data);

    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"id"));
    if(json_data!=NULL)
    {
        sprintf(IDbuf,"%s",json_data);
        InnerCallLift->id=atol(HCStingOut(IDbuf));

    }
    free(json_data);
    cJSON_Delete(cjson);
    return InnerCallLift;

}
ST_frontDoorCloseCommand * HCfrontDoorCloseCommand(char *Analysisbuf)
{
    int buf[100]={0};
    char IDbuf[20]={0};

    ST_frontDoorCloseCommand *frontDoorCloseCommand=( ST_frontDoorCloseCommand *)buf;
     HC_PRINT("Analysisbuf=%s",Analysisbuf);
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);
    //判断是否打包成功
    if(cjson == NULL){

        return NULL;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"params");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"frontDoorCloseFunction"));
    if(json_data!=NULL)
    {
        frontDoorCloseCommand->flag=json_data;

    }
    free(json_data);

    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"id"));
    if(json_data!=NULL)
    {
        sprintf(IDbuf,"%s",json_data);
        frontDoorCloseCommand->id=atol(HCStingOut(IDbuf));

    }
    free(json_data);
    cJSON_Delete(cjson);
    return frontDoorCloseCommand;

}
