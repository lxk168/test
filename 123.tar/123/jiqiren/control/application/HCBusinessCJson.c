﻿#include "application/HCBusinessCJson.h"
#include"application/HCMqttSubProcess.h"

#define MAXCJSONLENG (1024*10)




/***====================================================轿厢-轿门================================================*****/
/*
 * 函数功能：轿厢-轿门-门机预维保状态
 * method：
 * status：预维保状态  0：不处于预维保 1：处于预维保 2：不适合预维保 3：预维保结束
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorMachinePreMaintenanceStatus/post
 */
char* HCDoorMachinePreMaintenanceStatus(int status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorMachinePreMaintenanceStatus.post");

    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"preMaintenanceStatus\":%d}},\"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}
/*
 * 函数功能：轿厢-轿门-门锁短接故障检测
 * method：
 * status：电梯是否有E53门锁短接故障，ture：E53门锁短接故障，false：无E53门锁短接故障
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorLockShortCircuitFaultDetection/post
 */
char* HCDoorLockShortCircuitFaultDetection(char* status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorLockShortCircuitFaultDetection.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"doorLockShortCircuitFault\":\"%s\"}},\"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}
/***======================================================轿厢-轿门-光幕====================================*****/
/*
 * 函数功能：轿厢-轿门-光幕-特殊功能事件
 * method：
 * TotalOcclusionState：光管总遮挡状态 int
 * lightNumber：光管对数 int
 * BlockingState：光管1-48遮挡状态  int
 * DecayValue：光管强度值  int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.lightCurtain.specialFunction/post
 */
char* HCSpecialFunction(int TotalOcclusionState, int lightNumber, int BlockingState , int DecayValue, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.specialFunction.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"lightPipeTotalOcclusionState\":\"%d\",\"lightPipeDoubleNumber\":\"%d\",\"lightPipe1to48BlockingState\":\"%d\",\"lightPipeDecayValue\":\"%d\"}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),TotalOcclusionState,lightNumber,BlockingState,DecayValue , ack);
    char* temp = tempbuf;
    return temp;
}
/***======================================================轿厢-轿门-滑轨=========================================****/
/*
 * 函数功能：轿厢-轿门-滑轨-滑轨摩檫力检测数据
 * method:
 * doorFriction:门摩檫力  ture :正常  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.slide.slidingRailFrictionDetectionData/post
 */
char* HCSlidingRailFrictionDetectionData(char* doorFriction, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.slidingRailFrictionDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"doorFriction\":\"%s\",\"carCurrentFloor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),doorFriction , Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***======================================================轿厢-轿门-轿门锁===========================================***/
/*
 * 函数功能：轿厢-轿门-轿门锁-轿门锁统计数据
 * method：
 * openTimes:开门次数统计
 * closTimes:关门次数统计
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.carDoorLock.carDoorLockStatisticalData/post
 */
char* HCCarDoorLockStatisticalData(int openTimes,int closTimes, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.carDoorLockStatisticalData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"openingTimesStatistics\":\"%d\",\"closingTimesStatistics\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), openTimes, closTimes, ack);
    char* temp = tempbuf;
    return temp;
}
/*
 * 函数功能：轿厢-轿门-轿门锁-轿门锁通断状态
 * method：
 * state：轿门锁通断状态    ture : 轿门锁状态：通      false : 轿门锁状态：断
 * Floor: 轿厢所在楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.carDoorLock.carDoorLockOnOffState/post
 */
char* HCCarDoorLockOnOffState(char* state, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.carDoorLockStatisticalData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"carDoorLockOnOffState\":\"%s\",\"floor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), state, Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***=====================================================轿厢-轿门-轿厢地坎==================================================****/
/*
 * 函数功能：轿厢-轿门-轿厢地坎-轿厢地坎检测数据
 * method:
 * doorFriction:门摩檫力  ture :正常  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.carSill.carSillDetectionData/post
 */
char* carSillDetectionData(char* doorFriction, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.carSillDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"doorFriction\":\"%s\",\"carCurrentFloor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), doorFriction, Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***===================================================轿厢-轿门-门球====================================================****/
/*
 * 函数功能：轿厢-轿门-门球-门球数据集
 * method：
 * result：门球对中结果    0:左偏   1：对中   2：右偏
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorBall.doorBallDataSet/post
 */
char* HCDoorBallDataSet(int result, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorBallDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"doorBallCenterResult\":\"%d\",\"floor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), result, Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***====================================================轿厢-轿门-门板====================================================*****/
/*
 * 函数功能：轿厢-轿门-门板-门板检测数据
 * method：
 * pullDoor：扒门识别   ture:识别结果：有扒门   false:识别结果：无扒门
 * kickDoor: 踹门识别   ture:识别结果：有踹门   false:识别结果：无踹门
 * clip： 夹人夹物      ture:正常               false:异常：夹人/夹物
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorPanel.doorDetectionData/post
 */
char* HCDoorDetectionData(char* pullDoor,char* kickDoor,char* clip ,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorBallDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"pullDoorDetect\":\"%s\",\"kickDoorDetect\":\"%s\",\"clipPeopleClipThing\":\"%s\"}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), pullDoor,kickDoor,clip, ack);
    char* temp = tempbuf;
    return temp;
}
/*
 * 函数功能：轿厢-轿门-门板-门板统计数据
 * method：
 * time：开关门时间
 * times：开关门次数
 * abnormalTimes:异常反复开关门次数
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorPanel.doorPanelStatisticalData/post
 */
char* HCDoorPanelStatisticalData(int time,int times,int abnormalTimes,int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorPanelStatisticalData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"openingClosingTime\":\"%d\",\"openingClosingDoorTimes\":\"%d\",\"abnormalRepetitionOpeningClosingDoorTimes\":{\"times\":\"%d\",\"floor\":\"%d\"}}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), time, times, abnormalTimes, Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/*
 * 函数功能：轿厢-轿门-门板-门板状态数据
 * method：
 * status：开关门状态      0：未知状态  1：开门过程  2：开门到位  3：关门过程  4：关门到位
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorPanel.doorPanelStatisticalData/post
 */
char* HCDoorPanelStatusData(int status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorPanelStatusData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"doorOpeningClosingStatus\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}
/***==================================================轿厢-轿门-皮带==================================================***/
/*
 * 函数功能：轿厢-轿门-皮带-皮带检测数据
 * method：
 * result:门打滑检测结果    0:0  1:1  2:2  3:3    打滑检测结果，分为4等级 用数字表示等级
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.strap.beltDetectionData/post
 */
char* HCBeltDetectionData(int status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.beltDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"doorSlipDetectionResult\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}
/***================================================轿厢-轿门-锁钩=====================================================***/
/*
 * 函数功能：轿厢-轿门-锁钩-锁钩数据集
 * method:
 * state:锁钩状态   ture:锁钩  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.lockHook.lockHookDataSet/post
 */
char* HCLockHookDataSet(char* status, int Floor,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.lockHookDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"lockHookDataSet\":\"%s\",\"floor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status ,Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***=================================================轿厢-轿门-同步门电机==============================================***/
/*
 * 函数功能：轿厢-轿门-同步门电机-门电机检测数据
 * method
 * HighA:关门最大电流高速段 double  0.1A
 * LowA:关门最大电流低速段  double  0.1A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.synchronousDoorMotor.doorMotorDetectionData/post
 */
char* HCSyncDoorMotorDetectionData(double HighA ,double LowA , int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorMotorDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%d\",\"value\":{\"closeDoorMaximumCurrentHighSpeedSection\":\"%lf\",\"closeDoorMaximumCurrentLowSpeedSection\":\"%lf\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), HighA , LowA ,ack);
    char* temp = tempbuf;
    return temp;
}
/***==============================================轿厢-轿门-异步门电机=====================================================****/
/*
 * 函数功能：轿厢-轿门-异步门电机-门电机检测数据
 * method：
 * HighA:关门最大电流高速段 double  0.1A
 * LowA:关门最大电流低速段  double  0.1A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.asynchronousDoorMotor.doorMotorDetectionData/post
 */
//char* HCAsyncDoorMotorDetectionData(double HighA, double LowA, int ack)
//{
//    char tempbuf[MAXCJSONLENG] = { 0 };
//    char method[512] = { 0 };
//    strcat(method, "thing.event.doorMotorDetectionData.post");
//    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":,\"params\":{\"time\":%d,\"value\":{\"closeDoorMaximumCurrentHighSpeedSection\":\"%lf\",\"closeDoorMaximumCurrentLowSpeedSection\":\"%lf\"}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), HighA, LowA, ack);
//    char* temp = tempbuf;
//    return temp;
//}
/***==============================================机器人=====================================================****/
/*
 * 函数功能：电梯上报
 * method：
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * topic :thing.event.agvInformationEvent.post
 */
char *HCAGVInformationEvent( ST_AGVInformationEvent AGVInformationEvent,int ack)
{
    char runingStatus[5]={0};
    char upStopFloorValue[MAXCJSONLENG] = { 0 };
    char downStopFloorValue[MAXCJSONLENG] = { 0 };
    char identifier[512] = { 0 };
    if(AGVInformationEvent.runingStatus==true)
    {
        strcat(runingStatus,"true");
    }
    else {
        strcat(runingStatus,"false");
    }
    char overhaulStatus[5]={0};
    if(AGVInformationEvent.overhaulStatus==true)
    {
        strcat(overhaulStatus,"true");
    }
    else {
        strcat(overhaulStatus,"false");
    }
    char carOverloadSignal[5]={0};
    if(AGVInformationEvent.carOverloadSignal==true)
    {
        strcat(carOverloadSignal,"true");
    }
    else {
        strcat(carOverloadSignal,"false");
    }
    char carFullLoadSignal[5]={0};
    if(AGVInformationEvent.carFullLoadSignal==true)
    {
        strcat(carFullLoadSignal,"true");
    }
    else {
        strcat(carFullLoadSignal,"false");
    }
    char runningDirection[5]={0};
    if(AGVInformationEvent.runningDirection==true)
    {
        strcat(runningDirection,"true");
    }
    else {
        strcat(runningDirection,"false");
    }
    char serialCommunicationStatus[5]={0};
    if(AGVInformationEvent.serialCommunicationStatus==true)
    {
        strcat(serialCommunicationStatus,"true");
    }
    else {
        strcat(serialCommunicationStatus,"false");
    }
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    for (int i = 0; i < 48; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        if(AGVInformationEvent.UpStopFloor[i].upStopFloor!=0)
        {
            sprintf(identifier, "{\"floor\":%d}", AGVInformationEvent.UpStopFloor[i].upStopFloor);
            strcat(upStopFloorValue, identifier);
             //HC_PRINT("upStopFloor=%s",identifier);
        }

        if(i < AGVInformationEvent.upStopThick-1)
            strcat(upStopFloorValue, ",");

    }

    for (int i= 0; i < 48; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        if(AGVInformationEvent.DownStopFloor[i].downStopFloor!=0)
        {
            sprintf(identifier, "{\"floor\":%d}", AGVInformationEvent.DownStopFloor[i].downStopFloor);
            strcat(downStopFloorValue, identifier);
            // HC_PRINT("downStopFloor=%s",identifier);
        }

        if(i < AGVInformationEvent.downStopThick-1)
            strcat(downStopFloorValue, ",");

    }
    strcat(method, "thing.event.agvInformationEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"runingStatus\":%s,\"overhaulStatus\":%s,\"carOverloadSignal\":%s,\"carFullLoadSignal\":%s,\"runningDirection\":%s,\"carDoorOpeningClosingStatus\":%d,\"person\":%d,\"serialCommunicationStatus\":%s,\"callElevatorUpStopFloorRegistration\":[%s],\"callElevatorDownStopFloorRegistration\":[%s],\"downStatus\":%d,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",\
            HC_MQttIdGet(2294967295,4294967295), method, (long)(HC_LocalTimeGet()*1000), runingStatus, overhaulStatus,carOverloadSignal,carFullLoadSignal,runningDirection,AGVInformationEvent.carDoorOpeningClosingStatus,AGVInformationEvent.person,serialCommunicationStatus,upStopFloorValue,downStopFloorValue,AGVInformationEvent.downStatus,AGVInformationEvent.floor, ack);
    char* temp = tempbuf;
    return temp;
}


/*
 * 函数功能：方法回复
 * method：
 * methodReply :ture 成功，失败
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 */
char *HCmethodReply(long id, bool methodReply)
{
    char message[10]={0};
    char tempbuf[512] = { 0 };
    char methodReplybuf[5]={0};
    if(methodReply==true)
    {
        strcat(methodReplybuf,"true");
        strcat(message,"success");
    }
    else {
        strcat(methodReplybuf,"false");
        strcat(message,"failed");
    }

    sprintf(tempbuf, "{\"id\":%ld,\"code\":\"200\",\"data\":{\"methodReply\":%s}, \"message\":\"%s\"}", id, methodReplybuf, message);
    char* temp = tempbuf;
    return temp;
}


/*
 * 函数功能：显示楼层和物理楼层的对照表事件
 * method：
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * topic :thing.event.comparisonTableOfFloorAndPhysicalFloorEvent.post
 */
char *HCComparisonTableOfFloorAndPhysicalFloorEvent( ST_ComparisonTable ComparisonTable,int ack)
{
    char method[512] = { 0 };
    char tempbuf[MAXCJSONLENG] = { 0 };
    char databuf[MAXCJSONLENG] = { 0 };
    char buf[256]={0};
    for (int i=0;i<ComparisonTable.floorThick;i++) {
        memset(buf,0x0,sizeof (buf));
        sprintf(buf,"{\"realFloor\":%d,\"displayFloor\":\"%s\"}",ComparisonTable.FloorNum[i].physicalFloor,ComparisonTable.FloorNum[i].showFloor);
        strcat(databuf,buf);
        if(i<ComparisonTable.floorThick-1)
        {
            strcat(databuf,",");
        }
    }
    strcat(method, "thing.event.comparisonTableOfRealFloorAndDisplayFloorEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":[%s]}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method, (long)(HC_LocalTimeGet()*1000), databuf,ack);
    char* temp = tempbuf;
    return temp;
}
