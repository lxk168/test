
#include "HCMqttSubProcess.h"
#include"public/HCPulicAPI.h"
#include"public/HCFileOperation.h"
#include"application/HCBusinessTopic.h"
#include"application/HCBusinessCjsonAnalysis.h"
#include"application/HCBusinessCJson.h"
#include"application/HCBusinessCode.h"
static char Mmap_Clinetadress[256]={"/userdata/usr/local/control_mqtt_client.mmap"};
void *HC_MQTTSubProcess_Thread(void )

{
    ST_MqttMmapInfo *mmapfd;
    int ReadFd= 0,WriteFd=0;
    long cmp1=0;
    long cmp2=0;

    ST_InnerCallLift InnerCallLift;
    ST_OuterCallLift  OuterCallLift;
    ST_frontDoorOpenKeepCommand  frontDoorOpenKeepCommand;
    ST_frontDoorCloseCommand frontDoorCloseCommand;
    ReadFd = open(Mmap_Clinetadress, O_RDWR);
    if (ReadFd < 0)
    {
        HC_fileOpen(&WriteFd, Mmap_Clinetadress, O_RDWR | O_CREAT);
        lseek(WriteFd, MQTTLENG-1, SEEK_SET);
        write(WriteFd, "\0", 1);
        //申请映射
        mmapfd = mmap(NULL, (size_t)MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
        if ( mmapfd == MAP_FAILED)
        {
            HC_PRINT("mmap error\n");

            HCMsgSend(__FILE__,__LINE__,"all","mmap error");
            close(ReadFd);
            close(WriteFd);
        }
        close(ReadFd);
        close(WriteFd);

        munmap( mmapfd, MQTTLENG);
        ReadFd = open(Mmap_Clinetadress, O_RDWR);

    }
    mmapfd = mmap(NULL, MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
    if ( mmapfd == MAP_FAILED)
    {
        HC_PRINT("mmap error\n");
        HCMsgSend(__FILE__,__LINE__,"all","mmap error");
        close(ReadFd);
        close(WriteFd);
    }
    close(ReadFd);
    close(WriteFd);
    mmapfd->finishflag=0;
    mmapfd->time=0;

    while (1){

        cmp2=mmapfd->time;
        if(cmp1!=cmp2)
        {
            cmp1=cmp2;
            HC_PRINT("topic=%s \n json=%s",mmapfd->topic,mmapfd->mqttdata);
            Timer timer;
            InitTimer(&timer);
            countdown_ms(&timer, 2000);
            do{

                if(mmapfd->finishflag==1)
                    break;
            }while(!expired(&timer));
            mmapfd->finishflag=0;
            for (int i=0;i<3;i++) {
                if(strcmp(mmapfd->topic,HCinnerCallLiftTopic_Sub[i])==0)
                {

                    memset(&InnerCallLift,0x0,sizeof (ST_InnerCallLift));
                    memcpy(&InnerCallLift, HCinnerCallLift_Cjson_Analysis(mmapfd->mqttdata),sizeof (ST_InnerCallLift));
                    if(InnerCallLift.id!=0)
                    {

                        HC_PRINT("内呼楼层为%d",InnerCallLift.floor);
                        HC_internal_call(i+2,InnerCallLift.floor);
                        HCmethodReply_Upload(HCinnerCallLiftTopic_Pub[i],InnerCallLift.id,true);
                    }

                }
                else if(strcmp(mmapfd->topic,HCouterCallLiftTopic_Sub[i])==0)
                {
                    memset(&OuterCallLift,0x0,sizeof (ST_OuterCallLift));
                    memcpy(&OuterCallLift,HC_outerCallLift_Cjson_Analysis(mmapfd->mqttdata),sizeof (ST_OuterCallLift));
                    if(OuterCallLift.id!=0)
                    {
                        if(OuterCallLift.optType==1)
                        {

                            HC_PRINT("指定外呼楼层为%d，方向为%d",OuterCallLift.floor,OuterCallLift.direction);
                             HC_outer_call(i+2,OuterCallLift.floor,OuterCallLift.direction);

                            HCmethodReply_Upload(HCouterCallLiftTopic_Pub[i],OuterCallLift.id,true);

                        }else if (OuterCallLift.optType==2) {

                            HC_PRINT("动态外呼楼层为%d，方向为%d",OuterCallLift.floor,OuterCallLift.direction);
                              HC_disability_outer_call(i+2,OuterCallLift.floor,OuterCallLift.direction);

                            HCmethodReply_Upload(HCouterCallLiftTopic_Pub[i],OuterCallLift.id,true);

                        }

                    }

                }
                else if(strcmp(mmapfd->topic,HCfrontDoorOpenKeepCommandTopic_Sub[i])==0)
                {
                    memset(&frontDoorOpenKeepCommand,0x0,sizeof (ST_frontDoorOpenKeepCommand));
                    memcpy(&frontDoorOpenKeepCommand,HC_frontDoorOpenKeepCommand_Cjson_Analysis(mmapfd->mqttdata),sizeof (ST_frontDoorOpenKeepCommand));
                    if(frontDoorOpenKeepCommand.id!=0)
                    {

                        HC_PRINT("开门保持为%d，时间为%d",frontDoorOpenKeepCommand.frontDoorOpenKeepFunction,frontDoorOpenKeepCommand.delay);
                         HC_open_door(i+2,frontDoorOpenKeepCommand.frontDoorOpenKeepFunction,frontDoorOpenKeepCommand.delay);

                        HCmethodReply_Upload(HCfrontDoorOpenKeepCommandTopic_Pub[i],frontDoorOpenKeepCommand.id,true);


                    }

                }
                else if(strcmp(mmapfd->topic,HCfrontDoorCloseCommand_Sub[i])==0)
                {
                    memset(&frontDoorCloseCommand,0x0,sizeof (ST_frontDoorCloseCommand));
                    memcpy(&frontDoorCloseCommand,HCfrontDoorCloseCommand(mmapfd->mqttdata),sizeof (ST_frontDoorCloseCommand));
                    if(frontDoorCloseCommand.id!=0)
                    {

                            HC_PRINT("关门");
                            HC_close_door(i+2,1);
                            HCmethodReply_Upload(HCfrontDoorCloseCommand_Pub[i],frontDoorCloseCommand.id,true);


                    }

                }

            }
        }

        usleep(200000);
    }
}
