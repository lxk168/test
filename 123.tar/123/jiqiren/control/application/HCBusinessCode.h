﻿
#ifndef HCBUSINESSCODE_H
#define HCBUSINESSCODE_H
#include "common.h"
extern int HCmethodReply_Upload(char * topic,long id ,bool flag);
extern int HC_agvInformationEvent_Upload(int id,struct ST_elevator_common_data_t elevator_common_data_t);
extern int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload(int id,struct ST_elevator_display_param_t elevator_display_param_t);
extern int  HC_internal_call(int slave,int floor); //内呼
extern int HC_outer_call(int slave,int floor,int direction);//外呼
extern int HC_open_door(int slave,int door,int sec); //开门
extern int HC_close_door(int slave,int door); //关门
extern int HC_disability_outer_call(int slave, int floor, int direction); //残障
extern int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload2(int id,struct ST_elevator_display_param_t elevator_display_param_t);
#endif



