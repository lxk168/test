﻿
#ifndef HCBUSINESSCJSON_H
#define HCBUSINESSCJSON_H
#include "common.h"

#include "public/HCPublicStruct.h"
#include "public/HCPulicAPI.h"
#define MaxFloorNum   (112)   //最大楼层数
#define MaxButtonNum   (112)   //最大按钮个数
#pragma pack (1)
typedef struct
{
    int thick; //动作次数
}ST_FloorNum;
typedef struct
{
    int allNum; //总的有效按钮
    ST_FloorNum FloorNum[MaxButtonNum];//按钮号
}ST_ButtonEvent;

typedef struct
{
    char* upCall;//上召指令 ture:有上召指令  false:无上召指令
    char* downCall;//下召指令 ture:有下召指令  false:无下召指令
}ST_FloorCall;
typedef struct
{
    int allNum; //总的有效楼层
    ST_FloorCall FloorNum[MaxFloorNum];//楼层号
}ST_CallEvent;
enum ST_CarDoorStation
{
    ONE=0, TWO, THREE, FOUR, FIVE, SIX, SEVEN,EIGHT,NINE
};
typedef struct
{
    int upStopFloor;//呼梯上行停靠楼层

}ST_UpStopFloor;
typedef struct
{
    int downStopFloor;//呼梯下行停靠楼层

}ST_DownStopFloor;

typedef struct
{
    bool  runingStatus; //运行状态  ture:正常  false:故障
    bool  overhaulStatus; //检修状态  ture:正常  false:检修
    bool  carOverloadSignal; //轿厢超载信号  ture:超载信号有效  false:超载信号无效
    bool  carFullLoadSignal; //轿厢满载信号  ture:满载信号有效  false:满载信号无效
    bool  runningDirection; //运行方向  ture:上行  false:下行
    bool  serialCommunicationStatus; //串口通讯状态
    int person;//轿厢人数
    int floor;//轿厢当前楼层
    enum ST_CarDoorStation downStatus; //停机状态
    enum ST_CarDoorStation carDoorOpeningClosingStatus; //轿门开关门状态  0:未知状态 1:开门过程 2:开门到位 3:关门过程 4:关门到位
    int upStopThick; //呼梯上行停靠楼层总数
    int downStopThick; //呼梯下行停靠楼层总数
    ST_UpStopFloor UpStopFloor[MaxFloorNum];//最大楼层数112
    ST_DownStopFloor DownStopFloor[MaxFloorNum];//最大楼层数112
}ST_AGVInformationEvent;
//显示楼层和物理楼层的对照表事件
typedef struct
{
    int physicalFloor;//物理楼层
    char showFloor[10]; //显示楼层
}ST_FloorInfo;
typedef struct
{
    int floorThick; //记录的楼层数
    ST_FloorInfo FloorNum[MaxFloorNum];
}ST_ComparisonTable;
#pragma pack ()
extern char* HCDoorMachinePreMaintenanceStatus(int status, int ack);
extern char* HCDoorLockShortCircuitFaultDetection(char* status, int ack);
extern char* HCSpecialFunction(int TotalOcclusionState, int lightNumber, int BlockingState , int DecayValue, int ack);
extern char* HCSlidingRailFrictionDetectionData(char* doorFriction, int Floor, int ack);
extern char* HCCarDoorLockStatisticalData(int openTimes,int closTimes, int ack);
extern char* HCCarDoorLockOnOffState(char* state, int Floor, int ack);
extern char* carSillDetectionData(char* doorFriction, int Floor, int ack);
extern char* HCDoorBallDataSet(int result, int Floor, int ack);
extern char* HCDoorDetectionData(char* pullDoor,char* kickDoor,char* clip ,int ack);
extern char* HCDoorPanelStatisticalData(int time,int times,int abnormalTimes,int Floor, int ack);
extern char* HCDoorPanelStatusData(int status, int ack);
extern char* HCBeltDetectionData(int status, int ack);
extern char* HCLockHookDataSet(char* status, int Floor,int ack);
extern char* HCSyncDoorMotorDetectionData(double HighA ,double LowA , int ack);
extern char* HCAsyncDoorMotorDetectionData(double HighA, double LowA, int ack);
extern char *HCAGVInformationEvent( ST_AGVInformationEvent AGVInformationEvent,int ack);
extern char *HCinnerCallLift(long id, bool methodReply);
extern char *HCfrontDoorOpenKeepCommand( long id,bool methodReply);
extern char *HCbackDoorOpenKeepCommand( bool methodReply,int ack);
extern char *HCouterCallLift(long id, bool methodReply);
extern char *HCComparisonTableOfFloorAndPhysicalFloorEvent( ST_ComparisonTable ComparisonTable,int ack);
extern char *HCmethodReply(long id, bool methodReply);
#endif



