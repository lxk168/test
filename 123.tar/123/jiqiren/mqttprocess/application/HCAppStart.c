﻿#include "HCAppStart.h"
#include "common.h"
int processnum=0;

ST_Mmap_adress  Mmap_Serveradress[PROCESSNUM]={

    {"/userdata/usr/local/connect_mqtt_server.mmap"},
   {"/userdata/usr/local/remoteupgrade_mqtt_server.mmap"},
    {"/userdata/usr/local/control_mqtt_server.mmap"}

};
ST_Mmap_adress  Mmap_Clientadress[PROCESSNUM]={

    {"/userdata/usr/local/remoteupgrade_mqtt_client.mmap"},
   {"/userdata/usr/local/connect_mqtt_client.mmap"},
    {"/userdata/usr/local/control_mqtt_client.mmap"}

};
int HC_ProcessCount(int Processnum)
{
    int num=0;
    for (int i=0;i<Processnum;i++) {

        if (strlen(Mmap_Serveradress[i].filename)==0) {
            break;
        }
        num++;
    }

    return num;
}

void *HC_MmapProcess_Thread(void)
{
    ST_Cmp Cmp[PROCESSNUM];

    ST_MqttMmapInfo *mmapfd[PROCESSNUM];
    int ReadFd= 0,WriteFd=0;
    int i=0;
    for (int i=0;i<PROCESSNUM;i++) {
        memset(&Cmp[i],0x0,sizeof (ST_Cmp));
    }
    for (i=0;i<processnum;i++) {


        if(strlen(Mmap_Serveradress[i].filename)!=0)
        {

            ReadFd = open(Mmap_Serveradress[i].filename, O_RDWR);
            if (ReadFd < 0)
            {
                HC_fileOpen(&WriteFd, Mmap_Serveradress[i].filename, O_RDWR | O_CREAT);
                lseek(WriteFd, MAPLENG-1, SEEK_SET);
                write(WriteFd, "\0", 1);
                //申请映射
                mmapfd[i] = mmap(NULL, (size_t)MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
                if ( mmapfd[i] == MAP_FAILED)
                {
                    HC_PRINT("mmap error\n");

                    HCMsgSend(__FILE__,__LINE__,"mqttprocess","mmap error");
                    close(ReadFd);
                    close(WriteFd);
                }
                close(ReadFd);
                close(WriteFd);

                munmap( mmapfd[i], MAPLENG);
                ReadFd = open(Mmap_Serveradress[i].filename, O_RDWR);

            }
            mmapfd[i] = mmap(NULL, MAPLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
            if ( mmapfd[i] == MAP_FAILED)
            {
                HC_PRINT("mmap error\n");
                HCMsgSend(__FILE__,__LINE__,"mqttprocess","mmap error");
                close(ReadFd);
                close(WriteFd);
            }
            close(ReadFd);
            close(WriteFd);
        }

        mmapfd[i]->finishflag=0;
        mmapfd[i]->time=0;
        memset(&Cmp[i],0x0,sizeof (ST_Cmp));
    }

    while (1) {

        for (i=0;i<processnum;i++) {

            Cmp[i].cmp2=mmapfd[i]->time;

            if( Cmp[i].cmp1!= Cmp[i].cmp2)
            {
                Cmp[i].cmp1= Cmp[i].cmp2;
                if(Cmp[i].cmp1!=0)
                {


                    if(HCMqttClientMsgSend(mmapfd[i])!=ERR_COMMON_SUCCESS)
                    {
                        HC_PRINT("MQTTSendFall");
                        mmapfd[i]->finishflag=0;
                        continue;
                    }
                    else {

                        mmapfd[i]->finishflag=0;
                    }
                }
            }
            usleep(50000);
        }
    }
}
void HC_MQTTConnect(void )
{

    memset(&MqttLoginInfo,0x0,sizeof (ST_MqttLoginInfo));
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    char portbuf[10]={0};
    char hostbuf[512]={0};
    char clientIDbuf[512]={0};
    char UserNamebuf[1024]={0};
    char Passwordbuf[1024]={0};

    HCGetProfileString(file_path, app_name, (char*)"MqttHost", hostbuf);
    MqttLoginInfo.MqttHost=hostbuf;
    HCGetProfileString(file_path, app_name, (char*)"MqttPORT", portbuf);
    MqttLoginInfo.MqttPORT=atoi(portbuf);
    HCGetProfileString(file_path, app_name, (char*)"MqttClientID", clientIDbuf);
    MqttLoginInfo.MqttClientID=clientIDbuf;
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    MqttLoginInfo.MqttUserName=UserNamebuf;
    HCGetProfileString(file_path, app_name, (char*)"MqttPassWord", Passwordbuf);
    MqttLoginInfo.MqttPassWord=Passwordbuf;
    //            MqttLoginInfo.MqttHost="192.168.250.123";
    //            MqttLoginInfo.MqttPORT=1883;
    //            MqttLoginInfo.MqttClientID="123456789";
    //            MqttLoginInfo.MqttUserName="admin";
    //            MqttLoginInfo.MqttPassWord="public";
    ST_MqttTopicInfo MqttTopicInfo;
    memset(&MqttTopicInfo,0x0,sizeof (ST_MqttTopicInfo));
    memcpy(&MqttTopicInfo,HC_TopicRead(),sizeof (ST_MqttTopicInfo));
    HC_MQTT_Init(MqttLoginInfo,MqttTopicInfo);
}
int HCMqttClientMsgSend(ST_MqttMmapInfo *MqttMmapInfo)
{
    if(strlen(MqttMmapInfo->topic)!=0)
    {
        //HC_PRINT("pubtopic:%s\n json:%s",MqttMmapInfo->topic,MqttMmapInfo->mqttdata);
        HC_MQTT_Publish( MqttMmapInfo->topic,MqttMmapInfo->mqttdata);
    }
    else {
        return ERR_COMMON_FAILED;
    }
    return ERR_COMMON_SUCCESS;
}
void HCAppStart_Init(void)
{

    processnum=HC_ProcessCount(PROCESSNUM);
    HC_SubTopicRead();
    HC_MQTTConnect();
    pthread_t thread_ID2;                //定义线程id
    HCMmapsend_Process_Init();
    pthread_create(&thread_ID2, NULL, HC_MmapProcess_Thread, NULL); //创建一个线程执
    pthread_detach(thread_ID2);  //设置线程结束收尸
}

