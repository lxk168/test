﻿
#ifndef HCBUSINESSCJSON_H
#define HCBUSINESSCJSON_H
#include "common.h"

#include "public/HCPublicStruct.h"
#include "public/HCPulicAPI.h"
#define MaxFloorNum   (56)   //最大楼层数
#define MaxButtonNum   (112)   //最大按钮个数
typedef struct
{
    int thick; //动作次数
}ST_FloorNum;
typedef struct
{
    int allNum; //总的有效按钮
    ST_FloorNum FloorNum[MaxButtonNum];//按钮号
}ST_ButtonEvent;

typedef struct
{
    char* upCall;//上召指令 ture:有上召指令  false:无上召指令
    char* downCall;//下召指令 ture:有下召指令  false:无下召指令
}ST_FloorCall;
typedef struct
{
    int allNum; //总的有效楼层
    ST_FloorCall FloorNum[MaxFloorNum];//楼层号
}ST_CallEvent;
enum ST_CarDoorStation
{
    ONE=0, TWO, THREE, FOUR, FIVE, SIX, SEVEN,EIGHT,NINE
};
typedef struct
{

    bool  runingStatus; //运行状态
    bool  overhaulStatus; //检修状态
    bool  carOverloadSignal; //轿厢超载信号
    bool  carFullLoadSignal; //轿厢满载信号
    bool  runningDirection; //运行方向
    enum ST_CarDoorStation carDoorOpeningClosingStatus; //轿门开关门状态
    int person;
    bool  serialCommunicationStatus; //串口通讯状态
    enum ST_CarDoorStation downStatus; //轿门开关门状态
    int floor;//轿厢当前楼层

}ST_AGVInformationEvent;
extern char* HCDoorMachinePreMaintenanceStatus(int status, int ack);
extern char* HCDoorLockShortCircuitFaultDetection(char* status, int ack);
extern char* HCSpecialFunction(int TotalOcclusionState, int lightNumber, int BlockingState , int DecayValue, int ack);
extern char* HCSlidingRailFrictionDetectionData(char* doorFriction, int Floor, int ack);
extern char* HCCarDoorLockStatisticalData(int openTimes,int closTimes, int ack);
extern char* HCCarDoorLockOnOffState(char* state, int Floor, int ack);
extern char* carSillDetectionData(char* doorFriction, int Floor, int ack);
extern char* HCDoorBallDataSet(int result, int Floor, int ack);
extern char* HCDoorDetectionData(char* pullDoor,char* kickDoor,char* clip ,int ack);
extern char* HCDoorPanelStatisticalData(int time,int times,int abnormalTimes,int Floor, int ack);
extern char* HCDoorPanelStatusData(int status, int ack);
extern char* HCBeltDetectionData(int status, int ack);
extern char* HCLockHookDataSet(char* status, int Floor,int ack);
extern char* HCSyncDoorMotorDetectionData(double HighA ,double LowA , int ack);
extern char* HCAsyncDoorMotorDetectionData(double HighA, double LowA, int ack);
extern char *HCAGVInformationEvent( ST_AGVInformationEvent AGVInformationEvent,int ack);
#endif



