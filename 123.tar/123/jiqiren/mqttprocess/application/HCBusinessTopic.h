﻿
#ifndef HCBUSINESSTOPIC_H
#define HCBUSINESSTOPIC_H
#include"common.h"
extern char *HCBusinessTopicBulid(char *method);
#endif



