﻿#include"application/HCBusinessTopic.h"
#include"public/HCProfileUtil.h"

char *HCBusinessTopicBulid(char *method)
{
    char Topicbuf[2048]={0};
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";

    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);

    sprintf(Topicbuf,"/tsl/%s/%s/thing/event/%s/post",ThingCategoryKeybuf,DeviceName,method);

    char *temp=Topicbuf;
    return temp;
}
