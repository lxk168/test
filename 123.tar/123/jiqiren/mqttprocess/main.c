#include <stdio.h>
#include"application/HCAppStart.h"
#include "public/HCFileOperation.h"
#include"public/HCPulicAPI.h"
#include"public/HCPublicStruct.h"
#include"public/HCmqtt.h"
int main()
{

    HCAppStart_Init();

    while(1)
    {  
        sleep(1);
    }

}
