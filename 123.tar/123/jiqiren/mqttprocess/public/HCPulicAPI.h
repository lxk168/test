﻿#ifndef HCPULICAPI_H
#define HCPULICAPI_H
#include "common.h"
#include <pthread.h>
#include"public/HCPublicStruct.h"
#define MAPLENG 0x4000 //最大映射大小
#include "public/HCFileOperation.h"
#include "public/HCmqtt.h"
//数据结构体
typedef  struct{
  char name[20000];
}STU;
typedef  struct{

    long time;
    int finishflag;
    char topic[1024];
    char mqttdata[1024*10];
}ST_MqttMmapInfo;
typedef struct{
    long cmp1;
    long cmp2;
}ST_Cmp;
typedef struct  {

    char filename[512];

}ST_Mmap_adress;
extern  ST_Mmap_adress  Mmap_Serveradress[PROCESSNUM];
extern  ST_Mmap_adress  Mmap_Clientadress[PROCESSNUM];
extern ST_MqttMmapInfo *mmapfd[PROCESSNUM];
extern int HC_LinuxSystem( const char* pcCommand,  char *pcBackBuf);
extern int HC_LinuxKillProcess( const char* pcProcessName);
extern  int HC_ProcessMointor( const char* pcProcessName);
extern int HC_PthreadCreate(pthread_t ThreadID,void *Process_Thread);
extern St_SystemTime * HCGetTime(void);
extern void substr(char *source,int start,int length,char *dest);
extern int HC_LocalTimeGet(void);
extern int HCFileCopy(char *source,char *dist);
extern int HCMsgSend(char *file,int line,char *idbuf,char *sendbuf);
extern char * HCStingOut(char *intbuf);
extern int HCRemoveAdress(char *address);
extern void HC_MQTTMmap_Send(char *topic,char *sendbuf);
extern void HCMmapsend_Process_Init(void);
extern int mmapintflag;
#endif
