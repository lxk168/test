#ifndef HCPROFILEUTIL_H
#define HCPROFILEUTIL_H

#include "common.h"

extern char* l_trim(char* szOutput, const  char* szInput);
extern char* r_trim(char* szOutput, const  char* szInput);
extern char* a_trim(char* szOutput, const  char* szInput);
extern int  HCGetProfileString(char* profile, char* appName, char* keyName, char* keyVal);
#endif
