#ifndef HCPUBLICSTRUCT_H
#define HCPUBLICSTRUCT_H
#include "common.h"
#pragma pack (1)
typedef struct{
    char UserName[20];                      //用户名
    char Password[20];                       //密码
    unsigned int       S_ipAddr;
    unsigned short   S_PortNum;
    char lPortPasv;                              //主从模式
    char cDataType;                            //数据传输类型
    unsigned int uTimeOutUsec;       //超时时间
    char szRemFilePath[60];            //远程路径
} St_Net_Ftp_Info;

typedef struct
{

    int tm_sec;            /* seconds */
    int tm_min;           /* minutes */
    int tm_hour;         /* hours */
    int tm_mday;        /* day of the month */
    int tm_mon;         /* month */
    int tm_year;          /* year */
} St_SystemTime;
typedef struct {
    long int mtype;
    char mtext[2048];
}ST_mymesg;
#pragma pack()
extern St_Net_Ftp_Info    Net_Ftp_Info;
extern char idstrbuf[3][50];
extern int msgfd;
//extern zsock_t* logpush;
#endif // HCPUBLICSTRUCT_H
