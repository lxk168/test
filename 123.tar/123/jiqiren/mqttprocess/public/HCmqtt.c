
#include"common.h"
#include "public/HCmqtt.h"
#include "public/HCPulicAPI.h"
#include "public/HCProfileUtil.h"
#include "public/HCPublicStruct.h"
ST_MqttLoginInfo  MqttLoginInfo;
ST_MqttTopicInfo  MqttTopicInfo;
static int mqttsendfalg=1;

#define TIMEOUT     10000L
static MQTTClient client;
static MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
static MQTTClient_message pubmsg = MQTTClient_message_initializer;
static MQTTClient_deliveryToken token;
volatile MQTTClient_deliveryToken deliveredtoken;
static char getbuf[MQTT_BUF_SIZE]={0};
//static char topicbuf[MQTT_BUF_SIZE]={0};
ST_MqttTopicInfo MqttTopicInfoSum[5];
//MQTT初始化
int HC_SubTopicRead()
{
    char* topic_path = (char*)"/userdata/usr/local/subtopic.conf";
    char* topic_name = (char*)"mqtt_subtopic";
    char appnamebuf[10]={0};
    int num=0;


    for (int i=0;i<MQTT_NUM;i++) {
        memset(appnamebuf,0x0,sizeof (appnamebuf));
        sprintf(appnamebuf,"%dtopic",num);
        num++;
        HCGetProfileString(topic_path, topic_name, (char *)appnamebuf, MqttTopicInfoSum[2].MqttTopic[i].Topic);
        if(strlen(MqttTopicInfoSum[2].MqttTopic[i].Topic)==0)
            break;

    }

    return 0;

}
ST_MqttTopicInfo * HC_TopicRead()
{
    ST_MqttTopicInfo *mqttTopicInfo=&MqttTopicInfo;

    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    char *ptr=NULL;
    int topicnum=0;
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    sprintf(mqttTopicInfo->MqttTopic[topicnum].Topic,"/ota/%s/%s/firmware/#",ThingCategoryKeybuf,DeviceName);
    topicnum++;
    sprintf(mqttTopicInfo->MqttTopic[topicnum].Topic,"/tls/%s/%s/thing/#",ThingCategoryKeybuf,DeviceName);
    return mqttTopicInfo;
}
void delivered(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken = dt;
}
//int num=1;
int msgarrvd(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{

    memset(getbuf,0x0,sizeof (getbuf));
    sprintf(getbuf,"%.*s", message->payloadlen, (char*)message->payload);
    HC_PRINT(" topicName: %s\n",topicName);
   // HC_PRINT("   message: %.*s\n", message->payloadlen, (char*)message->payload);
    for (int j=0;j<processnum;j++) {

        for (int i=0;i<HCTopicNum(MqttTopicInfoSum[j]);i++) {
            if(strlen(MqttTopicInfoSum[j].MqttTopic[i].Topic)==0)
            {
                //j++;
                break;
            }
            if(strcmp(topicName,MqttTopicInfoSum[j].MqttTopic[i].Topic)==0)
            {
                HC_MQTTMmap_Send(topicName,getbuf);
            }
        }

    }

    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);

    return 1;
}

void connlost(void *context, char *cause)
{
    HC_PRINT("\nConnection lost\n");
    HC_PRINT("     cause: %s\n", cause);
}

int HC_MQTT_Init(ST_MqttLoginInfo  MqttLoginInfo,ST_MqttTopicInfo MqttTopicInfo)
{
    int rc;
    char hostbuf[512]={0};

    sprintf(hostbuf,"tcp://%s:%d",MqttLoginInfo.MqttHost,MqttLoginInfo.MqttPORT);
    if ((rc = MQTTClient_create(&client, hostbuf, MqttLoginInfo.MqttClientID,
                                MQTTCLIENT_PERSISTENCE_NONE, NULL)) != MQTTCLIENT_SUCCESS)
    {
        HC_PRINT("Failed to create client, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    if ((rc = MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered)) != MQTTCLIENT_SUCCESS)
    {
        HC_PRINT("Failed to set callbacks, return code %d\n", rc);
        rc = EXIT_FAILURE;
        MQTTClient_destroy(&client);
        return rc;
    }
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username=MqttLoginInfo.MqttUserName;
    conn_opts.password=MqttLoginInfo.MqttPassWord;
    if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS)
    {
        HC_PRINT("Failed to connect, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }


    for (int i=0;i<HCTopicNum(MqttTopicInfo);i++) {
        if ((rc = MQTTClient_subscribe(client, MqttTopicInfo.MqttTopic[i].Topic, 1)) != MQTTCLIENT_SUCCESS)
        {
            HC_PRINT("Failed to subscribe, return code %d\n", rc);
            rc = EXIT_FAILURE;
        }
        else {
            HC_PRINT("SubTopic=%s",MqttTopicInfo.MqttTopic[i].Topic);
        }
    }

    return rc;
}

//topic 数量计数
int HCTopicNum(ST_MqttTopicInfo MqttTopicInfo)
{
    int count=0,i=0;
    for (i=0;i<MQTT_NUM;i++) {

        if(strlen(MqttTopicInfo.MqttTopic[i].Topic)!=0)
        {
            count++;
        }
        else {
            break;
        }

    }
    return count;

}


int HC_MQTT_Publish(char * pubtopic,char *pbuf)
{

    int rc = 0;
    char my_topic[1024] = {0};
    int length=0;
    length=(int)strlen(pbuf);
    strcat(my_topic, pubtopic);
    pubmsg.payload = (void *)pbuf;
    pubmsg.payloadlen =length;
    pubmsg.retained = 0;
    pubmsg.qos = 1;
    if ((rc = MQTTClient_publishMessage(client, my_topic, &pubmsg, &token)) != MQTTCLIENT_SUCCESS)
    {
        //printf("Failed to publish message, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);

    return rc;
}
