﻿#include "HCAppStart.h"
#include "application/HCBusinessCJson.h"
#include "application/HCMqttPubProcess.h"
#include"application/HCMqttSubProcess.h"
#include "application/HCBusinessTopic.h"
#include"application/HCBusinessCjsonAnalysis.h"
#include"application/HCBusinessCode.h"
#include "application/HCVirtualdeviceSqlite.h"
#include "application/HCVirtualdeviceJsonBuild.h"
char Mmap_Serveradress[256]={"/userdata/usr/local/control_mqtt_server.mmap"};

ST_MqttInfo MqttInfo[3];
pthread_mutex_t mutex; //互斥锁
void HCStartTask(void)
{

    //       char buf[1024*2]={0};


    //       sprintf(buf,"{ \"method\": \"reply\",  \"timestamp\": 1639536175,  \"version\": 1,  \"payload\": {  \"status\": \"success\",  \"state\":{ \"desired\": {  \"elevator\": {  \"665601498937819136\": {  \"agvInformationEventConfiguration\": {  \"whetherToUpload\": false, \"whetherToUploadPeriodically\": false, \"uploadCycle\": 26392362}}}}},  \"metadata\": {  \"desired\": {   \"elevator\": {   \"665601498937819136\": {  \"agvInformationEventConfiguration\": { \"timestamp\": 1638859061}}}}}}}");
    //      HC_VirtualdevicGetInit(buf);

//    HCReadVirtualDeviceInforInit();

          //VirtualdeviceJsonBuild();
        pthread_t S1=1,S2=2,S3=3;
        HCZmqInit();
        HCTableInit(VIRTUALDEVICEPATH);
        sleep(2);
        HCSubTopicInit();
        HC_MmapProcess_Server_Init();
       // HCjsonFile("/userdata/usr/local/123.json");
        pthread_mutex_init(&mutex, NULL); //初始化互斥锁

        pthread_create(&S1, NULL, HC_MQTTSubProcess_Thread, NULL); //创建一个线程执
        pthread_detach(S1);  //设置线程结束收尸
        pthread_create(&S2, NULL, HCCollectionProcess_Thread, NULL); //创建一个线程执
        pthread_detach(S2);  //设置线程结束收尸
        pthread_create(&S3, NULL, HCMqttPubProcess_Thread, NULL); //创建一个线程执
        pthread_detach(S3);  //设置线程结束收尸



    //pthread_mutex_destroy(&mutex); //销毁互斥锁

}

int HCCollectionProcessStart(void )
{

    char pcCmdbuf[256]={0};
    sprintf(pcCmdbuf,"cd %s && nohup ./smart.exe 1 0 0 &",LocalPath);
    system(pcCmdbuf);
    return ERR_COMMON_SUCCESS;
}


