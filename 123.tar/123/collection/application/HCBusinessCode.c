﻿#include "application/HCBusinessCode.h"
#include "application/HCBusinessCJson.h"
#include"application/HCBusinessTopic.h"
#include"application/HCBusinessCjsonAnalysis.h"
#include "application/HCAppStart.h"
char idbuf[3][100]={
    "671785381129224192",
    "671785381129224192",
    "671785381129224192"
};
//   "680757119938199552"
int HC_agvInformationEvent_Upload(int id,struct ST_elevator_common_data_t elevator_common_data_t)
{
    char MqttSendBuf[1024*2]={0};
    ST_AGVInformationEvent AGVInformationEvent;
    memset(&AGVInformationEvent,0x0,sizeof (ST_AGVInformationEvent));
    if(elevator_common_data_t.fault_code==0)
    {
        AGVInformationEvent .runingStatus=true; //运行状态正常
    }else {
        AGVInformationEvent .runingStatus=false; //运行状态异常
    }
    if(elevator_common_data_t.service_mode==0)
    {
        AGVInformationEvent .overhaulStatus=true; //检修状态
    }else {
        AGVInformationEvent .overhaulStatus=false; //检修状态
    }

    if(elevator_common_data_t.load==1)
    {
        AGVInformationEvent .carOverloadSignal=false; //轿厢超载信号
        AGVInformationEvent .carFullLoadSignal=true; //轿厢满载信号
    }
    else if(elevator_common_data_t.load==2){
        AGVInformationEvent .carOverloadSignal=true; //轿厢超载信号
        AGVInformationEvent .carFullLoadSignal=true; //轿厢满载信号
    }
    else {
        AGVInformationEvent .carOverloadSignal=false; //轿厢超载信号
        AGVInformationEvent .carFullLoadSignal=false; //轿厢满载信号
    }

    if(elevator_common_data_t.car_status==1)
    {
        AGVInformationEvent .runningDirection=true; //上行
        AGVInformationEvent .downStatus=0; //轿门开关门状态上行
    }else if(elevator_common_data_t.car_status==2){
        AGVInformationEvent .runningDirection=false; //下行
        AGVInformationEvent .downStatus=1; //轿门开关门状态下行
    }else if(elevator_common_data_t.car_status==3) {
        AGVInformationEvent .downStatus=2; //轿门开关门状态停止
    }
    int up_callNum=0,down_callNum=0;
    for (int i=0;i<48;i++) {

        if(elevator_common_data_t.up_call[i]==1)
        {
            up_callNum++;
            AGVInformationEvent.UpStopFloor[i].upStopFloor=i+1;
            AGVInformationEvent.upStopThick=up_callNum;
        }
        if(elevator_common_data_t.down_call[i]==1)
        {
            down_callNum++;
            AGVInformationEvent.DownStopFloor[i].downStopFloor=i+1;
            AGVInformationEvent.downStopThick=down_callNum;


        }
    }
    AGVInformationEvent .carDoorOpeningClosingStatus=elevator_common_data_t.door_status; //轿门开关门状态
    AGVInformationEvent .person=0;
    AGVInformationEvent .serialCommunicationStatus=true; //串口通讯状态
    AGVInformationEvent .floor=elevator_common_data_t.current_floor;//轿厢当前楼层
    sprintf(MqttSendBuf,"%s",HCAGVInformationEvent(AGVInformationEvent,0));
    HC_MmapProcess_Server_Send(Topic_AllInfor.Topic_InforMation[id].Robot_Pub_Topic.HCagvInformationEventTopic_Pub,MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}
int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload(int id,struct ST_elevator_display_param_t elevator_display_param_t)
{
    char MqttSendBuf[1024*2]={0};

    ST_ComparisonTable ComparisonTable;
    memset(&ComparisonTable,0x0,sizeof (ST_ComparisonTable));
    int num=1;
    int num1=2;
    for (int i=0;i<30;i++) {

        sprintf(ComparisonTable.FloorNum[i].showFloor,"%d",num);

        ComparisonTable.FloorNum[i].physicalFloor=num1;
        num++;
        num1++;
        ComparisonTable.floorThick=i+1;
    }

    sprintf(MqttSendBuf,"%s",HCComparisonTableOfFloorAndPhysicalFloorEvent(ComparisonTable,1));
    HC_MmapProcess_Server_Send(Topic_AllInfor.Topic_InforMation[id].Robot_Pub_Topic.HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub,MqttSendBuf);
    HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}
int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload2(int id,struct ST_elevator_display_param_t elevator_display_param_t)
{
    char MqttSendBuf[1024*2]={0};

    ST_ComparisonTable ComparisonTable;
    memset(&ComparisonTable,0x0,sizeof (ST_ComparisonTable));
    int num=1;
    int count=0;
    for (int i=0;i<31;i++) {
        if( i==0)
        {
            sprintf(ComparisonTable.FloorNum[i].showFloor,"%d",-1);
              ComparisonTable.FloorNum[i].physicalFloor=1;

        }
        else {
             sprintf(ComparisonTable.FloorNum[i].showFloor,"%d",count);
               ComparisonTable.FloorNum[i].physicalFloor=num;
        }


        num++;count++;
        ComparisonTable.floorThick=i+1;
    }

    sprintf(MqttSendBuf,"%s",HCComparisonTableOfFloorAndPhysicalFloorEvent(ComparisonTable,1));
    HC_MmapProcess_Server_Send(Topic_AllInfor.Topic_InforMation[id].Robot_Pub_Topic.HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub,MqttSendBuf);
    HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}


int HCmethodReply_Upload(char * topic,long id ,bool flag)
{
    char TopicBuf[512]={0};
    char MqttSendBuf[512]={0};
    strcat(TopicBuf,topic);
    sprintf(MqttSendBuf,"%s",HCmethodReply(id,flag));
    HC_MmapProcess_Server_Send(topic,MqttSendBuf);
    HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
    return ERR_COMMON_SUCCESS;
}
int HC_internal_call(int slave,int floor)
{
     char buf[100]={0};
    sprintf(buf,"%s,%d,%d\n", "internal_call", slave, floor);
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_outer_call(int slave,int floor,int direction)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d,%d\n", "outer_call", slave, floor, direction);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_open_door(int slave,int door,int sec)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d,%d\n", "open_door", slave, door, sec);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_close_door(int slave,int door)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d\n", "close_door", slave, door);
    zmq_send(zmq_pub, buf,strlen(buf), 0);
    return ERR_COMMON_SUCCESS;
}
int HC_disability_outer_call(int slave, int floor, int direction)
{
    char buf[100]={0};
    zmq_send(zmq_pub, ELEVATOR_TOPIC_RPC,
             strlen(ELEVATOR_TOPIC_RPC), ZMQ_SNDMORE);
    sprintf(buf,"%s,%d,%d,%d\n", "disability_outer_call", slave, floor, direction);
    zmq_send(zmq_pub, buf,strlen(buf), 0);

   return ERR_COMMON_SUCCESS;
}
/*******************************************门机********************************************************************/

//(1)轿门个数
int HC_carDoorNumberEvent_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  int carDoorNumber;
  carDoorNumber=1;
  sprintf(MqttSendBuf,"%s",HCcarDoorNumberEvent(carDoorNumber,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarDoorNumberEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarDoorNumberEvent_Pub);
  return ERR_COMMON_SUCCESS;
}

//(2)门球对中
int HC_DoorBallDataSet_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*2]={0};
  int floor;
  int doorBallOffset;
//  floor=elevator_common_data_t.current_floor;
//  doorBallOffset=elevator_door_machine_t.front_door_center_result;
  floor=1;
  doorBallOffset=elevator_door_machine_t.front_door_center_result;
  sprintf(MqttSendBuf,"%s",HCDoorBallDataSet(doorBallOffset,floor,0));
  doorBallOffset=0;
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCdoorBallDataSet_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCdoorBallDataSet_Pub);
  return ERR_COMMON_SUCCESS;
}
//(3)皮带检测数据
int HC_BeltDetectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  int status;
  status=elevator_door_machine_t.front_door_double_slip_check_result;
  sprintf(MqttSendBuf,"%s",HCBeltDetectionData(status,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbeltDetectionData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbeltDetectionData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(4)轿厢地坎-轿厢地坎检测门摩檫力    偶数0:true  奇数：1:false
int HC_CarSillDetectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t ,struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*2]={0};
  int doorFriction;//门机预维保实时结果
  int Floor;
  doorFriction=elevator_door_machine_t.pre_maintain_result;
  Floor=elevator_common_data_t.current_floor;
  sprintf(MqttSendBuf,"%s",HCCarSillDetectionData(doorFriction,Floor,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarSillDetectionData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarSillDetectionData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(5)锁钩-锁钩故障
int HC_LockHookDataSet_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int floor;
  int pre_maintain_result;
  floor=elevator_common_data_t.current_floor;
  pre_maintain_result=elevator_door_machine_t.pre_maintain_result;
  sprintf(MqttSendBuf,"%s",HCLockHookDataSet(pre_maintain_result,floor,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HClockHookData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
 // HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HClockHookData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(6)厅门-弹簧自闭力
int HC_HallDoorStatistics_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int doorLockUpTime;
  int perc;
  int floor;
  doorLockUpTime=elevator_door_machine_t.front_door_lock_up_time;
  perc=elevator_door_machine_t.front_door_self_closing_coefficient;
  floor=elevator_common_data_t.current_floor;

  sprintf(MqttSendBuf,"%s", HCHallDoorStatistics(doorLockUpTime,perc,floor, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HChallDoorStatistics_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HChallDoorStatistics_Pub);
  return ERR_COMMON_SUCCESS;
}
//(7)厅门-门重锤检测结果
int HC_HallDoorInspectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*4]={0};
  //数据初始化
  int result;
  int floor;
  result=elevator_door_machine_t.front_door_heavy_hammer_check_result;
  floor=elevator_common_data_t.current_floor;
  sprintf(MqttSendBuf,"%s", HCHallDoorInspectionData(result,floor, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HChallDoorInspectionData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HChallDoorInspectionData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(8)控制柜-NICE3000-故障代码(无实时数据)
int HC_HCErrorCodeEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int errorCode;
  errorCode=0;
  sprintf(MqttSendBuf,"%s", HCErrorCodeEvent(errorCode, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCErrorCodeEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
 // HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCErrorCodeEvent_Pub);
  return ERR_COMMON_SUCCESS;
}
//（9）轿厢-轿门-轿门锁(无实时数据)
int HC_HCCarDoorLockStatisticalData_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t,struct ST_elevator_safety_circuit_t elevator_safety_circuit_t )
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int openTimes;
  int closeTimes;
  int floor;
  openTimes=elevator_safety_circuit_t.front_car_door_open_num;
  closeTimes=elevator_safety_circuit_t.front_car_door_close_num;
  floor=elevator_common_data_t.current_floor;
  sprintf(MqttSendBuf,"%s", HCCarDoorLockStatisticalData(openTimes,closeTimes,floor, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarDoorLockStatisticalData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarDoorLockStatisticalData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(10)轿厢-轿门-轿门门板-异常反复开关门次数(无实时数据)
int HC_HCDoorPanelStatisticalData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t, struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int time=elevator_door_machine_t.front_door_lock_up_time;
  int times=0;
  int abnormalTimes=0;
  int floor;
  floor=elevator_common_data_t.current_floor;
  sprintf(MqttSendBuf,"%s", HCDoorPanelStatisticalData(time,times,abnormalTimes,floor, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCdoorPanelStatisticalData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCdoorPanelStatisticalData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(11)轿厢-轿门-轿门门锁短接(无实时数据)
int HC_HCDoorLockShortCircuitFaultDetection_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化

  char status[6]={0};
  int floor;
  floor=elevator_door_machine_t.current_floor;
  sprintf(status,"%s","false");
  sprintf(MqttSendBuf,"%s", HCDoorLockShortCircuitFaultDetection(status,floor, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarDoorLockOnOffState_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcarDoorLockOnOffState_Pub);
  return ERR_COMMON_SUCCESS;
}
//（12）轿厢-轿门-光幕
int HC_HCLightPipe1to48BlockingState_Upload(int id, struct ST_elevator_light_curtain_t elevator_light_curtain_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_LightSpecialFunction LightSpecialFunction;
  memset(&LightSpecialFunction,0x0,sizeof (ST_LightSpecialFunction));
  LightSpecialFunction.TotalOcclusionState=elevator_light_curtain_t.front_door_light_curtain_total_status;//光管总遮挡状态
  LightSpecialFunction.lightNumber=elevator_light_curtain_t.front_door_light_tube_logarithm;//光管对数
  LightSpecialFunction.DecayValue=elevator_light_curtain_t.front_door_light_tube_intensity;//光管强度值
  LightSpecialFunction.lightPipeFault=0;//光管故障
  LightSpecialFunction.LightStateEvent.allNum=32;//总的有效光管数
  int i;
  for (i=1;i<=LightSpecialFunction.LightStateEvent.allNum;i++) {

      LightSpecialFunction.LightStateEvent.LightNum[i].lightState=elevator_light_curtain_t.front_door_light_curtain_status[i];

  }
  sprintf(MqttSendBuf,"%s", HCLightPipe1to48BlockingState(LightSpecialFunction, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCspecialFunction_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
 // HC_PRINT("TOPIC=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCspecialFunction_Pub);
  return ERR_COMMON_SUCCESS;
}
//（13）轿厢-轿门-同步门电机正常Max电流(只有关门最大电流、无电流高速段与低速段分类)
int HC_HCSyncDoorMotorDetectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t )
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int current;
  int floor;
  floor=elevator_common_data_t.current_floor;
  current=elevator_door_machine_t.close_door1_max_current;

  sprintf(MqttSendBuf,"%s", HCSyncDoorMotorDetectionData(current,floor, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCsyn_doorMotorDetectionData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
 // HC_PRINT("TOPIC=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCsyn_doorMotorDetectionData_Pub);
  return ERR_COMMON_SUCCESS;
}


/***=======================================曳引机===2021.12.21====================================================****/
//（21）机房设备-同步曳引机-永磁体(电流无空载电流高位、低位分类)
int HC_HCPermanentMagnetDataSet_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  double HighA=0 ;
  double LowA=0;
  double bucket1,bucket2;
  int i;
  for (i=0;i<=7;i++) {
      bucket1=0;
      bucket1=BitGet(Bit(elevator_traction_machine_t.no_load_current),i)*2^i;
      HighA+=bucket1/100;
      bucket2=0;
      bucket2=BitGet(Bit(elevator_traction_machine_t.no_load_current),i+8)*2^i;
      LowA+=bucket2/100;

  }
//  HighA=elevator_traction_machine_t.no_load_current;//4Btye的
//  unsigned int address=(unsigned int)(&elevator_traction_machine_t.no_load_current);
//  unsigned int adressLowA=address+1;
//  HighA=*((unsigned char *)address);//读adress+0:空载电流高位
//  LowA=*((unsigned char *)adressLowA);//读adress+1:空载电流低位
  sprintf(MqttSendBuf,"%s", HCPermanentMagnetDataSet(HighA,LowA, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCsyn_permanentMagnets_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("(Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCsyn_permanentMagnets_Pub);
  return ERR_COMMON_SUCCESS;
}
//(22)机房设备-同步曳引机-制动器热检测传感器-抱闸1动作次数
int HC_HCBrakeThermalDetectionSensorStatistics_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf1[1024*2]={0};
  //char MqttSendBuf2[1024*2]={0};
  //数据初始化
  int times1,times2;
  times1=elevator_traction_machine_t.brake1_action_num;
  //times2=elevator_traction_machine_t.brake2_action_num;
  sprintf(MqttSendBuf1,"%s", HCBrakeThermalDetectionSensorStatistics(times1, 0));
  //sprintf(MqttSendBuf2,"%s", HCBrakeThermalDetectionSensorStatistics(times2, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeThermalDetectionSensorStatistics_Pub,MqttSendBuf1);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf1);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeThermalDetectionSensorStatistics_Pub);
  //HC_PRINT("MqttSendBuf=%s",MqttSendBuf2);
  return ERR_COMMON_SUCCESS;
}
//(23)机房设备-同步曳引机-刹车片磨损传感器-打滑量
int HC_HCBrakePadWearSensorData_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int slip;//本次打滑量
  slip=elevator_traction_machine_t.traction_current_slip_quantity;
  sprintf(MqttSendBuf,"%s", HCBrakePadWearSensorData(slip, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeClosingAfterSlip_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeClosingAfterSlip_Pub);
  return ERR_COMMON_SUCCESS;
}
//(24)轿厢-额定运行速度（数据未采集）
int HC_HCrunData_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t,struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  char runState[6]={0};
  char runDirection[6]={0};
  int  ratedRunSpeed;
  switch (elevator_common_data_t.car_status) {
  case 0:sprintf(runState,"%s","true");
         sprintf(runDirection,"%s","true");break;
  case 1:sprintf(runState,"%s","true");
         sprintf(runDirection,"%s","true");break;
  case 2:sprintf(runState,"%s","true");
         sprintf(runDirection,"%s","false");break;
  case 3:sprintf(runState,"%s","false");
         sprintf(runDirection,"%s","NULL");break;
  }
  ratedRunSpeed=2;
  //数据未采集。默认为null
  sprintf(MqttSendBuf,"%s", HCrunData(runState,runDirection, ratedRunSpeed,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCrunData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCrunData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(25)机房设备-同步曳引机-电机额定转速，额定电流（数据未采集）
int HC_HCMotorRatedInfo_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int raredSpeed;
  double ratedCurrent;
  raredSpeed=0;
  ratedCurrent=0;
  sprintf(MqttSendBuf,"%s", HCMotorRatedInfo(raredSpeed,ratedCurrent, 0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCmotorRatedInfo_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  //HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCmotorRatedInfo_Pub);
  return ERR_COMMON_SUCCESS;
}
//(26)曳引机质量-井道-钢丝绳-抱闸力检测钢丝绳打滑量事件
int HC_HCBrakeForceDetectionSteelRopesSlip_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int detectDisplace;
  int warnDetectDisplace;
  int slipAmount;
  detectDisplace=elevator_traction_machine_t.current_brake_force_check_shift_quantity;
  warnDetectDisplace=elevator_traction_machine_t.brake_warning_check_result;
  slipAmount=elevator_traction_machine_t.current_pre_check_shift_quantity;
  sprintf(MqttSendBuf,"%s", HCBrakeForceDetectionSteelRopesSlip(detectDisplace,warnDetectDisplace,slipAmount,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeForceDetectionSteelRopesSlip_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
 // HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeForceDetectionSteelRopesSlip_Pub);
  return ERR_COMMON_SUCCESS;
}
//(27)轿厢-电梯运行里程(数据未采集)
int HC_HCElevatorMileage_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int mileage;
  mileage=0;//数据未采集，默认0
  sprintf(MqttSendBuf,"%s", HCElevatorMileage(mileage,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorMileage_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorMileage_Pub);
  return ERR_COMMON_SUCCESS;
}
//(28)轿厢-电梯当前位置信息(数据未采集)
int HC_HCElevatorCurrentPositionInfo_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int floor;
  int height;
  floor=0;
  height=0;//数据未采集  默认 ：0

  sprintf(MqttSendBuf,"%s", HCElevatorCurrentPositionInfo(floor,height,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorCurrentPositionInfo_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorCurrentPositionInfo_Pub);
  return ERR_COMMON_SUCCESS;
}
//(29)机房设备-同步曳引机-抱闸制动器-抱闸故障事件(数据未采集)
int HC_HCbrakeFaultEvent_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int breakFault;
  breakFault=0;//(数据未采集: 默认0)
  sprintf(MqttSendBuf,"%s", HCBrakeFaultEvent(breakFault,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeFaultEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeFaultEvent_Pub);
  return ERR_COMMON_SUCCESS;
}
//(30-1)曳引机-抱闸制动器-抱闸打开关闭时间事件（抱闸1&2）
int HC_HCBrakeOnOfftimeEvent_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf1[1024*2]={0};
  char MqttSendBuf2[1024*2]={0};
  //抱闸1数据初始化
  int openTime1;
  int closeTime1;
  openTime1=elevator_traction_machine_t.brake1_open_time;
  closeTime1=elevator_traction_machine_t.brake1_close_time;
  sprintf(MqttSendBuf1,"%s", HCBrakeOnOfftimeEvent(openTime1,closeTime1,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeONOFFtimeEvent_Pub1,MqttSendBuf1);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf1);
  HC_PRINT("Topic1=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeONOFFtimeEvent_Pub1);
  //抱闸2数据初始化
  int openTime2;
  int closeTime2;
  openTime2=elevator_traction_machine_t.brake2_open_time;
  closeTime2=elevator_traction_machine_t.brake2_close_time;
  sprintf(MqttSendBuf2,"%s", HCBrakeOnOfftimeEvent(openTime2,closeTime2,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbrakeONOFFtimeEvent_Pub2,MqttSendBuf2);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf2);
  return ERR_COMMON_SUCCESS;
}

//(31)机房设备-控制柜-运行时间(数据未采集)、次数
int HC_HCControlCabinetStatistics_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  int times;
  int time;
  times=elevator_traction_machine_t.physicial_floor_1_start_num;
  time=0;
  sprintf(MqttSendBuf,"%s", HCControlCabinetStatistics(times,time,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcontrolCabinetStatistics_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcontrolCabinetStatistics_Pub);
  return ERR_COMMON_SUCCESS;
}
/***===============================控制系统质量===================================***/
//（32-1）厅外显示板-按钮-上召、下召
int HC_HCfrontDoorHallUpAndDownCallButtonActionsNumber_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_upAndDownCallButton upAndDownCallButton;
  int i;
  upAndDownCallButton.num=10;
  for (i=0;i<10;i++) {
      upAndDownCallButton.ButtonActionsTimesArray[i+1].upCallActionTimes=elevator_ctrl_sys_t.front_door_outer_up_call_button_num[i];
      upAndDownCallButton.ButtonActionsTimesArray[i+1].downCallActionTimes=elevator_ctrl_sys_t.front_door_outer_down_call_button_num[i];
//      upAndDownCallButton.ButtonActionsTimesArray[i].upCallActionTimes=10;
//      upAndDownCallButton.ButtonActionsTimesArray[i].downCallActionTimes=10;
  }
  sprintf(MqttSendBuf,"%s", HCfrontDoorHallUpAndDownCallButtonActionsNumber(upAndDownCallButton,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCfrontDoorHallUpAndDownCallButtonActionsNumber_Pub,MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCfrontDoorHallUpAndDownCallButtonActionsNumber_Pub);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//（32-2）厅外显示板-按钮-上召、下召
int HC_HCbackDoorHallUpAndDownCallButtonActionsNumber_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_upAndDownCallButton upAndDownCallButton;
  int i;
  upAndDownCallButton.num=10;
  for (i=0;i<10;i++) {
      upAndDownCallButton.ButtonActionsTimesArray[i+1].upCallActionTimes=elevator_ctrl_sys_t.back_door_outer_up_call_button_num[i];
      upAndDownCallButton.ButtonActionsTimesArray[i+1].downCallActionTimes=elevator_ctrl_sys_t.back_door_outer_down_call_button_num[i];
  }
  sprintf(MqttSendBuf,"%s", HCbackDoorHallUpAndDownCallButtonActionsNumber(upAndDownCallButton,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbackDoorHallUpAndDownCallButtonActionsNumber_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//（32）轿厢-轿内-轿内指令板-按钮-主操纵盘（需要有有效按钮数数据）
int HC_HCMainControlPanelButtonStatisticsEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent;
  ButtonStatisticsEvent.doorOpenButtonActionsTimes=elevator_ctrl_sys_t.main_operation_box_open_button_num;
  ButtonStatisticsEvent.doorCloseButtonActionsTimes=elevator_ctrl_sys_t.main_operation_box_close_button_num;
  ButtonStatisticsEvent.num=10;
  int i;
  for (i=0;i<10;i++) {
      ButtonStatisticsEvent.ButtonActionsTimesArray[i+1].actionsTimes=elevator_ctrl_sys_t.main_operation_box_inner_call_button_num[i];
//      ButtonStatisticsEvent.ButtonActionsTimesArray[i].actionsTimes=0;
  }
  sprintf(MqttSendBuf,"%s", HCMainControlPanelButtonStatisticsEvent(ButtonStatisticsEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCmainControlPanelButtonStatisticsEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCmainControlPanelButtonStatisticsEvent_Pub);
  return ERR_COMMON_SUCCESS;
}
//（33）轿厢-轿内-轿内指令板-按钮-辅助操纵盘按钮
int HC_HCAuxiliaryControlPanelButtonStatisticsEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent;
  ButtonStatisticsEvent.doorOpenButtonActionsTimes=elevator_ctrl_sys_t.auxiliary_operation_box_open_button_num;
  ButtonStatisticsEvent.doorCloseButtonActionsTimes=elevator_ctrl_sys_t.auxiliary_operation_box_close_button_num;
  ButtonStatisticsEvent.num=10;
  int i;
  for (i=0;i<10;i++) {
      ButtonStatisticsEvent.ButtonActionsTimesArray[i+1].actionsTimes=elevator_ctrl_sys_t.auxiliary_operation_box_inner_call_button_num[i];
  }
  sprintf(MqttSendBuf,"%s", HCAuxiliaryControlPanelButtonStatisticsEvent(ButtonStatisticsEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCauxiliaryControlPanelButtonStatisticsEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//（34）轿厢-轿内-轿内指令板-按钮-残疾人操纵盘
int HC_HCHandicappedControlPanelButtonStatisticsEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent;
  ButtonStatisticsEvent.doorOpenButtonActionsTimes=elevator_ctrl_sys_t.disability_operation_box_open_button_num;
  ButtonStatisticsEvent.doorCloseButtonActionsTimes=elevator_ctrl_sys_t.disability_operation_box_close_button_num;
  ButtonStatisticsEvent.num=10;
  int i;
  for (i=0;i<10;i++) {
      ButtonStatisticsEvent.ButtonActionsTimesArray[i].actionsTimes=elevator_ctrl_sys_t.disability_operation_box_inner_call_button_num[i];
  }
  sprintf(MqttSendBuf,"%s", HCHandicappedControlPanelButtonStatisticsEvent(ButtonStatisticsEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HChandicappedControlPanelButtonStatisticsEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
/***=======================================控制系统质量++——2021.12.30==========================================**/
//（35）控制柜-接口板-电容容量/能耗/发电量（母线额定电容容量、电容容量数据缺失其一）(能耗数据、发电量未分类)
int HC_HCInterfaceBoardStatistics_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  ST_InterfaceBoardStatistics InterfaceBoardStatistics;
  InterfaceBoardStatistics.busbarRatedCapacitanceCapacity=elevator_ctrl_sys_t.bus_capatitor_power;//母线额定电容容量
  InterfaceBoardStatistics.capacitanceCapacity=elevator_ctrl_sys_t.bus_capatitor_power;//电容容量
  InterfaceBoardStatistics.energyConsumptionData=elevator_ctrl_sys_t.generated_electrical_energy;//能耗数据  double
  InterfaceBoardStatistics.powerGeneration=elevator_ctrl_sys_t.generated_electrical_energy;//发电量  double
  sprintf(MqttSendBuf,"%s", HCInterfaceBoardStatistics(InterfaceBoardStatistics,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCinterfaceBoardStatistics_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCinterfaceBoardStatistics_Pub);
  return ERR_COMMON_SUCCESS;
}
//(36)控制柜-接口板-温度(IGBT的NTC温度数据未采集)
int HC_HCInterfaceBoardTemperatrueData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*2]={0};
  //数据初始化
  ST_InterfaceBoardTemperatrueData InterfaceBoardTemperatrueData;
  InterfaceBoardTemperatrueData.igbTtemperatrue=elevator_ctrl_sys_t.igbt_temperature;//IGBT温度
  InterfaceBoardTemperatrueData.igbTNtctemperatrue=elevator_ctrl_sys_t.igbt_temperature;//IGBT的NTC温度
  InterfaceBoardTemperatrueData.inverterSideDiodeJunctionTemperatrue=elevator_ctrl_sys_t.inverter_side_diode_junction_temperature;//逆变侧二极管结温
  InterfaceBoardTemperatrueData.rectifierSideDiodeJunctionTemperature=elevator_ctrl_sys_t.rectifier_side_diode_junction_temperature;//整流侧二极管结温
  sprintf(MqttSendBuf,"%s", HCInterfaceBoardTemperatrueData(InterfaceBoardTemperatrueData,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCinterfaceBoardTemperatureData_Pub,MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCinterfaceBoardTemperatureData_Pub);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//(38-1)机房设备-控制柜-左接触器（抱闸1）(接触器主极点温度、接触器触点额定温度缺失其一)
int HC_HCLeftContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t)
{
  char MqttSendBuf[1024*4]={0};
  //数据初始化
  ST_ContactorIntegratedEvent IntegratedEvent;
  IntegratedEvent.MainPoleTemp=elevator_safety_circuit_t.contactor_temperature;//接触器主极点温度
  IntegratedEvent.RatedTemp=elevator_safety_circuit_t.contactor_temperature;//接触器触点额定温度
  IntegratedEvent.actionTimes=elevator_ctrl_sys_t.brake1_relay_action_num;//动作次数
  IntegratedEvent.closeTimes1=elevator_ctrl_sys_t.brake1_contactor_attempt_close_num;//尝试闭合次数
  IntegratedEvent.minTime1=elevator_ctrl_sys_t.brake1_contactor_auxiliary_close_min_interval;//辅触点吸合最小时间间隔
  IntegratedEvent.minTime2=elevator_ctrl_sys_t.brake1_contactor_action_instruction_interval;//吸合指令最小时间间隔
  IntegratedEvent.closeTimes2=elevator_ctrl_sys_t.brake1_contactor_close_num;//闭合次数
  IntegratedEvent.disConnectTimes=elevator_ctrl_sys_t.brake1_contactor_disconnect_num;//断开次数
  IntegratedEvent.closeDelayTime=elevator_ctrl_sys_t.brake1_contactor_recv_close_instruction_response_time;//吸合延时
  IntegratedEvent.openDelayTime=elevator_ctrl_sys_t.brake1_contactor_recv_disconnect_instruction_response_time;//断开延时
  sprintf(MqttSendBuf,"%s", HCContactorIntegratedEvent(IntegratedEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCLeftintegratedEvent_Pub,MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCLeftintegratedEvent_Pub);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//(38-2)机房设备-控制柜-右接触器（抱闸2）(接触器主极点温度、接触器触点额定温度缺失其一)
int HC_HCRightContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t)
{
  char MqttSendBuf[1024*4]={0};
  //数据初始化
  ST_ContactorIntegratedEvent IntegratedEvent;
  IntegratedEvent.MainPoleTemp=elevator_safety_circuit_t.contactor_temperature;//接触器主极点温度
  IntegratedEvent.RatedTemp=elevator_safety_circuit_t.contactor_temperature;//接触器触点额定温度
  IntegratedEvent.actionTimes=elevator_ctrl_sys_t.brake2_relay_action_num;//动作次数
  IntegratedEvent.closeTimes1=elevator_ctrl_sys_t.brake2_contactor_attempt_close_num;//尝试闭合次数
  IntegratedEvent.minTime1=elevator_ctrl_sys_t.brake2_contactor_auxiliary_close_min_interval;//辅触点吸合最小时间间隔
  IntegratedEvent.minTime2=elevator_ctrl_sys_t.brake2_contactor_action_instruction_interval;//吸合指令最小时间间隔
  IntegratedEvent.closeTimes2=elevator_ctrl_sys_t.brake2_contactor_close_num;//闭合次数
  IntegratedEvent.disConnectTimes=elevator_ctrl_sys_t.brake2_contactor_disconnect_num;//断开次数
  IntegratedEvent.closeDelayTime=elevator_ctrl_sys_t.brake2_contactor_recv_close_instruction_response_time;//吸合延时
  IntegratedEvent.openDelayTime=elevator_ctrl_sys_t.brake2_contactor_recv_disconnect_instruction_response_time;//断开延时
  sprintf(MqttSendBuf,"%s", HCContactorIntegratedEvent(IntegratedEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCRightintegratedEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//(38-3)机房设备-控制柜-运行接触器(接触器主极点温度、接触器触点额定温度缺失其一)
int HC_HCRunContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t)
{
  char MqttSendBuf[1024*5]={0};
  //数据初始化
  ST_ContactorIntegratedEvent IntegratedEvent;
  IntegratedEvent.MainPoleTemp=elevator_safety_circuit_t.contactor_temperature;//接触器主极点温度
  IntegratedEvent.RatedTemp=elevator_safety_circuit_t.contactor_temperature;//接触器触点额定温度
  IntegratedEvent.actionTimes=elevator_ctrl_sys_t.run_relay_action_num;//动作次数
  IntegratedEvent.closeTimes1=elevator_ctrl_sys_t.run_contactor_attempt_close_num;//尝试闭合次数
  IntegratedEvent.minTime1=elevator_ctrl_sys_t.run_contactor_auxiliary_close_min_interval;//辅触点吸合最小时间间隔
  IntegratedEvent.minTime2=elevator_ctrl_sys_t.run_contactor_action_instruction_interval;//吸合指令最小时间间隔
  IntegratedEvent.closeTimes2=elevator_ctrl_sys_t.run_contactor_close_num;//闭合次数
  IntegratedEvent.disConnectTimes=elevator_ctrl_sys_t.run_contactor_disconnect_num;//断开次数
  IntegratedEvent.closeDelayTime=elevator_ctrl_sys_t.run_contactor_recv_close_instruction_response_time;//吸合延时
  IntegratedEvent.openDelayTime=elevator_ctrl_sys_t.run_contactor_recv_disconnect_instruction_response_time;//断开延时
  sprintf(MqttSendBuf,"%s", HCContactorIntegratedEvent(IntegratedEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCRuntintegratedEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//(38-4)机房设备-控制柜-封星接触器(接触器主极点温度、接触器触点额定温度缺失其一)
int HC_HCFxContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t)
{
  char MqttSendBuf[1024*4]={0};
  //数据初始化
  ST_ContactorIntegratedEvent IntegratedEvent;
  IntegratedEvent.MainPoleTemp=elevator_safety_circuit_t.contactor_temperature;//接触器主极点温度
  IntegratedEvent.RatedTemp=elevator_safety_circuit_t.contactor_temperature;//接触器触点额定温度
  IntegratedEvent.actionTimes=elevator_ctrl_sys_t.stator_relay_action_num;//动作次数
  IntegratedEvent.closeTimes1=elevator_ctrl_sys_t.stator_contactor_attempt_close_num;//尝试闭合次数
  IntegratedEvent.minTime1=elevator_ctrl_sys_t.stator_contactor_auxiliary_close_min_interval;//辅触点吸合最小时间间隔
  IntegratedEvent.minTime2=elevator_ctrl_sys_t.stator_contactor_action_instruction_interval;//吸合指令最小时间间隔
  IntegratedEvent.closeTimes2=elevator_ctrl_sys_t.stator_contactor_close_num;//闭合次数
  IntegratedEvent.disConnectTimes=elevator_ctrl_sys_t.stator_contactor_disconnect_num;//断开次数
  IntegratedEvent.closeDelayTime=elevator_ctrl_sys_t.stator_contactor_recv_close_instruction_response_time;//吸合延时
  IntegratedEvent.openDelayTime=elevator_ctrl_sys_t.stator_contactor_recv_disconnect_instruction_response_time;//断开延时
  sprintf(MqttSendBuf,"%s", HCContactorIntegratedEvent(IntegratedEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCFXintegratedEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}


//通讯接口-CAN1通讯数据
int  HC_HCCAN1communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_CAN1communicationData communicationData;
  communicationData.CAN1communicationBusInterference=elevator_ctrl_sys_t.bus_inteference_can_1;
  communicationData.CAN1PCBcommunicationModuleSelfCheck=elevator_ctrl_sys_t.can_1_comm_single_board_self_check;
  /*OnlineStatus  Array*/
  int i;
  for (i=0;i<32;i++) {
      communicationData.CAN1communicationOnlineStatus[i+1].onlineStatus=BitGet(Bit(elevator_ctrl_sys_t.can1_comm_online_state),i);
      communicationData.CAN1communicationOnlineStatus[i+1].CAN1frameLossRate=elevator_ctrl_sys_t.can1_comm_drop_frame_rate[i];
  }

  sprintf(MqttSendBuf,"%s", HCCAN1communicationData(communicationData,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCCAN1communicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}



//通讯接口-SPI1
int  HC_HCSPI1communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int SPI1communicationBusInterference;
  int SPI1communicationOnlineStatus;
  int SPI1frameLossRate;
  SPI1communicationBusInterference=elevator_ctrl_sys_t.bus_inteference_spi_1;
  SPI1communicationOnlineStatus=elevator_ctrl_sys_t.spi1_online_state_mcb_check_dsp;
  SPI1frameLossRate=elevator_ctrl_sys_t.spi1_comm_drop_frame_rate_dsp;
  sprintf(MqttSendBuf,"%s", HCSPI1communicationData(SPI1communicationBusInterference,SPI1communicationOnlineStatus,SPI1frameLossRate,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCSPI1communicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//通讯接口-SPI2
int  HC_HCSPI2communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int SPI2communicationBusInterference;
  int SPI2communicationOnlineStatus;
  int SPI2frameLossRate;
  SPI2communicationBusInterference=elevator_ctrl_sys_t.bus_inteference_spi_2;
  SPI2communicationOnlineStatus=elevator_ctrl_sys_t.spi2_online_state_mcb_check_pg;
  SPI2frameLossRate=elevator_ctrl_sys_t.spi2_drop_frame_rate_mcb_check_pg;
  sprintf(MqttSendBuf,"%s", HCSPI2communicationData(SPI2communicationBusInterference,SPI2communicationOnlineStatus,SPI2frameLossRate,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCSPI2communicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//通讯接口-MOD1
int  HC_HCMOD1communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_MOD1communicationData MOD1communicationData;
  MOD1communicationData.MOD1communicationBusInterference=elevator_ctrl_sys_t.bus_inteference_mod_1;
  //在线状态
  int i,j,k;
  for (i=1;i<=112;i++) {
      for (j=1;j<=14;j++) {
          for (k=1;k<=8;k++) {
              MOD1communicationData.MOD1communicationOnlineStatus[i].onlineStatus=BitGet(Bit(elevator_ctrl_sys_t.mdo1_online_state[i]),k);
          }
      }
      MOD1communicationData.MOD1communicationOnlineStatus[i].MOD1frameLossRFate=elevator_ctrl_sys_t.mod1_drop_frame_rate[i];
  }
  sprintf(MqttSendBuf,"%s", HCMOD1communicationData(MOD1communicationData,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCMOD1communicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//通讯接口-MOD2
int  HC_HCMOD2communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int MOD2communication;
  MOD2communication=0;    //MOD2在线状态  0：在线  1：离线
  sprintf(MqttSendBuf,"%s", HCMOD2communicationData(MOD2communication,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCMOD2communicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//通讯接口-485-1
int  HC_HC4851communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int communicationBusInterference;
  int communicationOnlineStatus;
  int frameLossRate;
  communicationBusInterference=elevator_ctrl_sys_t.bus_inteference_485_1;
  communicationOnlineStatus=elevator_ctrl_sys_t.s485_1_online_state_dsp_check_encode;
  frameLossRate=elevator_ctrl_sys_t.s485_1_drop_frame_rate_dsp_check_encode;
  sprintf(MqttSendBuf,"%s", HC4851communicationData(communicationBusInterference,communicationOnlineStatus,frameLossRate,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HC4851communicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}


//通讯接口-485-2
int  HC_HC485TwoCommunicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int communicationBusInterference;
  int communicationOnlineStatus;
  int frameLossRate;
  communicationBusInterference=elevator_ctrl_sys_t.bus_inteference_485_2;
  communicationOnlineStatus=elevator_ctrl_sys_t.s485_2_online_state_pg_check_encode;
  frameLossRate=elevator_ctrl_sys_t.s485_2_drop_frame_rate_pg_check_encode;
  sprintf(MqttSendBuf,"%s", HC485TwoCommunicationData(communicationBusInterference,communicationOnlineStatus,frameLossRate,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HC485TwoCommunicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//通讯接口-串口
int  HC_HCserialCOmmunicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int serialCommunicationStatus;
  serialCommunicationStatus=0;
  sprintf(MqttSendBuf,"%s", HCserialCOmmunicationData(serialCommunicationStatus,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCserialCommunicationData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}








/***==============================================安全回路质量-2021.12.30===================================***/
//(37)控制柜-控制柜温度
int HC_HCControlCabinetTemperatrueData_Upload(int id, struct ST_elevator_safety_circuit_t elevator_safety_circuit_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int Temp;//柜内温度
  Temp=elevator_safety_circuit_t.contactor_temperature;
  sprintf(MqttSendBuf,"%s", HCControlCabinetTemperatrueData(Temp,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcontrolCabinetTemperatureData_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCcontrolCabinetTemperatureData_Pub);
  return ERR_COMMON_SUCCESS;
}
//(39)安全回路-电压
int HC_HCSafetyloop_Upload(int id, struct ST_elevator_safety_circuit_t elevator_safety_circuit_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  int safeCirHeadVol;//：安全回路端电压V =  首端电压
  int conCoilSteStaVol;//：接触器线圈稳态电压V  =  末端稳定电压
  int conCoilPullInTransVol;//：接触器线圈吸合瞬态电压V  =  KM1 吸合电压
  safeCirHeadVol=elevator_safety_circuit_t.head_voltage;//首端电压
  conCoilSteStaVol=elevator_safety_circuit_t.end_stable_voltage;//末端稳定电压
  conCoilPullInTransVol=elevator_safety_circuit_t.km1_pullin_voltage;//KM1 吸合电压
  sprintf(MqttSendBuf,"%s", HCSafetyloop(safeCirHeadVol,conCoilSteStaVol,conCoilPullInTransVol,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCSafetyloop_Pub,MqttSendBuf);
  HC_PRINT("Yopic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCSafetyloop_Pub);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

/***===========================================直梯-实时数据======================================***/
//(40)直梯-电梯管理-电梯展示事件
int HC_HCElevatorManagementElevatorDisplayEvent_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t )
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_ElevatorManagementElevatorDisplayEvent displayEvent;
  displayEvent.elevatorOnlineStatus=true;//电梯在线状态    true：电梯在线   false：电梯离线
  if(elevator_common_data_t.fault_code==0){
      displayEvent.elevatorRunningStatus=0;//电梯运行状态   0：正常   1：停梯    2：检修
      if(elevator_common_data_t.car_status==3){
          displayEvent.elevatorRunningStatus=1;//电梯运行状态   0：正常   1：停梯    2：检修
      }
    }
  else {
      displayEvent.elevatorRunningStatus=2;//电梯运行状态   0：正常   1：停梯    2：检修
  }
  displayEvent.elevatorFloor=elevator_common_data_t.current_floor;//电梯所在楼层
  displayEvent.elevatorUpAndDownStatus=elevator_common_data_t.car_status;//电梯上行、下行状态     1:电梯上行     2:电梯下行     3：电梯停止
  displayEvent.elevatorDoorOpeningAndClosingStatus=elevator_common_data_t.door_status;//开关门状态   0:未知状态  1:开门过程  2:开门到位  3:关门过程  4:关门到位
  displayEvent.communicationSignal=2;//通讯信号          0：2G     1：3G      2：4G
  displayEvent.signalIntensity=31;//信号强度   int
  displayEvent.errorCode;//故障代码    修改为string
  sprintf(displayEvent.errorCode,"%s","null");


  sprintf(MqttSendBuf,"%s", HCElevatorManagementElevatorDisplayEvent(displayEvent,0));
  HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorManagementElevatorDisplayEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  HC_PRINT("Topic=%s",Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorManagementElevatorDisplayEvent_Pub);
  return ERR_COMMON_SUCCESS;
}

//(41)直梯-电梯管理-电梯基本事件
int HC_HCElevatorManagementBasicInformationEvent_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t )
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_ElevatorManagementElevatorDisplayEvent displayEvent;
  displayEvent.elevatorOnlineStatus=true;//电梯在线状态    true：电梯在线   false：电梯离线
  if(elevator_common_data_t.fault_code==0){
      displayEvent.elevatorRunningStatus=0;//电梯运行状态   0：正常   1：停梯    2：检修
      if(elevator_common_data_t.car_status==3){
          displayEvent.elevatorRunningStatus=1;//电梯运行状态   0：正常   1：停梯    2：检修
      }
    }
  else {
      displayEvent.elevatorRunningStatus=2;//电梯运行状态   0：正常   1：停梯    2：检修
  }
  displayEvent.elevatorFloor=elevator_common_data_t.current_floor;//电梯所在楼层
  displayEvent.elevatorUpAndDownStatus=elevator_common_data_t.car_status;//电梯上行、下行状态     1:电梯上行     2:电梯下行     3：电梯停止
  displayEvent.elevatorDoorOpeningAndClosingStatus=elevator_common_data_t.door_status;//开关门状态   0:未知状态  1:开门过程  2:开门到位  3:关门过程  4:关门到位
  displayEvent.communicationSignal=2;//通讯信号          0：2G     1：3G      2：4G
  displayEvent.signalIntensity=31;//信号强度   int
  displayEvent.errorCode;//故障代码    修改为string
  sprintf(displayEvent.errorCode,"%s","null");

  ST_ElevatorManagementBasicInformationEvent  basicInfoEvent;
  basicInfoEvent.elevatorLevelingStatus=true;//平层状态   true:平层   false:非平层
  basicInfoEvent.sleepyPersonDetection=false;//困人检测    true:有困人  false:无困人
  basicInfoEvent.controllerEncryptionStatus=false;//控制器有无加密   true:有加密  false:无加密
  basicInfoEvent.controllerOnlineStatus=true;//控制器在线状态   true:在线   false:离线
  basicInfoEvent.intelligentHardwareOnlineStatus=true;//智能硬件在线状态   true:在线   false:离线
  basicInfoEvent.serviceModel=7;//:服务模式   0:检修模式 1:井道自学习 2:微动平层 3:消防返基站 4:消防员
                              //5:故障状态 6:司机 7:自动运行 8:锁梯 9:空闲泊梯 10:低速返平层
                              //11:救援运行 12:电机调谐 13:键盘控制 14:基站校验 15:VIP运行
  basicInfoEvent.runningSpeed=2;//运行速度
  switch (elevator_common_data_t.load) {/* 1: 满载, 2: 超载,  3: 空载, 4: 半载 */
  case 1:basicInfoEvent.elevatorLoadingStatus=1;break;//电梯负载状态  0:正常 1:满员 2:超载
  case 2:basicInfoEvent.elevatorLoadingStatus=2;break;//电梯负载状态  0:正常 1:满员 2:超载
  case 3:basicInfoEvent.elevatorLoadingStatus=0;break;//电梯负载状态  0:正常 1:满员 2:超载
  case 4:basicInfoEvent.elevatorLoadingStatus=0;break;//电梯负载状态  0:正常 1:满员 2:超载
  }

  int i;
  for (i=1;i<=48;i++) {
      basicInfoEvent.callUpFloor[i].floorNum=elevator_common_data_t.up_call[i];//array[]上召楼层
      basicInfoEvent.callDownFloor[i].floorNum=elevator_common_data_t.down_call[i];//array[]下召楼层
      basicInfoEvent.internalCallFloor[i].floorNum=elevator_common_data_t.inner_call[i];//array[]内召楼层
  }


  sprintf(MqttSendBuf,"%s", HCElevatorManagementBasicInformationEvent(basicInfoEvent,displayEvent,0));
  //HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorManagementBasicInformationEvent_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//(42)直梯-楼栋大屏
int HC_HCBuildingScreen_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_BuildingScreen  buildingScreen;
  buildingScreen.elevatorFloor;//电梯所在楼层 int
  buildingScreen.elevatorStatus;//电梯状态    0：正常  1：检修  2：故障
  buildingScreen.onlineStatus;//在线状态   true:在线  false:离线
  buildingScreen.runningDirection;//运行方向   1：上行  2：下行  3：停止
  buildingScreen.errorCode;//故障代码  string

  sprintf(MqttSendBuf,"%s", HCBuildingScreen(buildingScreen,0));
  //HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCbuildingScreen_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}

//(43)直梯-井道全息
int HC_HCHoistwayHolographic_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_HoistwayHolographic  hoistwayHolographic;
  hoistwayHolographic.elevatorFloor=elevator_common_data_t.current_floor;//电梯所在楼层 int
  if(elevator_common_data_t.fault_code==0){
        hoistwayHolographic.elevatorStatus=0;//电梯状态    0：正常  1：停梯  2：检修
  }
  if(elevator_common_data_t.car_status==3){
        hoistwayHolographic.elevatorStatus=1;//电梯状态    0：正常  1：停梯  2：检修
  }
  else {
      hoistwayHolographic.elevatorStatus=2;//电梯状态    0：正常  1：停梯  2：检修
  }

  hoistwayHolographic.onlineStatus=true;//在线状态   true:在线  false:离线
  hoistwayHolographic.recordStatus=0;//录制状态  int    null

  sprintf(MqttSendBuf,"%s", HCHoistwayHolographic(hoistwayHolographic,0));
  //HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCHoistwayHolographic_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}
//(44)直梯-电梯综合故障信息
int HC_HCelevatorComprehensiveFaultInformation_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t)
{
  char MqttSendBuf[1024*10]={0};
  //数据初始化
  ST_elevatorComprehensiveFaultInformation  faultInfo;
  faultInfo.eventMessageSequenceNumber;//事件消息序列号 int
  faultInfo.subDeviceAddressCode;//子设备地址码   string
  faultInfo.eventCode;//事件编码  int
  faultInfo.eventStatus;//事件状态  int    null
  faultInfo.eventData;//事件数据 string
  faultInfo.eventSubcode;//事件子码  string
  faultInfo.realTimeData;//实时数据  string
  faultInfo.eventGenerationTime;//事件产生时间  int
  faultInfo.eventCancellationTime;//事件解除时间  int
  faultInfo.whetherToLift;//是否解除
  faultInfo.alarmDescription;//告警描述  string
  faultInfo.whetherToTrapped;//是否困人 true:困人   false:无困人
  faultInfo.whetherToOverhaul;//是否检修 true:检修   false:不检修
  faultInfo.elevatorFloor;//电梯所在楼层  int

  sprintf(MqttSendBuf,"%s", HCelevatorComprehensiveFaultInformation(faultInfo,0));
  //HC_MmapProcess_Server_Send(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[id].HCelevatorComprehensiveFaultInformation_Pub,MqttSendBuf);
  HC_PRINT("MqttSendBuf=%s",MqttSendBuf);
  return ERR_COMMON_SUCCESS;
}























