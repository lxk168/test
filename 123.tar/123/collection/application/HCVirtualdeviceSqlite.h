﻿
#ifndef HCVIRTUALDEVICESQLITE_H
#define HCVIRTUALDEVICESQLITE_H
#include "common.h"
#include <sqlite3.h>
#include"public/HCPublicStruct.h"
#define VIRTUALDEVICEPATH   "/userdata/usr/local/Virtualdevice.db"

#define SQL_SIZE      (4096)           //sql语句最大字节长度

#define HCinformation "基本信息表"
#define HCelevatorAndSnInfor "电梯ID和SN码"
#define HCelevatorComprehensiveFaultInformationEventConfiguration "电梯综合故障信息"
#define HCagvInformationEventConfiguration "机器人事件信息"
#define HCControlCabinetStatisticsEventConfiguration "控制柜统计数据事件配置"
#define HCControlCabinetInherentDataEventConfiguration "控制柜固有数据事件配置"
#define HCControlCabinetTemperatrueDataEventConfiguration "控制柜温度数据事件配置"
#define HCLeftContactorList "左抱闸接触器"
#define HCRightContactorList "右抱闸接触器"
#define HCRunContactorList "运行接触器"
#define HCFXContactorList "封星接触器"
#define HCsystemStatusEventConfiguration "系统状态事件配置"
#define HCsystemSignalDetectionEventConfiguration "系统信号检测事件配置"
#define HCcontrollerPasswordEventConfiguration "控制器密码事件配置"
#define HCerrorCodeEventConfiguration "故障代码事件配置"
#define HCterminalStatusEventConfiguration "端子状态事件配置"
#define HCAGVheartbeatEventConfiguration "AGV心跳事件配置"
#define HCCAN1communicationDataEventConfiguration "CAN1通讯数据事件配置"
#define HCSPI1communicationDataEventConfiguration "SPI1通讯数据事件配置"
#define HCSPI2communicationDataEventConfiguration "SPI2通讯数据事件配置"
#define HCMOD1communicationDataEventConfiguration "MOD1通讯数据事件配置"
#define HCMOD2communicationDataEventConfiguration "MOD2通讯数据事件配置"
#define HCm485FirstcommunicationDataEventConfiguration "通讯485数据事件配置1"
#define HCm485TwocommunicationDataEventConfiguration "通讯485数据事件配置2"
#define HCserialPortcommunicationDataEventConfiguration "串口通讯数据事件配置"
#define HCinterfaceBoardStatisticalDataEventConfiguration "接口板统计数据事件配置"
#define HCinterfaceBoardTemperatrueDataEventConfiguration "接口板温度数据事件配置"
#define HCelevatorRemoteLockSignalEventConfiguration "新国标物联网模块第三方电梯远程锁梯信号事件配置"
#define HCmotorRatedInfoEventConfiguration "电机额定信息事件配置"
#define HCHoldingBrakeContactor1 "抱闸制动器1"
#define HCHoldingBrakeContactor2 "抱闸制动器2"
#define HCpermanentMagnetDataSetEventConfiguration  "永磁体数据集事件配置"
#define HCBrakeStrokeFeedbackSwitch1 "制动器行程反馈开关1"
#define HCBrakeStrokeFeedbackSwitch2 "制动器行程反馈开关2"
#define HCbrakeHeatDetectionSensor1 "制动器热检测传感器1"
#define HCbrakeHeatDetectionSensor2 "制动器热检测传感器2"
#define HCbrakePadWearSensorDataEventConfiguration "刹车片磨损传感器数据事件配置"
#define HCntcTempProtectCriticalPointEventConfiguration "NTC保护点临界温度事件配置"
#define HCelevatorCurrentPositionInfoEventConfig "电梯当前位置信息事件配置"
#define HCelevatorMileageEventConfig "电梯运行里程事件配置"
#define HCrunDataEventConfig "运行数据事件配置"
#define HCvisionElectricVehicleEventConfiguration "电瓶车识别事件配置"
#define HCvisionPryingDoorEventConfiguration "扒门识别事件配置"
#define HCvisionSmokeEventConfiguration "烟雾识别事件配置"
#define HCvisionTrappedEventConfiguration "困人识别事件配置"
#define HCvisionFallEventConfiguration "倒地识别事件配置"
#define HCvisionPersonEventConfiguration "人员计数事件配置"
#define HCvoiceRequestSignalEventConfig "语音请求信号事件配置"
#define HCinternalCallStatusEventConfiguration "内召状态事件配置"
#define HCfrontBackDoorInternalCallRegistrationCommandEventConfig "前后门内召登记指令事件配置"
#define HCfrontDoorInternalCallRegistrationCommandEventConfig "前门内召登记指令事件配置"
#define HCbackDoorInternalCallRegistrationCommandEventConfig "后门内召登记指令事件配置"
#define HCmainControlPanelButtonStatisticsEventConfig "主操纵盘按钮统计数据事件配置"
#define HCauxiliaryControlPanelButtonStatisticsEventConfig "辅助操纵盘按钮统计数据事件配置"
#define HChandicappedControlPanelButtonStatisticsEventConfig "残疾人操纵盘按钮统计数据事件配置"
#define HCdoorMachinePreMaintenanceStatusEventConfiguration "门机预维保状态事件配置"
#define HCdoorLockShortCircuitFaultDetectionEventConfiguration "门锁短接故障检测事件配置"
#define HCfontcarDoorLock "前门轿门锁"
#define HCbackcarDoorLock "后门轿门锁"
#define HCfontdoorPanel "前门门板"
#define HCbackdoorPanel "后门门板"
#define HCfontdoorBall "前门门球"
#define HCbackdoorBall "后门门球"
#define HCfontlockHook "前门锁钩"
#define HCbacklockHook "后门锁钩"
#define HCfontstrap "前门皮带"
#define HCbackstrap "后门皮带"
#define HCfontarSill "前门轿厢地坎"
#define HCbackarSill "后门轿厢地坎"
#define HCfontslide "前门滑轨"
#define HCbackslide "后门滑轨"
#define HCfontlightCurtain "前门光幕"
#define HCbacklightCurtain "后门光幕"
#define HCfontsynchronousDoorMotor "前门同步门电机"
#define HCbacksynchronousDoorMotor "后门同步门电机"
#define HCfontasynchronousDoorMotor "前门异步门电机"
#define HCbackasynchronousDoorMotor "后门异步门电机"
#define HCcarCarryingDataEventConfiguration "轿厢承载数据事件配置"
#define HCdoorZoneSignalEventConfiguration "门区信号事件配置"
#define HCaccelerationDataEventConfiguration "加速度数据事件配置"
#define HClocationDataEventConfiguration "位置数据事件配置"
#define HCm232InterfaceModule "RS232接口模块"
#define HCfrontBackUpDownCallRegistrationCommandEventConfig "前后上下召登记指令事件配置"
#define HCfrontUpDownCallRegistrationCommandEventConfig "前门上下召登记指令事件配置"
#define HCbackUpDownCallRegistrationCommandEventConfig "后门上下召登记指令事件配置"
#define HChandicappedFrontUpDownCallRegistrationCommandEventConfig "残障前门上下召登记指令事件配置"
#define HChandicappedBackUpDownCallRegistrationCommandEventConfig "残障后门上下召登记指令事件配置"
#define HCfrontDoorHallUpCallButtonActionsNumberEventConfiguration "前门外呼上召按钮动作次数事件配置"
#define HCfrontDoorHallDnCallButtonActionsNumberEventConfiguration "前门外呼下召按钮动作次数事件配置"
#define HCbackDoorHallUpCallButtonActionsNumberEventConfiguration "后门外呼上召按钮动作次数事件配置"
#define HCbackDoorHallDnCallButtonActionsNumberEventConfiguration "后门外呼下召按钮动作次数事件配置"
#define HCfonthallDoorList "前门厅门列表"
#define HCbackhallDoorList "后门厅门列表"
#define HCfonthallDoorLockList "前门厅门门锁列表"
#define HCbackhallDoorLockList "后门厅门门锁列表"
#define HCfonthallSill "前门厅门地坎"
#define HCbackhallSill "后门厅门地坎"
#define HCdoorInspectionDataEventConfiguration "门板检测数据事件配置"
#define HCdoorStatisticsEventConfiguration "门板统计数据事件配置"
#define HCdoorInherentDataEventConfiguration "门板固有数据事件配置"
#define HCelevatorSlippageDataDetectionEventConfiguration "电梯运行打滑量数据检测事件配置"
#define HCbrakeForceDetectionSteelRopesSlipEventConfiguration "抱闸力检测钢丝绳打滑量事件配置"
#define HCnumberOfStartsOnTheFirstFloorEventConfiguration "物理1楼启动次数事件配置"
#define HCbackToTheBaseStationSlipEventConfiguration "返基站打滑量事件配置"
#define HCvoltageDetectionEventConfiguration "电压检测事件配置"


extern sqlite3 *db;

extern int HCReadVirtualDeviceInfor(char *dbpath,char* tablename);
extern int HCDatabaseInit(const char *path);
extern int HCTableInit(const char *path);
extern int HCDataisExists(const char* path,char *tablename,int id);
extern int HCTable_is_exists(char * tablename);
extern int HCVirtualDeviceCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCelevatorIDAndSNCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern  int HCUpdateSetInfo(char *tablename ,int idnum,ST_VirtualDeviceALL  VirtualDeviceALL);

//数据库查看回调
extern int HCVirtualDeviceCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCelevatorComprehensiveFaultInformationEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCagvInformationEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCControlCabinetStatisticsEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCControlCabinetInherentDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCControlCabinetTemperatrueDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HC_LeftContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HC_RightContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HC_RunContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HC_FXContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCsystemStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCsystemSignalDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCcontrollerPasswordEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCerrorCodeEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCterminalStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCAGVheartbeatEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCCAN1communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCSPI1communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCSPI2communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCMOD1communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCMOD2communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCm485FirstcommunicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCm485TwocommunicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCserialPortcommunicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCinterfaceBoardStatisticalDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCinterfaceBoardTemperatrueDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCelevatorRemoteLockSignalEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCmotorRatedInfoEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HC_HoldingBrakeContactorCallback1(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HC_HoldingBrakeContactorCallback2(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);

extern int HCpermanentMagnetDataSetEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCBrakeStrokeFeedbackSwitchCallback1(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCBrakeStrokeFeedbackSwitchCallback2(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);

extern int HCbrakeHeatDetectionSensorCallback1(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbrakeHeatDetectionSensorCallback2(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);

extern int HCbrakePadWearSensorDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCntcTempProtectCriticalPointEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCelevatorCurrentPositionInfoEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCelevatorMileageEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCrunDataEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvisionElectricVehicleEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvisionPryingDoorEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvisionSmokeEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvisionTrappedEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvisionFallEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvisionPersonEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvoiceRequestSignalEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCinternalCallStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfrontBackDoorInternalCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfrontDoorInternalCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackDoorInternalCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCmainControlPanelButtonStatisticsEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCauxiliaryControlPanelButtonStatisticsEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HChandicappedControlPanelButtonStatisticsEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCdoorMachinePreMaintenanceStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCdoorLockShortCircuitFaultDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontcarDoorLockCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontdoorPanelCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontdoorBallCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontlockHookCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontstrapCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontcarSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontslideCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontlightCurtainCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontsynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfontasynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);


extern int HCbackcarDoorLockCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackdoorPanelCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackdoorBallCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbacklockHookCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackstrapCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackcarSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackslideCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbacklightCurtainCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbacksynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackasynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);




extern int HCcarCarryingDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCdoorZoneSignalEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCaccelerationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HClocationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCm232InterfaceModuleCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfrontBackUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfrontUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HChandicappedFrontUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HChandicappedBackUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfrontDoorHallUpCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfrontDoorHallDnCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackDoorHallUpCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackDoorHallDnCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfonthallDoorListCallback (__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfonthallDoorLockListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCfonthallSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackhallDoorListCallback (__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackhallDoorLockListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackhallSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);

extern int HCdoorInspectionDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCdoorStatisticsEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCdoorInherentDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCelevatorSlippageDataDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbrakeForceDetectionSteelRopesSlipEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCnumberOfStartsOnTheFirstFloorEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCbackToTheBaseStationSlipEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCvoltageDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName);
extern int HCReadVirtualDeviceInforInit(void);
#endif



