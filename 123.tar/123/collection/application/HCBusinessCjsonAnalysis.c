﻿#include "application/HCBusinessCjsonAnalysis.h"
#include"public/HCPulicAPI.h"
#include"application/HCBusinessTopic.h"


//(1) 获取虚拟设备的版本号
int HC_VirtualdeviceVersionGet(char * analysis)
{
    int version=0;
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(analysis);
    char *json_data = NULL;
    //判断是否打包成功
    if(cjson == NULL){
        version=-1;
        return version;
    }
    json_data = cJSON_Print(cJSON_GetObjectItem(cjson,"version"));
    if(json_data!=NULL)
    {
        version=atoi(json_data);

    }
    free(json_data);
    cJSON_Delete(cjson);
    return version;
}
//(2) 更新后获取虚拟设备的版本号
int HC_VirtualdeviceUpgradeVersionGet(char * analysis)
{
    int version=0;
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(analysis);
    char *json_data = NULL;
    //判断是否打包成功
    if(cjson == NULL){
        version=-1;
        cJSON_Delete(cjson);
        return version;
    }
    char flag[10]={0};
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"payload");
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"status"));
    if(json_data!=NULL)
    {
        strcat(flag,HCStingOut(json_data));

    }
    free(json_data);
    if(strcmp(flag,"success")){
        json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"version"));
        if(json_data!=NULL){
            version=atoi(json_data);
        }
        free(json_data);
    }else {
        version=-1;
    }
    cJSON_Delete(cjson);
    return version;
}
cJSON* HC_CJSON_PayloadInit(char * analysis,char *id)
{
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(analysis);
    cJSON* test_arrout=NULL;
    //判断是否打包成功
    if(cjson == NULL){

        return NULL;
    }

    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"payload");
    cJSON* test_arr1 = cJSON_GetObjectItem(test_arr,"state");
    cJSON* test_arr2 = cJSON_GetObjectItem(test_arr1,"desired");
    cJSON* test_arr3 = cJSON_GetObjectItem(test_arr2,"elevator");
    char idbuf[3][100]={
        "665601498937819135",
        "665601498937819134",
        "665601498937819136"
    };
    for (int i=0;i<3;i++) {
         test_arrout=cJSON_GetObjectItem(test_arr3,idbuf[i]);
         if(test_arrout!=NULL)
         {
             HC_PRINT("mum=%d",i);
         }
    }

    return test_arrout;
}
cJSON* HC_CJSON_MetaDataInit(char * analysis,char *id)
{
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(analysis);
    cJSON* test_arrout=NULL;
    //判断是否打包成功
    if(cjson == NULL){

        return NULL;
    }

    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"payload");
    cJSON* test_arr1 = cJSON_GetObjectItem(test_arr,"metadata");
    cJSON* test_arr2 = cJSON_GetObjectItem(test_arr1,"desired");
    cJSON* test_arr3 = cJSON_GetObjectItem(test_arr2,"elevator");
    test_arrout= cJSON_GetObjectItem(test_arr3,id);
    //如果解析电梯ID不到怎么办
    return test_arrout;
}
ST_SetInfoAnalysis *HC_CJSON_payloadFind(cJSON* cjson_find,char*findtemp)
{
    long buf[30]={0};
    ST_SetInfoAnalysis *SetInfoAnalysis=(ST_SetInfoAnalysis *)buf;
    cJSON* test_arr=NULL;
    test_arr = cJSON_GetObjectItem(cjson_find,findtemp);
    if(test_arr==NULL)
    {
        return SetInfoAnalysis;
    }
    char *json_data=NULL;
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"whetherToUpload"));
    if(json_data!=NULL)
    {
        sprintf(SetInfoAnalysis->whetherToUpload,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"whetherToUploadPeriodically"));
    if(json_data!=NULL)
    {
        sprintf(SetInfoAnalysis->whetherToUploadPeriodically,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"uploadCycle"));
    if(json_data!=NULL)
    {
        SetInfoAnalysis->uploadCycle=atol(json_data);
    }
    free(json_data);
    cJSON_Delete(cjson_find);
    return SetInfoAnalysis;
}
long HC_CJSON_metadataFind(cJSON* cjson_find,char*findtemp)
{
    long time=0;
    cJSON* test_arr=NULL;
    test_arr = cJSON_GetObjectItem(cjson_find,findtemp);
    if(test_arr==NULL)
    {
        return -1;
    }
    char *json_data=NULL;
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"timestamp"));
    if(json_data!=NULL)
    {

        time=atol(json_data);
    }
    free(json_data);

    cJSON_Delete(cjson_find);
    return time;
}
// 配置内容输出
ST_SetInfo *HC_CJSON_Config_Out(cJSON* cjson_desired,cJSON* cjson_metadata,char*findtemp)
{

    char buf[30]={0};
    char findtempbuf[512]={0};
    ST_SetInfo *SetInfo=( ST_SetInfo *)buf;
    ST_SetInfoAnalysis  SetInfoAnalysis;
    memset(&SetInfoAnalysis,0x0,sizeof (ST_SetInfoAnalysis));
    strcat(findtempbuf,findtemp);
    memcpy(&SetInfoAnalysis,HC_CJSON_payloadFind(cjson_desired,findtempbuf),sizeof (ST_SetInfoAnalysis));
    if(strlen(SetInfoAnalysis.whetherToUpload)==0)
    {
        return SetInfo;
    }
    SetInfo->time=HC_CJSON_metadataFind(cjson_metadata,findtempbuf);
    if( SetInfo->time==-1)
    {
        return SetInfo;
    }
    SetInfo->uploadCycle=SetInfoAnalysis.uploadCycle;
    strcat(SetInfo->whetherToUpload,SetInfoAnalysis.whetherToUpload);
    strcat(SetInfo->whetherToUploadPeriodically,SetInfoAnalysis.whetherToUploadPeriodically);
    return SetInfo;

}
int HC_VirtualDevice_Analysis(char *analysis)
{
    char IDBuf[3][100]={{0}};
    ST_SetInfo SetInfo;
    cJSON* desired_arr=NULL;
    cJSON* metadata_arr=NULL;
    memset(&SetInfo,0x0,sizeof (ST_SetInfo));
    for (int i=0;i<3;i++) {
        desired_arr=HC_CJSON_PayloadInit(analysis,IDBuf[i]);
        metadata_arr=HC_CJSON_MetaDataInit(analysis,IDBuf[i]);

    }

    return ERR_COMMON_SUCCESS;
}
//int HCjsonFile(char *filename)
//{

//    char devicebuf[1024*500]={0};
//    FILE *f;//输入文件
//    long len;//文件长度
//    char *content = NULL;//文件内容
//    f=fopen(filename,"rb");
//    fseek(f,0,SEEK_END);
//    len=ftell(f);
//    fseek(f,0,SEEK_SET);
//    content=(char*)malloc(len+1);

//    fread(content,1,(unsigned long)len,f);
//    fclose(f);
//    int j=0;

//    for (int i=0;i<(int)len;i++) {
//        if(content[i] != '\n'&&content[i] != '\r')
//        {
//            devicebuf[j]=content[i];
//            j++;
//        }
//    }
//    content=NULL;
//    free(content);
//   // HC_PRINT("JSON=%s",devicebuf);
//    sleep(1);
//    HC_MmapProcess_Server_Send(Topic_AllInfor.HCDevice_Pub,devicebuf);
//   char cleanbuf[256]={0};
//    usleep(100000);
//   sprintf(cleanbuf,"{\"method\": \"update\",\"state\": {\"desired\": \"null\"},\"version\": %d}",VERSION);
//     HC_MmapProcess_Server_Send(Topic_AllInfor.HCDevice_Pub,cleanbuf);
//    return ERR_COMMON_SUCCESS;

//}

