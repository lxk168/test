﻿#include "application/HCVirtualdeviceJsonBuild.h"
#include "public/HCPublicStruct.h"
#include "application/HCVirtualdeviceSqlite.h"
int VirtualdeviceJsonBuild()
{
    // char VirtualdeviceJson[1024*1024]={0};
    cJSON *root;
    root = cJSON_CreateObject();//创建一个json对象
    cJSON *state=cJSON_CreateObject();
    cJSON *reported=cJSON_CreateObject();


    cJSON_AddItemToObject(root, "method", cJSON_CreateString("update"));
    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCinformation);
    cJSON_AddItemToObject(root, "version", cJSON_CreateNumber(VirtualDeviceALL.version));
    cJSON_AddItemToObject(root, "state", state);
    cJSON_AddItemToObject(state, "status", cJSON_CreateString("success"));
    cJSON_AddItemToObject(state, "reported", reported);
    cJSON_AddItemToObject(reported, "elevator", elevatorJsonBuild(0));

    HC_PRINT("构建的JSON\n\r:%s", cJSON_Print(root));
    cJSON_Delete(root);
    //char *temp=VirtualdeviceJson;
    // return temp;
}
cJSON *TractionMachineJsonBuild(int id)
{
    cJSON *TractionMachine=cJSON_CreateObject();
    //电机额定信息事件配置
    if(VirtualDeviceALL.VirtualDevice[id].motorRatedInfoEventConfigurationflag==0)
    {
        cJSON *cJSONmotorRatedInfoEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONmotorRatedInfoEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].motorRatedInfoEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONmotorRatedInfoEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].motorRatedInfoEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONmotorRatedInfoEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].motorRatedInfoEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(TractionMachine, "motorRatedInfoEventConfiguration", cJSONmotorRatedInfoEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].motorRatedInfoEventConfigurationflag=1;
    }
    //抱闸制动器
    if(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactorflag==0)
    {
        cJSON*holdingBrakeContactor=cJSON_CreateObject();
        cJSON*baozha001=cJSON_CreateObject();
        cJSON*brakePreCheckStatusEventconfigurationbaozha001=cJSON_CreateObject();
        cJSON*brakeStatusEventConfigurationbaozha001=cJSON_CreateObject();
        cJSON*brakeForceDetectionDataSetEventConfigurationbaozha001=cJSON_CreateObject();
        cJSON*brakeOnOffTimeEventConfigurationbaozha001=cJSON_CreateObject();
        cJSON*baozha002=cJSON_CreateObject();
        cJSON*brakePreCheckStatusEventconfigurationbaozha002=cJSON_CreateObject();
        cJSON*brakeStatusEventConfigurationbaozha002=cJSON_CreateObject();
        cJSON*brakeForceDetectionDataSetEventConfigurationbaozha002=cJSON_CreateObject();
        cJSON*brakeOnOffTimeEventConfigurationbaozha002=cJSON_CreateObject();
        cJSON_AddItemToObject(baozha001,"instance",cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].instance));
        cJSON_AddItemToObject(baozha001,"use",cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].use));
        cJSON_AddItemToObject(brakePreCheckStatusEventconfigurationbaozha001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakePreCheckStatusEventconfigurationbaozha001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakePreCheckStatusEventconfigurationbaozha001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha001,"brakePreCheckStatusEventconfiguration",brakePreCheckStatusEventconfigurationbaozha001);
        cJSON_AddItemToObject(brakeStatusEventConfigurationbaozha001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeStatusEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeStatusEventConfigurationbaozha001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeStatusEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeStatusEventConfigurationbaozha001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeStatusEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha001,"brakeStatusEventConfiguration",brakeStatusEventConfigurationbaozha001);
        cJSON_AddItemToObject(brakeForceDetectionDataSetEventConfigurationbaozha001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeForceDetectionDataSetEventConfigurationbaozha001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeForceDetectionDataSetEventConfigurationbaozha001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha001,"brakeForceDetectionDataSetEventConfiguration",brakeForceDetectionDataSetEventConfigurationbaozha001);
        cJSON_AddItemToObject(brakeOnOffTimeEventConfigurationbaozha001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeOnOffTimeEventConfigurationbaozha001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeOnOffTimeEventConfigurationbaozha001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha001,"brakeOnOffTimeEventConfiguration",brakeOnOffTimeEventConfigurationbaozha001);
        cJSON_AddItemToObject(holdingBrakeContactor,VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[0].instance,baozha001);

        cJSON_AddItemToObject(baozha002,"instance",cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].instance));
        cJSON_AddItemToObject(baozha002,"use",cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].use));
        cJSON_AddItemToObject(brakePreCheckStatusEventconfigurationbaozha002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakePreCheckStatusEventconfigurationbaozha002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakePreCheckStatusEventconfigurationbaozha002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha002,"brakePreCheckStatusEventconfiguration",brakePreCheckStatusEventconfigurationbaozha002);
        cJSON_AddItemToObject(brakeStatusEventConfigurationbaozha002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeStatusEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeStatusEventConfigurationbaozha002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeStatusEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeStatusEventConfigurationbaozha002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeStatusEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha002,"brakeStatusEventConfiguration",brakeStatusEventConfigurationbaozha002);
        cJSON_AddItemToObject(brakeForceDetectionDataSetEventConfigurationbaozha002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeForceDetectionDataSetEventConfigurationbaozha002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeForceDetectionDataSetEventConfigurationbaozha002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha002,"brakeForceDetectionDataSetEventConfiguration",brakeForceDetectionDataSetEventConfigurationbaozha002);
        cJSON_AddItemToObject(brakeOnOffTimeEventConfigurationbaozha002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeOnOffTimeEventConfigurationbaozha002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeOnOffTimeEventConfigurationbaozha002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(baozha002,"brakeOnOffTimeEventConfiguration",brakeOnOffTimeEventConfigurationbaozha002);


        cJSON_AddItemToObject(holdingBrakeContactor,VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactor[1].instance,baozha002);
        cJSON_AddItemToObject(TractionMachine,"holdingBrakeContactor",holdingBrakeContactor);
        VirtualDeviceALL.VirtualDevice[id].holdingBrakeContactorflag=1;
    }
    //永磁体数据集事件配置
    if(VirtualDeviceALL.VirtualDevice[id].permanentMagnetDataSetEventConfigurationflag==0)
    {
        cJSON *cJSONpermanentMagnetDataSetEventConfiguration=cJSON_CreateObject();
        cJSON *permanentMagnets=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONpermanentMagnetDataSetEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].permanentMagnetDataSetEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONpermanentMagnetDataSetEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].permanentMagnetDataSetEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONpermanentMagnetDataSetEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].permanentMagnetDataSetEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(permanentMagnets, "permanentMagnetDataSetEventConfiguration", cJSONpermanentMagnetDataSetEventConfiguration);
        cJSON_AddItemToObject(TractionMachine, "permanentMagnets", permanentMagnets);
        VirtualDeviceALL.VirtualDevice[id].permanentMagnetDataSetEventConfigurationflag=1;
    }
    //制动器行程反馈开关
    if(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitchflag==0)
    {
        cJSON *brakeStrokeFeedbackSwitch=cJSON_CreateObject();
        cJSON *brakeStrokeFeedbackSwitch001=cJSON_CreateObject();
        cJSON *brakeStrokeFeedbackSwitch002=cJSON_CreateObject();
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch001,"instance",cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].instance));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch001,"use",cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].use));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch,VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].instance,brakeStrokeFeedbackSwitch001);

        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch002,"instance",cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].instance));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch002,"use",cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].use));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(brakeStrokeFeedbackSwitch,VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].instance,brakeStrokeFeedbackSwitch002);

        cJSON_AddItemToObject(TractionMachine, "brakeStrokeFeedbackSwitch", brakeStrokeFeedbackSwitch);
        VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitchflag=1;
    }
    //制动器热检测传感器
    if(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensorflag==0)
    {
        cJSON *brakeHeatDetectionSensor=cJSON_CreateObject();
        cJSON *brakeHeatDetectionSensor001=cJSON_CreateObject();
        cJSON *brakeHeatDetectionSensor002=cJSON_CreateObject();
        cJSON_AddItemToObject(brakeHeatDetectionSensor001,"instance",cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[0].instance));
        cJSON_AddItemToObject(brakeHeatDetectionSensor001,"use",cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[0].use));
        cJSON_AddItemToObject(brakeHeatDetectionSensor001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeHeatDetectionSensor001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeHeatDetectionSensor001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(brakeHeatDetectionSensor,VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[0].instance,brakeHeatDetectionSensor001);

        cJSON_AddItemToObject(brakeHeatDetectionSensor002,"instance",cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[1].instance));
        cJSON_AddItemToObject(brakeHeatDetectionSensor002,"use",cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[1].use));
        cJSON_AddItemToObject(brakeHeatDetectionSensor002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(brakeHeatDetectionSensor002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(brakeHeatDetectionSensor002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(brakeHeatDetectionSensor,VirtualDeviceALL.VirtualDevice[id].brakeStrokeFeedbackSwitch[1].instance,brakeHeatDetectionSensor002);

        cJSON_AddItemToObject(TractionMachine, "brakeHeatDetectionSensor", brakeHeatDetectionSensor);
        VirtualDeviceALL.VirtualDevice[id].brakeHeatDetectionSensorflag=1;
    }
    return TractionMachine;
}
cJSON *elevatorJsonBuild(int id)
{
    cJSON *elevator=cJSON_CreateObject();
    cJSON *elevatorID=cJSON_CreateObject();
    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCelevatorAndSnInfor);
    if(strlen(VirtualDeviceALL.VirtualDevice[id].elevatorid)==0||strlen(VirtualDeviceALL.VirtualDevice[id].sn)==0)
    {
        return NULL;
    }
    cJSON_AddItemToObject(elevator,VirtualDeviceALL.VirtualDevice[id].elevatorid, elevatorID);
    cJSON_AddItemToObject(elevatorID, "sn", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].sn));
    cJSON_AddItemToObject(elevatorID, "deviceRegistrationCode", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorid));
    //电梯综合故障信息
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    //机器人事件信息
    if(VirtualDeviceALL.VirtualDevice[id].agvInformationEventConfigurationflag==0)
    {
        cJSON *cJSOagvInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSOagvInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].agvInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSOagvInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].agvInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSOagvInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].agvInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "agvInformationEventConfiguration", cJSOagvInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].agvInformationEventConfigurationflag=1;
    }
    //控制柜统计数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].controlCabinetStatisticsEventConfigurationflag==0)
    {
        cJSON *cJSONcontrolCabinetStatisticsEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONcontrolCabinetStatisticsEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controlCabinetStatisticsEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONcontrolCabinetStatisticsEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controlCabinetStatisticsEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONcontrolCabinetStatisticsEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].controlCabinetStatisticsEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "controlCabinetStatisticsEventConfiguration", cJSONcontrolCabinetStatisticsEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].controlCabinetStatisticsEventConfigurationflag=1;
    }
    //控制柜固有数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].controlCabinetInherentDataEventConfigurationflag==0)
    {
        cJSON *cJSONcontrolCabinetInherentDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONcontrolCabinetInherentDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controlCabinetInherentDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONcontrolCabinetInherentDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controlCabinetInherentDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONcontrolCabinetInherentDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].controlCabinetInherentDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "controlCabinetInherentDataEventConfiguration", cJSONcontrolCabinetInherentDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].controlCabinetInherentDataEventConfigurationflag=1;
    }
    //控制柜温度数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].controlCabinetTemperatrueDataEventConfigurationflag==0)
    {
        cJSON *cJSONcontrolCabinetTemperatrueDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONcontrolCabinetTemperatrueDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controlCabinetTemperatrueDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONcontrolCabinetTemperatrueDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controlCabinetTemperatrueDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONcontrolCabinetTemperatrueDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].controlCabinetTemperatrueDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONcontrolCabinetTemperatrueDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].controlCabinetTemperatrueDataEventConfigurationflag=1;
    }
    //接触器列表
    if(VirtualDeviceALL.VirtualDevice[id].contactorListflag==0)
    {
        cJSON *cJSONcontactorList=cJSON_CreateObject();
        cJSON *jiechuqi001=cJSON_CreateObject();
        cJSON *jiechuqi002=cJSON_CreateObject();
        cJSON *jiechuqi003=cJSON_CreateObject();
        cJSON *jiechuqi004=cJSON_CreateObject();
        cJSON *integratedConfiguration001=cJSON_CreateObject();
        cJSON *integratedConfiguration002=cJSON_CreateObject();
        cJSON *integratedConfiguration003=cJSON_CreateObject();
        cJSON *integratedConfiguration004=cJSON_CreateObject();

        cJSON_AddItemToObject(jiechuqi001, "instance", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[0].instance));
        cJSON_AddItemToObject(jiechuqi001, "use", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[0].use));
        cJSON_AddItemToObject(integratedConfiguration001, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[0].integratedConfiguration.whetherToUpload));
        cJSON_AddItemToObject(integratedConfiguration001, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[0].integratedConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(integratedConfiguration001, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[0].integratedConfiguration.uploadCycle));
        cJSON_AddItemToObject(jiechuqi001, "integratedConfiguration", integratedConfiguration001);
        cJSON_AddItemToObject(cJSONcontactorList, VirtualDeviceALL.VirtualDevice[id].contactorList[0].instance, jiechuqi001);

        cJSON_AddItemToObject(jiechuqi002, "instance", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[1].instance));
        cJSON_AddItemToObject(jiechuqi002, "use", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[1].use));
        cJSON_AddItemToObject(integratedConfiguration002, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[1].integratedConfiguration.whetherToUpload));
        cJSON_AddItemToObject(integratedConfiguration002, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[1].integratedConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(integratedConfiguration002, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[1].integratedConfiguration.uploadCycle));
        cJSON_AddItemToObject(jiechuqi002, "integratedConfiguration", integratedConfiguration002);
        cJSON_AddItemToObject(cJSONcontactorList, VirtualDeviceALL.VirtualDevice[id].contactorList[1].instance, jiechuqi002);

        cJSON_AddItemToObject(jiechuqi003, "instance", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[2].instance));
        cJSON_AddItemToObject(jiechuqi003, "use", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[2].use));
        cJSON_AddItemToObject(integratedConfiguration003, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[2].integratedConfiguration.whetherToUpload));
        cJSON_AddItemToObject(integratedConfiguration003, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[2].integratedConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(integratedConfiguration003, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[2].integratedConfiguration.uploadCycle));
        cJSON_AddItemToObject(jiechuqi003, "integratedConfiguration", integratedConfiguration003);
        cJSON_AddItemToObject(cJSONcontactorList, VirtualDeviceALL.VirtualDevice[id].contactorList[2].instance, jiechuqi003);

        cJSON_AddItemToObject(jiechuqi004, "instance", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[3].instance));
        cJSON_AddItemToObject(jiechuqi004, "use", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[3].use));
        cJSON_AddItemToObject(integratedConfiguration004, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[3].integratedConfiguration.whetherToUpload));
        cJSON_AddItemToObject(integratedConfiguration004, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].contactorList[3].integratedConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(integratedConfiguration004, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].contactorList[3].integratedConfiguration.uploadCycle));
        cJSON_AddItemToObject(jiechuqi004, "integratedConfiguration", integratedConfiguration004);
        cJSON_AddItemToObject(cJSONcontactorList, VirtualDeviceALL.VirtualDevice[id].contactorList[3].instance, jiechuqi004);
        cJSON_AddItemToObject(elevatorID, "contactorList", cJSONcontactorList);
        VirtualDeviceALL.VirtualDevice[id].contactorListflag=1;
    }


    //系统状态事件配置
    if(VirtualDeviceALL.VirtualDevice[id].systemStatusEventConfigurationflag==0)
    {
        cJSON *cJSONsystemStatusEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONsystemStatusEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].systemStatusEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONsystemStatusEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].systemStatusEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONsystemStatusEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].systemStatusEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "systemStatusEventConfiguration", cJSONsystemStatusEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].systemStatusEventConfigurationflag=1;
    }
    //系统信号检测事件配置
    if(VirtualDeviceALL.VirtualDevice[id].systemSignalDetectionEventConfigurationflag==0)
    {
        cJSON *cJSONsystemSignalDetectionEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONsystemSignalDetectionEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].systemSignalDetectionEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONsystemSignalDetectionEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].systemSignalDetectionEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONsystemSignalDetectionEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].systemSignalDetectionEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "systemSignalDetectionEventConfiguration", cJSONsystemSignalDetectionEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].systemSignalDetectionEventConfigurationflag=1;
    }
    //控制器密码事件配置
    if(VirtualDeviceALL.VirtualDevice[id].controllerPasswordEventConfigurationflag==0)
    {
        cJSON *cJSONcontrollerPasswordEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONcontrollerPasswordEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controllerPasswordEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONcontrollerPasswordEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].controllerPasswordEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONcontrollerPasswordEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].controllerPasswordEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "controllerPasswordEventConfiguration", cJSONcontrollerPasswordEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].controllerPasswordEventConfigurationflag=1;
    }
    //故障代码事件配置
    if(VirtualDeviceALL.VirtualDevice[id].errorCodeEventConfigurationflag==0)
    {
        cJSON *cJSONerrorCodeEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONerrorCodeEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].errorCodeEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONerrorCodeEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].errorCodeEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONerrorCodeEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].errorCodeEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "errorCodeEventConfiguration", cJSONerrorCodeEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].errorCodeEventConfigurationflag=1;
    }
    //端子状态事件配置
    if(VirtualDeviceALL.VirtualDevice[id].terminalStatusEventConfigurationflag==0)
    {
        cJSON *cJSONterminalStatusEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONterminalStatusEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].terminalStatusEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONterminalStatusEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].terminalStatusEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONterminalStatusEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].terminalStatusEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "terminalStatusEventConfiguration", cJSONterminalStatusEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].terminalStatusEventConfigurationflag=1;
    }
    //AGV心跳事件配置
    if(VirtualDeviceALL.VirtualDevice[id].AGVheartbeatEventConfigurationflag==0)
    {
        cJSON *cJSONAGVheartbeatEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONAGVheartbeatEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].AGVheartbeatEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONAGVheartbeatEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].AGVheartbeatEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONAGVheartbeatEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].AGVheartbeatEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "AGVheartbeatEventConfiguration", cJSONAGVheartbeatEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].AGVheartbeatEventConfigurationflag=1;
    }
    //CAN1通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].CAN1communicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONCAN1communicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONCAN1communicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].CAN1communicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONCAN1communicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].CAN1communicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONCAN1communicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].CAN1communicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "CAN1communicationDataEventConfiguration", cJSONCAN1communicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].CAN1communicationDataEventConfigurationflag=1;
    }
    //SPI1通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].SPI1communicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONSPI1communicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONSPI1communicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].SPI1communicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONSPI1communicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].SPI1communicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONSPI1communicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].SPI1communicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "SPI1communicationDataEventConfiguration", cJSONSPI1communicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].SPI1communicationDataEventConfigurationflag=1;
    }
    //SPI2通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].SPI2communicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONSPI2communicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONSPI2communicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].SPI2communicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONSPI2communicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].SPI2communicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONSPI2communicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].SPI2communicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "SPI2communicationDataEventConfiguration", cJSONSPI2communicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].SPI2communicationDataEventConfigurationflag=1;
    }
    //MOD1通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].MOD1communicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONMOD1communicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONMOD1communicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].MOD1communicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONMOD1communicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].MOD1communicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONMOD1communicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].MOD1communicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "MOD1communicationDataEventConfiguration", cJSONMOD1communicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].MOD1communicationDataEventConfigurationflag=1;
    }
    //MOD2通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].MOD2communicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONMOD2communicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONMOD2communicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].MOD2communicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONMOD2communicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].MOD2communicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONMOD2communicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].MOD2communicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "MOD2communicationDataEventConfiguration", cJSONMOD2communicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].MOD2communicationDataEventConfigurationflag=1;
    }
    //485-1通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].m485FirstcommunicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONm485FirstcommunicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONm485FirstcommunicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].m485FirstcommunicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONm485FirstcommunicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].m485FirstcommunicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONm485FirstcommunicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].m485FirstcommunicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "m485FirstcommunicationDataEventConfiguration", cJSONm485FirstcommunicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].m485FirstcommunicationDataEventConfigurationflag=1;
    }
    //485-2通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].m485TwocommunicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONm485TwocommunicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONm485TwocommunicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].m485TwocommunicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONm485TwocommunicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].m485TwocommunicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONm485TwocommunicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].m485TwocommunicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "m485TwocommunicationDataEventConfiguration", cJSONm485TwocommunicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].m485TwocommunicationDataEventConfigurationflag=1;
    }
    //串口通讯数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].serialPortcommunicationDataEventConfigurationflag==0)
    {
        cJSON *cJSONserialPortcommunicationDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONserialPortcommunicationDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].serialPortcommunicationDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONserialPortcommunicationDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].serialPortcommunicationDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONserialPortcommunicationDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].serialPortcommunicationDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "serialPortcommunicationDataEventConfiguration", cJSONserialPortcommunicationDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].serialPortcommunicationDataEventConfigurationflag=1;
    }
    //接口板统计数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].interfaceBoardStatisticalDataEventConfigurationflag==0)
    {
        cJSON *cJSONinterfaceBoardStatisticalDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONinterfaceBoardStatisticalDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].interfaceBoardStatisticalDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONinterfaceBoardStatisticalDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].interfaceBoardStatisticalDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONinterfaceBoardStatisticalDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].interfaceBoardStatisticalDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "interfaceBoardStatisticalDataEventConfiguration", cJSONinterfaceBoardStatisticalDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].interfaceBoardStatisticalDataEventConfigurationflag=1;
    }
    //接口板温度数据事件配置
    if(VirtualDeviceALL.VirtualDevice[id].interfaceBoardTemperatrueDataEventConfigurationflag==0)
    {
        cJSON *cJSONinterfaceBoardTemperatrueDataEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONinterfaceBoardTemperatrueDataEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].interfaceBoardTemperatrueDataEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONinterfaceBoardTemperatrueDataEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].interfaceBoardTemperatrueDataEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONinterfaceBoardTemperatrueDataEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].interfaceBoardTemperatrueDataEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "interfaceBoardTemperatrueDataEventConfiguration", cJSONinterfaceBoardTemperatrueDataEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].interfaceBoardTemperatrueDataEventConfigurationflag=1;
    }
    //新国标物联网模块第三方电梯远程锁梯信号事件配置
    if(VirtualDeviceALL.VirtualDevice[id].elevatorRemoteLockSignalEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorRemoteLockSignalEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorRemoteLockSignalEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorRemoteLockSignalEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorRemoteLockSignalEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorRemoteLockSignalEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorRemoteLockSignalEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorRemoteLockSignalEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorRemoteLockSignalEventConfiguration", cJSONelevatorRemoteLockSignalEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorRemoteLockSignalEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }
    if(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag==0)
    {
        cJSON *cJSONelevatorComprehensiveFaultInformationEventConfiguration=cJSON_CreateObject();
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUpload", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "whetherToUploadPeriodically", cJSON_CreateString(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically));
        cJSON_AddItemToObject(cJSONelevatorComprehensiveFaultInformationEventConfiguration, "uploadCycle", cJSON_CreateNumber(VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle));
        cJSON_AddItemToObject(elevatorID, "elevatorComprehensiveFaultInformationEventConfiguration", cJSONelevatorComprehensiveFaultInformationEventConfiguration);
        VirtualDeviceALL.VirtualDevice[id].elevatorComprehensiveFaultInformationEventConfigurationflag=1;
    }

    return elevator;
}
