﻿#include "application/HCBusinessCJson.h"
#include"application/HCMqttSubProcess.h"
#include "public/HCPublicStruct.h"

#define MAXCJSONLENG (1024*10)
//十进制转2进制函数
int  Bit(int N)
{
    if(N<2)
    {return N ;}
    else {
        return Bit(N/2)*10+N%2;
    }
}
//输出一个数的各个位
int BitGet(int N,int i)
{
    int a[65]={0};
    for(int j=1; N != 0; j++)
        {
            a[j] = N%10;
            N /= 10;
        }
    return a[i];
}

/***===================================================（1）轿门个数================================================*****/
/*
 * 函数功能：轿门个数
 * method：
 * carDoorNumber    轿门个数
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.carDoorNumberEvent/post
 */
char *HCcarDoorNumberEvent(int carDoorNumber,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.carDoorNumber.post");

    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"carDoorNumber\":%d}},\"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), carDoorNumber, ack);
    char* temp = tempbuf;
    return temp;
}
/***===================================================（2）轿厢-轿门-门球====================================================****/
/*
 * 函数功能：轿厢-轿门-门球-门球数据集
 * method：
 * result：门球对中结果    0:左偏   1：对中   2：右偏 //对中结果（录屏结束后弃用）
 * doorBallOffset://偏移量 （录屏结束后启用）
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.doorBall.front.doorBallDataSet/post
 */
char* HCDoorBallDataSet(int doorBallOffset, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorBallDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorBallCenterResult\":%d,\"doorBallOffset\":%d,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method,HC_LocalTimeGet(), doorBallOffset,doorBallOffset, Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***==================================================（3）轿厢-轿门-皮带==================================================***/
/*
 * 函数功能：轿厢-轿门-皮带-皮带检测数据
 * method：
 * result:门打滑检测结果    0:0  1:1  2:2  3:3    打滑检测结果，分为4等级 用数字表示等级
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.strap.front.beltDetectionData/post

 */
char* HCBeltDetectionData(int status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.beltDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorSlipDetectionResult\":%d}}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method,HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}

/***=====================================================（4）轿厢-轿门-轿厢地坎==================================================****/
/*
 * 函数功能：轿厢-轿门-轿厢地坎-轿厢地坎检测数据
 * method:
 * doorFriction：门机预维保实时结果  BIT0：前门摩擦力检测结果
 * doorFrictionStatus:门摩檫力  ture :正常  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.carSill.carSillDetectionData/post
 */
char* HCCarSillDetectionData(int doorFriction, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    char doorFrictionStatus[6]={0};
    strcat(method, "thing.event.carSillDetectionData.post");
    if(doorFriction%2==0)
    {
        sprintf(doorFrictionStatus,"%s","ture");
    }
    else if (doorFriction%2!=0)
    {
        sprintf(doorFrictionStatus,"%s","false");
    }

    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%ld\",\"value\":{\"doorFriction\":\"%s\",\"floor\":%d}}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), doorFrictionStatus, Floor, ack);
    char* temp = tempbuf;
    return temp;
}

/***================================================（5）轿厢-轿门-锁钩=====================================================***/
/*
 * 函数功能：轿厢-轿门-锁钩-锁钩数据集
 * method:
 * state:锁钩状态   ture:正常  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.lockHook.front.lockHookData/post
 */
char* HCLockHookDataSet(int  pre_maintain_result, int Floor,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    char status[6]={0};
    if(BitGet(Bit(pre_maintain_result),1)==0)
    {
        sprintf(status,"%s","true");
    }
    else if (BitGet(Bit(pre_maintain_result),1)!=0) {
        sprintf(status,"%s","false");
    }
    strcat(method, "thing.event.lockHookDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"lockHookStatus\":%s,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status ,Floor, ack);
    char* temp = tempbuf;
    return temp;
}   
/***===============================================（6）厅外-厅门-弹簧自闭力、门锁抬起时间=====================================================***/
/*
 * 函数功能：厅外-厅门-弹簧自闭力、门锁抬起时间
 * method：
 * doorLockUpTime:门锁抬起时间
 * doorSelfClosingForceCoefficientPercentage:门自闭力系数百分比
 * floor:楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 *  MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.hall.hallDoorList.front.hallDoorStatistics/post
 */
char* HCHallDoorStatistics(int doorLockUpTime,int perc,int floor ,int ack)
{
    char method[512] = { 0 };
    char tempbuf[1024] = { 0 };
    strcat(method, "thing.event.hallDoorStatistics.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorLockUpTime\":%d,\"doorSelfClosingForceCoefficientPercentage\":%d,\"hallDoorFloor\":%d}},\"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), doorLockUpTime,perc,floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***================================================(7)厅门-厅门-门重锤检测结果=========================================================*****/
/*
 * 函数功能：厅门-厅门检测数据
 * method：
 * DoorHeavyHammerTestResults:门重锤检测结果  true:正常  false:损坏
 * hallDoorFloor:厅门所在楼层
 * floornum：有效楼层数
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 *
 */
char* HCHallDoorInspectionData(int result,int floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    char DoorHeavyHammerTestResults[6]={0};
    if(result==1){
        sprintf(DoorHeavyHammerTestResults,"%s","false");
    }
    else {
        sprintf(DoorHeavyHammerTestResults,"%s","true");
    }
    strcat(method, "thing.event.hallDoorInspectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"hallDoorHeavyHammerTestResults\":%s,\"hallDoorFloor\":%d}},\"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), DoorHeavyHammerTestResults, floor,ack);
    char*temp = tempbuf;
    return temp;
}
/***=================================================(8)机房设备-控制柜-NICE3000-故障代码====================================================***/
/*
 * 函数功能：机房设备-控制柜-nice3000new一体机-故障代码事件
 * method：
 * errorCode：故障代码         int  电梯故障代码，用数字对应不同的故障
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.errorCodeEvent/post
 */
char* HCErrorCodeEvent(int errorCode, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.errorCodeEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"errorCode\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), errorCode, ack);
    char* temp = tempbuf;
    return temp;
}
/***=================================================(9)轿厢-轿门-轿门锁====================================================***/
/*
 * 函数功能：轿厢-轿门-轿门锁-轿门锁统计数据
 * method：
 * openTimes:开门次数统计
 * closTimes:关门次数统计
 * floor : 楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.carDoorLock.front.carDoorLockStatisticalData/post
 */
char* HCCarDoorLockStatisticalData(int openTimes,int closTimes, int floor,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.carDoorLockStatisticalData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"openingTimesStatistics\":%d,\"closingTimesStatistics\":%d,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), openTimes, closTimes,floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***=================================================(10)轿厢-轿门-轿门门板-异常反复开关门次数====================================================***/
/*
 * 函数功能：轿厢-轿门-门板-异常反复开关门次数
 * method：
 * time：开关门时间
 * times：开关门次数
 * abnormalTimes:异常反复开关门次数
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.123456789.car.carDoor.doorPanel.front.doorPanelStatisticalData/post
 */
char* HCDoorPanelStatisticalData(int time,int times,int abnormalTimes,int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorPanelStatisticalData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"openingClosingTime\":%d,\"openingClosingDoorTimes\":%d,\"abnormalTimes\":%d,\"floor\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), time, times, abnormalTimes, Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***=================================================(11)轿厢-轿门-轿门门锁短接====================================================***/

/*
 * 函数功能：轿厢-轿门-门锁短接故障检测
 * method：
 * status：电梯是否有E53门锁短接故障，ture：E53门锁短接故障，false：无E53门锁短接故障
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorLockShortCircuitFaultDetection/post
 */
char* HCDoorLockShortCircuitFaultDetection(char* status,int floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorLockShortCircuitFaultDetection.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"state\":%s,\"floor\":%d}},\"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status,floor, ack);
    char* temp = tempbuf;
    return temp;
}

/***=================================================(12)轿厢-轿门-光幕==========================================*****/
/*
 * 函数功能：轿厢-轿门-光幕-特殊功能事件
 * method：
 * TotalOcclusionState：光管总遮挡状态   0:无遮挡   1:遮挡
 * lightNumber：光管对数 int
 * DecayValue：光管强度值  int
 * lightPipeFault：光管故障  0：无  1：有
 * lightCurtainSpace;//光幕距离 0：近距离  1：远距离
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.lightCurtain.specialFunction/post
 */

char* HCLightPipe1to48BlockingState(ST_LightSpecialFunction LightSpecialFunction, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    char* temp = "";
    char identifier[256] = { 0 };
    char valuebuf[MAXCJSONLENG] = { 0 };
    if (LightSpecialFunction.LightStateEvent.allNum > MaxLightNum)
    {
        return temp;
    }
    for (int i = 1; i <= LightSpecialFunction.LightStateEvent.allNum; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        sprintf(identifier, "{\"lightPipeNumber\":%d,\"blockingStatus\":%d}", i, LightSpecialFunction.LightStateEvent.LightNum[i].lightState );
        strcat(valuebuf, identifier);
        if (i <= LightSpecialFunction.LightStateEvent.allNum - 1)
        {
            strcat(valuebuf, ",");
        }
    }

    int lightStatus;//光管总遮挡状态
    int lightSpace;//光管距离
    switch (LightSpecialFunction.TotalOcclusionState) {
    case 0:lightStatus=0;lightSpace=0;break;
    case 1:lightStatus=1;lightSpace=0;break;
    case 2:lightStatus=0;lightSpace=1;break;
    case 3:lightStatus=1;lightSpace=1;break;
    }
\
    strcat(method, "thing.event.specialFunction.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"lightPipeTotalOcclusionState\":%d,\"lightPipeStateArray\":[%s],\"lightPipeDoubleNumber\":%d,\"lightPipeDecayValue\":%d,\"lightCurtainSpace\":%d,\"lightPipeFault\":%d}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, (long)(HC_LocalTimeGet()*1000),lightStatus ,valuebuf,LightSpecialFunction.lightNumber,LightSpecialFunction.DecayValue,lightSpace,LightSpecialFunction.lightPipeFault, ack);
    temp = tempbuf;
    return temp;
}
/***=================================================(13)轿厢-轿门-同步门电机正常Max电流==============================================***/
/*
 * 函数功能：轿厢-轿门-同步门电机-门电机检测数据
 * method
 * HighA:关门最大电流高速段 double  0.01A
 * LowA:关门最大电流低速段  double  0.01A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.synchronousDoorMotor.front.doorMotorDetectionData/post
 */
char* HCSyncDoorMotorDetectionData(int current ,int floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    double HighA=0;
    double LowA=0;
    int bucket;
    int i;
    for (i=0;i<=7;i++) {
        bucket=BitGet(Bit(current),i)*2^i;
        HighA+=bucket/100;
        bucket=0;
        bucket=BitGet(Bit(current),i+8)*2^i;
        LowA+=bucket/100;
        bucket=0;
    }
    strcat(method, "thing.event.doorMotorDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"closeDoorMaximumCurrentHighSpeedSection\":%lf,\"closeDoorMaximumCurrentLowSpeedSection\":%lf,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method,HC_LocalTimeGet(), HighA , LowA ,floor,ack);
    char* temp = tempbuf;
    return temp;
}
/***==============================================(14)轿厢-轿门-异步门电机电机正常Max电流=====================================================****/
/*
 * 函数功能：轿厢-轿门-异步门电机-门电机检测数据
 * method：
 * HighA:关门最大电流高速段 double  0.1A
 * LowA:关门最大电流低速段  double  0.1A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.carDoor.asynchronousDoorMotor.doorMotorDetectionData/post
 */
char* HCAsyncDoorMotorDetectionData(int current ,int floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    double HighA=0;
    double LowA=0;
    int bucket;
    int i;
    for (i=0;i<=7;i++) {
        bucket=BitGet(Bit(current),i)*2^i;
        HighA+=bucket;
        bucket=0;
        bucket=BitGet(Bit(current),i+8)*2^i;
        LowA+=bucket;
        bucket=0;
    }
    strcat(method, "thing.event.doorMotorDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"closeDoorMaximumCurrentHighSpeedSection\":%lf,\"closeDoorMaximumCurrentLowSpeedSection\":%lf,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), HighA, LowA,floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(15)轿厢-轿内-电瓶车识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-电瓶车识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionElectricVehicle/post
 */
char* HCVisionElectricVehicle(ST_VisionData  visionElectricVehicle, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionElectricVehicle.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),visionElectricVehicle.image.bucket,visionElectricVehicle.image.path,visionElectricVehicle.video.bucket,visionElectricVehicle.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(16)轿厢-轿内-扒门识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-电瓶车识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionPryingDoor/post
 */
char* HCVisionPryingDoor(ST_VisionData  visionPryingDoor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionPryingDoor.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),visionPryingDoor.image.bucket,visionPryingDoor.image.path,visionPryingDoor.video.bucket,visionPryingDoor.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(17)轿厢-轿内-烟雾识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-电瓶车识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionSmoke/post
 */
char* HCVisionSmoke(ST_VisionData  visionSmoke, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionSmoke.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),visionSmoke.image.bucket,visionSmoke.image.path,visionSmoke.video.bucket,visionSmoke.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(18)轿厢-轿内-困人识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-困人识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionTrapped/post
 */
char* HCVisionTrapped(ST_VisionData  visionTrapped, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionTrapped.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),visionTrapped.image.bucket,visionTrapped.image.path,visionTrapped.video.bucket,visionTrapped.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(19)轿厢-轿内-倒地识别=====================================================****/
/*
 * 函数功能：轿厢-轿内-倒地识别
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionFall/post
 */
char* HCVisionFall(ST_VisionData  visionFall, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionFall.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"image\":{\"bucket\":\"%s\",\"path\":\"%s\"},\"video\":{\"bucket\":\"%s\",\"path\":\"%s\"}}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),visionFall.image.bucket,visionFall.image.path,visionFall.video.bucket,visionFall.video.path , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(20)轿厢-轿内-人员计数=====================================================****/
/*
 * 函数功能：轿厢-轿内-人员计数
 * method：
 * bucket:桶
 * path:  图片、视频的url
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.car.insideCar.visionPerson/post
 */
char* HCVisionPerson(int visionPerson, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.visionPerson.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"visionPerson\":%d}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),visionPerson , ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================================(21)机房设备-同步曳引机-永磁体=======================================================****/
/*
 * 函数功能：机房设备-同步曳引机-永磁体-永磁体数据集
 * method:
 * highA:空载电流高位          单位精度：0.01A
 * lowA:空载电流低位           单位精度：0.01A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.synchronousTractionMachine.permanentMagnets.permanentMagnetDataSet/post
 */
char* HCPermanentMagnetDataSet(double  highA, double lowA, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.permanentMagnetDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"noLoadCurrentHigh\":%lf,\"noLoadCurrentLow\":%lf}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), highA,lowA, ack);
    char* temp = tempbuf;
    return temp;
}
/***======================================================(22)机房设备-同步曳引机-制动器热检测传感器==================================================****/
/*
 * 函数功能：机房设备-同步曳引机-制动器热检测传感器-制动器热检测传感器统计数据抱闸动作次数
 * method:
 * times:抱闸动作次数
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.synchronousTractionMachine.brakeHeatDetectionSensor.brakeThermalDetectionSensorStatistics/post
 */
char* HCBrakeThermalDetectionSensorStatistics(int times, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.brakeThermalDetectionSensorStatistics.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"actionTimes\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), times, ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================================(23)机房设备-同步曳引机-刹车片磨损传感器-打滑量=================================================****/
/*
 * 函数功能：机房设备-同步曳引机-刹车片磨损传感器-刹车片磨损传感器数据
 * method：
 * slip:抱闸闭合后的打滑量     单位精度：1mm
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.synchronousTractionMachine.brakePadWearSensor.brakePadWearSensorData/post
 */
char* HCBrakePadWearSensorData(int slip, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.brakePadWearSensorData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"brakeClosingAfterSlip\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), slip, ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================================(24) 轿厢-额定运行速度=================================================****/
/*
 * 函数功能：机房设备-同步曳引机-刹车片磨损传感器-刹车片磨损传感器数据
 * method：
 * runState:运行状态  true:运行  false:停车
 * runDirection:运行方向   true:上行   false:下行
 * ratedRunSpeed:额定运行速度   int  m/s
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.667707515965014016.car.runData/post
 */
char* HCrunData(char* runStatebuf,char* runDirectionbuf,int  ratedRunSpeed, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.runData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"runState\":%s,\"runDirection\":%s,\"ratedRunSpeed\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), runStatebuf,runDirectionbuf,ratedRunSpeed, ack);
    char* temp = tempbuf;
    return temp;
}

/***============================================================(25)机房设备-同步曳引机-电机额定转速，额定电流=============================================*****/
/*
 * 函数功能：机房设备-同步曳引机-电机额定信息
 * method：
 * ratedSpeed:  电机额定转速         1 r/min
 * ratedCurrent:  电机额定电流        0.01A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.synchronousTractionMachine.motorRatedInfo/post
 */
char* HCMotorRatedInfo(int raredSpeed, double ratedCurrent,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.motorRatedInfo.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"ratedSpeed\":%d,\"ratedCurrent\":%lf}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), raredSpeed,ratedCurrent ,ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================================(26)井道-钢丝绳-抱闸力检测钢丝绳打滑量事件=============================================*****/
/*
 * 函数功能：井道-钢丝绳-抱闸力检测钢丝绳打滑量事件
 * method:
 * theDetectionDisplacementOfThisBrakeForce:本次抱闸力检测位移量
 * thisBrakeForceEarlyWarningDetectionDisplacementAmount:本次抱闸力预警检测位移量
 * theBrakeForceDetectsTheAmountOfSlip:抱闸力检测打滑量（脉冲）
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.667707515965014016.shaft.steelRopes.brakeForceDetectionSteelRopesSlip/post
 */
char* HCBrakeForceDetectionSteelRopesSlip(int theDetectionDisplacementOfThisBrakeForce, int thisBrakeForceEarlyWarningDetectionDisplacementAmount, int theBrakeForceDetectsTheAmountOfSlip, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.brakeForceDetectionSteelRopesSlip.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"theDetectionDisplacementOfThisBrakeForce\":%d,\"thisBrakeForceEarlyWarningDetectionDisplacementAmount\":%d,\"theBrakeForceDetectsTheAmountOfSlip\":%d}},\"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), theDetectionDisplacementOfThisBrakeForce, thisBrakeForceEarlyWarningDetectionDisplacementAmount, theBrakeForceDetectsTheAmountOfSlip, ack);
    char* temp = tempbuf;
    return temp;
}
/***= ==================================================(27)轿厢-电梯运行里程================================================*****/
/*
 * 函数功能：轿厢-电梯运行里程
 * method：
 * mileage：运行里程  int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.car.elevatorMileage/post
 */
char* HCElevatorMileage(int mileage, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.elevatorMileage.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"mileage\":%d}},\"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), mileage, ack);
    char* temp = tempbuf;
    return temp;
}
/***= ==================================================(28)轿厢-电梯当前位置信息================================================*****/
/*
 * 函数功能：轿厢-电梯运行里程
 * method：
 * floor：楼层  int
 * elevatorCurrentHeight:电梯当前高度
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.car.elevatorCurrentPositionInfo/post
 */
char* HCElevatorCurrentPositionInfo(int floor,int elevatorCurrentHeight,  int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.elevatorCurrentPositionInfo.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"floor\":%d,\"elevatorCurrentHeight\":%d}},\"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), floor, elevatorCurrentHeight, ack);
    char* temp = tempbuf;
    return temp;
}
/***= ===========================================(29)机房设备-同步曳引机-抱闸制动器-抱闸故障事件================================================*****/
/*
 * 函数功能：机房设备-同步曳引机-抱闸制动器-抱闸故障事件
 * method:
 * breakFault:抱闸故障   int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.machineRoomEquipment.synchronousTractionMachine.holdingBrakeContactor.brakeFaultEvent/post
 */
char* HCBrakeFaultEvent(int breakFault, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.brakeFaultEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"breakFault\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), breakFault, ack);
    char* temp = tempbuf;
    return temp;
}
/***= ===========================================(30)机房设备-同步曳引机-抱闸制动器-抱闸打开关闭时间事件================================================*****/
/*
 * 函数功能：机房设备-同步曳引机-抱闸制动器-抱闸打开关闭时间事件
 * method：
 * openTime:抱闸打开时间    单位精度：1ms
 * closeTime:抱闸关闭时间    单位精度：1ms
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.machineRoomEquipment.synchronousTractionMachine.holdingBrakeContactor.brakeOnOfftimeEvent/post
 */
char* HCBrakeOnOfftimeEvent(int openTime, int closeTime, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.brakeOnOfftimeEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"brakeOpeningTime\":%d,\"brakeClosingTime\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), openTime,closeTime, ack);
    char* temp = tempbuf;
    return temp;
}
/***==============================================(31)机房设备-控制柜-运行时间、次数=======================================================***/
/*
 * 函数功能：机房设备-控制柜-控制柜统计数据
 * method：
 * times:电梯运行次数
 * time:电梯运行时间
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.controlCabinetStatistics/post
 */
char* HCControlCabinetStatistics(int times, int time, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.controlCabinetStatistics.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"elevatorOperationTimes\":%d,\"elevatorRunningTime\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), times, time, ack);
    char* temp = tempbuf;
    return temp;
}
/****====控制系统质量======***/
/***============================================（32-1）厅外显示板-按钮-上召、下召======================================================***/
/*
 * 函数功能：厅外显示板-按钮-上召、下召
 * method：
 * upCallActionsTimes;//上召按钮动作次数
 * downCallActionsTimes;//下召钮动作次数
 * floor:楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为0
 *  MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.car.insideCar.carCallBoard.buttonOfCarCallBoard.mainControlPanelButtonStatisticsEvent/post
 */
char* HCfrontDoorHallUpAndDownCallButtonActionsNumber(ST_upAndDownCallButton upAndDownCallButton, int ack)
{
    char tempbuf[1024*4] = { 0 };
    char method[512] = { 0 };
    char* temp = "";
    char identifier[256] = { 0 };
    char valuebuf[1024*10] = { 0 };
    if (upAndDownCallButton.num > MaxFloorNum)
    {
        return temp;
    }
    for (int i = 1; i <= upAndDownCallButton.num; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        sprintf(identifier, "{\"floor\":%d,\"upCallActionsTimes\":%d,\"downCallActionsTimes\":%d}", i,upAndDownCallButton.ButtonActionsTimesArray[i].upCallActionTimes, upAndDownCallButton.ButtonActionsTimesArray[i].downCallActionTimes);
        strcat(valuebuf, identifier);
        if (i < upAndDownCallButton.num)
        {
            strcat(valuebuf, ",");
        }
    }
    strcat(method, "thing.event.frontDoorHallUpAndDownCallButtonActionsNumber.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":[%s]},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, (long)(HC_LocalTimeGet()*1000), valuebuf, ack);
    temp = tempbuf;
    return temp;
}

char* HCbackDoorHallUpAndDownCallButtonActionsNumber(ST_upAndDownCallButton upAndDownCallButton, int ack)
{
    char tempbuf[1024*4] = { 0 };
    char method[512] = { 0 };
    char* temp = "";
    char identifier[256] = { 0 };
    char valuebuf[MAXCJSONLENG] = { 0 };
    if (upAndDownCallButton.num > MaxButtonNum)
    {
        return temp;
    }
    for (int i = 1; i <= upAndDownCallButton.num; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        sprintf(identifier, "{\"floor\":%d,\"upCallActionsTimes\":%d,\"downCallActionsTimes\":%d}", i,upAndDownCallButton.ButtonActionsTimesArray[i].upCallActionTimes, upAndDownCallButton.ButtonActionsTimesArray[i].downCallActionTimes);
        strcat(valuebuf, identifier);
        if (i <= upAndDownCallButton.num - 1)
        {
            strcat(valuebuf, ",");
        }
    }
    strcat(method, "thing.event.backDoorHallUpAndDownCallButtonActionsNumber.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":[%s]},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, (long)(HC_LocalTimeGet()*1000), valuebuf, ack);
    temp = tempbuf;
    return temp;
}
/***============================================（32-2）轿厢-轿内-轿内指令板-按钮-主操纵盘======================================================***/
/*
 * 函数功能：按钮（轿内指令板）-主操纵盘
 * method：
 * doorCloseButtonActionsTimes;//关门按钮动作次数
 * doorOpenButtonActionsTimes;//开门钮动作次数
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为0
 *  MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.car.insideCar.carCallBoard.buttonOfCarCallBoard.mainControlPanelButtonStatisticsEvent/post
 */

char* HCMainControlPanelButtonStatisticsEvent(ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent, int ack)
{
    char tempbuf[1024*8] = { 0 };
    char method[512] = { 0 };
    char* temp=",";
    char identifier[512] = { 0 };
    char valuebuf[1024*8] = { 0 };
    if (ButtonStatisticsEvent.num > MaxButtonNum)
    {
        return temp;
    }
    for (int i = 1; i <= ButtonStatisticsEvent.num; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        sprintf(identifier, "{\"buttonNumber\":%d,\"actionsTimes\":%d}", i, ButtonStatisticsEvent.ButtonActionsTimesArray[i-1].actionsTimes);
        strcat(valuebuf, identifier);
        if (i < ButtonStatisticsEvent.num)
        {
            strcat(valuebuf, ",");
        }
    }
    strcat(method, "thing.event.mainControlPanelButtonStatisticsEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorOpenButtonActionsTimes\":%d,\"doorCloseButtonActionsTimes\":%d,\"buttonActionsTimesArray\":[%s]}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), ButtonStatisticsEvent.doorOpenButtonActionsTimes, ButtonStatisticsEvent.doorCloseButtonActionsTimes, valuebuf, ack);
    temp = tempbuf;
    return temp;
}

/***============================================（33）轿厢-轿内-轿内指令板-按钮-辅助操纵盘按钮======================================================***/
/*
 * 函数功能：按钮（轿内指令板）-辅助操纵盘按钮
 * method：
 * doorCloseButtonActionsTimes;//关门按钮动作次数
 * doorOpenButtonActionsTimes;//开门钮动作次数
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为0
 *  MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.car.insideCar.carCallBoard.buttonOfCarCallBoard.auxiliaryControlPanelButtonStatisticsEvent/post
 */

char* HCAuxiliaryControlPanelButtonStatisticsEvent(ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent, int ack)
{
    char tempbuf[1024*10] = { 0 };
    char method[512] = { 0 };
    char* temp = "";
    char identifier[256] = { 0 };
    char valuebuf[1024*10] = { 0 };
    if (ButtonStatisticsEvent.num > MaxButtonNum)
    {
        return temp;
    }
    for (int i = 1; i <=ButtonStatisticsEvent.num; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        sprintf(identifier, "{\"buttonNumber\":%d,\"actionsTimes\":%d}", i, ButtonStatisticsEvent.ButtonActionsTimesArray[i-1].actionsTimes);
        strcat(valuebuf, identifier);
        if (i < ButtonStatisticsEvent.num)
        {
            strcat(valuebuf, ",");
        }
    }
    strcat(method, "thing.event.auxiliaryControlPanelButtonStatisticsEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorOpenButtonActionsTimes\":%d,\"doorCloseButtonActionsTimes\":%d,\"buttonActionsTimesArray\":[%s]}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), ButtonStatisticsEvent.doorOpenButtonActionsTimes, ButtonStatisticsEvent.doorCloseButtonActionsTimes, valuebuf, ack);
    temp = tempbuf;
    return temp;
}

/***============================================（34）轿厢-轿内-轿内指令板-按钮-残疾人操纵盘======================================================***/
/*
 * 函数功能：按钮（轿内指令板）-残疾人操纵盘
 * method：
 * doorCloseButtonActionsTimes;//关门按钮动作次数
 * doorOpenButtonActionsTimes;//开门钮动作次数
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为0
 *  MQTT.topic: tls/se_gateway_a_1.0.0/inovance_paas/inovance123456/thing/event/elevator.123456789.car.insideCar.carCallBoard.buttonOfCarCallBoard.handicappedControlPanelButtonStatisticsEvent/post
 */
char* HCHandicappedControlPanelButtonStatisticsEvent(ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent, int ack)
{
    char tempbuf[1024*10] = { 0 };
    char method[512] = { 0 };
    char* temp = "";
    char identifier[256] = { 0 };
    char valuebuf[1024*10] = { 0 };
    if (ButtonStatisticsEvent.num > MaxButtonNum)
    {
        return temp;
    }
    for (int i = 1; i <= ButtonStatisticsEvent.num; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        sprintf(identifier, "{\"buttonNumber\":%d,\"actionsTimes\":%d}", i, ButtonStatisticsEvent.ButtonActionsTimesArray[i].actionsTimes);
        strcat(valuebuf, identifier);
        if (i < ButtonStatisticsEvent.num )
        {
            strcat(valuebuf, ",");
        }
    }
    strcat(method, "thing.event.handicappedControlPanelButtonStatisticsEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorOpenButtonActionsTimes\":%d,\"doorCloseButtonActionsTimes\":%d,\"buttonActionsTimesArray\":[%s]}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), ButtonStatisticsEvent.doorOpenButtonActionsTimes, ButtonStatisticsEvent.doorCloseButtonActionsTimes, valuebuf, ack);
    temp = tempbuf;
    return temp;
}
/***=====================---------------============（35）控制柜-接口板-电容容量/能耗/发电量================================***/
/*
 * 函数功能：机房设备-控制柜-接口板-接口板统计数据
 * method：
 * busbarRatedCapacitanceCapacity;//母线额定电容容量  int
 * capacitanceCapacity;//电容容量  int
 * energyConsumptionData;//能耗数据  double   KWH
 * powerGeneration;//发电量  double   KWH
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.interfaceBoard.interfaceBoardStatistics/post
 */

char* HCInterfaceBoardStatistics(ST_InterfaceBoardStatistics InterfaceBoardStatistics, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.interfaceBoardStatistics.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"busbarRatedCapacitanceCapacityBusbar\":%d,\"capacitanceCapacity\":%d,\"energyConsumptionData\":%lf,\"powerGeneration\":%lf}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), InterfaceBoardStatistics.busbarRatedCapacitanceCapacity, InterfaceBoardStatistics.capacitanceCapacity, InterfaceBoardStatistics.energyConsumptionData, InterfaceBoardStatistics.powerGeneration, ack);
    char* temp = tempbuf;
    return temp;
}
/***===================================================(36)控制柜-接口板-温度===============================***/
/*
 * 函数功能：机房设备-控制柜-接口板-接口板温度数据
 * method：
 * igbTtemperatrue;//IGBT温度  int
 * igbTNtctemperatrue;//IGBT的NTC温度  int
 * inverterSideDiodeJunctionTemperatrue;//逆变侧二极管结温  int
 * rectifierSideDiodeJunctionTemperature;//整流侧二极管结温  int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.interfaceBoard.interfaceBoardTemperatrueData/post
 */
char* HCInterfaceBoardTemperatrueData(ST_InterfaceBoardTemperatrueData InterfaceBoardTemperatrueData, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.interfaceBoardTemperatrueData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"igbTtemperatrue\":%d,\"igbTNtctemperatrue\":%d,\"inverterSideDiodeJunctionTemperatrue\":%d,\"rectifierSideDiodeJunctionTemperature\":%d}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), InterfaceBoardTemperatrueData.igbTtemperatrue, InterfaceBoardTemperatrueData.igbTNtctemperatrue, InterfaceBoardTemperatrueData.inverterSideDiodeJunctionTemperatrue, InterfaceBoardTemperatrueData.rectifierSideDiodeJunctionTemperature, ack);
    char* temp = tempbuf;
    return temp;
}
/***================================================(37)控制柜-温度数据=================================**/
/*
 * 函数功能：机房设备-控制柜-控制柜温度数据数据
 * method：
 * Temp:柜内温度   int   1℃
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.controlCabinetTemperatrueData/post
 */
char* HCControlCabinetTemperatrueData( int Temp, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.controlCabinetTemperatrueData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"cabinetTemperatrue\":%d}}, \"sys\":{\"ack\":%d}}", HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), Temp, ack);
    char* temp = tempbuf;
    return temp;
}
/***==========================================(38)机房设备-控制柜-接触器========================================****/
/*
 * 函数功能：机房设备-控制柜-接触器-整合事件
 * method：
 * MainPoleTemp:接触器主极点温度
 * RatedTemp:接触器触点额定温度
 * actionTimes:动作次数
 * closeTimes1:尝试闭合次数
 * minTime1:辅触点吸合最小时间间隔
 * minTime2:吸合指令最小时间间隔
 * closeTimes2:闭合次数
 * disConnectTimes:断开次数
 * closeDelayTime:吸合延时
 * openDelayTime:断开延时
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.contactorList.jiechuqi001.integratedEvent/post
 */
char* HCContactorIntegratedEvent(ST_ContactorIntegratedEvent IntegratedEvent,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.integratedEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"contactorMainPoleTemperature\":%d,\"contactorContactRatedTemperature\":%d,\"actionTimes\":%d,\"closingAttemptsNumber\":%d,\"minimumTimeIntervalBetweenAuxiliaryContacts\":%d,\"minimumTimeIntervalForClosingCommand\":%d,\"numberOfClosures\":%d,\"numberOfDisconnects\":%d,\"closingDelay\":%d,\"openDelay\":%d}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(), IntegratedEvent.MainPoleTemp, IntegratedEvent.RatedTemp, IntegratedEvent.actionTimes, IntegratedEvent.closeTimes1, IntegratedEvent.minTime1, IntegratedEvent.minTime2, IntegratedEvent.closeTimes1, IntegratedEvent.closeTimes2, IntegratedEvent.closeDelayTime, IntegratedEvent.openDelayTime, ack);
    char* temp = tempbuf;
    return temp;
}
/***==========================================机房-控制柜-nice3000-通讯接口-CAN1=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-CAN1通讯数据
 * method: thing.event.CAN1communicationData.post
 * CAN1communicationBusInterference:   CAN1通信总线干扰   int
 * CAN1PCBcommunicationModuleSelf-check:   CAN1单板通讯模块自检  int
 * CAN1communicationOnlineStatus:   CAN1通信在线状态   array
 * CANNode:CAN节点   int
 * onlineStatus:在线状态  true:在线  false:离线
 * CAN1frameLossRate:CAN1丢帧率   int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.CAN1communicationData/post
 */
char* HCCAN1communicationData(ST_CAN1communicationData communicationData,int ack)
{
    char tempbuf[1024*4] = { 0 };
    char valuebuf[1024*4]={0};
    char transitionBuf[512]={0};
    char status[6]={0};
    char method[512] = { 0 };
    strcat(method, "thing.event.CAN1communicationData.post");
    int i;
    for (i=1;i<=32;i++) {
        memset(transitionBuf,0x0,sizeof (transitionBuf));
        memset(status,0x0,sizeof (status));
        if(communicationData.CAN1communicationOnlineStatus[i].onlineStatus==0)
        {
            strcat(status,"true");
        }
        else {
            strcat(status,"false");
        }
        sprintf(transitionBuf,"{\"CANNode\":%d,\"onlineStatus\":%s,\"CAN1frameLossRate\":%d}",i,status,communicationData.CAN1communicationOnlineStatus[i].CAN1frameLossRate);
        strcat(valuebuf,transitionBuf);
        if(i<32){
            strcat(valuebuf,",");
        }
    }

    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"CAN1communicationBusInterference\":%d,\"CAN1PCBcommunicationModuleSelfCheck\":%d,\"CAN1communicationOnlineStatus\":[%s]}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(),communicationData.CAN1communicationBusInterference,communicationData.CAN1PCBcommunicationModuleSelfCheck,valuebuf, ack);
    char* temp = tempbuf;
    return temp;
}

/***==========================================机房-控制柜-nice3000-通讯接口-SPI1=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-SPI1通讯数据
 * method: thing.event.SPI1communicationData.post
 * SPI1communicationBusInterference:   SPI1通信总线干扰   int
 * SPI1communicationOnlineStatus:   SPI1通信在线状态
 * SPI1frameLossRate:    SPI1丢帧率   int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.SPI1communicationData/post
 */

char* HCSPI1communicationData(int SPI1communicationBusInterference,int SPI1communicationOnlineStatus,int SPI1frameLossRate, int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char status[6]={0};
    char method[512]={0};
    strcat(method,"thing.event.SPI1communicationData.post");
    if(SPI1communicationOnlineStatus==0){
        sprintf(status,"%s","true");
    }
    else {
        sprintf(status,"%s","false");
    }
    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"SPI1communicationBusInterference\":%d,\"SPI1communicationOnlineStatus\":%s,\"SPI1frameLossRate\":%d}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method,HC_LocalTimeGet(),SPI1communicationBusInterference, status,SPI1frameLossRate,ack);
    char *temp=tempbuf;
    return temp;
}

/***==========================================机房-控制柜-nice3000-通讯接口-SPI2=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-SPI2通讯数据
 * method: thing.event.SPI2communicationData.post
 * SPI2communicationBusInterference:   SPI2通信总线干扰   int
 * SPI2communicationOnlineStatus:   SPI2通信在线状态
 * SPI2frameLossRate:    SPI2丢帧率   int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.SPI2communicationData/post
 */
char* HCSPI2communicationData(int SPI2communicationBusInterference,int SPI2communicationOnlineStatus,int SPI2frameLossRate, int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char status[6]={0};
    char method[512]={0};
    strcat(method,"thing.event.SPI2communicationData.post");
    if(SPI2communicationOnlineStatus==0){
        sprintf(status,"%s","true");
    }
    else {
        sprintf(status,"%s","false");
    }
    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"SPI2communicationBusInterference\":%d,\"SPI2communicationOnlineStatus\":%s,\"SPI2frameLossRate\":%d}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method,HC_LocalTimeGet(),SPI2communicationBusInterference, status,SPI2frameLossRate,ack);
    char *temp=tempbuf;
    return temp;
}

/***==========================================机房-控制柜-nice3000-通讯接口-MOD1=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-MOD1通讯数据
 * method: thing.event.MOD1communicationData.post
 * MOD1communicationBusInterference:   MOD1通信总线干扰   int
 * MOD1communicationOnlineStatus:   MOD1通信在线状态  array
 * floor: 厅外楼层
 * onlineStatus：在线状态
 * MOD1frameLossRate:    MOD1丢帧率   int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.SPI2communicationData/post
 */
char* HCMOD1communicationData(ST_MOD1communicationData MOD1communicationData, int ack)
{
    char tempbuf[1024*8]={0};
    char valuebuf[1024*8]={0};
    char method[512]={0};
    char onlineStatus[6]={0};
    char transitionBuf[512]={0};
    strcat(method,"thing.event.MOD1communicationData.post");
    int i;
    for (i=1;i<=112;i++) {
        memset(onlineStatus,0x0,sizeof (onlineStatus));
        memset(transitionBuf,0x0,sizeof (transitionBuf));
        if(MOD1communicationData.MOD1communicationOnlineStatus[i].onlineStatus==0){
            strcat(onlineStatus,"true");
        }
        else {
            strcat(onlineStatus,"false");
        }
        sprintf(transitionBuf,"{\"floor\":%d,\"onlineStatus\":%s,\"frameLossRate\":%d}",i,onlineStatus,MOD1communicationData.MOD1communicationOnlineStatus[i].MOD1frameLossRFate);
        strcat(valuebuf,transitionBuf);
        if(i<112){
            strcat(valuebuf,",");
        }
    }

    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"MOD1communicationBusInterference\":%d,\"MOD1communicationOnlineStatus\":[%s]}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method,HC_LocalTimeGet(),MOD1communicationData.MOD1communicationBusInterference,valuebuf, ack);

    char* temp;
    temp = tempbuf;
    return temp;

}
/***==========================================机房-控制柜-nice3000-通讯接口-MOD2=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-MOD2通讯数据
 * method: thing.event.MOD2communicationData.post
 * MOD2communicationData:   MOD2通讯在线状态   true:在线   false:离线
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.MOD2communicationData/post
 */

char* HCMOD2communicationData(int MOD2communication,int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char method[512]={0};
    char valuebuf[6]={0};
    strcat(method,"thing.event.MOD2communicationData.post");
    if(MOD2communication==0){
        strcat(valuebuf,"true");
    }
    else {
        strcat(valuebuf,"false");
    }
    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"MOD2communicationData\":%s}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method,HC_LocalTimeGet(),valuebuf,ack);
    char* temp;
    temp=tempbuf;
    return temp;
}
/***==========================================机房-控制柜-nice3000-通讯接口-485-1=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-4851通讯数据
 * method: thing.event.4851communicationData.post
 * 4851communicationBusInterference:  485-1通信总线干扰
 * 4851communicationOnlineStatus:   485-1通讯在线状态   true:在线   false:离线
 * 4851frameLossRate:   485-1丢帧率
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.4851communicationData/post
 */

char* HC4851communicationData(int communicationBusInterference ,int communicationOnlineStatus,int frameLossRate,int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char status[6]={0};
    char method[512]={0};
    strcat(method,"thing.event.4851communicationData.post");
    if(communicationOnlineStatus==0){
        strcat(status,"true");
    }
    else {
        strcat(status,"false");
    }

    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"4851communicationBusInterference\":%d,\"4851communicationOnlineStatus\":%s,\"4851frameLossRate\":%d}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295),method,HC_LocalTimeGet(),communicationBusInterference,status,frameLossRate,ack);
    char* temp;
    temp=tempbuf;
    return temp;
}

/***==========================================机房-控制柜-nice3000-通讯接口-485-2=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-4852通讯数据
 * method: thing.event.485TwoCommunicationData.post
 * 485TwoCommunicationBusInterference:  485-2通信总线干扰
 * 485TwoCommunicationOnlineStatus:   485-2通讯在线状态   true:在线   false:离线
 * 485TwoFrameLossRate:   485-2丢帧率
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.485TwoCommunicationData/post
 */
char* HC485TwoCommunicationData(int communicationBusInterference,int communicationOnlineStatus,int frameLossRate,int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char status[6]={0};
    char method[512]={0};
    strcat(method,"thing.event.485TwoCommunicationData");
    if(communicationOnlineStatus==0){
        strcat(status,"true");
    }
    else {
        strcat(status,"false");
    }
    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"485TwoCommunicationBusInterference\":%d,\"485TwoCommunicationOnlineStatus\":%s,\"485TwoFrameLossRate\":%d}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967259),method,HC_LocalTimeGet(),communicationBusInterference,status,frameLossRate,ack);
    char* temp;
    temp=tempbuf;
    return temp;
}

/***==========================================机房-控制柜-nice3000-通讯接口-串口=========================================****/
/* 函数功能：机房-控制柜-nice3000-通讯接口-串口通讯数据
 * method: thing.event.serialCommunicationData.post
 * serialCommunicationOnlineStatus:   串口通讯在线状态   true:在线   false:离线
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.serialCommunicationData/post
 */
char* HCserialCOmmunicationData(int serialCommunicationStatus,int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char status[6]={0};
    char method[512]={0};
    strcat(method,"thing.event.serialCommunicationStatus");
    if(serialCommunicationStatus==0){
        strcat(status,"true");
    }
    else {
        strcat(status,"false");
    }
    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"serialCommunicationStatus\":%s}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295,4294967295),method,HC_LocalTimeGet(),status,ack);
    char* temp;
    temp=tempbuf;
    return temp;
}

/***============================================(39)安全回路=======================================================****/
/*
 * 函数功能 : 安全回路
 * method：thing.event.safetyCircuitVoltageDetectionData.post
 * safeCirHeadVol ：安全回路端电压V1.0.0
 * conCoilSteStaVol ：接触器线圈稳态电压V1.0.0
 * conCoilPullInTransVol ：接触器线圈吸合瞬态电压V1.0.0
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.safetyCircuit.safetyCircuitVoltageDetectionData/post
 */

char * HCSafetyloop(int safeCirHeadVol,int conCoilSteStaVol,int conCoilPullInTransVol, int ack)
{
    char tempbuf[MAXCJSONLENG]={0};
    char method[512]={0};
    double V1,V2,V3;
    V1=safeCirHeadVol/10;
    V2=conCoilSteStaVol/10;
    V3=conCoilPullInTransVol/10;
    strcat(method,"thing.event.safetyCircuitVoltageDetectionData.post");
    sprintf(tempbuf,"{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"safetyCircuitHeadVoltage\":%d,\"contactorCoilSteadyStateVoltage\":%d,\"contactorCoilPullInTransientVoltage\":%d}},\"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method,HC_LocalTimeGet(), V1, V2, V3,ack);
    char *temp=tempbuf;
    return temp;
}

/***============================================(40)直梯-电梯管理-电梯展示事件================================*****/
/*
 * 函数功能：直梯-电梯管理-电梯展示事件
 * method：
 * elevatorOnlineStatus：电梯在线状态    true：电梯在线   false：电梯离线
 * elevatorRunningStatus：电梯运行状态   0：正常   1：停梯    2：检修
 * elevatorFloor：电梯所在楼层           int
 * elevatorUpAndDownStatus:电梯上行、下行状态     1:电梯上行     2:电梯下行     3：电梯停止
 * elevatorDoorOpeningAndClosingStatus:开关门状态   0:未知状态  1:开门过程  2:开门到位  3:关门过程  4:关门到位
 * communicationSignal:通讯信号          0：2G     1：3G      2：4G
 * signalIntensity：信号强度   int
 * errorCode：故障代码    修改为string    (废弃：int  用数字表示故障)
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为0
 * MQTT.topic: /tsl/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.123456789.elevatorManagementElevatorDisplayEvent/post
 */

char* HCElevatorManagementElevatorDisplayEvent(ST_ElevatorManagementElevatorDisplayEvent  displayEvent, int ack)
{
    char tempbuf[1024*10] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.elevatorManagementElevatorDisplayEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"elevatorOnlineStatus\":%s,\"elevatorRunningStatus\":%d,\"elevatorFloor\":%d,\"elevatorUpAndDownStatus\":%s,\"elevatorDoorOpeningAndClosingStatus\":%d,\"communicationSignal\":%d,\"signalIntensity\":%d,\"errorCode\":\"%s\"}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(),displayEvent.elevatorOnlineStatus,displayEvent.elevatorRunningStatus,displayEvent.elevatorFloor,displayEvent.elevatorUpAndDownStatus,displayEvent.elevatorDoorOpeningAndClosingStatus,displayEvent.communicationSignal,displayEvent.signalIntensity,displayEvent.errorCode, ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(41)直梯-电梯管理-电梯基本事件================================*****/
/*
 * 函数功能：直梯-电梯管理-电梯基本事件
 * method:
 * elevatorLevelingStatus:平层状态   true:平层   false:非平层
 * sleepyPersonDetection:困人检测    true:有困人  false:无困人
 * controllerEncryptionStatus:控制器有无加密   true:有加密  false:无加密
 * controllerOnlineStatus:控制器在线状态   true:在线   false:离线
 * intelligentHardwareOnlineStatus:智能硬件在线状态   true:在线   false:离线
 * serviceModel:服务模式   0:检修模式 1:井道自学习 2:微动平层 3:消防返基站 4:消防员 5:故障状态 6:司机 7:自动运行 8:锁梯 9:空闲泊梯 10:低速返平层 11:救援运行 12:电机调谐 13:键盘控制 14:基站校验 15:VIP运行
 * runningSpeed:运行速度
 * elevatorLoadingStatus:电梯负载状态  0:正常 1:满员 2:超载
 * callUpFloor:     array[]上召楼层
 * callDownFloor:    array[]下召楼层
 * internalCallFloor:    array[]内召楼层
 * 备注：该事件包含电梯展示信息内容
 * MQTT.topic: /tsl/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.123456789.elevatorManagementBasicInformationEvent/post
 */

char* HCElevatorManagementBasicInformationEvent(ST_ElevatorManagementBasicInformationEvent  elevatorManagementBasicInformationEvent, ST_ElevatorManagementElevatorDisplayEvent  displayEvent  ,int ack)
{
    char tempbuf1[MAXCJSONLENG] = { 0 };
    char tempbuf2[MAXCJSONLENG] = { 0 };
    char tempbuf3[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    char valuebuf[1024*4]={ 0 };
    strcat(method, "thing.event.elevatorManagementBasicInformationEvent.post");
    //电梯展示信息
    sprintf(tempbuf1, "\"elevatorOnlineStatus\":%d,\"elevatorRunningStatus\":%d,\"elevatorFloor\":%d,\"elevatorUpAndDownStatus\":%d,\"elevatorDoorOpeningAndClosingStatus\":%d,\"communicationSignal\":%d,\"signalIntensity\":%d,\"errorCode\":\"%s\"",
            displayEvent.elevatorOnlineStatus,displayEvent.elevatorRunningStatus,displayEvent.elevatorFloor,displayEvent.elevatorUpAndDownStatus,displayEvent.elevatorDoorOpeningAndClosingStatus,displayEvent.communicationSignal,displayEvent.signalIntensity,displayEvent.errorCode);
    strcat(valuebuf, tempbuf1);
    //电梯基本信息
    sprintf(tempbuf2,",\"elevatorLevelingStatus\":%d,\"sleepyPersonDetection\":%s,\"controllerEncryptionStatus\":%s,\"controllerOnlineStatus\":%s,\"intelligentHardwareOnlineStatus\":%s,\"serviceModel\":%d,\"runningSpeed\":%d,\"elevatorLoadingStatus\":%d",
            elevatorManagementBasicInformationEvent.elevatorLevelingStatus,elevatorManagementBasicInformationEvent.sleepyPersonDetection,elevatorManagementBasicInformationEvent.controllerOnlineStatus,elevatorManagementBasicInformationEvent.intelligentHardwareOnlineStatus,elevatorManagementBasicInformationEvent.serviceModel,elevatorManagementBasicInformationEvent.runningSpeed,elevatorManagementBasicInformationEvent.elevatorLoadingStatus);
    strcat(valuebuf,tempbuf2);
    //上召、下召、内召楼层
    int i;
    int upCallNum=0,downCallNum=0,innerCallNum=0;
    for (i=1;i<=10;i++) {
        if(elevatorManagementBasicInformationEvent.callUpFloor[i].floorNum!=0){
            upCallNum+=1;
        }
        if(elevatorManagementBasicInformationEvent.callDownFloor[i].floorNum!=0){
            downCallNum+=1;
        }
        if(elevatorManagementBasicInformationEvent.internalCallFloor[i].floorNum!=0){
            innerCallNum+=1;
        }

    }
    char upCallBuf[512]={0};
    char downCallBuf[512]={0};
    char internalCallBuf[512]={0};
    char buf[5]={0};
    for (i=1;i<=10;i++) {
        memset(buf,0x0,sizeof (buf));
        if(elevatorManagementBasicInformationEvent.callUpFloor[i].floorNum!=0){
            sprintf(buf,"%d",i);
            strcat(upCallBuf, buf);
        }
        if(i<upCallNum){
            strcat(upCallBuf, ",");
        }
    }
    for (i=1;i<=10;i++) {
        memset(buf,0x0,sizeof (buf));
        if(elevatorManagementBasicInformationEvent.callDownFloor[i].floorNum!=0){
            sprintf(buf,"%d",i);
            strcat(downCallBuf, buf);
        }
        if(i<downCallNum){
            strcat(downCallBuf, ",");
        }
    }
    for (i=1;i<=10;i++) {
        memset(buf,0x0,sizeof (buf));
        if(elevatorManagementBasicInformationEvent.internalCallFloor[i].floorNum!=0){
            sprintf(buf,"%d",i);
            strcat(internalCallBuf, buf);
        }
        if(i<innerCallNum){
            strcat(internalCallBuf, ",");
        }
    }

    sprintf(tempbuf3, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{%s,\"callUpFloor\":[%s],\"callDownFloor\":[%s],\"internalCallFloor\":[%s]}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(),valuebuf,upCallBuf,downCallBuf,internalCallBuf, ack);
    char* temp = tempbuf3;
    return temp;
}


/***============================================(42)直梯-楼栋大屏================================*****/
/*
 * 函数功能：直梯-楼栋大屏
 * method:
 * elevatorFloor:电梯所在楼层 int
 * elevatorStatus:电梯状态    0：正常  1：检修  2：故障
 * onlineStatus:在线状态   true:在线  false:离线
 * runningDirection:运行方向   1：上行  2：下行  3：停止
 * errorCode：故障代码  string
 * MQTT.topic: /tsl/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.123456789.buildingScreen/post
 */
char* HCBuildingScreen(ST_BuildingScreen  buildingScreen, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.buildingScreen.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"elevatorFloor\":%s,\"elevatorStatus\":%d,\"onlineStatus\":%d,\"runningDirection\":%d,\"errorCode\":\"%s\"}}, \"sys\":{\"ack\":%d}}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(),buildingScreen.elevatorFloor,buildingScreen.elevatorStatus,buildingScreen.onlineStatus,buildingScreen.runningDirection,buildingScreen.errorCode, ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(43)直梯-井道全息================================*****/
/*
 * 函数功能：直梯-井道全息
 * method:
 * elevatorFloor:电梯所在楼层 int
 * elevatorStatus:电梯状态    0：正常  1：停梯  2：检修
 * onlineStatus:在线状态   true:在线  false:离线
 * recordStatus：录制状态  int    null
 * MQTT.topic: /tsl/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.123456789.hoistwayHolographic/post
 */
char* HCHoistwayHolographic(ST_HoistwayHolographic  hoistwayHolographic, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.hoistwayHolographic.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"elevatorFloor\":%d,\"elevatorStatus\":%d,\"onlineStatus\":%s,\"recordStatus\":%d}}, \"sys\":{\"ack\":%d}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(),hoistwayHolographic.elevatorFloor,hoistwayHolographic.elevatorStatus,hoistwayHolographic.onlineStatus,hoistwayHolographic.recordStatus, ack);
    char* temp = tempbuf;
    return temp;
}
/***============================================(44)直梯-电梯综合故障信息================================*****/
/*
 * 函数功能：直梯-电梯综合故障信息
 * method:
 * eventMessageSequenceNumber:事件消息序列号 int
 * subDeviceAddressCode:子设备地址码   string
 * eventCode:事件编码  int
 * eventStatus:事件状态  int    null
 * eventData:事件数据 string
 * eventSubcode:事件子码  string
 * realTimeData:实时数据  string
 * eventGenerationTime:事件产生时间  int
 * eventCancellationTime:事件解除时间  int
 * whetherToLift: 是否解除
 * alarmDescription: 告警描述  string
 * whetherToTrapped: 是否困人 true:困人   false:无困人
 * whetherToOverhaul:是否检修 true:检修   false:不检修
 * elevatorFloor: 电梯所在楼层  int
 * MQTT.topic: /tsl/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.123456789.elevatorComprehensiveFaultInformation/post
 */
char* HCelevatorComprehensiveFaultInformation(ST_elevatorComprehensiveFaultInformation  faultInfo, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.elevatorComprehensiveFaultInformation.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"eventMessageSequenceNumber\":%d,\"subDeviceAddressCode\":\"%s\",\"eventCode\":%d,\"eventStatus\":%d,\"eventData\":\"%s\",\"eventSubcode\":\"%s\",\"realTimeData\":\"%s\",\"eventGenerationTime\":%d,\"eventCancellationTime\":%d,\"whetherToLift\":%d,\"alarmDescription\":\"%s\",\"whetherToTrapped\":%s,\"whetherToOverhaul\":%s,\"elevatorFloor\":%d}}, \"sys\":{\"ack\":%d}",
            HC_MQttIdGet(2294967295, 4294967295), method, HC_LocalTimeGet(),faultInfo.eventMessageSequenceNumber,faultInfo.subDeviceAddressCode,faultInfo.eventCode,faultInfo.eventStatus,faultInfo.eventData,faultInfo.eventSubcode,faultInfo.realTimeData,faultInfo.eventGenerationTime,faultInfo.eventCancellationTime,faultInfo.whetherToLift,faultInfo.alarmDescription,faultInfo.whetherToTrapped,faultInfo.whetherToOverhaul,faultInfo.elevatorFloor, ack);
    char* temp = tempbuf;
    return temp;
}


























































































































/***================================================轿厢-轿门-锁钩=====================================================***/
/*
 * 函数功能：轿厢-轿门-锁钩-锁钩数据集
 * method:
 * state:锁钩状态   ture:锁钩  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tls/se_gateway_a_1.0.0/inovance_paas/9527/thing/event/elevator.667707515965014016.hall.hallDoorList.front.hallDoorStatistics/post

 */
char* HChallDoorStatistics(char* status, int Floor,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.hallDoorStatistics.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"lockHookDataSet\":\"%s\",\"floor\":%d}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status ,Floor, ack);
    char* temp = tempbuf;
    return temp;
}














/***======================================================轿厢-轿门-滑轨=========================================****/
/*
 * 函数功能：轿厢-轿门-地坎-滑轨摩檫力检测数据
 * method:
 * doorFriction:门摩檫力  ture :正常  false:异常
 * Floor:轿厢所处楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.slide.slidingRailFrictionDetectionData/post
 */
char* HCSlidingRailFrictionDetectionData(char* doorFriction, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.slidingRailFrictionDetectionData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"doorFriction\":\"%s\",\"carCurrentFloor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),doorFriction , Floor, ack);
    char* temp = tempbuf;
    return temp;
}
/***====================================================轿厢-轿门================================================*****/
/*
 * 函数功能：轿厢-轿门-门机预维保状态
 * method：
 * status：预维保状态  0：不处于预维保 1：处于预维保 2：不适合预维保 3：预维保结束
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorMachinePreMaintenanceStatus/post
 */
char* HCDoorMachinePreMaintenanceStatus(int status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorMachinePreMaintenanceStatus.post");

    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"preMaintenanceStatus\":%d}},\"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}

/***======================================================轿厢-轿门-光幕====================================*****/
/*
 * 函数功能：轿厢-轿门-光幕-特殊功能事件
 * method：
 * TotalOcclusionState：光管总遮挡状态 int
 * lightNumber：光管对数 int
 * BlockingState：光管1-48遮挡状态  int
 * DecayValue：光管强度值  int
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.lightCurtain.specialFunction/post
 */
char* HCSpecialFunction(int TotalOcclusionState, int lightNumber, int BlockingState , int DecayValue, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.specialFunction.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"lightPipeTotalOcclusionState\":\"%d\",\"lightPipeDoubleNumber\":\"%d\",\"lightPipe1to48BlockingState\":\"%d\",\"lightPipeDecayValue\":\"%d\"}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(),TotalOcclusionState,lightNumber,BlockingState,DecayValue , ack);
    char* temp = tempbuf;
    return temp;
}


/*
 * 函数功能：轿厢-轿门-轿门锁-轿门锁通断状态
 * method：
 * state：轿门锁通断状态    ture : 轿门锁状态：通      false : 轿门锁状态：断
 * Floor: 轿厢所在楼层
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.carDoorLock.carDoorLockOnOffState/post
 */
char* HCCarDoorLockOnOffState(char* state, int Floor, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.carDoorLockStatisticalData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%ld\",\"value\":{\"carDoorLockOnOffState\":\"%s\",\"floor\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), state, Floor, ack);
    char* temp = tempbuf;
    return temp;
}


/***====================================================轿厢-轿门-门板====================================================*****/
/*
 * 函数功能：轿厢-轿门-门板-门板检测数据
 * method：
 * pullDoor：扒门识别   ture:识别结果：有扒门   false:识别结果：无扒门
 * kickDoor: 踹门识别   ture:识别结果：有踹门   false:识别结果：无踹门
 * clip： 夹人夹物      ture:正常               false:异常：夹人/夹物
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorPanel.doorDetectionData/post
 */
char* HCDoorDetectionData(char* pullDoor,char* kickDoor,char* clip ,int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorBallDataSet.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%ld\",\"value\":{\"pullDoorDetect\":\"%s\",\"kickDoorDetect\":\"%s\",\"clipPeopleClipThing\":\"%s\"}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), pullDoor,kickDoor,clip, ack);
    char* temp = tempbuf;
    return temp;
}

/*
 * 函数功能：轿厢-轿门-门板-门板状态数据
 * method：
 * status：开关门状态      0：未知状态  1：开门过程  2：开门到位  3：关门过程  4：关门到位
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.doorPanel.doorPanelStatisticalData/post
 */
char* HCDoorPanelStatusData(int status, int ack)
{
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    strcat(method, "thing.event.doorPanelStatusData.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":\"%ld\",\"value\":{\"doorOpeningClosingStatus\":\"%d\"}}, \"sys\":{\"ack\":%d}",  HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), status, ack);
    char* temp = tempbuf;
    return temp;
}














/***==============================================轿厢-轿门-异步门电机=====================================================****/
/*
 * 函数功能：轿厢-轿门-异步门电机-门电机检测数据
 * method：
 * HighA:关门最大电流高速段 double  0.1A
 * LowA:关门最大电流低速段  double  0.1A
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * MQTT.topic: /tsl/{thingCategoryKey}/{deviceName}/thing/event/elevator.123456789.car.carDoor.asynchronousDoorMotor.doorMotorDetectionData/post
 */
//char* HCAsyncDoorMotorDetectionData(double HighA, double LowA, int ack)
//{
//    char tempbuf[MAXCJSONLENG] = { 0 };
//    char method[512] = { 0 };
//    strcat(method, "thing.event.doorMotorDetectionData.post");
//    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":,\"params\":{\"time\":%d,\"value\":{\"closeDoorMaximumCurrentHighSpeedSection\":\"%lf\",\"closeDoorMaximumCurrentLowSpeedSection\":\"%lf\"}}, \"sys\":{\"ack\":%d}", HC_MQttIdGet(2294967295,4294967295), method, HC_LocalTimeGet(), HighA, LowA, ack);
//    char* temp = tempbuf;
//    return temp;
//}
/***==============================================机器人=====================================================****/
/*
 * 函数功能：电梯上报
 * method：
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * topic :thing.event.agvInformationEvent.post
 */
char *HCAGVInformationEvent( ST_AGVInformationEvent AGVInformationEvent,int ack)
{
    char runingStatus[5]={0};
    char upStopFloorValue[MAXCJSONLENG] = { 0 };
    char downStopFloorValue[MAXCJSONLENG] = { 0 };
    char identifier[512] = { 0 };
    if(AGVInformationEvent.runingStatus==true)
    {
        strcat(runingStatus,"true");
    }
    else {
        strcat(runingStatus,"false");
    }
    char overhaulStatus[5]={0};
    if(AGVInformationEvent.overhaulStatus==true)
    {
        strcat(overhaulStatus,"true");
    }
    else {
        strcat(overhaulStatus,"false");
    }
    char carOverloadSignal[5]={0};
    if(AGVInformationEvent.carOverloadSignal==true)
    {
        strcat(carOverloadSignal,"true");
    }
    else {
        strcat(carOverloadSignal,"false");
    }
    char carFullLoadSignal[5]={0};
    if(AGVInformationEvent.carFullLoadSignal==true)
    {
        strcat(carFullLoadSignal,"true");
    }
    else {
        strcat(carFullLoadSignal,"false");
    }
    char runningDirection[5]={0};
    if(AGVInformationEvent.runningDirection==true)
    {
        strcat(runningDirection,"true");
    }
    else {
        strcat(runningDirection,"false");
    }
    char serialCommunicationStatus[5]={0};
    if(AGVInformationEvent.serialCommunicationStatus==true)
    {
        strcat(serialCommunicationStatus,"true");
    }
    else {
        strcat(serialCommunicationStatus,"false");
    }
    char tempbuf[MAXCJSONLENG] = { 0 };
    char method[512] = { 0 };
    for (int i = 0; i < 48; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        if(AGVInformationEvent.UpStopFloor[i].upStopFloor!=0)
        {
            sprintf(identifier, "{\"floor\":%d}", AGVInformationEvent.UpStopFloor[i].upStopFloor);
            strcat(upStopFloorValue, identifier);
            //HC_PRINT("upStopFloor=%s",identifier);
        }

        if(i < AGVInformationEvent.upStopThick-1)
            strcat(upStopFloorValue, ",");

    }

    for (int i= 0; i < 48; i++) {
        memset(identifier, 0x0, sizeof(identifier));
        if(AGVInformationEvent.DownStopFloor[i].downStopFloor!=0)
        {
            sprintf(identifier, "{\"floor\":%d}", AGVInformationEvent.DownStopFloor[i].downStopFloor);
            strcat(downStopFloorValue, identifier);
            // HC_PRINT("downStopFloor=%s",identifier);
        }

        if(i < AGVInformationEvent.downStopThick-1)
            strcat(downStopFloorValue, ",");

    }
    strcat(method, "thing.event.agvInformationEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":{\"runingStatus\":%s,\"overhaulStatus\":%s,\"carOverloadSignal\":%s,\"carFullLoadSignal\":%s,\"runningDirection\":%s,\"carDoorOpeningClosingStatus\":%d,\"person\":%d,\"serialCommunicationStatus\":%s,\"callElevatorUpStopFloorRegistration\":[%s],\"callElevatorDownStopFloorRegistration\":[%s],\"downStatus\":%d,\"floor\":%d}}, \"sys\":{\"ack\":%d}}",\
            HC_MQttIdGet(2294967295,4294967295), method, (long)(HC_LocalTimeGet()*1000), runingStatus, overhaulStatus,carOverloadSignal,carFullLoadSignal,runningDirection,AGVInformationEvent.carDoorOpeningClosingStatus,AGVInformationEvent.person,serialCommunicationStatus,upStopFloorValue,downStopFloorValue,AGVInformationEvent.downStatus,AGVInformationEvent.floor, ack);
    char* temp = tempbuf;
    return temp;
}


/*
 * 函数功能：方法回复
 * method：
 * methodReply :ture 成功，失败
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 */
char *HCmethodReply(long id, bool methodReply)
{
    char message[10]={0};
    char tempbuf[512] = { 0 };
    char methodReplybuf[5]={0};
    if(methodReply==true)
    {
        strcat(methodReplybuf,"true");
        strcat(message,"success");
    }
    else {
        strcat(methodReplybuf,"false");
        strcat(message,"failed");
    }

    sprintf(tempbuf, "{\"id\":%ld,\"code\":\"200\",\"data\":{\"methodReply\":%s}, \"message\":\"%s\"}", id, methodReplybuf, message);
    char* temp = tempbuf;
    return temp;
}


/*
 * 函数功能：显示楼层和物理楼层的对照表事件
 * method：
 * ack :是否需要返回响应数据，取值：1-返回；0-不返回，默认值为1
 * topic :thing.event.comparisonTableOfFloorAndPhysicalFloorEvent.post
 */
char *HCComparisonTableOfFloorAndPhysicalFloorEvent( ST_ComparisonTable ComparisonTable,int ack)
{
    char method[512] = { 0 };
    char tempbuf[MAXCJSONLENG] = { 0 };
    char databuf[MAXCJSONLENG] = { 0 };
    char buf[256]={0};
    for (int i=0;i<ComparisonTable.floorThick;i++) {
        memset(buf,0x0,sizeof (buf));
        sprintf(buf,"{\"realFloor\":%d,\"displayFloor\":\"%s\"}",ComparisonTable.FloorNum[i].physicalFloor,ComparisonTable.FloorNum[i].showFloor);
        strcat(databuf,buf);
        if(i<ComparisonTable.floorThick-1)
        {
            strcat(databuf,",");
        }
    }
    strcat(method, "thing.event.comparisonTableOfRealFloorAndDisplayFloorEvent.post");
    sprintf(tempbuf, "{\"id\":\"%u\",\"method\":\"%s\",\"params\":{\"time\":%ld,\"value\":[%s]}, \"sys\":{\"ack\":%d}}",  HC_MQttIdGet(2294967295,4294967295), method, (long)(HC_LocalTimeGet()*1000), databuf,ack);
    char* temp = tempbuf;
    return temp;
}
