﻿#include "application/HCVirtualdeviceJsonAnalysis.h"



int HC_VirtualdevicInit()
{
    HC_PRINT("1`W1WW");
    return ERR_COMMON_SUCCESS;
}
int HC_VirtualdevicGetInit(char *analysis)
{
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(analysis);
    cJSON* test_arrout=NULL;
    //判断是否打包成功
    if(cjson == NULL){

        return ERR_COMMON_FAILED;
    }

    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"payload");
    cJSON* test_arr1 = cJSON_GetObjectItem(test_arr,"state");
    cJSON* test_arr2 = cJSON_GetObjectItem(test_arr1,"desired");
    cJSON* test_arr3 = cJSON_GetObjectItem(test_arr2,"elevator");

    for (int i=0;i<3;i++) {
         if(strlen(idbuf[i])!=0)
         {
             test_arrout=cJSON_GetObjectItem(test_arr3,idbuf[i]);
             if(test_arrout!=NULL)
             {
                 HC_PRINT("mum=%d",i);
             }
         }

    }

    return ERR_COMMON_SUCCESS;
}
