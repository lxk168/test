﻿
#ifndef HCVIRTUALDEVICEJSONANALYSIS_H
#define HCVIRTUALDEVICEJSONANALYSIS_H
#include "common.h"
#include"public/HCJson.h"



extern char Virtualdevicelabel[100][256];
extern int HC_VirtualdevicInit(void);
extern int HC_VirtualdevicGetInit(char *analysis);
#endif



