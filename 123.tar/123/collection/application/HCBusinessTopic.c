﻿#include"application/HCBusinessTopic.h"
#include"public/HCProfileUtil.h"
#include"public/HCFileOperation.h"

ST_Topic_AllInfor Topic_AllInfor;
char *HCBusinessTopicBulid(char *method)
{
    char Topicbuf[2048]={0};
    char* file_path = (char*)"/usr/local/jiqiren/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";

    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);

    sprintf(Topicbuf,"/tsl/%s/%s/%s",ThingCategoryKeybuf,DeviceName,method);

    char *temp=Topicbuf;
    return temp;
}
void HCSubTopicInit(void)
{

    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* topic_path = (char*)"/userdata/usr/local/subtopic.conf";
    char* app_name = (char*)"mqtt_userdata";
    char* topic_name = (char*)"mqtt_subtopic";
    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    int ReadFd=0,WriteFd=0;
    char valuebuf[10]={0};
    int num=2;//0 和1是ota 的
    ReadFd = open(topic_path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, topic_path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);

        }
    }
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    write_profile_string(topic_name,valuebuf,"",topic_path);
    memset(&Topic_AllInfor,0x0,sizeof (ST_Topic_AllInfor));
    for (int i=0;i<3;i++) {
        sprintf(Topic_AllInfor.HCDevice_Pub,"/shadow/update/%s/%s",ThingCategoryKeybuf,DeviceName);
        //机器人发布
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Pub_Topic.HCagvInformationEventTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.agvInformationEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Pub_Topic.HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub,"/tls/%s/%s/thing/event/elevator.%s.comparisonTableOfFloorAndPhysicalFloorEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Pub_Topic.HCfrontDoorOpenKeepCommandTopic_Pub,"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Pub_Topic.HCouterCallLiftTopic_Pub,"/tls/%s/%s/thing/method/elevator.%s.outerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Pub_Topic.HCinnerCallLiftTopic_Pub,"/tls/%s/%s/thing/method/elevator.%s.innerCallLift_reply",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Pub_Topic.HCfrontDoorCloseCommand_Pub,"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand_reply",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //电梯信息发布
        /***======================================门机======================================================================门机===============================================================================门机=====================================***/
        //轿门个数
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCcarDoorNumberEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.carDoorNumberEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //门球对中
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCdoorBallDataSet_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.doorBall.front.doorBallDataSet/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //前门皮带打滑
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbeltDetectionData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.strap.front.beltDetectionData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //前门摩擦力
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCcarSillDetectionData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.carSill.front.carSillDetectionData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //前门锁钩故障
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HClockHookData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.lockHook.front.lockHookData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //前门弹簧自闭力
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HChallDoorStatistics_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.hall.hallDoorList.front.hallDoorStatistics/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //前门重锤检测
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HChallDoorInspectionData_Pub,"/tls/%s/%s/thing/event/elevator.%s.hall.hallDoorList.front.hallDoorInspectionData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]); 
        //前门门故障次数
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCerrorCodeEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinetList.front.NICE3000newIntegratedController.errorCodeEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //前门轿门开关次数
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCcarDoorLockStatisticalData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.carDoorLock.front.carDoorLockStatisticalData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //异常反复开关门次数
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCdoorPanelStatisticalData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.doorPanel.front.doorPanelStatisticalData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //门锁短接
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCcarDoorLockOnOffState_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.carDoorLock.front.carDoorLockOnOffState/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //正常Max电流 - 同步门电机
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCsyn_doorMotorDetectionData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.synchronousDoorMotor.front.doorMotorDetectionData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //正常Max电流 - 异步门电机
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCasy_doorMotorDetectionData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.asynchronousDoorMotor.front.doorMotorDetectionData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        /***======================================光幕====================================================================光幕=========================================================================光幕============================***/
        //光幕
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCspecialFunction_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.carDoor.lightCurtain.front.specialFunction/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        /***=====================================曳引机====================================================================曳引机=====================================================================曳引机=============================================================================曳引机=========================***/
        //永磁体-电流
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCsyn_permanentMagnets_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.permanentMagnets.permanentMagnetDataSet/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //制动器热检测传感器-抱闸动作次数
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbrakeThermalDetectionSensorStatistics_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.brakeHeatDetectionSensor.brakeThermalDetectionSensorStatistics/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //刹车片磨损传感器-打滑量
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbrakeClosingAfterSlip_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.brakePadWearSensor.brakePadWearSensorData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //曳引机-电机额定转速，额定电流
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCmotorRatedInfo_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.motorRatedInfo/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //抱闸制动器-故障
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbrakeFaultEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.holdingBrakeContactor.brakeFaultEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //抱闸制动器-卡阻(抱闸1)
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbrakeONOFFtimeEvent_Pub1,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.holdingBrakeContactor.holdingBrakeContactor1.brakeONOFFtimeEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //抱闸制动器-卡阻(抱闸2)
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbrakeONOFFtimeEvent_Pub2,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.synchronousTractionMachine.holdingBrakeContactor.holdingBrakeContactor2.brakeONOFFtimeEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);

        //井道钢丝绳-抱闸力检测位移量，抱闸力检测打滑量（脉冲）
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbrakeForceDetectionSteelRopesSlip_Pub,"/tls/%s/%s/thing/event/elevator.%s.shaft.steelRopes.brakeForceDetectionSteelRopesSlip/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);

        //轿厢-额定运行速度
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCrunData_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.runData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //轿厢-运行里程
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCelevatorMileage_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.elevatorMileage/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //轿厢-当前高度
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCelevatorCurrentPositionInfo_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.elevatorCurrentPositionInfo/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //控制柜列表-电梯运行时间运行次数
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCcontrolCabinetStatistics_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinetList.controlCabinetStatistics/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        /***=======================================控制系统质量====================================================控制系统质量=======================================================================控制系统质量==================================================控制系统质量=================***/
        //前门-外呼板（上召-下召）
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCfrontDoorHallUpAndDownCallButtonActionsNumber_Pub,"/tls/%s/%s/thing/event/elevator.%s.hall.hallCallBoard.buttonOfHallCallBoard.frontDoorHallUpAndDownCallButtonActionsNumber/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //后门-外呼板（上召-下召）
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbackDoorHallUpAndDownCallButtonActionsNumber_Pub,"/tls/%s/%s/thing/event/elevator.%s.hall.hallCallBoard.buttonOfHallCallBoard.backDoorHallUpAndDownCallButtonActionsNumber/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //按钮-主操纵盘按钮
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCmainControlPanelButtonStatisticsEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.carCallBoard.buttonOfCarCallBoard.mainControlPanelButtonStatisticsEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //按钮-辅助操纵盘按钮
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCauxiliaryControlPanelButtonStatisticsEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.carCallBoard.buttonOfCarCallBoard.auxiliaryControlPanelButtonStatisticsEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //按钮-残疾人操纵盘按钮
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HChandicappedControlPanelButtonStatisticsEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.car.insideCar.carCallBoard.buttonOfCarCallBoard.handicappedControlPanelButtonStatisticsEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //接口板-统计数据(电容/能耗/发电量)
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCinterfaceBoardStatistics_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.interfaceBoard.interfaceBoardStatistics/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //接口板-接口板温度数据(IGBT温度和风扇温度)
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCinterfaceBoardTemperatureData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.interfaceBoard.interfaceBoardTemperatrueData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //控制柜-温度数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCcontrolCabinetTemperatureData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.controlCabinetTemperatureData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //左接触器-整合事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCLeftintegratedEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.contactorList.leftcontactor.integratedEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //右接触器-整合事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCRightintegratedEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.contactorList.rightcontactor.integratedEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //运行接触器-整合事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCRuntintegratedEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.contactorList.runcontactor.integratedEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //FX接触器-整合事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCFXintegratedEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.contactorList.fxcontactor.integratedEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //CAN1通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCCAN1communicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.CAN1communicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //SPI1通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCSPI1communicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.SPI1communicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //SPI2通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCSPI2communicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.SPI2communicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //MOD1通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCMOD1communicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.MOD1communicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //MOD2通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCMOD2communicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.MOD2communicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //485-1通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HC4851communicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.4851communicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //485-2通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HC485TwoCommunicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.485TwoCommunicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //串口通讯数据
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCserialCommunicationData_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.communicationInterface.serialCommunicationData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);

        /***====================================安全回路==============================================================安全回路===================================================================安全回路=============***/
        //安全回路-电压检测事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCSafetyloop_Pub,"/tls/%s/%s/thing/event/elevator.%s.safetyCircuit.safetyCircuitVoltageDetectionData/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);



        //控制柜-NICE3000-故障代码
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCErrorCodeEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.machineRoomEquipment.controlCabinet.NICE3000newIntegratedController.errorCodeEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);


        /***==================================直梯-实时数据=====================================*****/
        //直梯-电梯管理-电梯展示事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCelevatorManagementElevatorDisplayEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.elevatorManagementElevatorDisplayEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //直梯-电梯管理-基本信息事件
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCelevatorManagementBasicInformationEvent_Pub,"/tls/%s/%s/thing/event/elevator.%s.elevatorManagementBasicInformationEvent/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //直梯-楼栋大屏
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCbuildingScreen_Pub,"/tls/%s/%s/thing/event/elevator.%s.buildingScreen/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //直梯-井道全息
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCHoistwayHolographic_Pub,"/tls/%s/%s/thing/event/elevator.%s.hoistwayHolographic/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        //直梯-电梯综合故障信息
        sprintf(Topic_AllInfor.motorRatedInfo_Collecttion_Topic[i].HCelevatorComprehensiveFaultInformation_Pub,"/tls/%s/%s/thing/event/elevator.%s.elevatorComprehensiveFaultInformation/post",ThingCategoryKeybuf,DeviceName,idbuf[i]);







        //订阅
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCfrontDoorOpenKeepCommandTopic_Sub,"/tls/%s/%s/thing/method/elevator.%s.frontDoorOpenKeepCommand",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        memset(valuebuf,0x0,sizeof (valuebuf));
        sprintf(valuebuf,"%dtopic",num);
        write_profile_string(topic_name,valuebuf,Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCfrontDoorOpenKeepCommandTopic_Sub,topic_path);
        num++;
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCouterCallLiftTopic_Sub,"/tls/%s/%s/thing/method/elevator.%s.outerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        memset(valuebuf,0x0,sizeof (valuebuf));
        sprintf(valuebuf,"%dtopic",num);
        write_profile_string(topic_name,valuebuf,Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCouterCallLiftTopic_Sub,topic_path);
        num++;
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCinnerCallLiftTopic_Sub,"/tls/%s/%s/thing/method/elevator.%s.innerCallLift",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        memset(valuebuf,0x0,sizeof (valuebuf));
        sprintf(valuebuf,"%dtopic",num);
        write_profile_string(topic_name,valuebuf,Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCinnerCallLiftTopic_Sub,topic_path);
        num++;
        sprintf(Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCfrontDoorCloseCommand_Sub,"/tls/%s/%s/thing/method/elevator.%s.frontDoorCloseCommand",ThingCategoryKeybuf,DeviceName,idbuf[i]);
        memset(valuebuf,0x0,sizeof (valuebuf));
        sprintf(valuebuf,"%dtopic",num);
        write_profile_string(topic_name,valuebuf,Topic_AllInfor.Topic_InforMation[i].Robot_Sub_Topic.HCfrontDoorCloseCommand_Sub,topic_path);
        num++;

    }

    close(ReadFd);
    close(WriteFd);
    return ;
}
