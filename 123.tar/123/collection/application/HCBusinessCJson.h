﻿
#ifndef HCBUSINESSCJSON_H
#define HCBUSINESSCJSON_H
#include "common.h"

#include "public/HCPublicStruct.h"
#include "public/HCPulicAPI.h"
#define MaxFloorNum   (112)   //最大楼层数
#define MaxButtonNum   (112)   //最大按钮数
#define MaxLightNum   (48)   //最大光管数
#pragma pack (1)
typedef struct
{
    int thick; //动作次数
}ST_FloorNum;
typedef struct
{
    int allNum; //总的有效按钮
    ST_FloorNum FloorNum[MaxButtonNum];//按钮号
}ST_ButtonEvent;

typedef struct
{
    bool upCall;//上召指令 ture:有上召指令  false:无上召指令
    bool downCall;//下召指令 ture:有下召指令  false:无下召指令
}ST_FloorCall;
typedef struct
{
    int allNum; //总的有效楼层
    ST_FloorCall FloorNum[MaxFloorNum];//楼层号
}ST_CallEvent;
enum ST_CarDoorStation
{
    ONE=0, TWO, THREE, FOUR, FIVE, SIX, SEVEN,EIGHT,NINE
};
typedef struct
{
    int upStopFloor;//呼梯上行停靠楼层

}ST_UpStopFloor;
typedef struct
{
    int downStopFloor;//呼梯下行停靠楼层

}ST_DownStopFloor;
//机器人采集
typedef struct
{
    bool  runingStatus; //运行状态  ture:正常  false:故障
    bool  overhaulStatus; //检修状态  ture:正常  false:检修
    bool  carOverloadSignal; //轿厢超载信号  ture:超载信号有效  false:超载信号无效
    bool  carFullLoadSignal; //轿厢满载信号  ture:满载信号有效  false:满载信号无效
    bool  runningDirection; //运行方向  ture:上行  false:下行
    bool  serialCommunicationStatus; //串口通讯状态
    int person;//轿厢人数
    int floor;//轿厢当前楼层
    enum ST_CarDoorStation downStatus; //停机状态
    enum ST_CarDoorStation carDoorOpeningClosingStatus; //轿门开关门状态  0:未知状态 1:开门过程 2:开门到位 3:关门过程 4:关门到位
    int upStopThick; //呼梯上行停靠楼层总数
    int downStopThick; //呼梯下行停靠楼层总数
    ST_UpStopFloor UpStopFloor[MaxFloorNum];//最大楼层数112
    ST_DownStopFloor DownStopFloor[MaxFloorNum];//最大楼层数112
}ST_AGVInformationEvent;
// 电梯采集
typedef struct
{
    int carDoorNumber;

}ST_Elevatoracquisition;




//光幕
typedef struct
{
    int lightState; //光管遮挡状态
}ST_LightNum;
typedef struct
{
    int allNum; //总的有效光管数
    ST_LightNum LightNum[MaxLightNum];//光管号
}ST_LightStateEvent;
typedef struct
{
    int TotalOcclusionState;//光管总遮挡状态   0:无遮挡   1:遮挡
    int lightNumber;//光管对数
    int DecayValue;//光管强度值
    int lightPipeFault;//光管故障
    int lightCurtainSpace;//光幕距离 0：近距离  1：远距离
    ST_LightStateEvent LightStateEvent;//1-48光管遮挡状态
}ST_LightSpecialFunction;
//显示楼层和物理楼层的对照表事件
typedef struct
{
    int physicalFloor;//物理楼层
    char showFloor[10]; //显示楼层
}ST_FloorInfo;
typedef struct
{
    int floorThick; //记录的楼层数
    ST_FloorInfo FloorNum[MaxFloorNum];
}ST_ComparisonTable;

//轿内视觉
typedef struct
{
    char bucket[512];
    char path[512];
}ST_BasePropertys;
typedef struct
{
    ST_BasePropertys video;
    ST_BasePropertys image;
}ST_VisionData;
//按钮（轿内指令版）
typedef struct {
    int actionsTimes;//按钮动作次数
}ST_ButtonActionsTimesArray;
typedef struct {
    int doorOpenButtonActionsTimes;//开门钮动作次数
    int doorCloseButtonActionsTimes;//关门按钮动作次数
    int num;//有效按钮数
    ST_ButtonActionsTimesArray ButtonActionsTimesArray[MaxButtonNum];
}ST_ControlPanelButtonStatisticsEvent;
//厅外
typedef struct{
    int upCallActionTimes;
    int downCallActionTimes;
}ST_upAndDownCallButtonActionsTimesArray;//上下召按钮动作次数
typedef struct{
    int num;//有效按钮数
    ST_upAndDownCallButtonActionsTimesArray ButtonActionsTimesArray[MaxButtonNum];
}ST_upAndDownCallButton;//上下召按钮动作次数
//接口板
typedef struct
{
    int busbarRatedCapacitanceCapacity;//母线额定电容容量
    int capacitanceCapacity;//电容容量
    double energyConsumptionData;//能耗数据
    double powerGeneration;//发电量
}ST_InterfaceBoardStatistics;
typedef struct
{
    int igbTtemperatrue;//IGBT温度
    int igbTNtctemperatrue;//IGBT的NTC温度
    int inverterSideDiodeJunctionTemperatrue;//逆变侧二极管结温
    int rectifierSideDiodeJunctionTemperature;//整流侧二极管结温
}ST_InterfaceBoardTemperatrueData;
//控制柜-接触器
typedef struct
{
    int MainPoleTemp;//接触器主极点温度
    int RatedTemp;   //接触器触点额定温度
    int actionTimes; //动作次数
    int closeTimes1; //尝试闭合次数
    int minTime1;    //辅触点吸合最小时间间隔
    int minTime2;    //吸合指令最小时间间隔
    int closeTimes2; //闭合次数
    int disConnectTimes; //断开次数
    int closeDelayTime;  //吸合延时
    int openDelayTime;   //断开延时
}ST_ContactorIntegratedEvent;
//CAN1节点在线状态
typedef struct{
    int onlineStatus;//在线状态
    int CAN1frameLossRate;   //CAN1丢帧率
}ST_CAN1communicationOnlineStatus;
//控制柜-Nice3000-通讯接口-CAN1
typedef struct{
    int CAN1communicationBusInterference;   //CAN1通信总线干扰
    int CAN1PCBcommunicationModuleSelfCheck;  //CAN1单板通讯模块自检
    ST_CAN1communicationOnlineStatus  CAN1communicationOnlineStatus[32];
}ST_CAN1communicationData;
//MOD1通信在线状态
typedef struct{
    int onlineStatus;// 在线状态
    int MOD1frameLossRFate;    //MOD1丟帧率
}ST_MOD1communicationOnlineStatus;
//MOD1通讯数据
typedef struct{
    int MOD1communicationBusInterference;   //MOD1通信总线干扰
    ST_MOD1communicationOnlineStatus MOD1communicationOnlineStatus[112];  //MOD1通信在线状态
}ST_MOD1communicationData;
//直梯-电梯管理-电梯展示
typedef struct
{
    int elevatorOnlineStatus;//电梯在线状态  true:电梯在线  false:电梯离线
    int elevatorUpAndDownStatus;//电梯上行、下行状态  1：上行  2：下行  3：停止
    int elevatorRunningStatus;//电梯运行状态 0:正常  1：停梯  3：检修
    int elevatorFloor;//电梯所在楼层
    int elevatorDoorOpeningAndClosingStatus;//开关门状态 0：未知状态  1：开门过程  2：开门到位  3：关门过程  4：关门到位
    int communicationSignal;//通讯信号   0:2G   1:3G   2:4G
    int signalIntensity;//信号强度
    char errorCode[30];//故障代码  string
}ST_ElevatorManagementElevatorDisplayEvent;
//直梯-电梯管理-电梯基本信息
typedef struct{
    int floorNum;
}ST_callUpFloor;
typedef struct{
    int floorNum;
}ST_callDownFloor;
typedef struct{
    int floorNum;
}ST_internalCallFloor;
typedef struct{
    bool elevatorLevelingStatus;//平层状态 true:平层  false:非平层
    bool sleepyPersonDetection;//困人检测  true:有困人 false:无困人
    bool controllerEncryptionStatus;//控制器有无加密  true:有加密  false:无加密
    bool controllerOnlineStatus;//控制器在线状态  true:在线  false:离线
    bool intelligentHardwareOnlineStatus;//智能硬件在线状态  true:在线  false:离线
    int serviceModel;//服务模式
    int runningSpeed;//运行速度
    int elevatorLoadingStatus;//电梯负载状态   0：正常  1：满员  2：超载
    int num;//有效按钮数
    ST_callUpFloor callUpFloor[MaxFloorNum];//上召楼层
    ST_callDownFloor callDownFloor[MaxFloorNum];//下召楼层
    ST_internalCallFloor internalCallFloor[MaxFloorNum];//内召楼层
}ST_ElevatorManagementBasicInformationEvent;
//楼栋大屏
typedef struct{
    int elevatorFloor;//电梯所在楼层
    int elevatorStatus;//电梯状态 0：正常   1：检修   2：故障
    int runningDirection;//运行方向  1：上行  2：下行  3：停止
    bool onlineStatus;//在线状态  true:在线  false:离线
    char errorCode[30];//故障代码
}ST_BuildingScreen;
//井道全息
typedef struct{
    int elevatorFloor;//电梯所在楼层
    int elevatorStatus;//电梯状态 0:正常  1：停梯  2：检修
    bool onlineStatus;//在线状态  true:在线  false:离线
    int recordStatus;//录制状态  int   null
}ST_HoistwayHolographic;
//电梯综合故障信息
typedef struct{
    int eventMessageSequenceNumber;//事件消息序列号
    char subDeviceAddressCode[128];//子设备地址码
    int eventCode;//事件编码
    int eventStatus;//事件状态
    char eventData;//事件数据
    char eventSubcode;//事件子码
    char realTimeData;//实时数据
    int eventGenerationTime;//事件产生时间
    int eventCancellationTime;//事件解除时间
    int whetherToLift;//是否解除
    char alarmDescription;//告警描述
    bool whetherToTrapped;//是否困人
    bool whetherToOverhaul;//是否检修
    int elevatorFloor;//电梯所在楼层
}ST_elevatorComprehensiveFaultInformation;




#pragma pack ()

extern char* HCDoorPanelStatisticalData(int time,int times,int abnormalTimes,int Floor, int ack);
extern char* HCCarDoorLockStatisticalData(int openTimes,int closTimes, int floor,int ack);
extern char* HCHallDoorInspectionData(int result,int floor, int ack);
extern char* HCHallDoorStatistics(int doorLockUpTime,int perc,int floor ,int ack);
extern char* HCDoorMachinePreMaintenanceStatus(int status, int ack);
extern char* HCDoorLockShortCircuitFaultDetection(char* status, int floor,int ack);
extern char* HCSpecialFunction(int TotalOcclusionState, int lightNumber, int BlockingState , int DecayValue, int ack);
extern char* HCSlidingRailFrictionDetectionData(char* doorFriction, int Floor, int ack);
extern char* HCCarDoorLockStatisticalData(int openTimes,int closTimes, int floor,int ack);
extern char* HCCarDoorLockOnOffState(char* state, int Floor, int ack);

extern char* HCCarSillDetectionData(int doorFriction, int Floor, int ack);
extern char* HCDoorBallDataSet(int result, int Floor, int ack);
extern char *HCcarDoorNumberEvent(int carDoorNumber,int ack);
extern char* HCDoorDetectionData(char* pullDoor,char* kickDoor,char* clip ,int ack);
extern char* HCDoorPanelStatisticalData(int time,int times,int abnormalTimes,int Floor, int ack);
extern char* HCDoorPanelStatusData(int status, int ack);
extern char* HCBeltDetectionData(int status, int ack);
extern char* HCLockHookDataSet(int  pre_maintain_result, int Floor,int ack);
extern char* HCSyncDoorMotorDetectionData(int current ,int floor, int ack);
extern char* HCAsyncDoorMotorDetectionData(int current ,int floor, int ack);
extern char *HCAGVInformationEvent( ST_AGVInformationEvent AGVInformationEvent,int ack);
extern char *HCinnerCallLift(long id, bool methodReply);
extern char *HCfrontDoorOpenKeepCommand( long id,bool methodReply);
extern char *HCbackDoorOpenKeepCommand( bool methodReply,int ack);
extern char *HCouterCallLift(long id, bool methodReply);
extern char *HCComparisonTableOfFloorAndPhysicalFloorEvent( ST_ComparisonTable ComparisonTable,int ack);
extern char *HCmethodReply(long id, bool methodReply);
extern char* HCLightPipe1to48BlockingState(ST_LightSpecialFunction LightSpecialFunction, int ack);
extern char* HCErrorCodeEvent(int errorCode, int ack);
extern char* HCBrakeThermalDetectionSensorStatistics(int times, int ack);
extern char* HCVisionElectricVehicle(ST_VisionData  visionElectricVehicle, int ack);
extern char* HCVisionPryingDoor(ST_VisionData  visionPryingDoor, int ack);
extern char* HCVisionSmoke(ST_VisionData  visionSmoke, int ack);
extern char* HCVisionTrapped(ST_VisionData  visionTrapped, int ack);
extern char* HCVisionFall(ST_VisionData  visionFall, int ack);
extern char* HCVisionPerson(int visionPerson, int ack);
extern char* HCPermanentMagnetDataSet(double  highA, double lowA, int ack);
extern char* HCBrakePadWearSensorData(int slip, int ack);
extern char* HCrunData(char* runStatebuf,char* runDirectionbuf,int  ratedRunSpeed, int ack);
extern char* HCMotorRatedInfo(int raredSpeed, double ratedCurrent,int ack);
extern char* HCBrakeForceDetectionSteelRopesSlip(int theDetectionDisplacementOfThisBrakeForce, int thisBrakeForceEarlyWarningDetectionDisplacementAmount, int theBrakeForceDetectsTheAmountOfSlip, int ack);
extern char* HCElevatorMileage(int mileage, int ack);
extern char* HCElevatorCurrentPositionInfo(int floor,int elevatorCurrentHeight,  int ack);
extern char* HCBrakeFaultEvent(int breakFault, int ack);
extern char* HCBrakeOnOfftimeEvent(int openTime, int closeTime, int ack);
extern char* HCControlCabinetStatistics(int times, int time, int ack);

//控制系统质量
extern char* HCfrontDoorHallUpAndDownCallButtonActionsNumber(ST_upAndDownCallButton upAndDownCallButton, int ack);
extern char* HCbackDoorHallUpAndDownCallButtonActionsNumber(ST_upAndDownCallButton upAndDownCallButton, int ack);

extern char* HCMainControlPanelButtonStatisticsEvent(ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent, int ack);
extern char* HCAuxiliaryControlPanelButtonStatisticsEvent(ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent, int ack);
extern char* HCHandicappedControlPanelButtonStatisticsEvent(ST_ControlPanelButtonStatisticsEvent ButtonStatisticsEvent, int ack);
extern char* HCInterfaceBoardStatistics(ST_InterfaceBoardStatistics InterfaceBoardStatistics, int ack);
extern char* HCInterfaceBoardTemperatrueData(ST_InterfaceBoardTemperatrueData InterfaceBoardTemperatrueData, int ack);
extern char* HCControlCabinetTemperatrueData( int Temp, int ack);
extern char* HCContactorIntegratedEvent(ST_ContactorIntegratedEvent IntegratedEvent,int ack);
extern char* HCSafetyloop(int safeCirHeadVol,int conCoilSteStaVol,int conCoilPullInTransVol, int ack);
extern char* HCCAN1communicationData(ST_CAN1communicationData communicationData,int ack);
extern char* HCSPI1communicationData(int SPI1communicationBusInterference,int SPI1communicationOnlineStatus,int SPI1frameLossRate, int ack);
extern char* HCSPI2communicationData(int SPI2communicationBusInterference,int SPI2communicationOnlineStatus,int SPI2frameLossRate, int ack);
extern char* HCMOD1communicationData(ST_MOD1communicationData MOD1communicationData, int ack);
extern char* HCMOD2communicationData(int MOD2communication,int ack);
extern char* HC4851communicationData(int communicationBusInterference ,int communicationOnlineStatus,int frameLossRate,int ack);
extern char* HC485TwoCommunicationData(int communicationBusInterference,int communicationOnlineStatus,int frameLossRate,int ack);
extern char* HCserialCOmmunicationData(int serialCommunicationStatus,int ack);



//直梯下时实数据
extern char* HCElevatorManagementElevatorDisplayEvent(ST_ElevatorManagementElevatorDisplayEvent  displayEvent, int ack);
extern char* HCElevatorManagementBasicInformationEvent(ST_ElevatorManagementBasicInformationEvent  elevatorManagementBasicInformationEvent, ST_ElevatorManagementElevatorDisplayEvent  displayEvent,int ack);
extern char* HCBuildingScreen(ST_BuildingScreen  buildingScreen, int ack);
extern char* HCHoistwayHolographic(ST_HoistwayHolographic  hoistwayHolographic, int ack);
extern char* HCelevatorComprehensiveFaultInformation(ST_elevatorComprehensiveFaultInformation  faultInfo, int ack);


//虚拟文档-轿厢-轿内
extern char* HCinsideCar(ST_VirtualDevice  insideCar);
//虚拟文档-轿厢-轿门
extern char* HCCarDoor(ST_VirtualDevice  carDoor);
//虚拟设备文档-机房-控制柜
extern char* HCControlCabinet(ST_VirtualDevice  controlCabinet);
//虚拟设备文档-机房-曳引机
extern char* HCSynchronousTractionMachine(ST_VirtualDevice  synchronousTractionMachine);
//虚拟设备文档-安全回路
extern char* HCSafetyCircuit(ST_VirtualDevice  safetyCircuit);
//虚拟设备文档-井道
extern char* HCShaft(ST_VirtualDevice  shaft);
//虚拟设备文档-直梯
extern char* HCElevator(ST_VirtualDevice  elevator);

//10进制转2进制
extern int  Bit(int N);
//取出数的第i位
extern int BitGet(int N,int i);

#endif



