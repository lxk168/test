﻿
#ifndef HCVIRTUALDEVICEJSONBUILD_H
#define HCVIRTUALDEVICEJSONBUILD_H
#include "common.h"
#include"public/HCJson.h"

extern int VirtualdeviceJsonBuild(void);
extern cJSON *elevatorJsonBuild(int id);
extern cJSON *TractionMachineJsonBuild(int id);
#endif



