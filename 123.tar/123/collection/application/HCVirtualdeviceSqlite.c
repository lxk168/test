#include"application/HCVirtualdeviceSqlite.h"
#include"public/HCFileOperation.h"
#include "public/HCPulicAPI.h"
sqlite3 *db;
ST_VirtualDeviceALL VirtualDeviceALL;
char sn[3][100]={
    "dianti123456",
    "dianti654321",
    "dianti987654"
};

int elevatorNum=0;
//基本信息
int HCVirtualDeviceCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    VirtualDeviceALL.time=atol(columnValue[1]);
    VirtualDeviceALL.version=(unsigned int)atoi(columnValue[2]);
    strcpy(VirtualDeviceALL.shiqu,columnValue[3]);

    return ERR_COMMON_SUCCESS;
}
//电梯综合故障信息
int HCelevatorIDAndSNCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].time=atol(columnValue[3]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//电梯综合故障信息
int HCelevatorComprehensiveFaultInformationEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorComprehensiveFaultInformationEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//机器人事件信息
int HCagvInformationEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].agvInformationEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].agvInformationEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].agvInformationEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].agvInformationEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//控制柜统计数据事件配置
int HCControlCabinetStatisticsEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetStatisticsEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetStatisticsEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetStatisticsEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//控制柜固有数据事件配置
int HCControlCabinetInherentDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetInherentDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetInherentDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetInherentDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetInherentDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//控制柜温度数据事件配置
int HCControlCabinetTemperatrueDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetTemperatrueDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetTemperatrueDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetTemperatrueDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controlCabinetTemperatrueDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//左接触器列表

int HC_LeftContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[0].integratedConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[0].integratedConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[0].integratedConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[0].integratedConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//右接触器列表

int HC_RightContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[1].integratedConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[1].integratedConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[1].integratedConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[1].integratedConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//运行接触器列表

int HC_RunContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[2].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[2].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[2].integratedConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[2].integratedConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[2].integratedConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[2].integratedConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//封星接触器

int HC_FXContactorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[3].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[3].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[3].integratedConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[3].integratedConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[3].integratedConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].contactorList[3].integratedConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

//nice3000new一体机
//系统状态事件配置
int HCsystemStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].systemStatusEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].systemStatusEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].systemStatusEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].systemStatusEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//系统信号检测事件配置
int HCsystemSignalDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].systemSignalDetectionEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].systemSignalDetectionEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].systemSignalDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].systemSignalDetectionEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//控制器密码事件配置
int HCcontrollerPasswordEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controllerPasswordEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controllerPasswordEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].controllerPasswordEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].controllerPasswordEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//故障代码事件配置
int HCerrorCodeEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].errorCodeEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].errorCodeEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].errorCodeEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].errorCodeEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//端子状态事件配置
int HCterminalStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].terminalStatusEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].terminalStatusEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].terminalStatusEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].terminalStatusEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//AGV心跳事件配置
int HCAGVheartbeatEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].AGVheartbeatEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].AGVheartbeatEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].AGVheartbeatEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].AGVheartbeatEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//通讯接口
//CAN1通讯数据事件配置
int HCCAN1communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].CAN1communicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].CAN1communicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].CAN1communicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].CAN1communicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//SPI1通讯数据事件配置
int HCSPI1communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].SPI1communicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].SPI1communicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].SPI1communicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].SPI1communicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

//SPI2通讯数据事件配置
int HCSPI2communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].SPI2communicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].SPI2communicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].SPI2communicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].SPI2communicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//MOD1通讯数据事件配置
int HCMOD1communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].MOD1communicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].MOD1communicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].MOD1communicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].MOD1communicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//MOD2通讯数据事件配置
int HCMOD2communicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].MOD2communicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].MOD2communicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].MOD2communicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].MOD2communicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//485-1通讯数据事件配置
int HCm485FirstcommunicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].m485FirstcommunicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].m485FirstcommunicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].m485FirstcommunicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].m485FirstcommunicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//485-2通讯数据事件配置
int HCm485TwocommunicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].m485TwocommunicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].m485TwocommunicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].m485TwocommunicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].m485TwocommunicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//串口通讯数据事件配置
int HCserialPortcommunicationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].serialPortcommunicationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].serialPortcommunicationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].serialPortcommunicationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].serialPortcommunicationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//接口板
//接口板统计数据事件配置
int HCinterfaceBoardStatisticalDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardStatisticalDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardStatisticalDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardStatisticalDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardStatisticalDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//接口板温度数据事件配置
int HCinterfaceBoardTemperatrueDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardTemperatrueDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardTemperatrueDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardTemperatrueDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].interfaceBoardTemperatrueDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//新国标物联网模块/第三方
int HCelevatorRemoteLockSignalEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorRemoteLockSignalEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorRemoteLockSignalEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorRemoteLockSignalEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorRemoteLockSignalEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//电机额定信息事件配置
int HCmotorRatedInfoEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].motorRatedInfoEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].motorRatedInfoEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].motorRatedInfoEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].motorRatedInfoEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//抱闸制动器1
int HC_HoldingBrakeContactorCallback1(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeStatusEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeStatusEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeStatusEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeStatusEventConfiguration.uploadCycle=atol(columnValue[12]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.time=atol(columnValue[13]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.whetherToUpload,columnValue[14]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[15]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.uploadCycle=atol(columnValue[16]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.time=atol(columnValue[17]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.whetherToUpload,columnValue[18]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.whetherToUploadPeriodically,columnValue[19]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.uploadCycle=atol(columnValue[20]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//抱闸制动器2
int HC_HoldingBrakeContactorCallback2(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeStatusEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeStatusEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeStatusEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeStatusEventConfiguration.uploadCycle=atol(columnValue[12]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.time=atol(columnValue[13]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.whetherToUpload,columnValue[14]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[15]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.uploadCycle=atol(columnValue[16]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.time=atol(columnValue[17]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.whetherToUpload,columnValue[18]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.whetherToUploadPeriodically,columnValue[19]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.uploadCycle=atol(columnValue[20]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

//永磁体数据集事件配置
int HCpermanentMagnetDataSetEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].permanentMagnetDataSetEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].permanentMagnetDataSetEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].permanentMagnetDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].permanentMagnetDataSetEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//制动器行程反馈开关1

int HCBrakeStrokeFeedbackSwitchCallback1(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//制动器行程反馈开关2

int HCBrakeStrokeFeedbackSwitchCallback2(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//制动器热检测传感器1
int HCbrakeHeatDetectionSensorCallback1(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//制动器热检测传感器2
int HCbrakeHeatDetectionSensorCallback2(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

//刹车片磨损传感器数据事件配置
int HCbrakePadWearSensorDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakePadWearSensorDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakePadWearSensorDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakePadWearSensorDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakePadWearSensorDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//NTC保护点临界温度事件配置
int HCntcTempProtectCriticalPointEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].ntcTempProtectCriticalPointEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].ntcTempProtectCriticalPointEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].ntcTempProtectCriticalPointEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].ntcTempProtectCriticalPointEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//轿厢
//电梯当前位置信息事件配置
int HCelevatorCurrentPositionInfoEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorCurrentPositionInfoEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorCurrentPositionInfoEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorCurrentPositionInfoEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorCurrentPositionInfoEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//电梯运行里程事件配置
int HCelevatorMileageEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorMileageEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorMileageEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorMileageEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorMileageEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//运行数据事件配置
int HCrunDataEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].runDataEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].runDataEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].runDataEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].runDataEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//电瓶车识别事件配置
int HCvisionElectricVehicleEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionElectricVehicleEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionElectricVehicleEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionElectricVehicleEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionElectricVehicleEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//扒门识别事件配置
int HCvisionPryingDoorEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionPryingDoorEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionPryingDoorEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionPryingDoorEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionPryingDoorEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//烟雾识别事件配置
int HCvisionSmokeEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionSmokeEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionSmokeEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionSmokeEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionSmokeEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//困人识别事件配置
int HCvisionTrappedEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionTrappedEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionTrappedEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionTrappedEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionTrappedEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//倒地识别事件配置
int HCvisionFallEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionFallEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionFallEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionFallEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionFallEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//人员计数事件配置
int HCvisionPersonEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionPersonEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionPersonEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].visionPersonEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].visionPersonEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//语音请求信号事件配置
int HCvoiceRequestSignalEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].voiceRequestSignalEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].voiceRequestSignalEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].voiceRequestSignalEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].voiceRequestSignalEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//轿内指令板
//内召状态事件配置
int HCinternalCallStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].internalCallStatusEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].internalCallStatusEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].internalCallStatusEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].internalCallStatusEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//前后门内召登记指令事件配置
int HCfrontBackDoorInternalCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackDoorInternalCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackDoorInternalCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackDoorInternalCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackDoorInternalCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//前门内召登记指令事件配置
int HCfrontDoorInternalCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorInternalCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorInternalCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorInternalCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorInternalCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//后门内召登记指令事件配置
int HCbackDoorInternalCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorInternalCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorInternalCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorInternalCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorInternalCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//主操纵盘按钮统计数据事件配置
int HCmainControlPanelButtonStatisticsEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].mainControlPanelButtonStatisticsEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].mainControlPanelButtonStatisticsEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].mainControlPanelButtonStatisticsEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].mainControlPanelButtonStatisticsEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//辅助操纵盘按钮统计数据事件配置
int HCauxiliaryControlPanelButtonStatisticsEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].auxiliaryControlPanelButtonStatisticsEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].auxiliaryControlPanelButtonStatisticsEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].auxiliaryControlPanelButtonStatisticsEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].auxiliaryControlPanelButtonStatisticsEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//残疾人操纵盘按钮统计数据事件配置
int HChandicappedControlPanelButtonStatisticsEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedControlPanelButtonStatisticsEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedControlPanelButtonStatisticsEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedControlPanelButtonStatisticsEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedControlPanelButtonStatisticsEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//轿门
//门机预维保状态事件配置

int HCdoorMachinePreMaintenanceStatusEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorMachinePreMaintenanceStatusEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorMachinePreMaintenanceStatusEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorMachinePreMaintenanceStatusEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorMachinePreMaintenanceStatusEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门锁短接故障检测事件配置
int HCdoorLockShortCircuitFaultDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorLockShortCircuitFaultDetectionEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorLockShortCircuitFaultDetectionEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorLockShortCircuitFaultDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorLockShortCircuitFaultDetectionEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//轿门锁
int HCfontcarDoorLockCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.uploadCycle=atol(columnValue[12]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门板
int HCfontdoorPanelCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorPanelDetectionDataEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorPanelDetectionDataEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorPanelDetectionDataEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorPanelDetectionDataEventConfig.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatisticsEventConfig.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatisticsEventConfig.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatisticsEventConfig.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatisticsEventConfig.uploadCycle=atol(columnValue[12]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatusDataEventConfig.time=atol(columnValue[13]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatusDataEventConfig.whetherToUpload,columnValue[14]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatusDataEventConfig.whetherToUploadPeriodically,columnValue[15]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[0].doorStatusDataEventConfig.uploadCycle=atol(columnValue[16]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门球
int HCfontdoorBallCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[0].doorBallDataSetEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[0].doorBallDataSetEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[0].doorBallDataSetEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[0].doorBallDataSetEventConfig.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//锁钩
int HCfontlockHookCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[0].lockHookDataSetEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[0].lockHookDataSetEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[0].lockHookDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[0].lockHookDataSetEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//皮带
int HCfontstrapCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].strap[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].strap[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].strap[0].beltDetectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].strap[0].beltDetectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].strap[0].beltDetectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].strap[0].beltDetectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//轿厢地坎
int HCfontcarSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[0].carSillDetectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[0].carSillDetectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[0].carSillDetectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[0].carSillDetectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}


//滑轨

int HCfontslideCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].slide[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].slide[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//光幕
int HCfontlightCurtainCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[0].specialFunctionEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[0].specialFunctionEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[0].specialFunctionEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[0].specialFunctionEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//"同步门电机"
int HCfontsynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}

int HCfontasynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[0].doorMotorDetectionDataEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[0].doorMotorDetectionDataEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[0].doorMotorDetectionDataEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[0].doorMotorDetectionDataEventConfig.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
int HCbackcarDoorLockCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.uploadCycle=atol(columnValue[12]);

    elevatorNum++;

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门板
int HCbackdoorPanelCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorPanelDetectionDataEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorPanelDetectionDataEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorPanelDetectionDataEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorPanelDetectionDataEventConfig.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatisticsEventConfig.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatisticsEventConfig.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatisticsEventConfig.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatisticsEventConfig.uploadCycle=atol(columnValue[12]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatusDataEventConfig.time=atol(columnValue[13]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatusDataEventConfig.whetherToUpload,columnValue[14]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatusDataEventConfig.whetherToUploadPeriodically,columnValue[15]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorPanel[1].doorStatusDataEventConfig.uploadCycle=atol(columnValue[16]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门球
int HCbackdoorBallCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[1].doorBallDataSetEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[1].doorBallDataSetEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[1].doorBallDataSetEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorBall[1].doorBallDataSetEventConfig.uploadCycle=atol(columnValue[8]);
    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//锁钩
int HCbacklockHookCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[1].lockHookDataSetEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[1].lockHookDataSetEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[1].lockHookDataSetEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lockHook[1].lockHookDataSetEventConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//皮带
int HCbackstrapCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].strap[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].strap[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].strap[1].beltDetectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].strap[1].beltDetectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].strap[1].beltDetectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].strap[1].beltDetectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//轿厢地坎
int HCbackcarSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[1].carSillDetectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[1].carSillDetectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[1].carSillDetectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carSill[1].carSillDetectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}


//滑轨

int HCbackslideCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].slide[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].slide[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//光幕
int HCbacklightCurtainCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[1].specialFunctionEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[1].specialFunctionEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[1].specialFunctionEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].lightCurtain[1].specialFunctionEventConfiguration.uploadCycle=atol(columnValue[8]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}
//"同步门电机"
int HCbacksynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

int HCbackasynchronousDoorMotorCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[1].doorMotorDetectionDataEventConfig.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[1].doorMotorDetectionDataEventConfig.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[1].doorMotorDetectionDataEventConfig.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].asynchronousDoorMotor[1].doorMotorDetectionDataEventConfig.uploadCycle=atol(columnValue[8]);
    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}

//轿顶
//轿厢承载数据事件配置

int HCcarCarryingDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carCarryingDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carCarryingDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].carCarryingDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].carCarryingDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门区信号事件配置
int HCdoorZoneSignalEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorZoneSignalEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorZoneSignalEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorZoneSignalEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorZoneSignalEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//加速度数据事件配置
int HCaccelerationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].accelerationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].accelerationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].accelerationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].accelerationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//轿顶气压传感器
//位置数据事件配置
int HClocationDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].locationDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].locationDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].locationDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].locationDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//轿顶sensor处理器
//232接口模块
int HCm232InterfaceModuleCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].m232InterfaceModule.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].m232InterfaceModule.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].m232InterfaceModule.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].m232InterfaceModule.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//厅外
//前后上下召登记指令事件配置
int HCfrontBackUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackUpDownCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackUpDownCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontBackUpDownCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//控制柜统计数据事件配置
int HCfrontUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontUpDownCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontUpDownCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontUpDownCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//后门上下召登记指令事件配置
int HCbackUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backUpDownCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backUpDownCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backUpDownCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//残障前门上下召登记指令事件配置
int HChandicappedFrontUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedFrontUpDownCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedFrontUpDownCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedFrontUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedFrontUpDownCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//残障后门上下召登记指令事件配置
int HChandicappedBackUpDownCallRegistrationCommandEventConfigCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedBackUpDownCallRegistrationCommandEventConfig.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedBackUpDownCallRegistrationCommandEventConfig.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedBackUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].handicappedBackUpDownCallRegistrationCommandEventConfig.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//按钮(厅外显示板)
//前门外呼上召按钮动作次数事件配置
int HCfrontDoorHallUpCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//前门外呼下召按钮动作次数事件配置
int HCfrontDoorHallDnCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//后门外呼上召按钮动作次数事件配置
int HCbackDoorHallUpCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallUpCallButtonActionsNumberEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallUpCallButtonActionsNumberEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//后门外呼下召按钮动作次数事件配置
int HCbackDoorHallDnCallButtonActionsNumberEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallDnCallButtonActionsNumberEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backDoorHallDnCallButtonActionsNumberEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//厅门V1.0.0列表

int HCfonthallDoorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorStatisticsEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorStatisticsEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[0].hallDoorStatisticsEventConfiguration.uploadCycle=atol(columnValue[12]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}


//厅门锁V1.0.0列表
int HCfonthallDoorLockListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.uploadCycle=atol(columnValue[12]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.time=atol(columnValue[13]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.whetherToUpload,columnValue[14]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[15]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.uploadCycle=atol(columnValue[16]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}

//厅门地坎
int HCfonthallSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[0].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[0].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

//厅门V1.0.0列表

int HCbackhallDoorListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorStatisticsEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorStatisticsEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallDoorList[1].hallDoorStatisticsEventConfiguration.uploadCycle=atol(columnValue[12]);

    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}


//厅门锁V1.0.0列表
int HCbackhallDoorLockListCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle=atol(columnValue[8]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.time=atol(columnValue[9]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.whetherToUpload,columnValue[10]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[11]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.uploadCycle=atol(columnValue[12]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.time=atol(columnValue[13]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.whetherToUpload,columnValue[14]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[15]);
    VirtualDeviceALL.VirtualDevice[elevatorNum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.uploadCycle=atol(columnValue[16]);
    elevatorNum++;

    return ERR_COMMON_SUCCESS;
}

//厅门地坎
int HCbackhallSillCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[1].instance,columnValue[3]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[1].use=atoi(columnValue[4]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.time=atol(columnValue[5]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,columnValue[6]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[7]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle=atol(columnValue[8]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

//门板检测数据事件配置
int HCdoorInspectionDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorInspectionDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorInspectionDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorInspectionDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorInspectionDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门板统计数据事件配置
int HCdoorStatisticsEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorStatisticsEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorStatisticsEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorStatisticsEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorStatisticsEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//门板固有数据事件配置
int HCdoorInherentDataEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorInherentDataEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorInherentDataEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].doorInherentDataEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].doorInherentDataEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//井道
//电梯运行打滑量数据检测事件配置
int HCelevatorSlippageDataDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorSlippageDataDetectionEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorSlippageDataDetectionEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorSlippageDataDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorSlippageDataDetectionEventConfiguration.uploadCycle=atol(columnValue[6]);
    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//抱闸力检测钢丝绳打滑量事件配置
int HCbrakeForceDetectionSteelRopesSlipEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeForceDetectionSteelRopesSlipEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeForceDetectionSteelRopesSlipEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].brakeForceDetectionSteelRopesSlipEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].brakeForceDetectionSteelRopesSlipEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//物理1楼启动次数事件配置
int HCnumberOfStartsOnTheFirstFloorEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].numberOfStartsOnTheFirstFloorEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].numberOfStartsOnTheFirstFloorEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].numberOfStartsOnTheFirstFloorEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].numberOfStartsOnTheFirstFloorEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//返基站打滑量事件配置
int HCbackToTheBaseStationSlipEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backToTheBaseStationSlipEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backToTheBaseStationSlipEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].backToTheBaseStationSlipEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].backToTheBaseStationSlipEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}
//安全回路
int HCvoltageDetectionEventConfigurationCallback(__attribute__((unused))void* para, __attribute__((unused))int columnCount, __attribute__((unused))char** columnValue, __attribute__((unused))char** columnName)
{

    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].elevatorid,columnValue[1]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].sn,columnValue[2]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].voltageDetectionEventConfiguration.time=atol(columnValue[3]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].voltageDetectionEventConfiguration.whetherToUpload,columnValue[4]);
    strcpy(VirtualDeviceALL.VirtualDevice[elevatorNum].voltageDetectionEventConfiguration.whetherToUploadPeriodically,columnValue[5]);
    VirtualDeviceALL.VirtualDevice[elevatorNum].voltageDetectionEventConfiguration.uploadCycle=atol(columnValue[6]);

    elevatorNum++;
    return ERR_COMMON_SUCCESS;
}

int HCReadVirtualDeviceInforInit()
{
    memset(&VirtualDeviceALL,0x0,sizeof (ST_VirtualDeviceALL));
    HCTableInit(VIRTUALDEVICEPATH);
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCinformation);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCelevatorComprehensiveFaultInformationEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCagvInformationEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCControlCabinetStatisticsEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCControlCabinetInherentDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCControlCabinetTemperatrueDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCLeftContactorList);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCRightContactorList);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCRunContactorList);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCFXContactorList);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCsystemStatusEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCsystemSignalDetectionEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCcontrollerPasswordEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCerrorCodeEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCterminalStatusEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCAGVheartbeatEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCCAN1communicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCSPI1communicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCSPI2communicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCMOD1communicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCMOD2communicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCm485FirstcommunicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCm485TwocommunicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCserialPortcommunicationDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCinterfaceBoardStatisticalDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCinterfaceBoardTemperatrueDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCelevatorRemoteLockSignalEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCmotorRatedInfoEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCHoldingBrakeContactor1);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCHoldingBrakeContactor2);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCpermanentMagnetDataSetEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCBrakeStrokeFeedbackSwitch1);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCBrakeStrokeFeedbackSwitch2);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbrakeHeatDetectionSensor1);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbrakeHeatDetectionSensor2);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbrakePadWearSensorDataEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCntcTempProtectCriticalPointEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCelevatorCurrentPositionInfoEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCelevatorMileageEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCrunDataEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvisionElectricVehicleEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvisionPryingDoorEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvisionSmokeEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvisionTrappedEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvisionFallEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvisionPersonEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvoiceRequestSignalEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCinternalCallStatusEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfrontBackDoorInternalCallRegistrationCommandEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfrontDoorInternalCallRegistrationCommandEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackDoorInternalCallRegistrationCommandEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCmainControlPanelButtonStatisticsEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCauxiliaryControlPanelButtonStatisticsEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HChandicappedControlPanelButtonStatisticsEventConfig);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCdoorMachinePreMaintenanceStatusEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCdoorLockShortCircuitFaultDetectionEventConfiguration);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontcarDoorLock);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontdoorPanel);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontdoorBall);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontlockHook);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontstrap);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontarSill);

//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontslide);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontlightCurtain);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontsynchronousDoorMotor);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfontasynchronousDoorMotor);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackcarDoorLock);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackdoorPanel);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackdoorBall);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbacklockHook);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackstrap);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackarSill);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackslide);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbacklightCurtain);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbacksynchronousDoorMotor);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackasynchronousDoorMotor);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCcarCarryingDataEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCdoorZoneSignalEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCaccelerationDataEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HClocationDataEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCm232InterfaceModule);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfrontBackUpDownCallRegistrationCommandEventConfig);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfrontUpDownCallRegistrationCommandEventConfig);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackUpDownCallRegistrationCommandEventConfig);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HChandicappedFrontUpDownCallRegistrationCommandEventConfig);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HChandicappedBackUpDownCallRegistrationCommandEventConfig);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfrontDoorHallUpCallButtonActionsNumberEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfrontDoorHallDnCallButtonActionsNumberEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackDoorHallUpCallButtonActionsNumberEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackDoorHallDnCallButtonActionsNumberEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfonthallDoorList);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfonthallDoorLockList);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCfonthallSill);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackhallDoorList);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackhallDoorLockList);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackhallSill);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCdoorInspectionDataEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCdoorStatisticsEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCdoorInherentDataEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCelevatorSlippageDataDetectionEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbrakeForceDetectionSteelRopesSlipEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCnumberOfStartsOnTheFirstFloorEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCbackToTheBaseStationSlipEventConfiguration);
//    elevatorNum=0;
//    HCReadVirtualDeviceInfor(VIRTUALDEVICEPATH,HCvoltageDetectionEventConfiguration);

    return ERR_COMMON_SUCCESS;
}

int HCReadVirtualDeviceInfor(char *dbpath,char* tablename)
{//根据传入的表名显示表格内容
    char* errmsg;
    int rc;
    char sql[SQL_SIZE]={0};
    int ReadFd=0;
    int WriteFd=0;
    elevatorNum=0;
    ReadFd = open(dbpath, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, dbpath, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
    }
    rc = sqlite3_open(VIRTUALDEVICEPATH, &db);
    if (rc) {

        sqlite3_close(db);
        return ERR_COMMON_FAILED;
    }
    sprintf(sql, "select * from '%s';", tablename);
    if(strcmp(tablename,HCinformation)==0)

    {
        rc = sqlite3_exec(db, sql, HCVirtualDeviceCallback, NULL, &errmsg); //基本信息
        if(rc != SQLITE_OK){

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCelevatorAndSnInfor)==0)

    {
        rc = sqlite3_exec(db, sql, HCelevatorIDAndSNCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCelevatorComprehensiveFaultInformationEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCelevatorComprehensiveFaultInformationEventConfigurationCallback, NULL, &errmsg);//电梯综合故障信息
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCagvInformationEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCagvInformationEventConfigurationCallback, NULL, &errmsg);//机器人事件信息
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCControlCabinetStatisticsEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCControlCabinetStatisticsEventConfigurationCallback, NULL, &errmsg);//控制柜统计数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCControlCabinetInherentDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCControlCabinetInherentDataEventConfigurationCallback, NULL, &errmsg);//控制柜固有数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCControlCabinetTemperatrueDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCControlCabinetTemperatrueDataEventConfigurationCallback, NULL, &errmsg);//控制柜温度数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCLeftContactorList)==0)

    {
        rc = sqlite3_exec(db, sql, HC_LeftContactorListCallback, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCRightContactorList)==0)

    {
        rc = sqlite3_exec(db, sql, HC_RightContactorListCallback, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCRunContactorList)==0)

    {
        rc = sqlite3_exec(db, sql, HC_RunContactorListCallback, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCFXContactorList)==0)

    {
        rc = sqlite3_exec(db, sql, HC_FXContactorListCallback, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCsystemStatusEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCsystemStatusEventConfigurationCallback, NULL, &errmsg);//系统状态事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCsystemSignalDetectionEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCsystemSignalDetectionEventConfigurationCallback, NULL, &errmsg);//系统信号检测事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCcontrollerPasswordEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCcontrollerPasswordEventConfigurationCallback, NULL, &errmsg);//控制器密码事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCerrorCodeEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCerrorCodeEventConfigurationCallback, NULL, &errmsg);//故障代码事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCterminalStatusEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCterminalStatusEventConfigurationCallback, NULL, &errmsg);//端子状态事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCAGVheartbeatEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCAGVheartbeatEventConfigurationCallback, NULL, &errmsg);//AGV心跳事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCCAN1communicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCCAN1communicationDataEventConfigurationCallback, NULL, &errmsg);//CAN1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCSPI1communicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCSPI1communicationDataEventConfigurationCallback, NULL, &errmsg);//SPI1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCSPI2communicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCSPI2communicationDataEventConfigurationCallback, NULL, &errmsg);//SPI2通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCMOD1communicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCMOD1communicationDataEventConfigurationCallback, NULL, &errmsg);//MOD1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCMOD2communicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCMOD2communicationDataEventConfigurationCallback, NULL, &errmsg);//MOD2通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCm485FirstcommunicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCm485FirstcommunicationDataEventConfigurationCallback, NULL, &errmsg);//485-1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCm485TwocommunicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCm485TwocommunicationDataEventConfigurationCallback, NULL, &errmsg);//485-2通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCserialPortcommunicationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCserialPortcommunicationDataEventConfigurationCallback, NULL, &errmsg);//串口通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCinterfaceBoardStatisticalDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCinterfaceBoardStatisticalDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCinterfaceBoardTemperatrueDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCinterfaceBoardTemperatrueDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCelevatorRemoteLockSignalEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCelevatorRemoteLockSignalEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCmotorRatedInfoEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCmotorRatedInfoEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCHoldingBrakeContactor1)==0)

    {
        rc = sqlite3_exec(db, sql, HC_HoldingBrakeContactorCallback1, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCHoldingBrakeContactor2)==0)

    {
        rc = sqlite3_exec(db, sql, HC_HoldingBrakeContactorCallback2, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCpermanentMagnetDataSetEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCpermanentMagnetDataSetEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCBrakeStrokeFeedbackSwitch1)==0)

    {
        rc = sqlite3_exec(db, sql, HCBrakeStrokeFeedbackSwitchCallback1, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCBrakeStrokeFeedbackSwitch2)==0)

    {
        rc = sqlite3_exec(db, sql, HCBrakeStrokeFeedbackSwitchCallback2, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbrakeHeatDetectionSensor1)==0)

    {
        rc = sqlite3_exec(db, sql, HCbrakeHeatDetectionSensorCallback1, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbrakeHeatDetectionSensor2)==0)

    {
        rc = sqlite3_exec(db, sql, HCbrakeHeatDetectionSensorCallback2, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbrakePadWearSensorDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCbrakePadWearSensorDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCntcTempProtectCriticalPointEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCntcTempProtectCriticalPointEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCelevatorCurrentPositionInfoEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCelevatorCurrentPositionInfoEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCelevatorMileageEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCelevatorMileageEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCrunDataEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCrunDataEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvisionElectricVehicleEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvisionElectricVehicleEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvisionPryingDoorEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvisionPryingDoorEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvisionSmokeEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvisionSmokeEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvisionTrappedEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvisionTrappedEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvisionFallEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvisionFallEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvisionPersonEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvisionPersonEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvoiceRequestSignalEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCvoiceRequestSignalEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCinternalCallStatusEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCinternalCallStatusEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfrontBackDoorInternalCallRegistrationCommandEventConfig)==0)


    {
        rc = sqlite3_exec(db, sql, HCfrontBackDoorInternalCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfrontDoorInternalCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCfrontDoorInternalCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackDoorInternalCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackDoorInternalCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCmainControlPanelButtonStatisticsEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCmainControlPanelButtonStatisticsEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCauxiliaryControlPanelButtonStatisticsEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCauxiliaryControlPanelButtonStatisticsEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HChandicappedControlPanelButtonStatisticsEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HChandicappedControlPanelButtonStatisticsEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCdoorMachinePreMaintenanceStatusEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCdoorMachinePreMaintenanceStatusEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCdoorLockShortCircuitFaultDetectionEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCdoorLockShortCircuitFaultDetectionEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }

    }
    if(strcmp(tablename,HCfontcarDoorLock)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontcarDoorLockCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontdoorPanel)==0)

    {

        rc = sqlite3_exec(db, sql, HCfontdoorPanelCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontdoorBall)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontdoorBallCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontlockHook)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontlockHookCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }

    }
    if(strcmp(tablename,HCfontstrap)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontstrapCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontarSill)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontcarSillCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }

    }
    if(strcmp(tablename,HCfontslide)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontslideCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontlightCurtain)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontlightCurtainCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontsynchronousDoorMotor)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontsynchronousDoorMotorCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfontasynchronousDoorMotor)==0)

    {
        rc = sqlite3_exec(db, sql, HCfontasynchronousDoorMotorCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackcarDoorLock)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackcarDoorLockCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackdoorPanel)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackdoorPanelCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackdoorBall)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackdoorBallCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbacklockHook)==0)

    {
        rc = sqlite3_exec(db, sql, HCbacklockHookCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackstrap)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackstrapCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackarSill)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackcarSillCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackslide)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackslideCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbacklightCurtain)==0)

    {
        rc = sqlite3_exec(db, sql, HCbacklightCurtainCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbacksynchronousDoorMotor)==0)

    {
        rc = sqlite3_exec(db, sql, HCbacksynchronousDoorMotorCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackasynchronousDoorMotor)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackasynchronousDoorMotorCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCcarCarryingDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCcarCarryingDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCdoorZoneSignalEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCdoorZoneSignalEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCaccelerationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCaccelerationDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HClocationDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HClocationDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCm232InterfaceModule)==0)

    {
        rc = sqlite3_exec(db, sql, HCm232InterfaceModuleCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfrontBackUpDownCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCfrontBackUpDownCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfrontUpDownCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCfrontUpDownCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackUpDownCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackUpDownCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HChandicappedFrontUpDownCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HChandicappedFrontUpDownCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HChandicappedBackUpDownCallRegistrationCommandEventConfig)==0)

    {
        rc = sqlite3_exec(db, sql, HChandicappedBackUpDownCallRegistrationCommandEventConfigCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfrontDoorHallUpCallButtonActionsNumberEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCfrontDoorHallUpCallButtonActionsNumberEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfrontDoorHallDnCallButtonActionsNumberEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCfrontDoorHallDnCallButtonActionsNumberEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackDoorHallUpCallButtonActionsNumberEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackDoorHallUpCallButtonActionsNumberEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackDoorHallDnCallButtonActionsNumberEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackDoorHallDnCallButtonActionsNumberEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfonthallDoorList)==0)

    {
        rc = sqlite3_exec(db, sql, HCfonthallDoorListCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfonthallDoorLockList)==0)

    {
        rc = sqlite3_exec(db, sql, HCfonthallDoorLockListCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCfonthallSill)==0)

    {
        rc = sqlite3_exec(db, sql, HCfonthallSillCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackhallDoorList)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackhallDoorListCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackhallDoorLockList)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackhallDoorLockListCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackhallSill)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackhallSillCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCdoorInspectionDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCdoorInspectionDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCdoorStatisticsEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCdoorStatisticsEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCdoorInherentDataEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCdoorInherentDataEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCelevatorSlippageDataDetectionEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCelevatorSlippageDataDetectionEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbrakeForceDetectionSteelRopesSlipEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCbrakeForceDetectionSteelRopesSlipEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCnumberOfStartsOnTheFirstFloorEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCnumberOfStartsOnTheFirstFloorEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCbackToTheBaseStationSlipEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCbackToTheBaseStationSlipEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    if(strcmp(tablename,HCvoltageDetectionEventConfiguration)==0)

    {
        rc = sqlite3_exec(db, sql, HCvoltageDetectionEventConfigurationCallback, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
            return ERR_COMMON_FAILED;
        }
    }
    sqlite3_close(db);
    close(ReadFd);
    close(WriteFd);
    return ERR_COMMON_SUCCESS;
}


int HCTableInit(const char *path)
{//判断表是否存在，不存在则创建
    char* errmsg;
    int rc;
    char sql[SQL_SIZE];
    HC_ASSERT(path);
    if(path==NULL)
        return -1;
    int ReadFd=0;
    int WriteFd=0;
    ReadFd = open(path, O_RDWR);
    if (ReadFd < 0)
    {
        if(HC_fileOpen(&WriteFd, path, O_RDWR | O_CREAT)==ERR_COMMON_FAILED){
            close(ReadFd);
            close(WriteFd);
            return ERR_COMMON_FAILED;
        }
        else {

            rc = sqlite3_open(path, &db);
            if (rc) {
                //printf("open failed\n");
                sqlite3_close(db);
                close(ReadFd);
                close(WriteFd);
                return -1;
            }
            sqlite3_limit(db, SQLITE_LIMIT_COLUMN,30);
            //构建虚拟设备表
            memset(sql,0x0,SQL_SIZE);
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,时间 long, 软件版本 int, 时区 varchar);", HCinformation);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long);", HCelevatorAndSnInfor);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //电梯综合故障信息
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long,是否上报 varchar,是否周期上报 varchar, 上报周期 long);", HCelevatorComprehensiveFaultInformationEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //机器人事件信息
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCagvInformationEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//控制柜统计数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCControlCabinetStatisticsEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//控制柜固有数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCControlCabinetInherentDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//控制柜温度数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCControlCabinetTemperatrueDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//左接触器列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 接触器名称 varchar, 接触器类型 int, 修改时间 long,  是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCLeftContactorList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//右接触器列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 接触器名称 varchar, 接触器类型 int, 修改时间 long,  是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCRightContactorList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//运行接触器列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 接触器名称 varchar, 接触器类型 int, 修改时间 long,  是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCRunContactorList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//FX接触器列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 接触器名称 varchar, 接触器类型 int, 修改时间 long,  是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCFXContactorList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //系统状态事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCsystemStatusEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//系统信号检测事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCsystemSignalDetectionEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//控制器密码事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCcontrollerPasswordEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//故障代码事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCerrorCodeEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//端子状态事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCterminalStatusEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//AGV心跳事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCAGVheartbeatEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//CAN1通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCCAN1communicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//SPI1通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCSPI1communicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //SPI2通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCSPI2communicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//MOD1通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCMOD1communicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//MOD2通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCMOD2communicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//485-1通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCm485FirstcommunicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//485-2通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCm485TwocommunicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//串口通讯数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCserialPortcommunicationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//接口板统计数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCinterfaceBoardStatisticalDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//接口板温度数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCinterfaceBoardTemperatrueDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//新国标物联网模块第三方电梯远程锁梯信号事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCelevatorRemoteLockSignalEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//电机额定信息事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCmotorRatedInfoEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//抱闸制动器1
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 抱闸制动器名称 varchar,抱闸制动器类型 int, 抱闸预检状态事件配置修改时间 long, 抱闸预检状态事件配置是否上报 varchar, 抱闸预检状态事件配置是否周期上报 varchar, 抱闸预检状态事件配置上报周期 long, 抱闸状态事件配置修改时间 long, 抱闸状态事件配置是否上报 varchar, 抱闸状态事件配置是否周期上报 varchar, 抱闸状态事件配置上报周期 long, 抱闸力检测数据集事件配置修改时间 long, 抱闸力检测数据集事件配置是否上报 varchar, 抱闸力检测数据集事件配置是否周期上报 varchar, 抱闸力检测数据集事件配置上报周期 long, 抱闸打开关闭时间事件配置修改时间 long, 抱闸打开关闭时间事件配置是否上报 varchar, 抱闸打开关闭时间事件配置是否周期上报 varchar, 抱闸打开关闭时间事件配置上报周期 long);", HCHoldingBrakeContactor1);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//抱闸制动器2
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 抱闸制动器名称 varchar,抱闸制动器类型 int, 抱闸预检状态事件配置修改时间 long, 抱闸预检状态事件配置是否上报 varchar, 抱闸预检状态事件配置是否周期上报 varchar, 抱闸预检状态事件配置上报周期 long, 抱闸状态事件配置修改时间 long, 抱闸状态事件配置是否上报 varchar, 抱闸状态事件配置是否周期上报 varchar, 抱闸状态事件配置上报周期 long, 抱闸力检测数据集事件配置修改时间 long, 抱闸力检测数据集事件配置是否上报 varchar, 抱闸力检测数据集事件配置是否周期上报 varchar, 抱闸力检测数据集事件配置上报周期 long, 抱闸打开关闭时间事件配置修改时间 long, 抱闸打开关闭时间事件配置是否上报 varchar, 抱闸打开关闭时间事件配置是否周期上报 varchar, 抱闸打开关闭时间事件配置上报周期 long);", HCHoldingBrakeContactor2);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//永磁体数据集事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCpermanentMagnetDataSetEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//制动器行程反馈开关1
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 制动器行程反馈开关名称 varchar,制动器行程反馈开关类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCBrakeStrokeFeedbackSwitch1);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//制动器行程反馈开关2
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 制动器行程反馈开关名称 varchar,制动器行程反馈开关类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCBrakeStrokeFeedbackSwitch2);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//制动器热检测传感器1
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,制动器热检测传感器名称 varchar,制动器热检测传感器类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbrakeHeatDetectionSensor1);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//制动器热检测传感器2
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 制动器热检测传感器名称 varchar,制动器热检测传感器类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbrakeHeatDetectionSensor2);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//刹车片磨损传感器数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbrakePadWearSensorDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//NTC保护点临界温度事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCntcTempProtectCriticalPointEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //电梯当前位置信息事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCelevatorCurrentPositionInfoEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//电梯运行里程事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCelevatorMileageEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//运行数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCrunDataEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//电瓶车识别事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvisionElectricVehicleEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//扒门识别事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long,  是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvisionPryingDoorEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//烟雾识别事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvisionSmokeEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//困人识别事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvisionTrappedEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//倒地识别事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvisionFallEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //人员计数事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvisionPersonEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//语音请求信号事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvoiceRequestSignalEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//内召状态事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCinternalCallStatusEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前后门内召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfrontBackDoorInternalCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门内召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfrontDoorInternalCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //后门内召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackDoorInternalCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//主操纵盘按钮统计数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCmainControlPanelButtonStatisticsEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//辅助操纵盘按钮统计数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCauxiliaryControlPanelButtonStatisticsEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//残疾人操纵盘按钮统计数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HChandicappedControlPanelButtonStatisticsEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //门机预维保状态事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCdoorMachinePreMaintenanceStatusEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//门锁短接故障检测事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCdoorLockShortCircuitFaultDetectionEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门轿门锁
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 轿门锁统计数据事件配置修改时间 long, 轿门锁统计数据事件配置是否上报 varchar, 轿门锁统计数据事件配置是否周期上报 varchar, 轿门锁统计数据事件配置上报周期 long, 轿门锁锁通断状态事件配置修改时间 long, 轿门锁锁通断状态事件配置是否上报 varchar, 轿门锁锁通断状态事件配置是否周期上报 varchar, 轿门锁锁通断状态事件配置上报周期 long);", HCfontcarDoorLock);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }

            memset(sql,0x0,SQL_SIZE);//前门门板
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 门板检测数据事件配置修改时间 long, 门板检测数据事件配置是否上报 varchar, 门板检测数据事件配置是否周期上报 varchar, 门板检测数据事件配置上报周期 long, 门板统计数据事件配置修改时间 long, 门板统计数据事件配置是否上报 varchar, 门板统计数据事件配置是否周期上报 varchar, 门板统计数据事件配置上报周期 long, 门板状态数据事件配置修改时间 long, 门板状态数据事件配置是否上报 varchar, 门板状态数据事件配置是否周期上报 varchar, 门板状态数据事件配置上报周期 long);", HCfontdoorPanel);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门门球
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontdoorBall);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门锁钩
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontlockHook);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门皮带
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontstrap);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门轿厢地坎
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontarSill);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门滑轨
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontslide);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门光幕
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontlightCurtain);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //"前门同步门电机"
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontsynchronousDoorMotor);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门异步门电机
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfontasynchronousDoorMotor);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门轿门锁
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,轿门锁统计数据事件配置修改时间 long, 轿门锁统计数据事件配置是否上报 varchar, 轿门锁统计数据事件配置是否周期上报 varchar, 轿门锁统计数据事件配置上报周期 long, 轿门锁锁通断状态事件配置修改时间 long, 轿门锁锁通断状态事件配置是否上报 varchar, 轿门锁锁通断状态事件配置是否周期上报 varchar, 轿门锁锁通断状态事件配置上报周期 long);", HCbackcarDoorLock);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            //添加默认值

            memset(sql,0x0,SQL_SIZE);//后门门板
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,门板检测数据事件配置修改时间 long, 门板检测数据事件配置是否上报 varchar, 门板检测数据事件配置是否周期上报 varchar, 门板检测数据事件配置上报周期 long, 门板统计数据事件配置修改时间 long, 门板统计数据事件配置是否上报 varchar, 门板统计数据事件配置是否周期上报 varchar, 门板统计数据事件配置上报周期 long, 门板状态数据事件配置修改时间 long, 门板状态数据事件配置是否上报 varchar, 门板状态数据事件配置是否周期上报 varchar, 门板状态数据事件配置上报周期 long);", HCbackdoorPanel);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //后门门球
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackdoorBall);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门锁钩
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbacklockHook);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //后门皮带
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackstrap);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门轿厢地坎
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackarSill);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门滑轨
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackslide);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门光幕
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbacklightCurtain);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //后门同步门电机"
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbacksynchronousDoorMotor);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //后门异步门电机
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackasynchronousDoorMotor);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }

            memset(sql,0x0,SQL_SIZE);  //轿厢承载数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCcarCarryingDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//门区信号事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCdoorZoneSignalEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //加速度数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCaccelerationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);  //位置数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HClocationDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//232接口模块
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCm232InterfaceModule);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            //添加默认值
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前后上下召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfrontBackUpDownCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门上下召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfrontUpDownCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门上下召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackUpDownCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            //添加默认值
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //残障前门上下召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HChandicappedFrontUpDownCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//残障后门上下召登记指令事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HChandicappedBackUpDownCallRegistrationCommandEventConfig);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门外呼上召按钮动作次数事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfrontDoorHallUpCallButtonActionsNumberEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门外呼下召按钮动作次数事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfrontDoorHallDnCallButtonActionsNumberEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            //添加默认值
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门外呼上召按钮动作次数事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackDoorHallUpCallButtonActionsNumberEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门外呼下召按钮动作次数事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackDoorHallDnCallButtonActionsNumberEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门厅门V1.0.0列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,厅门检测数据事件配置修改时间 long, 厅门检测数据事件配置是否上报 varchar, 厅门检测数据事件配置是否周期上报 varchar, 厅门检测数据事件配置上报周期 long, 厅门统计数据事件配置修改时间 long, 厅门统计数据事件配置是否上报 varchar, 厅门统计数据事件配置是否周期上报 varchar, 厅门统计数据事件配置上报周期 long);", HCfonthallDoorList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//前门厅门锁V1.0.0列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar,名称 varchar, 类型 int, 层门锁通断检测事件配置修改时间 long, 层门锁通断检测事件配置是否上报 varchar, 层门锁通断检测事件配置是否周期上报 varchar, 层门锁通断检测事件配置上报周期 long, 开门数据统计事件配置修改时间 long, 开门数据统计事件配置是否上报 varchar, 开门数据统计事件配置是否周期上报 varchar, 开门数据统计事件配置上报周期 long, 关门数据统计事件配置修改时间 long, 关门数据统计事件配置是否上报 varchar, 关门数据统计事件配置是否周期上报 varchar, 关门数据统计事件配置上报周期 long);", HCfonthallDoorLockList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //前门厅门地坎
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCfonthallSill);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门厅门V1.0.0列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,厅门检测数据事件配置修改时间 long, 厅门检测数据事件配置是否上报 varchar, 厅门检测数据事件配置是否周期上报 varchar, 厅门检测数据事件配置上报周期 long, 厅门统计数据事件配置修改时间 long, 厅门统计数据事件配置是否上报 varchar, 厅门统计数据事件配置是否周期上报 varchar, 厅门统计数据事件配置上报周期 long);", HCbackhallDoorList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//后门厅门锁V1.0.0列表
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,层门锁通断检测事件配置修改时间 long, 层门锁通断检测事件配置是否上报 varchar, 层门锁通断检测事件配置是否周期上报 varchar, 层门锁通断检测事件配置上报周期 long, 开门数据统计事件配置修改时间 long, 开门数据统计事件配置是否上报 varchar, 开门数据统计事件配置是否周期上报 varchar, 开门数据统计事件配置上报周期 long, 关门数据统计事件配置修改时间 long, 关门数据统计事件配置是否上报 varchar, 关门数据统计事件配置是否周期上报 varchar, 关门数据统计事件配置上报周期 long);", HCbackhallDoorLockList);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //后门厅门地坎
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 名称 varchar, 类型 int,修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackhallSill);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //门板检测数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCdoorInspectionDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //门板统计数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCdoorStatisticsEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//门板固有数据事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT,电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCdoorInherentDataEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE); //电梯运行打滑量数据检测事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCelevatorSlippageDataDetectionEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//抱闸力检测钢丝绳打滑量事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbrakeForceDetectionSteelRopesSlipEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//物理1楼启动次数事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCnumberOfStartsOnTheFirstFloorEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//返基站打滑量事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCbackToTheBaseStationSlipEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            memset(sql,0x0,SQL_SIZE);//电压检测事件配置
            sprintf(sql, "CREATE TABLE IF NOT EXISTS %s(id INTEGER PRIMARY KEY AUTOINCREMENT, 电梯ID varchar, 设备注册SN码 varchar, 修改时间 long, 是否上报 varchar, 是否周期上报 varchar, 上报周期 long);", HCvoltageDetectionEventConfiguration);
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }

            //添加默认值
            memset(sql,0x0,SQL_SIZE);
            sprintf(sql,"insert into %s values(NULL, %ld,%d,\"%s\");", HCinformation, HC_LocalTimeGet(),0,"8");
            rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
            if(rc != SQLITE_OK)
            {
                HC_PRINT("select error : %s\n",errmsg);
            }
            for(int i=0;i<3;i++)
            {
                //添加默认值
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld);", HCelevatorAndSnInfor,i,idbuf[i],sn[i], HC_LocalTimeGet());
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //添加默认值
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCelevatorComprehensiveFaultInformationEventConfiguration,i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //机器人事件信息
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCagvInformationEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //控制柜统计数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\", \"%s\", %ld,\"%s\",\"%s\",%d );", HCControlCabinetStatisticsEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //控制柜固有数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCControlCabinetInherentDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //控制柜温度数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCControlCabinetTemperatrueDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }

                //接触器列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d,%ld,\"%s\",\"%s\",%d ) ;", HCLeftContactorList, i,idbuf[i],sn[i], "leftContactor",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //接触器列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d,%ld,\"%s\",\"%s\",%d ) ;", HCRightContactorList, i,idbuf[i],sn[i], "rightContactor",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //接触器列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d,%ld,\"%s\",\"%s\",%d ) ;", HCRunContactorList, i,idbuf[i],sn[i], "runContactor",2,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //接触器列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d,%ld,\"%s\",\"%s\",%d ) ;", HCFXContactorList, i,idbuf[i],sn[i], "fxContactor",3,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }

                //系统状态事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCsystemStatusEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //系统信号检测事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCsystemSignalDetectionEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //控制器密码事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCcontrollerPasswordEventConfiguration,i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //故障代码事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCerrorCodeEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //端子状态事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCterminalStatusEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //AGV心跳事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCAGVheartbeatEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //CAN1通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCCAN1communicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //SPI1通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCSPI1communicationDataEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //SPI2通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCSPI2communicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //MOD1通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCMOD1communicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //MOD2通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCMOD2communicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //485-1通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCm485FirstcommunicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //485-2通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCm485TwocommunicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //串口通讯数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCserialPortcommunicationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //接口板统计数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCinterfaceBoardStatisticalDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //接口板温度数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCinterfaceBoardTemperatrueDataEventConfiguration,i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //新国标物联网模块第三方电梯远程锁梯信号事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCelevatorRemoteLockSignalEventConfiguration,i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //电机额定信息事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCmotorRatedInfoEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //抱闸制动器1
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d, %ld,\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCHoldingBrakeContactor1, i,idbuf[i],sn[i],"holdingBrakeContactor1",0, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //抱闸制动器2
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCHoldingBrakeContactor2, i,idbuf[i],sn[i], "holdingBrakeContactor2",1,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //永磁体数据集事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCpermanentMagnetDataSetEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //制动器行程反馈开关1
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d,  %ld,\"%s\",\"%s\",%d );", HCBrakeStrokeFeedbackSwitch1, i,idbuf[i],sn[i], "brakeStrokeFeedbackSwitch1",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //制动器行程反馈开关2
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\", %d,  %ld,\"%s\",\"%s\",%d );", HCBrakeStrokeFeedbackSwitch2, i,idbuf[i],sn[i], "brakeStrokeFeedbackSwitch2",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //制动器热检测传感器1
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\", %d, %ld,\"%s\",\"%s\",%d );", HCbrakeHeatDetectionSensor1, i,idbuf[i],sn[i], "brakeHeatDetectionSensor1",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //制动器热检测传感器2
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\", %d, %ld,\"%s\",\"%s\",%d );", HCbrakeHeatDetectionSensor2, i,idbuf[i],sn[i], "brakeHeatDetectionSensor2",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //刹车片磨损传感器数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCbrakePadWearSensorDataEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //NTC保护点临界温度事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCntcTempProtectCriticalPointEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //电梯当前位置信息事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCelevatorCurrentPositionInfoEventConfig,i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //电梯运行里程事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCelevatorMileageEventConfig,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //运行数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCrunDataEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //电瓶车识别事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCvisionElectricVehicleEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //扒门识别事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCvisionPryingDoorEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //烟雾识别事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCvisionSmokeEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //困人识别事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCvisionTrappedEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //倒地识别事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ", HCvisionFallEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //人员计数事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ", HCvisionPersonEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //语音请求信号事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCvoiceRequestSignalEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //内召状态事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCinternalCallStatusEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前后门内召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCfrontBackDoorInternalCallRegistrationCommandEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门内召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCfrontDoorInternalCallRegistrationCommandEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门内召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCbackDoorInternalCallRegistrationCommandEventConfig,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //主操纵盘按钮统计数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCmainControlPanelButtonStatisticsEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //辅助操纵盘按钮统计数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCauxiliaryControlPanelButtonStatisticsEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //残疾人操纵盘按钮统计数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HChandicappedControlPanelButtonStatisticsEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //门机预维保状态事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCdoorMachinePreMaintenanceStatusEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //门锁短接故障检测事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCdoorLockShortCircuitFaultDetectionEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门轿门锁
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCfontcarDoorLock, i,idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门门板
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCfontdoorPanel, i,idbuf[i],sn[i], "font",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门门球
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d ) ;", HCfontdoorBall, i,idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门锁钩
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d ) ;", HCfontlockHook,i, idbuf[i],sn[i], "font",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门皮带
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d ) ;", HCfontstrap, i,idbuf[i],sn[i], "font",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门轿厢地坎
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d ) ;", HCfontarSill,i, idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门滑轨
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d ) ;", HCfontslide,i,idbuf[i],sn[i], "font",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门光幕
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d );", HCfontlightCurtain, i,idbuf[i],sn[i], "font",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //"前门同步门电机"
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCfontsynchronousDoorMotor,i, idbuf[i],sn[i], "font",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门异步门电机
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCfontasynchronousDoorMotor, i,idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门轿门锁
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackcarDoorLock, i,idbuf[i],sn[i], "back",1,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门门板
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackdoorPanel, i,idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门门球
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackdoorBall, i,idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门锁钩
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbacklockHook,i, idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门皮带
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackstrap, i,idbuf[i],sn[i], "back",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门轿厢地坎
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackarSill,i, idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门滑轨
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackslide,i,idbuf[i],sn[i], "back",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门光幕
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d );", HCbacklightCurtain, i,idbuf[i],sn[i], "back",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门同步门电机"
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbacksynchronousDoorMotor,i, idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门异步门电机
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackasynchronousDoorMotor, i,idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //轿厢承载数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCcarCarryingDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //门区信号事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCdoorZoneSignalEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //加速度数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCaccelerationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //位置数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HClocationDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //232接口模块
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\", %d ) ;", HCm232InterfaceModule, i,idbuf[i],sn[i],HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前后上下召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCfrontBackUpDownCallRegistrationCommandEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门上下召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCfrontUpDownCallRegistrationCommandEventConfig,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门上下召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCbackUpDownCallRegistrationCommandEventConfig, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //残障前门上下召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HChandicappedFrontUpDownCallRegistrationCommandEventConfig,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //残障后门上下召登记指令事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HChandicappedBackUpDownCallRegistrationCommandEventConfig,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门外呼上召按钮动作次数事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCfrontDoorHallUpCallButtonActionsNumberEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门外呼下召按钮动作次数事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCfrontDoorHallDnCallButtonActionsNumberEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门外呼上召按钮动作次数事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCbackDoorHallUpCallButtonActionsNumberEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门外呼下召按钮动作次数事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCbackDoorHallDnCallButtonActionsNumberEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门厅门V1.0.0列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCfonthallDoorList, i,idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门厅门锁V1.0.0列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", \"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCfonthallDoorLockList, i,idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //前门厅门地坎
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d );", HCfonthallSill,i, idbuf[i],sn[i],"font",0, HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门厅门V1.0.0列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackhallDoorList, i,idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门厅门锁V1.0.0列表
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d,%ld,\"%s\",\"%s\",%d ) ;", HCbackhallDoorLockList, i,idbuf[i],sn[i],"back",1, HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //后门厅门地坎
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\",\"%s\",%d, %ld,\"%s\",\"%s\",%d );", HCbackhallSill,i, idbuf[i],sn[i], "back",1,HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //门板检测数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCdoorInspectionDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //门板统计数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCdoorStatisticsEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //门板固有数据事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCdoorInherentDataEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //电梯运行打滑量数据检测事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCelevatorSlippageDataDetectionEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //抱闸力检测钢丝绳打滑量事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCbrakeForceDetectionSteelRopesSlipEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //物理1楼启动次数事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d );", HCnumberOfStartsOnTheFirstFloorEventConfiguration, i,idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //返基站打滑量事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d,\"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCbackToTheBaseStationSlipEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
                //电压检测事件配置
                memset(sql,0x0,SQL_SIZE);
                sprintf(sql,"insert into %s values(%d, \"%s\",\"%s\", %ld,\"%s\",\"%s\",%d ) ;", HCvoltageDetectionEventConfiguration,i, idbuf[i],sn[i], HC_LocalTimeGet(),"true","true",0);
                rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
                if(rc != SQLITE_OK)
                {
                    HC_PRINT("select error : %s\n",errmsg);
                }
            }
            sqlite3_close(db);

        }
        close(ReadFd);
        close(WriteFd);

    }
    return ERR_COMMON_SUCCESS;
}

int HCUpdateSetInfo(char *tablename ,int idnum,ST_VirtualDeviceALL  VirtualDeviceALL)
{
    char* errmsg;
    int rc;
    char sql[SQL_SIZE]={0};
    rc = sqlite3_open(VIRTUALDEVICEPATH, &db);
    if (rc) {
        //printf("open databade failed\n");
        sqlite3_close(db);
        return ERR_COMMON_FAILED;
    }

    if(strcmp(tablename,HCinformation)==0)

    {
        sprintf(sql, "update %s set 时间=%ld,软件版本=%d,时区=\"%s\" where id=%d;", tablename,VirtualDeviceALL.time,VirtualDeviceALL.version,VirtualDeviceALL.shiqu,1);

        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg); //基本信息
        if(rc != SQLITE_OK){

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCelevatorAndSnInfor)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld  where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].time,\
                idnum);

        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//电梯综合故障信息
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCelevatorComprehensiveFaultInformationEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld  where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorComprehensiveFaultInformationEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorComprehensiveFaultInformationEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorComprehensiveFaultInformationEventConfiguration.uploadCycle,idnum);

        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//电梯综合故障信息
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCagvInformationEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].agvInformationEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].agvInformationEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].agvInformationEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].agvInformationEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//机器人事件信息
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCControlCabinetStatisticsEventConfiguration)==0)//

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld  where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetStatisticsEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//控制柜统计数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCControlCabinetInherentDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld  where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetInherentDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetInherentDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetInherentDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetInherentDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//控制柜固有数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCControlCabinetTemperatrueDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetTemperatrueDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetTemperatrueDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetTemperatrueDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].controlCabinetTemperatrueDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//控制柜温度数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCLeftContactorList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",接触器名称=\"%s\",接触器类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[0].integratedConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[0].integratedConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[0].integratedConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[0].integratedConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//左接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCRightContactorList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",接触器名称=\"%s\",接触器类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[1].integratedConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[1].integratedConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[1].integratedConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[1].integratedConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCRunContactorList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",接触器名称=\"%s\",接触器类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[2].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[2].use,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[2].integratedConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[2].integratedConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[2].integratedConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[2].integratedConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCFXContactorList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",接触器名称=\"%s\",接触器类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[3].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[3].use,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[3].integratedConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[3].integratedConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[3].integratedConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].contactorList[3].integratedConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//接触器列表
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCsystemStatusEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].systemStatusEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].systemStatusEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].systemStatusEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].systemStatusEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//系统状态事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCsystemSignalDetectionEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].systemSignalDetectionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].systemSignalDetectionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].systemSignalDetectionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].systemSignalDetectionEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//系统信号检测事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCcontrollerPasswordEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].controllerPasswordEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].controllerPasswordEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].controllerPasswordEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].controllerPasswordEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//控制器密码事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCerrorCodeEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].errorCodeEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].errorCodeEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].errorCodeEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].errorCodeEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//故障代码事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCterminalStatusEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].terminalStatusEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].terminalStatusEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].terminalStatusEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].terminalStatusEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//端子状态事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCAGVheartbeatEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].AGVheartbeatEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].AGVheartbeatEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].AGVheartbeatEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].AGVheartbeatEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//AGV心跳事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCCAN1communicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].CAN1communicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].CAN1communicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].CAN1communicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].CAN1communicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//CAN1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCSPI1communicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].SPI1communicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].SPI1communicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].SPI1communicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].SPI1communicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//SPI1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCSPI2communicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].SPI2communicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].SPI2communicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].SPI2communicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].SPI2communicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//SPI2通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCMOD1communicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].MOD1communicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].MOD1communicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].MOD1communicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].MOD1communicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//MOD1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCMOD2communicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].MOD2communicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].MOD2communicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].MOD2communicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].MOD2communicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//MOD2通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCm485FirstcommunicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].m485FirstcommunicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].m485FirstcommunicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].m485FirstcommunicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].m485FirstcommunicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//485-1通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCm485TwocommunicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].m485TwocommunicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].m485TwocommunicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].m485TwocommunicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].m485TwocommunicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//485-2通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCserialPortcommunicationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].serialPortcommunicationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].serialPortcommunicationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].serialPortcommunicationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].serialPortcommunicationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//串口通讯数据事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCinterfaceBoardStatisticalDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardStatisticalDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardStatisticalDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardStatisticalDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardStatisticalDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCinterfaceBoardTemperatrueDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardTemperatrueDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardTemperatrueDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardTemperatrueDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].interfaceBoardTemperatrueDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCelevatorRemoteLockSignalEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorRemoteLockSignalEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorRemoteLockSignalEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorRemoteLockSignalEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorRemoteLockSignalEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCmotorRatedInfoEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].motorRatedInfoEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].motorRatedInfoEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].motorRatedInfoEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].motorRatedInfoEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//电机额定信息事件配置
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCHoldingBrakeContactor1)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",抱闸制动器名称=\"%s\",抱闸制动器类型=%d,抱闸预检状态事件配置修改时间=%ld,抱闸预检状态事件配置是否上报=\"%s\",抱闸预检状态事件配置是否周期上报=\"%s\", 抱闸预检状态事件配置上报周期=%ld,抱闸状态事件配置修改时间=%ld,抱闸状态事件配置是否上报=\"%s\",抱闸状态事件配置是否周期上报=\"%s\", 抱闸状态事件配置上报周期=%ld,抱闸力检测数据集事件配置修改时间=%ld,抱闸力检测数据集事件配置是否上报=\"%s\",抱闸力检测数据集事件配置是否周期上报=\"%s\", 抱闸力检测数据集事件配置上报周期=%ld,抱闸打开关闭时间事件配置修改时间=%ld,抱闸打开关闭时间事件配置是否上报=\"%s\",抱闸打开关闭时间事件配置是否周期上报=\"%s\", 抱闸打开关闭时间事件配置上报周期=%ld where id=%d;", tablename,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakePreCheckStatusEventconfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeStatusEventConfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeStatusEventConfiguration.whetherToUpload, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeStatusEventConfiguration.whetherToUploadPeriodically, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeStatusEventConfiguration.uploadCycle, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.whetherToUpload, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeForceDetectionDataSetEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.whetherToUpload, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.whetherToUploadPeriodically, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[0].brakeOnOffTimeEventConfiguration.uploadCycle, \
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//抱闸制动器1
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCHoldingBrakeContactor2)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",抱闸制动器名称=\"%s\",抱闸制动器类型=%d,抱闸预检状态事件配置修改时间=%ld,抱闸预检状态事件配置是否上报=\"%s\",抱闸预检状态事件配置是否周期上报=\"%s\", 抱闸预检状态事件配置上报周期=%ld,抱闸状态事件配置修改时间=%ld,抱闸状态事件配置是否上报=\"%s\",抱闸状态事件配置是否周期上报=\"%s\", 抱闸状态事件配置上报周期=%ld,抱闸力检测数据集事件配置修改时间=%ld,抱闸力检测数据集事件配置是否上报=\"%s\",抱闸力检测数据集事件配置是否周期上报=\"%s\", 抱闸力检测数据集事件配置上报周期=%ld,抱闸打开关闭时间事件配置修改时间=%ld,抱闸打开关闭时间事件配置是否上报=\"%s\",抱闸打开关闭时间事件配置是否周期上报=\"%s\", 抱闸打开关闭时间事件配置上报周期=%ld where id=%d;", tablename,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakePreCheckStatusEventconfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeStatusEventConfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeStatusEventConfiguration.whetherToUpload, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeStatusEventConfiguration.whetherToUploadPeriodically, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeStatusEventConfiguration.uploadCycle, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.whetherToUpload, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeForceDetectionDataSetEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.time, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.whetherToUpload, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.whetherToUploadPeriodically, \
                VirtualDeviceALL.VirtualDevice[idnum].holdingBrakeContactor[1].brakeOnOffTimeEventConfiguration.uploadCycle, \
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//抱闸制动器2
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCpermanentMagnetDataSetEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].permanentMagnetDataSetEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].permanentMagnetDataSetEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].permanentMagnetDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].permanentMagnetDataSetEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCBrakeStrokeFeedbackSwitch1)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",制动器行程反馈开关名称=\"%s\",制动器行程反馈开关类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[0].brakeStrokeFeedbackSwitchDataSetEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCBrakeStrokeFeedbackSwitch2)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",制动器行程反馈开关名称=\"%s\",制动器行程反馈开关类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeStrokeFeedbackSwitch[1].brakeStrokeFeedbackSwitchDataSetEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbrakeHeatDetectionSensor1)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",制动器热检测传感器名称=\"%s\",制动器热检测传感器类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[0].brakeThermalDetectionSensorStatisticalDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbrakeHeatDetectionSensor2)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",制动器热检测传感器名称=\"%s\",制动器热检测传感器类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeHeatDetectionSensor[1].brakeThermalDetectionSensorStatisticalDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {
            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCbrakePadWearSensorDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].brakePadWearSensorDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].brakePadWearSensorDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].brakePadWearSensorDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].brakePadWearSensorDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCntcTempProtectCriticalPointEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].ntcTempProtectCriticalPointEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].ntcTempProtectCriticalPointEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].ntcTempProtectCriticalPointEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].ntcTempProtectCriticalPointEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCelevatorCurrentPositionInfoEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorCurrentPositionInfoEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorCurrentPositionInfoEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorCurrentPositionInfoEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorCurrentPositionInfoEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCelevatorMileageEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorMileageEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorMileageEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorMileageEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorMileageEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCrunDataEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].runDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].runDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].runDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].runDataEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvisionElectricVehicleEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].visionElectricVehicleEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].visionElectricVehicleEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].visionElectricVehicleEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].visionElectricVehicleEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvisionPryingDoorEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].visionPryingDoorEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].visionPryingDoorEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].visionPryingDoorEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].visionPryingDoorEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvisionSmokeEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].visionSmokeEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].visionSmokeEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].visionSmokeEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].visionSmokeEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvisionTrappedEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].visionTrappedEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].visionTrappedEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].visionTrappedEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].visionTrappedEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvisionFallEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].visionFallEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].visionFallEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].visionFallEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].visionFallEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvisionPersonEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].visionPersonEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].visionPersonEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].visionPersonEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].visionPersonEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCvoiceRequestSignalEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].voiceRequestSignalEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].voiceRequestSignalEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].voiceRequestSignalEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].voiceRequestSignalEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCinternalCallStatusEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].internalCallStatusEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].internalCallStatusEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].internalCallStatusEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].internalCallStatusEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCfrontBackDoorInternalCallRegistrationCommandEventConfig)==0)


    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].frontBackDoorInternalCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].frontBackDoorInternalCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].frontBackDoorInternalCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].frontBackDoorInternalCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCfrontDoorInternalCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorInternalCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorInternalCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorInternalCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorInternalCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCbackDoorInternalCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].backDoorInternalCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorInternalCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorInternalCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorInternalCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCmainControlPanelButtonStatisticsEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].mainControlPanelButtonStatisticsEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].mainControlPanelButtonStatisticsEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].mainControlPanelButtonStatisticsEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].mainControlPanelButtonStatisticsEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);
        }
    }
    if(strcmp(tablename,HCauxiliaryControlPanelButtonStatisticsEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].auxiliaryControlPanelButtonStatisticsEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].auxiliaryControlPanelButtonStatisticsEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].auxiliaryControlPanelButtonStatisticsEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].auxiliaryControlPanelButtonStatisticsEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HChandicappedControlPanelButtonStatisticsEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].handicappedControlPanelButtonStatisticsEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedControlPanelButtonStatisticsEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedControlPanelButtonStatisticsEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedControlPanelButtonStatisticsEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCdoorMachinePreMaintenanceStatusEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorMachinePreMaintenanceStatusEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorMachinePreMaintenanceStatusEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorMachinePreMaintenanceStatusEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorMachinePreMaintenanceStatusEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCdoorLockShortCircuitFaultDetectionEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorLockShortCircuitFaultDetectionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorLockShortCircuitFaultDetectionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorLockShortCircuitFaultDetectionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorLockShortCircuitFaultDetectionEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }

    }
    if(strcmp(tablename,HCfontcarDoorLock)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,轿门锁统计数据事件配置修改时间=%ld,轿门锁统计数据事件配置是否上报=\"%s\",轿门锁统计数据事件配置是否周期上报=\"%s\", 轿门锁统计数据事件配置上报周期=%ld,轿门锁锁通断状态事件配置修改时间=%ld,轿门锁锁通断状态事件配置是否上报=\"%s\",轿门锁锁通断状态事件配置是否周期上报=\"%s\", 轿门锁锁通断状态事件配置上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockStatisticsEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[0].carDoorLockOnOffStateEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//前门轿门锁
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontdoorPanel)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,门板检测数据事件配置修改时间=%ld,门板检测数据事件配置是否上报=\"%s\",门板检测数据事件配置是否周期上报=\"%s\", 门板检测数据事件配置上报周期=%ld,门板统计数据事件配置修改时间=%ld,门板统计数据事件配置是否上报=\"%s\",门板统计数据事件配置是否周期上报=\"%s\", 门板统计数据事件配置上报周期=%ld,门板状态数据事件配置修改时间=%ld,门板状态数据事件配置是否上报=\"%s\",门板状态数据事件配置是否周期上报=\"%s\", 门板状态数据事件配置上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorPanelDetectionDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorPanelDetectionDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorPanelDetectionDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorPanelDetectionDataEventConfig.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatisticsEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatisticsEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatisticsEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatisticsEventConfig.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatusDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatusDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatusDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[0].doorStatusDataEventConfig.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontdoorBall)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[0].doorBallDataSetEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[0].doorBallDataSetEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[0].doorBallDataSetEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[0].doorBallDataSetEventConfig.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//前门门球
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontlockHook)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[0].lockHookDataSetEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[0].lockHookDataSetEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[0].lockHookDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[0].lockHookDataSetEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);//前门锁钩
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }

    }
    if(strcmp(tablename,HCfontstrap)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].strap[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[0].beltDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[0].beltDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[0].beltDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[0].beltDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontarSill)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].carSill[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[0].carSillDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[0].carSillDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[0].carSillDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[0].carSillDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }

    }
    if(strcmp(tablename,HCfontslide)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontlightCurtain)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[0].slidingRailFrictionDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontsynchronousDoorMotor)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[0].specialFunctionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[0].specialFunctionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[0].specialFunctionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[0].specialFunctionEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfontasynchronousDoorMotor)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[0].doorMotorDetectionDataEventConfig.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackcarDoorLock)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,轿门锁统计数据事件配置修改时间=%ld,轿门锁统计数据事件配置是否上报=\"%s\",轿门锁统计数据事件配置是否周期上报=\"%s\", 轿门锁统计数据事件配置上报周期=%ld,轿门锁锁通断状态事件配置修改时间=%ld,轿门锁锁通断状态事件配置是否上报=\"%s\",轿门锁锁通断状态事件配置是否周期上报=\"%s\", 轿门锁锁通断状态事件配置上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockStatisticsEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carDoorLock[1].carDoorLockOnOffStateEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackdoorPanel)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,门板检测数据事件配置修改时间=%ld,门板检测数据事件配置是否上报=\"%s\",门板检测数据事件配置是否周期上报=\"%s\", 门板检测数据事件配置上报周期=%ld,门板统计数据事件配置修改时间=%ld,门板统计数据事件配置是否上报=\"%s\",门板统计数据事件配置是否周期上报=\"%s\", 门板统计数据事件配置上报周期=%ld,门板状态数据事件配置修改时间=%ld,门板状态数据事件配置是否上报=\"%s\",门板状态数据事件配置是否周期上报=\"%s\", 门板状态数据事件配置上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorPanelDetectionDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorPanelDetectionDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorPanelDetectionDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorPanelDetectionDataEventConfig.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatisticsEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatisticsEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatisticsEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatisticsEventConfig.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatusDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatusDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatusDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorPanel[1].doorStatusDataEventConfig.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackdoorBall)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[1].doorBallDataSetEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[1].doorBallDataSetEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[1].doorBallDataSetEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorBall[1].doorBallDataSetEventConfig.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbacklockHook)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[1].lockHookDataSetEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[1].lockHookDataSetEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[1].lockHookDataSetEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].lockHook[1].lockHookDataSetEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackstrap)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].strap[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[1].beltDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[1].beltDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[1].beltDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].strap[1].beltDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackarSill)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].carSill[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[1].carSillDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[1].carSillDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[1].carSillDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carSill[1].carSillDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackslide)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbacklightCurtain)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].slide[1].slidingRailFrictionDetectionDataEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbacksynchronousDoorMotor)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[1].specialFunctionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[1].specialFunctionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[1].specialFunctionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].lightCurtain[1].specialFunctionEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackasynchronousDoorMotor)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].synchronousDoorMotor[1].doorMotorDetectionDataEventConfig.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCcarCarryingDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].carCarryingDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].carCarryingDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].carCarryingDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].carCarryingDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCdoorZoneSignalEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorZoneSignalEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorZoneSignalEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorZoneSignalEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorZoneSignalEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCaccelerationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].accelerationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].accelerationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].accelerationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].accelerationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HClocationDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].locationDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].locationDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].locationDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].locationDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCm232InterfaceModule)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].m232InterfaceModule.time,\
                VirtualDeviceALL.VirtualDevice[idnum].m232InterfaceModule.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].m232InterfaceModule.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].m232InterfaceModule.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfrontBackUpDownCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].frontBackUpDownCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].frontBackUpDownCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].frontBackUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].frontBackUpDownCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfrontUpDownCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].frontUpDownCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].frontUpDownCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].frontUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].frontUpDownCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackUpDownCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].backUpDownCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].backUpDownCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].backUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].backUpDownCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HChandicappedFrontUpDownCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].handicappedFrontUpDownCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedFrontUpDownCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedFrontUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedFrontUpDownCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HChandicappedBackUpDownCallRegistrationCommandEventConfig)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].handicappedBackUpDownCallRegistrationCommandEventConfig.time,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedBackUpDownCallRegistrationCommandEventConfig.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedBackUpDownCallRegistrationCommandEventConfig.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].handicappedBackUpDownCallRegistrationCommandEventConfig.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfrontDoorHallUpCallButtonActionsNumberEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallUpCallButtonActionsNumberEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfrontDoorHallDnCallButtonActionsNumberEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].frontDoorHallDnCallButtonActionsNumberEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackDoorHallUpCallButtonActionsNumberEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallUpCallButtonActionsNumberEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallUpCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallUpCallButtonActionsNumberEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackDoorHallDnCallButtonActionsNumberEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallDnCallButtonActionsNumberEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallDnCallButtonActionsNumberEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].backDoorHallDnCallButtonActionsNumberEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfonthallDoorList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,厅门检测数据事件配置修改时间=%ld,厅门检测数据事件配置是否上报=\"%s\",厅门检测数据事件配置是否周期上报=\"%s\", 厅门检测数据事件配置上报周期=%ld,厅门统计数据事件配置修改时间=%ld,厅门统计数据事件配置是否上报=\"%s\",厅门统计数据事件配置是否周期上报=\"%s\", 厅门统计数据事件配置上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorInspectionDataEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[0].hallDoorStatisticsEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfonthallDoorLockList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,层门锁通断检测事件配置是否上报=%ld,层门锁通断检测事件配置是否周期上报=\"%s\",层门锁通断检测事件配置上报周期=\"%s\", 开门数据统计事件配置修改时间=%ld,开门数据统计事件配置是否上报=%ld,开门数据统计事件配置是否周期上报=\"%s\",开门数据统计事件配置上报周期=\"%s\", 关门数据统计事件配置修改时间=%ld,关门数据统计事件配置修改时间=%ld,关门数据统计事件配置是否周期上报=\"%s\",关门数据统计事件配置上报周期=\"%s\", 关门数据统计事件配置修改时间=%ld where id=%d;",tablename,
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].instance,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].use,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorOpeningStatisticsEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[0].landingDoorClosingStatisticsEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCfonthallSill)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[0].instance,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[0].use,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.time,\
                  VirtualDeviceALL.VirtualDevice[idnum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[0].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackhallDoorList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,厅门检测数据事件配置修改时间=%ld,厅门检测数据事件配置是否上报=\"%s\",厅门检测数据事件配置是否周期上报=\"%s\", 厅门检测数据事件配置上报周期=%ld,厅门统计数据事件配置修改时间=%ld,厅门统计数据事件配置是否上报=\"%s\",厅门统计数据事件配置是否周期上报=\"%s\", 厅门统计数据事件配置上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorInspectionDataEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].hallDoorList[1].hallDoorStatisticsEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackhallDoorLockList)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,层门锁通断检测事件配置是否上报=%ld,层门锁通断检测事件配置是否周期上报=\"%s\",层门锁通断检测事件配置上报周期=\"%s\", 开门数据统计事件配置修改时间=%ld,开门数据统计事件配置是否上报=%ld,开门数据统计事件配置是否周期上报=\"%s\",开门数据统计事件配置上报周期=\"%s\", 关门数据统计事件配置修改时间=%ld,关门数据统计事件配置修改时间=%ld,关门数据统计事件配置是否周期上报=\"%s\",关门数据统计事件配置上报周期=\"%s\", 关门数据统计事件配置修改时间=%ld where id=%d;",tablename,
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].instance,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].use,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorOpeningStatisticsEventConfiguration.uploadCycle,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum]._hallDoorLockList[1].landingDoorClosingStatisticsEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackhallSill)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",名称=\"%s\",类型=%d,修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[1].instance,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[1].use,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.time,\
                  VirtualDeviceALL.VirtualDevice[idnum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUpload,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.whetherToUploadPeriodically,\
                 VirtualDeviceALL.VirtualDevice[idnum].hallSill[1].landingDoorLockOnOffDetectionEventConfiguration.uploadCycle,\
                idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCdoorInspectionDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorInspectionDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorInspectionDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorInspectionDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorInspectionDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCdoorStatisticsEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorStatisticsEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorStatisticsEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorStatisticsEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorStatisticsEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCdoorInherentDataEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].doorInherentDataEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].doorInherentDataEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].doorInherentDataEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].doorInherentDataEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCelevatorSlippageDataDetectionEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorSlippageDataDetectionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorSlippageDataDetectionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorSlippageDataDetectionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].elevatorSlippageDataDetectionEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbrakeForceDetectionSteelRopesSlipEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].brakeForceDetectionSteelRopesSlipEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeForceDetectionSteelRopesSlipEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeForceDetectionSteelRopesSlipEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].brakeForceDetectionSteelRopesSlipEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCnumberOfStartsOnTheFirstFloorEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].numberOfStartsOnTheFirstFloorEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].numberOfStartsOnTheFirstFloorEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].numberOfStartsOnTheFirstFloorEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].numberOfStartsOnTheFirstFloorEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCbackToTheBaseStationSlipEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].backToTheBaseStationSlipEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].backToTheBaseStationSlipEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].backToTheBaseStationSlipEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].backToTheBaseStationSlipEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    if(strcmp(tablename,HCvoltageDetectionEventConfiguration)==0)

    {
        sprintf(sql, "update %s set 电梯ID=\"%s\",设备注册SN码=\"%s\",修改时间=%ld,是否上报=\"%s\",是否周期上报=\"%s\", 上报周期=%ld where id=%d;", tablename, \
                VirtualDeviceALL.VirtualDevice[idnum].elevatorid, VirtualDeviceALL.VirtualDevice[idnum].sn, \
                VirtualDeviceALL.VirtualDevice[idnum].voltageDetectionEventConfiguration.time,\
                VirtualDeviceALL.VirtualDevice[idnum].voltageDetectionEventConfiguration.whetherToUpload,\
                VirtualDeviceALL.VirtualDevice[idnum].voltageDetectionEventConfiguration.whetherToUploadPeriodically,\
                VirtualDeviceALL.VirtualDevice[idnum].voltageDetectionEventConfiguration.uploadCycle,idnum);
        rc = sqlite3_exec(db, sql, NULL, NULL, &errmsg);
        if(rc != SQLITE_OK)
        {

            HC_PRINT("select error : %s\n",errmsg);

        }
    }
    sqlite3_close(db);
    return ERR_COMMON_SUCCESS;
}
