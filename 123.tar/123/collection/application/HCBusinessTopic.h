﻿
#ifndef HCBUSINESSTOPIC_H
#define HCBUSINESSTOPIC_H
#include"common.h"
#pragma pack (1)

typedef struct
{

    char HCcarDoorNumberEvent_Pub[512];//轿门个数
    char HCdoorBallDataSet_Pub[512];//门球对中
    char HCbeltDetectionData_Pub[512];//皮带打滑
    char HCcarSillDetectionData_Pub[512];//摩擦力
    char HClockHookData_Pub[512];//锁钩故障
    char HChallDoorStatistics_Pub[512];//弹簧自闭力
    char HChallDoorInspectionData_Pub[512];//重锤检测
    char HCerrorCodeEvent_Pub[512];//门故障次数
    char HCcarDoorLockStatisticalData_Pub[512];//轿门开关次数
    char HCdoorPanelStatisticalData_Pub[512];//异常反复开关门次数
    char HCcarDoorLockOnOffState_Pub[512];//门锁短接
    char HCspecialFunction_Pub[512];//光幕
    char HCsyn_doorMotorDetectionData_Pub[512];//正常Max电流 - 同步门电机
    char HCasy_doorMotorDetectionData_Pub[512];//正常Max电流 - 异步门电机
    char HCsyn_permanentMagnets_Pub[512];//永磁体-电流
    char HCbrakeThermalDetectionSensorStatistics_Pub[512];//制动器热检测传感器-抱闸动作次数
    char HCbrakeClosingAfterSlip_Pub[512];//刹车片磨损传感器-打滑量
    char HCrunData_Pub[512];//轿厢-额定运行速度
    char HCmotorRatedInfo_Pub[512];//电机额定转速，额定电流
    char HCbrakeForceDetectionSteelRopesSlip_Pub[512];//抱闸力检测位移量，抱闸力检测打滑量
    char HCelevatorMileage_Pub[512];//运行里程
    char HCelevatorCurrentPositionInfo_Pub[512];//当前高度
    char HCbrakeFaultEvent_Pub[512];//抱闸制动器-故障
    char HCbrakeONOFFtimeEvent_Pub1[512];//抱闸制动器-卡阻（抱闸1）
    char HCbrakeONOFFtimeEvent_Pub2[512];//抱闸制动器-卡阻（抱闸2）
    char HCcontrolCabinetStatistics_Pub[512];//运行时间运行次数
    char HCfrontDoorHallUpAndDownCallButtonActionsNumber_Pub[512];//前门-外呼板（丄召-下召）
    char HCbackDoorHallUpAndDownCallButtonActionsNumber_Pub[512];//后门-外呼板（丄召-下召）
    char HCmainControlPanelButtonStatisticsEvent_Pub[512];//主操纵盘按钮
    char HCauxiliaryControlPanelButtonStatisticsEvent_Pub[512];//辅助操纵盘按钮
    char HChandicappedControlPanelButtonStatisticsEvent_Pub[512];//按钮-残疾人操纵盘按钮
    char HCinterfaceBoardStatistics_Pub[512];//接口板-统计数据(电容/能耗/发电量)
    char HCinterfaceBoardTemperatureData_Pub[512];//接口板-接口板温度数据(IGBT温度和风扇温度)
    char HCcontrolCabinetTemperatureData_Pub[512];//控制柜-温度数据
    char HCLeftintegratedEvent_Pub[512];//左接触器-整合事件
    char HCRightintegratedEvent_Pub[512];//右接触器-整合事件
    char HCRuntintegratedEvent_Pub[512];//运行接触器-整合事件
    char HCFXintegratedEvent_Pub[512];//FX接触器-整合事件
    char HCSafetyloop_Pub[512];//（39）安全回路-电压检测事件
    char HCErrorCodeEvent_Pub[512];//控制柜-NICE3000-故障代码
    char HCCAN1communicationData_Pub[512];//CAN1通讯数据
    char HCSPI1communicationData_Pub[512];//SPI1通讯数据
    char HCSPI2communicationData_Pub[512];//SPI2通讯数据
    char HCMOD1communicationData_Pub[512];//MOD1通讯数据
    char HCMOD2communicationData_Pub[512];//MOD2通讯数据
    char HC4851communicationData_Pub[512];//485-1通讯数据
    char HC485TwoCommunicationData_Pub[512];//485-2通讯数据
    char HCserialCommunicationData_Pub[512];//串口通讯数据

    //实时上报数据
    char HCelevatorManagementElevatorDisplayEvent_Pub[512];//直梯-电梯管理-电梯展示事件
    char HCelevatorManagementBasicInformationEvent_Pub[512];//直梯-电梯管理-基本信息事件
    char HCbuildingScreen_Pub[512];//直梯-楼栋大屏
    char HCHoistwayHolographic_Pub[512];//直梯-井道全息
    char HCelevatorComprehensiveFaultInformation_Pub[512];//直梯-电梯综合故障信息

}ST_motorRatedInfo_Collecttion_Topic;
typedef struct
{
    //机器人发布
    char HCagvInformationEventTopic_Pub[512];//机器人乘梯实时数据
    char HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[512]; //机器人乘梯楼层对照数据
    char HCfrontDoorOpenKeepCommandTopic_Pub[512];//机器人乘梯前门开关门响应Topic
    char HCouterCallLiftTopic_Pub[512];//外呼响应
    char HCinnerCallLiftTopic_Pub[512];//内呼响应
    char HCfrontDoorCloseCommand_Pub[512];//机器人关门响应TOPIC
}ST_Robot_Pub_Topic;
typedef struct
{
    //机器人订阅
    char HCfrontDoorOpenKeepCommandTopic_Sub[512];//机器人乘梯前门开关门响应Topic
    char HCouterCallLiftTopic_Sub[512];//机器人乘梯外呼响应Topic
    char HCinnerCallLiftTopic_Sub[512];//机器人乘梯内呼响应Topic
    char HCfrontDoorCloseCommand_Sub[512];//机器人关门响应TOPIC
}ST_Robot_Sub_Topic;

typedef struct
{

    ST_Robot_Pub_Topic Robot_Pub_Topic;
    ST_Robot_Sub_Topic Robot_Sub_Topic;
}ST_Topic_InforMation;
typedef struct
{
    char HCDevice_Pub[512]; //虚拟设备
    ST_motorRatedInfo_Collecttion_Topic motorRatedInfo_Collecttion_Topic[3];
    ST_Topic_InforMation Topic_InforMation[3];
}ST_Topic_AllInfor;
#pragma pack ()
extern char *HCBusinessTopicBulid(char *method);
extern void HCSubTopicInit(void);

extern ST_Topic_AllInfor Topic_AllInfor;
#endif



