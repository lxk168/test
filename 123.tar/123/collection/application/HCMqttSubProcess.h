﻿
#ifndef HCMQTTSUBPROCESS_H
#define HCMQTTSUBPROCESS_H
#include "common.h"

extern void *HC_MQTTSubProcess_Thread(void);



#endif



