﻿
#ifndef HCBUSINESSCJSONANALYSIS_H
#define HCBUSINESSCJSONANALYSIS_H
#include "HCBusinessCjsonAnalysis.h"
#include "common.h"
#include "public/HCJson.h"
#include"public/HCPublicStruct.h"

typedef struct
{

    long uploadCycle; //上传时间
    char whetherToUpload[6];//是否上传
    char whetherToUploadPeriodically[6];//是否周期上传

}ST_SetInfoAnalysis;

extern   cJSON* HC_CJSON_PayloadInit(char * analysis,char *id);
extern ST_SetInfoAnalysis *HC_CJSON_payloadFind(cJSON* cjson_find,char*findtemp);
extern cJSON* HC_CJSON_MetaDataInit(char * analysis,char *id);
extern long HC_CJSON_metadataFind(cJSON* cjson_find,char*findtemp);
extern ST_SetInfo *HC_CJSON_Config_Out(cJSON* cjson_desired,cJSON* cjson_metadata,char*findtemp);
extern int HCjsonFile(char *filename);
extern int HC_VirtualdeviceVersionGet(char * analysis);//(1) 获取虚拟设备的版本号
extern int HC_VirtualdeviceUpgradeVersionGet(char * analysis);

#endif



