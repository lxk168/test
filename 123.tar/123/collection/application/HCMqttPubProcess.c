﻿#include"application/HCMqttPubProcess.h"
#include"application/HCBusinessCJson.h"
#include"application/HCBusinessTopic.h"
#include"application/HCBusinessCode.h"
#include"common.h"
static char *g_display_param_addr = NULL;
static char *g_common_data_addr = NULL;
static sem_t *g_elevator_data_sem = NULL;
static char * g_elevator_door_machine_t= NULL;// 门机预维保
static char * g_elevator_traction_machine_t= NULL;// 曳引机质量
static char * g_elevator_transport_t= NULL;// 乘运质量
static char * g_elevator_ctrl_sys_t= NULL;// 控制系统质量
static char * g_elevator_safety_circuit_t= NULL;// 安全回路质量
static char * g_elevator_light_curtain_t= NULL;// 光幕
struct ST_elevator_common_data_t  elevator_common_data_t[3];
struct ST_elevator_door_machine_t elevator_door_machine_t[3];// 门机预维保
struct ST_elevator_traction_machine_t elevator_traction_machine_t[3];// 曳引机质量
struct ST_elevator_transport_t elevator_transport_t[3];// 乘运质量
struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t[3];// 控制系统质量
struct ST_elevator_safety_circuit_t elevator_safety_circuit_t[3];// 安全回路质量
struct ST_elevator_light_curtain_t elevator_light_curtain_t[3];// 光幕


static char *create_shared_memory(char *name, int len);

char *create_shared_memory(char *name, int len)
{
    int fd;
    int rc;
    char *addr;

    fd = shm_open(name, O_RDONLY|O_CREAT, 0);
    if (fd == -1)
    {
        fprintf(stderr, "shm_open %s fail: [%s]\n", name, strerror(errno));
        return NULL;
    }

    addr = mmap(NULL, len, PROT_READ, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED)
    {
        return NULL;
    }

    rc = close(fd);
    if (rc == -1)
    {
        fprintf(stderr, "close %s fail", name);
        return NULL;
    }

    return addr;
}


void *HCCollectionProcess_Thread(void)
{

    memset(&elevator_common_data_t,0x0,sizeof (elevator_common_data_t));
    memset(&elevator_door_machine_t,0x0,sizeof (elevator_door_machine_t));
    memset(&elevator_traction_machine_t,0x0,sizeof (elevator_traction_machine_t));
    memset(&elevator_transport_t,0x0,sizeof (elevator_transport_t));
    memset(&elevator_ctrl_sys_t,0x0,sizeof (elevator_ctrl_sys_t));
    memset(&elevator_safety_circuit_t,0x0,sizeof (elevator_safety_circuit_t));
    memset(&elevator_light_curtain_t,0x0,sizeof (elevator_light_curtain_t));
    g_display_param_addr = create_shared_memory(
                SHARED_OBJ_DISPLAY_PARAM, sizeof( struct ST_elevator_display_param_t) * 3);
    if (g_display_param_addr == NULL)
    {
        return NULL;
    }

    g_common_data_addr = create_shared_memory(
                SHARED_OBJ_COMMON_DATA, sizeof(struct  ST_elevator_common_data_t) * 3);
    if (g_common_data_addr == NULL)
    {
        return NULL;
    }
    g_elevator_door_machine_t = create_shared_memory(
                SHARED_OBJ_DOOR_MACHINE, sizeof(struct  ST_elevator_door_machine_t) * 3);
    if (g_elevator_door_machine_t == NULL)
    {
        return NULL;
    }

    g_elevator_traction_machine_t = create_shared_memory(
                SHARED_OBJ_TRACTION_MACHINE, sizeof(struct  ST_elevator_traction_machine_t) * 3);
    if (g_elevator_traction_machine_t == NULL)
    {
        return NULL;
    }
    g_elevator_transport_t = create_shared_memory(
                SHARED_OBJ_TRANSPORT, sizeof(struct  ST_elevator_transport_t) * 3);
    if (g_elevator_transport_t == NULL)
    {
        return NULL;
    }
    g_elevator_ctrl_sys_t = create_shared_memory(
                SHARED_OBJ_CTRL_SYS, sizeof(struct  ST_elevator_ctrl_sys_t) * 3);
    if (g_elevator_ctrl_sys_t == NULL)
    {
        return NULL;
    }
    g_elevator_safety_circuit_t = create_shared_memory(
                SHARED_OBJ_SAFETY_CIRCUIT, sizeof(struct  ST_elevator_safety_circuit_t) * 3);
    if (g_elevator_safety_circuit_t == NULL)
    {
        return NULL;
    }
    g_elevator_light_curtain_t = create_shared_memory(
                SHARED_OBJ_LIGHT_CURTAIN, sizeof(struct  ST_elevator_light_curtain_t) * 3);
    if (g_elevator_light_curtain_t == NULL)
    {
        return NULL;
    }


    g_elevator_data_sem = sem_open(SEM_OBJ_ELEVATOR_DATA, O_RDONLY|O_CREAT, 0);
    if (g_elevator_data_sem == SEM_FAILED)
    {
        fprintf(stderr, "sem_open %s fail: [%s]\n", SEM_OBJ_ELEVATOR_DATA, strerror(errno));
        return NULL;
    }
    sem_post(g_elevator_data_sem);
    while (1)
    {
        if (sem_trywait(g_elevator_data_sem) == 0)
        {
            memcpy(&elevator_common_data_t, g_common_data_addr, sizeof(elevator_common_data_t));
//            HC_PRINT("common_floor:%d",elevator_common_data_t->car_status);
            memcpy(&elevator_door_machine_t, g_elevator_door_machine_t, sizeof(elevator_door_machine_t));
//            HC_PRINT("门机预维保实时结果:%d",elevator_door_machine_t->pre_maintain_result);
//            HC_PRINT("door_machine_floor:%d",elevator_door_machine_t->current_floor);
//            HC_PRINT("1本次关门最大电流数:%d",elevator_door_machine_t->close_door1_max_current);
//            HC_PRINT("对打滑检测结果:%d",elevator_door_machine_t->front_door_double_slip_check_result);
//            HC_PRINT("重锤检测结果:%d",elevator_door_machine_t->front_door_heavy_hammer_check_result);
//            HC_PRINT("前门锁抬起时间:%d",elevator_door_machine_t->front_door_lock_up_time);
//            HC_PRINT("hou门对中结果:%d",elevator_door_machine_t->back_door_center_result);
//            HC_PRINT("前门对中结果:%d",elevator_door_machine_t->front_door_center_result);
//            HC_PRINT("前门自闭力系数百分比:%d",elevator_door_machine_t->front_door_self_closing_coefficient);

            memcpy(&elevator_traction_machine_t, g_elevator_traction_machine_t, sizeof(elevator_traction_machine_t));
//            HC_PRINT("电流:%ld",elevator_traction_machine_t->no_load_current);

            memcpy(&elevator_transport_t, g_elevator_transport_t, sizeof(elevator_transport_t));
            memcpy(&elevator_ctrl_sys_t, g_elevator_ctrl_sys_t, sizeof(elevator_ctrl_sys_t));
            memcpy(&elevator_safety_circuit_t, g_elevator_safety_circuit_t, sizeof(elevator_safety_circuit_t));
//            HC_PRINT("首端电压:%d",elevator_safety_circuit_t->head_voltage);
//            HC_PRINT("末端稳定电压:%d",elevator_safety_circuit_t->end_stable_voltage);
//            HC_PRINT("KM1 吸合电压:%d",elevator_safety_circuit_t->km1_pullin_voltage);
//            HC_PRINT("控制柜温度:%d",elevator_safety_circuit_t->control_cabinet_temperature);
//            HC_PRINT("接触器温度:%d",elevator_safety_circuit_t->contactor_temperature);

            memcpy(&elevator_light_curtain_t, g_elevator_light_curtain_t, sizeof(elevator_light_curtain_t));
//            HC_PRINT("前门-通信光幕总工作状态 =%d",elevator_light_curtain_t->front_door_light_curtain_total_status);
//            HC_PRINT("前门-光管工作状态（第1-48管）=%s",elevator_light_curtain_t->front_door_light_curtain_status);
//            HC_PRINT("前门-光管强度值=%d",elevator_light_curtain_t->front_door_light_tube_intensity);
//            HC_PRINT("前门-光管对数=%d",elevator_light_curtain_t->front_door_light_tube_logarithm);


            sem_post(g_elevator_data_sem);
        }
        usleep(100000);


    }
}
void *HCMqttPubProcess_Thread(void)
{
    int i=0;
    while(1)
    {
//        for (i=0;i<1;i++) {
//            if(elevator_common_data_t[i].slave!=0)
//            {

//            }
//            //门机
//            if(elevator_door_machine_t[i].elevator_id!=0)
//            {
//                //(1)轿门个数
//                HC_carDoorNumberEvent_Upload(i,elevator_door_machine_t[i]);
//                usleep(100000);
//                //(2)门球对中
//                HC_DoorBallDataSet_Upload(i,elevator_door_machine_t[i],elevator_common_data_t[i]);
//                usleep(500000);
//                //(3)皮带打滑
//                HC_BeltDetectionData_Upload(i,elevator_door_machine_t[i]);
//                usleep(500000);
//                //(4)轿厢地坎摩擦力
//                HC_CarSillDetectionData_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//                usleep(100000);
//                //(5)锁钩故障
//                HC_LockHookDataSet_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//                usleep(100000);
//                //(6)厅门-弹簧自闭力，无值
//                HC_HallDoorStatistics_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//                usleep(100000);
//                //(7)重锤检测
//                HC_HallDoorInspectionData_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//                usleep(100000);
//                //(9)轿厢-轿门-轿门锁检测开关门次数
//                HC_HCCarDoorLockStatisticalData_Upload( i,  elevator_common_data_t[i],elevator_safety_circuit_t[i]);
//                usleep(100000);
//                //(10)轿厢-轿门-轿门门板-异常反复开关门次数(无实时数据)
//                HC_HCDoorPanelStatisticalData_Upload( i,  elevator_door_machine_t[i]);
//                usleep(100000);
//                //(11)轿厢-轿门-轿门门锁短接(无实时数据)
//                HC_HCDoorLockShortCircuitFaultDetection_Upload(i, elevator_door_machine_t[i]);
//                usleep(100000);
//                //(13）轿厢-轿门-同步门电机正常Max电流
//                HC_HCSyncDoorMotorDetectionData_Upload(i, elevator_door_machine_t[i],elevator_common_data_t[i]);
//                usleep(100000);
//            }
//            //曳引机
//            if(elevator_traction_machine_t[i].elevator_id!=0)
//            {
//                //(21）机房设备-同步曳引机-永磁体-电流
//                HC_HCPermanentMagnetDataSet_Upload(i,elevator_traction_machine_t[i]);
//                usleep(100000);
//                //(22)机房设备-同步曳引机-制动器热检测传感器-抱闸1动作次数
//                HC_HCBrakeThermalDetectionSensorStatistics_Upload(i,elevator_traction_machine_t[i]);
//                usleep(100000);
//                //(23)机房设备-同步曳引机-刹车片磨损传感器-打滑量
//                HC_HCBrakePadWearSensorData_Upload(i,elevator_traction_machine_t[i]);
//                usleep(100000);
//                //(26)曳引机质量-井道-钢丝绳-抱闸力检测钢丝绳打滑量事件
//                HC_HCBrakeForceDetectionSteelRopesSlip_Upload(i,elevator_traction_machine_t[i]);
//                usleep(100000);
//                //(30-1)曳引机-抱闸制动器(卡阻)-抱闸打开关闭时间事件（抱闸1&2）
//                HC_HCBrakeOnOfftimeEvent_Upload(i,elevator_traction_machine_t[i]);
//                usleep(100000);
//                //(31)机房设备-控制柜-运行时间(数据未采集)、次数
//                HC_HCControlCabinetStatistics_Upload(i,elevator_traction_machine_t[i]);

//            }
//            // 乘运质量
//            if(elevator_transport_t[i].elevator_id!=0)
//            {

//            }
//            //控制系统质量
//            if(elevator_ctrl_sys_t[i].elevator_id!=0)
//            {
//                HC_HCErrorCodeEvent_Upload( i,  elevator_ctrl_sys_t[i]);
//                usleep(100000);
//                //（32-1）厅外显示板-按钮-上召、下召
//                HC_HCfrontDoorHallUpAndDownCallButtonActionsNumber_Upload( i,  elevator_ctrl_sys_t[i]);
//                usleep(100000);
//                //（32）轿厢-轿内-轿内指令板-按钮-主操纵盘（需要有有效按钮数数据）
//                HC_HCMainControlPanelButtonStatisticsEvent_Upload( i,  elevator_ctrl_sys_t[i]);
//                usleep(100000);
//                //（35）控制柜-接口板-电容容量/能耗/发电量（母线额定电容容量、电容容量数据缺失其一）(能耗数据、发电量未分类)
//                HC_HCInterfaceBoardStatistics_Upload( i,  elevator_ctrl_sys_t[i]);
//                usleep(100000);
//                //(36)控制柜-接口板-温度(IGBT的NTC温度数据未采集)
//                HC_HCInterfaceBoardTemperatrueData_Upload( i,  elevator_ctrl_sys_t[i]);
//                usleep(100000);
//                //(38-1)机房设备-控制柜-左接触器（抱闸1）(接触器主极点温度、接触器触点额定温度缺失其一)
//                HC_HCLeftContactorIntegratedEvent_Upload( i,  elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
//                usleep(1000000);
//                //(38-2)机房设备-控制柜-右接触器（抱闸2）(接触器主极点温度、接触器触点额定温度缺失其一)
//                HC_HCRightContactorIntegratedEvent_Upload( i,  elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
//                usleep(100000);
//                //(38-3)机房设备-控制柜-运行接触器(接触器主极点温度、接触器触点额定温度缺失其一)
//                HC_HCRunContactorIntegratedEvent_Upload( i,  elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
//                usleep(100000);
//                //(38-4)机房设备-控制柜-封星接触器(接触器主极点温度、接触器触点额定温度缺失其一)
//                HC_HCFxContactorIntegratedEvent_Upload( i,  elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
//                usleep(100000);


//            }
//            if(elevator_safety_circuit_t[i].elevator_id!=0)
//            {
//                //(37)控制柜-控制柜温度
//                HC_HCControlCabinetTemperatrueData_Upload(i,elevator_safety_circuit_t[i]);
//                usleep(1000000);
//                //(39)安全回路-电压
//                HC_HCSafetyloop_Upload(i,elevator_safety_circuit_t[i]);
//                usleep(1000000);
//            }
//            if(elevator_light_curtain_t[i].elevator_id!=0)
//            {
////                HC_HCLightPipe1to48BlockingState_Upload( i,  elevator_light_curtain_t[i]);
////                usleep(100000);
//            }

//        }
//         //光幕（已经拍摄）
//         HC_HCLightPipe1to48BlockingState_Upload( 0,  elevator_light_curtain_t[i]);
//        usleep(300000);
        //2022.1.7——test.门机：

            //(1)轿门个数
//            HC_carDoorNumberEvent_Upload(i,elevator_door_machine_t[i]);
//            usleep(100000);
//            //(2)门球对中
//            HC_DoorBallDataSet_Upload(i,elevator_door_machine_t[i],elevator_common_data_t[i]);
//            usleep(100000);
//            //(3)皮带打滑
 //          HC_BeltDetectionData_Upload(i,elevator_door_machine_t[i]);
//            usleep(100000);
//            //(4)轿厢地坎摩擦力
//            HC_CarSillDetectionData_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//            usleep(100000);
//            //(5)锁钩故障
//            HC_LockHookDataSet_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//            usleep(100000);
//            //(6)厅门-弹簧自闭力
//            HC_HallDoorStatistics_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//            usleep(3000000);
//            //(7)重锤检测
//            HC_HallDoorInspectionData_Upload( i,  elevator_door_machine_t[i],elevator_common_data_t[i]);
//            usleep(100000);
//            //(9)轿厢-轿门-轿门锁检测开关门次数(无实时数据)
//            HC_HCCarDoorLockStatisticalData_Upload( i,  elevator_common_data_t[i],elevator_safety_circuit_t[i]);
//            usleep(100000);
//            //(10)轿厢-轿门-轿门门板-异常反复开关门次数(无实时数据)
//            HC_HCDoorPanelStatisticalData_Upload( i,  elevator_door_machine_t[i], elevator_common_data_t[i]);
//            usleep(100000);
//            //(11)轿厢-轿门-轿门门锁短接(无实时数据)
//            HC_HCDoorLockShortCircuitFaultDetection_Upload(i, elevator_door_machine_t[i]);
//            usleep(100000);
//            //(13）轿厢-轿门-同步门电机正常Max电流
//            HC_HCSyncDoorMotorDetectionData_Upload(i, elevator_door_machine_t[i],elevator_common_data_t[i]);
//            usleep(100000);

        //2021.1.7——曳引机-Test
//        //(21）机房设备-同步曳引机-永磁体-电流
//        HC_HCPermanentMagnetDataSet_Upload(i,elevator_traction_machine_t[i]);
//        usleep(200000);
//        //(22)机房设备-同步曳引机-制动器热检测传感器-抱闸1动作次数
//        HC_HCBrakeThermalDetectionSensorStatistics_Upload(i,elevator_traction_machine_t[i]);
//        usleep(200000);
//        //(23)机房设备-同步曳引机-刹车片磨损传感器-打滑量
//        HC_HCBrakePadWearSensorData_Upload(i,elevator_traction_machine_t[i]);
//        usleep(200000);
//        //(24)轿厢-额定运行速度
//         HC_HCrunData_Upload(i,elevator_traction_machine_t[i],elevator_common_data_t[i]);
//         usleep(200000);
//         //(25)机房设备-同步曳引机-电机额定转速，额定电流
//         HC_HCMotorRatedInfo_Upload(i,elevator_traction_machine_t[i]);
//         usleep(500000);
//         //(26)曳引机质量-井道-钢丝绳-抱闸力检测钢丝绳打滑量事件
//         HC_HCBrakeForceDetectionSteelRopesSlip_Upload(i,elevator_traction_machine_t[i]);
//         usleep(200000);
//         //(27)轿厢-电梯运行里程
//         HC_HCElevatorMileage_Upload(i,elevator_traction_machine_t[i]);
//         usleep(500000);
//           //(28)轿厢-电梯当前位置信息
//         HC_HCElevatorCurrentPositionInfo_Upload(i,elevator_traction_machine_t[i]);
//         usleep(500000);
//         //(29)机房设备-同步曳引机-抱闸制动器-抱闸故障事件
//         HC_HCbrakeFaultEvent_Upload(i,elevator_traction_machine_t[i]);
//         usleep(500000);
//        //(30-1)曳引机-抱闸制动器(卡阻)-抱闸打开关闭时间事件（抱闸1&2）
//        HC_HCBrakeOnOfftimeEvent_Upload(i,elevator_traction_machine_t[i]);
//        usleep(200000);
//        //(31)机房设备-控制柜-运行时间(数据未采集)、次数
//        HC_HCControlCabinetStatistics_Upload(i,elevator_traction_machine_t[i]);
//        usleep(100000);

//        //2022.1.11-控制系统质量
        //（32-1）厅外显示板-按钮-上召、下召
        HC_HCfrontDoorHallUpAndDownCallButtonActionsNumber_Upload(i,elevator_ctrl_sys_t[i]);
        usleep(500000);
//        //（32-2）厅外显示板-按钮-上召、下召
//        HC_HCbackDoorHallUpAndDownCallButtonActionsNumber_Upload(i,elevator_ctrl_sys_t[i]);
//        usleep(3000000);
        //（32）轿厢-轿内-轿内指令板-按钮-主操纵盘（需要有有效按钮数数据）
        HC_HCMainControlPanelButtonStatisticsEvent_Upload(i,elevator_ctrl_sys_t[i]);
        usleep(500000);
        //（33）轿厢-轿内-轿内指令板-按钮-辅助操纵盘按钮
        HC_HCAuxiliaryControlPanelButtonStatisticsEvent_Upload(i,elevator_ctrl_sys_t[i]);
        usleep(500000);
        //（34）轿厢-轿内-轿内指令板-按钮-残疾人操纵盘
        HC_HCHandicappedControlPanelButtonStatisticsEvent_Upload(i,elevator_ctrl_sys_t[i]);
        usleep(500000);
        //（35）控制柜-接口板-电容容量/能耗/发电量（母线额定电容容量、电容容量数据缺失其一）(能耗数据、发电量未分类)
        HC_HCInterfaceBoardStatistics_Upload(i,elevator_ctrl_sys_t[i]);
        usleep(500000);
        //(36)控制柜-接口板-温度(IGBT的NTC温度数据未采集)
        HC_HCInterfaceBoardTemperatrueData_Upload(i,elevator_ctrl_sys_t[i]);
        usleep(500000);
        //(38-1)机房设备-控制柜-左接触器（抱闸1）(接触器主极点温度、接触器触点额定温度缺失其一)
        HC_HCLeftContactorIntegratedEvent_Upload(i,elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
        usleep(500000);
        //(38-2)机房设备-控制柜-右接触器（抱闸2）(接触器主极点温度、接触器触点额定温度缺失其一)
        HC_HCRightContactorIntegratedEvent_Upload(i,elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
        usleep(500000);
        //(38-3)机房设备-控制柜-运行接触器(接触器主极点温度、接触器触点额定温度缺失其一)
        HC_HCRunContactorIntegratedEvent_Upload(i,elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
        usleep(500000);
        //(38-4)机房设备-控制柜-封星接触器(接触器主极点温度、接触器触点额定温度缺失其一)
        HC_HCFxContactorIntegratedEvent_Upload(i,elevator_ctrl_sys_t[i],elevator_safety_circuit_t[i]);
        usleep(500000);

        //通讯接口-CAN1通讯数据
        HC_HCCAN1communicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-SPI1
        HC_HCSPI1communicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-SPI2
        HC_HCSPI2communicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-MOD1
        HC_HCMOD1communicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-MOD2
        HC_HCMOD2communicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-485-1
        HC_HC4851communicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-485-2
        HC_HC485TwoCommunicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);
        //通讯接口-串口
        HC_HCserialCOmmunicationData_Upload(i,  elevator_ctrl_sys_t[i]);
        usleep(500000);


        //2022.1.11-安全回路质量
        //(37)控制柜-控制柜温度
        HC_HCControlCabinetTemperatrueData_Upload(i,elevator_safety_circuit_t[i]);
        usleep(500000);
        //(39)安全回路-电压
        HC_HCSafetyloop_Upload(i,elevator_safety_circuit_t[i]);
        usleep(500000);

//        //直梯-实时数据
//        //(40)直梯-电梯管理-电梯展示事件
//        HC_HCElevatorManagementElevatorDisplayEvent_Upload(i,  elevator_common_data_t[i] );
//        usleep(1000000);
//        //(41)直梯-电梯管理-电梯基本事件
//        HC_HCElevatorManagementBasicInformationEvent_Upload(i,  elevator_common_data_t[i] );
//        usleep(100000);
//        //(42)直梯-楼栋大屏
//        HC_HCBuildingScreen_Upload(i,  elevator_common_data_t[i] );
//        usleep(100000);
//        //(43)直梯-井道全息
//        HC_HCHoistwayHolographic_Upload(i,  elevator_common_data_t[i] );
//        usleep(100000);
//        //(44)直梯-电梯综合故障信息
//        HC_HCelevatorComprehensiveFaultInformation_Upload(i,  elevator_common_data_t[i] );
//        usleep(100000);


    }
}
