﻿
#ifndef HCBUSINESSCODE_H
#define HCBUSINESSCODE_H
#include "common.h"
extern int HCmethodReply_Upload(char * topic,long id ,bool flag);
extern int HC_agvInformationEvent_Upload(int id,struct ST_elevator_common_data_t elevator_common_data_t);
extern int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload(int id,struct ST_elevator_display_param_t elevator_display_param_t);
extern int  HC_internal_call(int slave,int floor); //内呼
extern int HC_outer_call(int slave,int floor,int direction);//外呼
extern int HC_open_door(int slave,int door,int sec); //开门
extern int HC_close_door(int slave,int door); //关门
extern int HC_disability_outer_call(int slave, int floor, int direction); //残障
extern int HC_comparisonTableOfRealFloorAndDisplayFloorEvent_Upload2(int id,struct ST_elevator_display_param_t elevator_display_param_t);
//2021.12.21
//(1)轿门个数
extern int HC_carDoorNumberEvent_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t);
//(2)门球对中
extern int HC_DoorBallDataSet_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t);
//(3)皮带检测数据
extern int HC_BeltDetectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t);
//(4)轿厢地坎-轿厢地坎检测门摩檫力
extern int HC_CarSillDetectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t);
//(5)锁钩-锁钩故障
extern int HC_LockHookDataSet_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t);
//(6)厅门-弹簧自闭力
extern int HC_HallDoorStatistics_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t);
//(7)厅门-门重锤检测结果
extern int HC_HallDoorInspectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t);
//(8)机房设备-控制柜-NICE3000-故障代码
extern int HC_HCErrorCodeEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//(9)轿厢-轿门-轿门锁检测开关门次数
extern int HC_HCCarDoorLockStatisticalData_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t,struct ST_elevator_safety_circuit_t elevator_safety_circuit_t );
//(10)轿厢-轿门-轿门门板-异常反复开关门次数
extern int HC_HCDoorPanelStatisticalData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t, struct ST_elevator_common_data_t elevator_common_data_t);
//(11)轿厢-轿门-轿门门锁短接
extern int HC_HCDoorLockShortCircuitFaultDetection_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t);
//(13）轿厢-轿门-同步门电机正常Max电流
extern int HC_HCSyncDoorMotorDetectionData_Upload(int id, struct ST_elevator_door_machine_t elevator_door_machine_t,struct ST_elevator_common_data_t elevator_common_data_t );

//光幕
extern int HC_HCLightPipe1to48BlockingState_Upload(int id, struct ST_elevator_light_curtain_t elevator_light_curtain_t);

//曳引机
//(21）机房设备-同步曳引机-永磁体-电流
extern int HC_HCPermanentMagnetDataSet_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(22)机房设备-同步曳引机-制动器热检测传感器-抱闸动作次数
extern int HC_HCBrakeThermalDetectionSensorStatistics_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(23)机房设备-同步曳引机-刹车片磨损传感器-打滑量
extern int HC_HCBrakePadWearSensorData_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(24)轿厢-额定运行速度
extern int HC_HCrunData_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t,struct ST_elevator_common_data_t elevator_common_data_t);
//(25)机房设备-同步曳引机-电机额定转速，额定电流
extern int HC_HCMotorRatedInfo_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(26)曳引机质量-井道-钢丝绳-抱闸力检测钢丝绳打滑量事件
extern int HC_HCBrakeForceDetectionSteelRopesSlip_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(27)轿厢-电梯运行里程
extern int HC_HCElevatorMileage_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(28)轿厢-电梯当前位置信息
extern int HC_HCElevatorCurrentPositionInfo_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(29)机房设备-同步曳引机-抱闸制动器-抱闸故障事件
extern int HC_HCbrakeFaultEvent_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(30-1)曳引机-抱闸制动器(卡阻)-抱闸打开关闭时间事件（抱闸1&2）
extern int HC_HCBrakeOnOfftimeEvent_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);
//(31)机房设备-控制柜-运行时间、次数
extern int HC_HCControlCabinetStatistics_Upload(int id, struct ST_elevator_traction_machine_t elevator_traction_machine_t);

//控制系统质量
//（32-1）厅外显示板-按钮-上召、下召
extern int HC_HCfrontDoorHallUpAndDownCallButtonActionsNumber_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
extern int HC_HCbackDoorHallUpAndDownCallButtonActionsNumber_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//（32）轿厢-轿内-轿内指令板-按钮-主操纵盘
extern int HC_HCMainControlPanelButtonStatisticsEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//（33）轿厢-轿内-轿内指令板-按钮-辅助操纵盘按钮
extern int HC_HCAuxiliaryControlPanelButtonStatisticsEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//（34）轿厢-轿内-轿内指令板-按钮-残疾人操纵盘
extern int HC_HCHandicappedControlPanelButtonStatisticsEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//（35）控制柜-接口板-电容容量/能耗/发电量
extern int HC_HCInterfaceBoardStatistics_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//(36)控制柜-接口板-温度(IGBT的NTC温度数据未采集)
extern int HC_HCInterfaceBoardTemperatrueData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//(38-1)机房设备-控制柜-左接触器（抱闸1）
extern int HC_HCLeftContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t);
//(38-2)机房设备-控制柜-右接触器（抱闸2）
extern int HC_HCRightContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t);
//(38-3)机房设备-控制柜-运行接触器
extern int HC_HCRunContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t);
//(38-4)机房设备-控制柜-封星接触器
extern int HC_HCFxContactorIntegratedEvent_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t,struct ST_elevator_safety_circuit_t  elevator_safety_circuit_t);

/*===控制柜-Nice3000-通讯接口===*/
//通讯接口-CAN1通讯数据
extern int  HC_HCCAN1communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-SPI1
extern int  HC_HCSPI1communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-SPI2
extern int  HC_HCSPI2communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-MOD1
extern int  HC_HCMOD1communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-MOD2
extern int  HC_HCMOD2communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-485-1
extern int  HC_HC4851communicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-485-2
extern int  HC_HC485TwoCommunicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);
//通讯接口-串口
extern int  HC_HCserialCOmmunicationData_Upload(int id, struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t);

//安全回路质量
//(37)控制柜-控制柜温度
extern int HC_HCControlCabinetTemperatrueData_Upload(int id, struct ST_elevator_safety_circuit_t elevator_safety_circuit_t);
//(39)安全回路-电压
extern int HC_HCSafetyloop_Upload(int id, struct ST_elevator_safety_circuit_t elevator_safety_circuit_t);

//直梯-实时数据
//(40)直梯-电梯管理-电梯展示事件
extern int HC_HCElevatorManagementElevatorDisplayEvent_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t );
//(41)直梯-电梯管理-电梯基本事件
extern int HC_HCElevatorManagementBasicInformationEvent_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t );
//(42)直梯-楼栋大屏
extern int HC_HCBuildingScreen_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t);
//(43)直梯-井道全息
extern int HC_HCHoistwayHolographic_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t);
//(44)直梯-电梯综合故障信息
extern int HC_HCelevatorComprehensiveFaultInformation_Upload(int id, struct ST_elevator_common_data_t elevator_common_data_t);



















#endif



