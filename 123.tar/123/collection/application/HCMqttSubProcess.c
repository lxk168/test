
#include "HCMqttSubProcess.h"
#include"public/HCPulicAPI.h"
#include"public/HCFileOperation.h"
#include"application/HCBusinessTopic.h"
#include"application/HCBusinessCjsonAnalysis.h"
#include"application/HCBusinessCJson.h"
#include"application/HCBusinessCode.h"
static char Mmap_Clinetadress[256]={"/userdata/usr/local/control_mqtt_client.mmap"};
void *HC_MQTTSubProcess_Thread(void )

{
    ST_MqttMmapInfo *mmapfd;
    int ReadFd= 0,WriteFd=0;
    long cmp1=0;
    long cmp2=0;
    ReadFd = open(Mmap_Clinetadress, O_RDWR);
    if (ReadFd < 0)
    {
        HC_fileOpen(&WriteFd, Mmap_Clinetadress, O_RDWR | O_CREAT);
        lseek(WriteFd, MQTTLENG-1, SEEK_SET);
        write(WriteFd, "\0", 1);
        //申请映射
        mmapfd = mmap(NULL, (size_t)MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
        if ( mmapfd == MAP_FAILED)
        {
            HC_PRINT("mmap error\n");

            HCMsgSend(__FILE__,__LINE__,"all","mmap error");
            close(ReadFd);
            close(WriteFd);
        }
        close(ReadFd);
        close(WriteFd);

        munmap( mmapfd, MQTTLENG);
        ReadFd = open(Mmap_Clinetadress, O_RDWR);

    }
    mmapfd = mmap(NULL, MQTTLENG, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
    if ( mmapfd == MAP_FAILED)
    {
        HC_PRINT("mmap error\n");
        HCMsgSend(__FILE__,__LINE__,"all","mmap error");
        close(ReadFd);
        close(WriteFd);
    }
    close(ReadFd);
    close(WriteFd);
    mmapfd->finishflag=0;
    mmapfd->time=0;

    while (1){

        cmp2=mmapfd->time;
        if(cmp1!=cmp2)
        {
            cmp1=cmp2;
            HC_PRINT("topic=%s \n json=%s",mmapfd->topic,mmapfd->mqttdata);
            Timer timer;
            InitTimer(&timer);
            countdown_ms(&timer, 2000);
            do{

                if(mmapfd->finishflag==1)
                    break;
            }while(!expired(&timer));
            mmapfd->finishflag=0;

        }

        usleep(200000);
    }
}
