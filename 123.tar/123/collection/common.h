﻿#ifndef COMMON_H
#define COMMON_H

#include "string.h"
#include "stdio.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include "errno.h"
#include <assert.h>
#include <dirent.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <pthread.h>
#include <sys/msg.h>
#include <sys/shm.h>
#include <dirent.h>
#include <time.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <sys/ioctl.h>
#include <semaphore.h>
#include <linux/if.h>
#include <linux/sockios.h>
#include <linux/ethtool.h>
#include <stdlib.h>
#include <stdio.h>
#include <stddef.h>
#include <netinet/tcp.h>
#include <sys/socket.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <semaphore.h>
#include "sys/stat.h"
#include "sys/types.h"
#include "netinet/in.h"
#include "arpa/inet.h"
#include <time.h>
#include <zmq/zmq.h>
#include <math.h>
#include<sys/msg.h>
#include<sys/ipc.h>
#include<stdbool.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <stdbool.h>
#include <ctype.h>
#define ERR_COMMON_SUCCESS 0
#define ERR_COMMON_FAILED  -1

#define   IN
#define   OUT
#define   INOUT

//#define  bool	_Bool
#define  false  0
#define  true   1

#define  __u8       unsigned char
#define  __u16     unsigned short
#define  __u32     unsigned int
#define LocalPath   "/userdata/usr/local/"   //本地目录
#define SdcardPath  "/mnt/sdcard/"  // sd卡目录
#define HC_ASSERT(bResult) assert(bResult)

#define HC_ERROR(format, args...)	do {fprintf(stderr, " [HC_ERROR]%s %s(Line %d): (errno=%d) ",  __FILE__, __func__, __LINE__, errno);perror("reason");} while(0)

#define HC_DEBUG(format, args...)	do {fprintf(stdout, " [HC_DEBUG]%s (Line %d):", __FILE__, __LINE__);fprintf(stdout, format, ##args);fprintf(stdout, "\n");} while(0)

#define HC_PRINT(format, args...) do {fprintf(stdout, " [HC_PRINT]%s (Line %d):", __FILE__, __LINE__);fprintf(stdout, format, ##args);fprintf(stdout, "\n");fflush(stdout);} while(0)
#define VERSION                         (38)
#define ZMQ_ENDPOINT_RPC                "tcp://*:6000"
#define ELEVATOR_TOPIC_RPC              "elevator topic rpc"
#define RPC_INTERNAL_CALL               "internal_call"
#define RPC_OUTER_CALL                  "outer_call"
#define RPC_DISABILITY_OUTER_CALL       "disability_outer_call"
#define RPC_OPEN_DOOR                   "open_door"
#define RPC_CLOSE_DOOR                  "close_door"
#define RPC_OPEN_DOOR_HOLDING           "open_door_holding"
#define RPC_RELEASE_OPEN_DOOR_HOLDING   "release_open_door_holding"

#define SHARED_OBJ_DISPLAY_PARAM            "/smart_shared_display_param"
#define SHARED_OBJ_COMMON_DATA              "/smart_shared_common_data"

#define SHARED_OBJ_DOOR_MACHINE             "/smart_shared_door_machine"
#define SHARED_OBJ_TRACTION_MACHINE         "/smart_shared_traction_machine"
#define SHARED_OBJ_TRANSPORT                "/smart_shared_transport"
#define SHARED_OBJ_CTRL_SYS                 "/smart_shared_ctrl_sys"
#define SHARED_OBJ_SAFETY_CIRCUIT           "/smart_shared_safety_circuit"
#define SHARED_OBJ_LIGHT_CURTAIN            "/smart_shared_light_curtain"

#define SEM_OBJ_ELEVATOR_DATA               "/smart_sem_elevator_data"


#define TOPICLENG (1024)
#define MSGBUFLENG (1024*2)
#define MQTTLENG 0x80000
#pragma pack(1)
typedef  struct{

    long time;
    int finishflag;
    char topic[1024];
    char mqttdata[1024*500];
}ST_MqttMmapInfo;

struct ST_elevator_display_param_t
{
    int slave;
    short floor_display[40];                /* floor 1 to 40 display parameters, ascii value */
};
//电梯信息
struct ST_elevator_common_data_t
{
    int slave;
    char sn[8];                             /* ascii */
    unsigned short car_status;              /* 1: 上行, 2: 下行, 3: 停止 */
    unsigned short current_floor;
    unsigned short service_mode;            /* nice3000+ p196 */
    unsigned short load;                    /* 1: 满载, 2: 超载,  3: 空载, 4: 半载 */
    unsigned short door_status;             /* 1: 开门中, 2: 开门, 3: 关门中, 4: 关门 */
    unsigned short fault_code;              /* 0: 正常, other: 错误*/
    unsigned char inner_call[48];           /* 1-48 floor */
    unsigned char up_call[48];              /* 1-48 floor */
    unsigned char down_call[48];            /* 1-48 floor */
};
// 门机预维保
struct ST_elevator_door_machine_t
{
    int elevator_id;
    // 门机预维保状态：0：不处于预先维保，1：处于预先维保，2：不适合预先维保，3：预先维保结束
    unsigned short pre_maintain_status;
    // 扒门状态：0：扒门，1：未扒门
    unsigned short push_door_status;
    // 门 1本次关门最大电流数
    unsigned short close_door1_max_current;
    // 门 2本次关门最大电流数
    unsigned short close_door2_max_current;
    // 门机预维保实时结果：BIT0：前门摩擦力检测结果，BIT1：前门锁勾故障结果，
    //                    BIT2：前门保留，BIT3： 前门保留
    //                    BIT4：后门摩擦力检测结果，BIT5：后门锁勾故障结果
    unsigned short pre_maintain_result;

    //// 6B-03
    // 物理楼层
    unsigned short current_floor;
    // 前门和后门数据更新标记，单位时back_door_update_flag为0，贯通门时两个同时置位
    unsigned char front_door_update_flag;
    unsigned char back_door_update_flag;
    // 前门预维保结果位，0表示正常，1表示异常
    // - 重锤检测结果
    unsigned char front_door_heavy_hammer_check_result;
    // - 对打滑检测结果
    unsigned char front_door_double_slip_check_result;
    // 后门预维保结果位，0表示正常，1表示异常
    // - 重锤检测结果
    unsigned char back_door_heavy_hammer_check_result;
    // - 对打滑检测结果
    unsigned char back_door_double_slip_check_result;
    // 前门锁抬起时间
    unsigned char front_door_lock_up_time;
    // 后门锁抬起时间
    unsigned char back_door_lock_up_time;
    // 前门对中结果
    unsigned char front_door_center_result;
    // 后门对中结果
    unsigned char back_door_center_result;
    // 前门自闭力系数百分比
    unsigned char front_door_self_closing_coefficient;
    // 后门自闭力系数百分比
    unsigned char back_door_self_closing_coefficient;
};

// 曳引机质量
struct ST_elevator_traction_machine_t
{
    int elevator_id;
    // 抱闸力状态：0：不处于抱闸力状态，1：正处于抱闸力状态，2：不适合抱闸力，3：抱闸力结束
    unsigned short brake_force_status;

    //// 6B-04
    // byte1 抱闸 1 更新标记， 0 表示未更新， 1 表示更新
    // 抱闸 1 行程关闭时间更新
    unsigned char brake1_stroke_close_time_update_flag;
    // 抱闸 1 接触器次数更新
    unsigned char brake1_contactor_num_update_flag;
    // 抱闸 1 接触器打开时间更新
    unsigned char brake1_contactor_open_time_update_flag;
    // 抱闸 1 行程打开时间更新
    unsigned char brake1_stroke_open_time_update_flag;
    // 抱闸 1 接触器关闭时间更新
    unsigned char brake1_contactor_close_time_update_flag;
    // byte2
    // 抱闸 2 更新标记， 0 表示未更新， 1 表示更新
    // 抱闸 2 行程关闭时间更新
    unsigned char brake2_stroke_close_time_update_flag;
    // 抱闸 2 接触器次数更新
    unsigned char brake2_contactor_num_update_flag;
    // 抱闸 2 接触器打开时间更新
    unsigned char brake2_contactor_open_time_update_flag;
    // 表示抱闸 2 行程打开时间更新
    unsigned char brake2_stroke_open_time_update_flag;
    // 抱闸 2 接触器关闭时间更新
    unsigned char brake2_contactor_close_time_update_flag;
    // 抱闸 1 动作次数
    unsigned int brake1_action_num;
    // 抱闸 2 动作次数
    unsigned int brake2_action_num;
    // 抱闸 1 打开时间
    unsigned char brake1_open_time;
    // 抱闸 2 打开时间
    unsigned char brake2_open_time;
    // 抱闸 1 行程打开时间
    unsigned char brake1_stroke_open_time;
    // 抱闸 2 行程打开时间
    unsigned char brake2_stroke_open_time;
    // 抱闸 1 关闭时间
    unsigned char brake1_close_time;
    // 抱闸 2 关闭时间
    unsigned char brake2_close_time;
    // 抱闸 1 行程关闭时间
    unsigned char brake1_stroke_close_time;
    // 抱闸 2 行程关闭时间
    unsigned char brake2_stroke_close_time;
    // 抱闸 1 和 2 的行程开关关闭不一致时间差
    unsigned char brake12_stroke_close_time_difference;
    // 抱闸 1 和 2 的行程开关打开不一致时间差
    unsigned char brake12_stroke_open_time_difference;
    // 抱闸 1 状态，0 表示关闭， 1 表示打开
    unsigned char brake1_status;
    // 抱闸 2 状态，0 表示关闭， 1 表示打开
    unsigned char brake2_status;

    //// 6B-05
    // byte1 曳引机预检更新标记， 0 表示未更新， 1 表示更新
    // 打滑量更新
    unsigned char slip_quantity_update_flag;
    // 空载电流更新
    unsigned char no_load_update_flag;
    // 抱闸检测结果更新
    unsigned char brake_check_result_update_flag;
    // 抱闸预检测结果更新
    unsigned char brake_pre_check_result_update_flag;
    // 1 楼启动次数更新
    unsigned char floor_1_start_num_update_flag;
    // 返基站的打滑量更新
    unsigned char return_basesation_slip_quantity_update_flag;

    // 打滑量目标楼层
    unsigned char traction_slip_end_floor;
    // 打滑量起始楼层
    unsigned char traction_slip_start_floor;
    // 本次打滑量
    unsigned char traction_current_slip_quantity;
    // 反基站打滑量
    unsigned char traction_return_basestation_slip_quantity;
    // 抱闸闭合后的位移量
    unsigned char brake_close_shift_quantity;
    // 空载电流
    unsigned int no_load_current;
    // 抱闸检测结果 0：无意义，1：合格，2：不合格
    unsigned char brake_check_result;
    // 本次抱闸力检测位移量
    unsigned char current_brake_force_check_shift_quantity;
    // 抱闸预警检测结果
    unsigned char brake_warning_check_result;
    // 本次预检测位移量
    unsigned char current_pre_check_shift_quantity;
    // 物理 1 楼启动次数
    unsigned int physicial_floor_1_start_num;
};

// 乘运质量
struct ST_elevator_transport_t
{
    int elevator_id;

    //// 6B-01
    // 乘运质量-加速度曲线，acceleration_length为读到的有效数据长度
    int acceleration_length;
    unsigned char acceleration_curve[256 * 1024];

    //// 6B-02
    // 乘运质量-绝对位置曲线，abs_location_length为读到的有效数据长度
    int abs_location_length;
    unsigned char abs_location_curve[256 * 1024];
};

// 控制系统质量
struct ST_elevator_ctrl_sys_t
{
    int elevator_id;

    // 母线电容容量
    unsigned short bus_capatitor_power;
    // IGBT温度
    unsigned short igbt_temperature;
    // 逆变侧二极管结温
    unsigned short inverter_side_diode_junction_temperature;
    // 整流侧二极管结温
    unsigned short rectifier_side_diode_junction_temperature;
    // 能耗数据-发电量,单位千瓦时
    double generated_electrical_energy;

    // CAN1 通讯-总线干扰
    unsigned short bus_inteference_can_1;
    // CAN1 通讯-单板通讯模块自检
    unsigned short can_1_comm_single_board_self_check;
    // SPI1 通信-总线干扰
    unsigned short bus_inteference_spi_1;
    // MOD1 通讯-总线干扰
    unsigned short bus_inteference_mod_1;
    // 485-1 通信-总线干扰
    unsigned short bus_inteference_485_1;
    // SPI2 通信-总线干扰
    unsigned short bus_inteference_spi_2;
    // 485-2 通信-总线干扰
    unsigned short bus_inteference_485_2;

    //// 6B-06
    // 运行接触器尝试闭合的次数（累加）
    unsigned short run_contactor_attempt_close_num;
    // 运行接触器辅助触点闭合时的最小时间间隔
    unsigned short run_contactor_auxiliary_close_min_interval;
    // 运行接触器动作指令时间间隔（指令的频率）
    unsigned short run_contactor_action_instruction_interval;
    // 运行接触器闭合次数
    unsigned short run_contactor_close_num;
    // 运行接触器断开次数
    unsigned short run_contactor_disconnect_num;
    // 运行接触器收到闭合指令到辅助触点闭合反馈时间(最大值)
    unsigned short run_contactor_recv_close_instruction_response_time;
    // 运行接触器收到断开指令到辅助触点断开反馈时间（最大值）
    unsigned short run_contactor_recv_disconnect_instruction_response_time;

    // 封星接触器尝试闭合的次数（累加）
    unsigned short stator_contactor_attempt_close_num;
    // 封星接触器辅助触点闭合时的最小时间间隔
    unsigned short stator_contactor_auxiliary_close_min_interval;
    // 封星接触器动作指令时间间隔（指令的频率）
    unsigned short stator_contactor_action_instruction_interval;
    // 封星接触器闭合次数
    unsigned short stator_contactor_close_num;
    // 封星接触器断开次数
    unsigned short stator_contactor_disconnect_num;
    // 封星接触器收到闭合指令到辅助触点闭合反馈时间（最大值）
    unsigned short stator_contactor_recv_close_instruction_response_time;
    // 封星接触器收到断开指令到辅助触点断开反馈时间（最大值）
    unsigned short stator_contactor_recv_disconnect_instruction_response_time;

    // 抱闸 1 接触器尝试闭合的次数（累加）
    unsigned short brake1_contactor_attempt_close_num;
    // 抱闸 1 接触器辅助触点闭合时的最小时间间隔
    unsigned short brake1_contactor_auxiliary_close_min_interval;
    // 抱闸 1 接触器动作指令时间间隔（指令的频率）
    unsigned short brake1_contactor_action_instruction_interval;
    // 抱闸 1 接触器闭合次数
    unsigned short brake1_contactor_close_num;
    // 抱闸 1 接触器断开次数
    unsigned short brake1_contactor_disconnect_num;
    // 抱闸 1 接触器收到闭合指令到辅助触点闭合反馈时间（最大值）
    unsigned short brake1_contactor_recv_close_instruction_response_time;
    // 抱闸 1 接触器收到断开指令到辅助触点断开反馈时间（最大值）
    unsigned short brake1_contactor_recv_disconnect_instruction_response_time;

    // 抱闸 2 接触器尝试闭合的次数（累加）
    unsigned short brake2_contactor_attempt_close_num;
    // 抱闸 2 接触器辅助触点闭合时的最小时间间隔
    unsigned short brake2_contactor_auxiliary_close_min_interval;
    // 抱闸 2 接触器动作指令时间间隔（指令的频率）
    unsigned short brake2_contactor_action_instruction_interval;
    // 抱闸 2 接触器闭合次数
    unsigned short brake2_contactor_close_num;
    // 抱闸 2 接触器断开次数
    unsigned short brake2_contactor_disconnect_num;
    // 抱闸 2 接触器收到闭合指令到辅助触点闭合反馈时间（最大值）
    unsigned short brake2_contactor_recv_close_instruction_response_time;
    // 抱闸 2 接触器收到断开指令到辅助触点断开反馈时间（最大值）
    unsigned short brake2_contactor_recv_disconnect_instruction_response_time;

    // 运行继电器动作次数统计
    unsigned short run_relay_action_num;
    // 封星继电器动作次数统计
    unsigned short stator_relay_action_num;
    // 抱闸 1 继电器动作次数统计
    unsigned short brake1_relay_action_num;
    // 抱闸 2 继电器动作次数统计
    unsigned short brake2_relay_action_num;

    //// 6B-07
    // 按钮次数统计
    // 1~112 层外召前门上
    unsigned char front_door_outer_up_call_button_num[112];
    // 1~112 层外召后门上
    unsigned char back_door_outer_up_call_button_num[112];
    // 1~112 层外召前门下
    unsigned char front_door_outer_down_call_button_num[112];
    // 1~112 层外召后门下
    unsigned char back_door_outer_down_call_button_num[112];
    // 1~112 内招主操纵箱+开关门
    unsigned char main_operation_box_inner_call_button_num[112];
    unsigned char main_operation_box_open_button_num;
    unsigned char main_operation_box_close_button_num;
    // 1~112 内招辅操纵箱+开关门
    unsigned char auxiliary_operation_box_inner_call_button_num[112];
    unsigned char auxiliary_operation_box_open_button_num;
    unsigned char auxiliary_operation_box_close_button_num;
    // 1~112 内招残疾人操纵箱+开关门
    unsigned char disability_operation_box_inner_call_button_num[112];
    unsigned char disability_operation_box_open_button_num;
    unsigned char disability_operation_box_close_button_num;

    //// 6B-08
    // 控制系统质量-MCB 统计通信信息
    // CAN1 通讯-在线状态 32*1bit  4*8
    unsigned int can1_comm_online_state;
    //CAN1 通讯-丢帧率 32*1byte
    unsigned char can1_comm_drop_frame_rate[32];
    //SPI1 在线状态-MCB 检测 DSP
    unsigned char spi1_online_state_mcb_check_dsp;
    //SPI1 通讯-丢帧率-DSP
    unsigned char spi1_comm_drop_frame_rate_dsp;
    //485-1 在线状态-DSP 检测编码器
    unsigned char s485_1_online_state_dsp_check_encode;
    //485-1 丢帧率-DSP 检测编码器
    unsigned char s485_1_drop_frame_rate_dsp_check_encode;
    //SPI2 在线状态-MCB 检测 PG 卡
    unsigned char spi2_online_state_mcb_check_pg;
    //SPI2 丢帧率-MCB 检测 PG 卡
    unsigned char spi2_drop_frame_rate_mcb_check_pg;
    //485-2 在线状态-PG 卡检测编码器
    unsigned char s485_2_online_state_pg_check_encode;
    //485-2 丢帧率-PG 卡检测编码器
    unsigned char s485_2_drop_frame_rate_pg_check_encode;
    //MOD1 在线状态28*8
    unsigned char mdo1_online_state[28];
    //MOD1 丢帧率
    unsigned char mod1_drop_frame_rate[224];
};

// 安全回路质量
struct ST_elevator_safety_circuit_t
{
    int elevator_id;

    //// voltage sampling board
    // 首端电压
    unsigned short head_voltage;
    // 末端稳定电压
    unsigned short end_stable_voltage;
    // KM1 吸合电压
    unsigned short km1_pullin_voltage;
    // 控制柜温度
    unsigned short control_cabinet_temperature;
    // 接触器温度
    unsigned short contactor_temperature;

    //// 6B-09
    // 前门开门次数统计——层门, 1-112层
    unsigned short front_floor_door_open_num[112];
    // 前门关门次数统计——层门, 1-112层
    unsigned short front_floor_door_close_num[112];
    // 后门开门次数统计——层门, 1-112层
    unsigned short back_floor_door_open_num[112];
    // 后门关门次数统计——层门, 1-112层
    unsigned short back_floor_door_close_num[112];
    // 前门开门次数统计——轿门
    unsigned short front_car_door_open_num;
    // 前门关门次数统计——轿门
    unsigned short front_car_door_close_num;
    // 后门开门次数统计——轿门
    unsigned short back_car_door_open_num;
    // 后门关门次数统计——轿门
    unsigned short back_car_door_close_num;
};

// 光幕
struct ST_elevator_light_curtain_t
{
    int elevator_id;

    // 前门-通信光幕总工作状态
    unsigned short front_door_light_curtain_total_status;
    // 前门-光管工作状态（第1-48管）
    unsigned char front_door_light_curtain_status[48];
    // 前门-光管强度值
    unsigned short front_door_light_tube_intensity;
    // 前门-光管对数
    unsigned short front_door_light_tube_logarithm;
    // 后门-通信光幕总工作状态
    unsigned short back_door_light_curtain_total_status;
    // 后门-光管工作状态（第1-48管）
    unsigned char back_door_light_curtain_status[48];
    // 后门-光管强度值
    unsigned short back_door_light_tube_intensity;
    // 后门-光管对数
    unsigned short back_door_light_tube_logarithm;
};


typedef  struct
{
    int id;
    char topic[TOPICLENG];
    char msgbuf[MSGBUFLENG];
}ST_MqttInfo;

typedef  struct
{
    int id;
}ST_CMP;

#pragma pack()
extern char idbuf[3][100];
extern ST_MqttMmapInfo mqttMmapInfo;
extern ST_MqttInfo MqttInfo[3];

extern int MQTTSendFlag;
extern pthread_mutex_t mutex; //互斥锁;
extern char Mmap_Serveradress[256];
extern struct ST_elevator_common_data_t  elevator_common_data_t[3];
extern struct ST_elevator_door_machine_t elevator_door_machine_t[3];// 门机预维保
extern struct ST_elevator_traction_machine_t elevator_traction_machine_t[3];// 曳引机质量
extern struct ST_elevator_transport_t elevator_transport_t[3];// 乘运质量
extern struct ST_elevator_ctrl_sys_t elevator_ctrl_sys_t[3];// 控制系统质量
extern struct ST_elevator_safety_circuit_t elevator_safety_circuit_t[3];// 安全回路质量
extern struct ST_elevator_light_curtain_t elevator_light_curtain_t[3];// 光幕
#endif
