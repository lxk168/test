#include <stdio.h>
#include "common.h"
#include "application/HCAppStart.h"
int main()
{
    HCStartTask();
    while(1)
    {
        sleep(2);
    }
}
