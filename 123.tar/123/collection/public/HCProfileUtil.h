#ifndef HCPROFILEUTIL_H
#define HCPROFILEUTIL_H

#include "common.h"
#define KEYVALLEN 100
extern char* l_trim(char* szOutput, const  char* szInput);
extern char* r_trim(char* szOutput, const  char* szInput);
extern char* a_trim(char* szOutput, const  char* szInput);
extern int  HCGetProfileString(char* profile, char* appName, char* keyName, char* keyVal);
extern int read_profile_string(char* chAppName,char* chKeyName,char* chDefault,char* chReturnedString,int nSize,char* chFileName);
extern bool write_profile_string(char* chAppName,char* chKeyName,char* chValue,char* chFileName);
#endif
