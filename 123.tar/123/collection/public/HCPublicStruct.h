#ifndef HCPUBLICSTRUCT_H
#define HCPUBLICSTRUCT_H
#include "common.h"


#pragma pack (1)
typedef struct{
    char UserName[20];                      //用户名
    char Password[20];                       //密码
    unsigned int       S_ipAddr;
    unsigned short   S_PortNum;
    char lPortPasv;                              //主从模式
    char cDataType;                            //数据传输类型
    unsigned int uTimeOutUsec;       //超时时间
    char szRemFilePath[60];            //远程路径
} St_Net_Ftp_Info;

typedef struct
{

    int tm_sec;            /* seconds */
    int tm_min;           /* minutes */
    int tm_hour;         /* hours */
    int tm_mday;        /* day of the month */
    int tm_mon;         /* month */
    int tm_year;          /* year */
} St_SystemTime;
typedef struct {
    long int mtype;
    char mtext[2048];
}ST_mymesg;
typedef struct
{
    long time; //修改时间
    long uploadCycle; //上传时间
    char whetherToUpload[6];//是否上传
    char whetherToUploadPeriodically[6];//是否周期上传

}ST_SetInfo;
typedef  struct
{
    char instance[512];
    int use;//接触器类型  0：左抱闸接触器  1：右抱闸接触器  2：运行接触器  3：封星接触器
    ST_SetInfo integratedConfiguration;
}ST_ContactorList;
//抱闸制动器
typedef  struct
{
    char instance[512];
    int use;//抱闸列表   0：抱闸1  1：抱闸2
    ST_SetInfo brakePreCheckStatusEventconfiguration;   //抱闸预检状态事件配置
    ST_SetInfo brakeStatusEventConfiguration;     //抱闸状态事件配置
    ST_SetInfo brakeForceDetectionDataSetEventConfiguration;   //抱闸力检测数据集事件配置
    ST_SetInfo brakeOnOffTimeEventConfiguration;    //抱闸打开关闭时间事件配置
}ST_HoldingBrakeContactor;
//制动器行程反馈开关
typedef  struct
{
    char instance[512];
    int use;//抱闸行程反馈开关分类    0：抱闸1行程反馈开关    1：抱闸2行程反馈开关
    ST_SetInfo brakeStrokeFeedbackSwitchDataSetEventConfiguration;   //抱闸预检状态事件配置

}ST_BrakeStrokeFeedbackSwitch;
//制动器热检测传感器
typedef  struct
{
    char instance[512];
    int use;//抱闸热检测传感器分类  //  0:抱闸1热检测传感器   1:抱闸2热检测传感器
    ST_SetInfo brakeThermalDetectionSensorStatisticalDataEventConfiguration;   //制动器热检测传感器统计数据事件配置

}ST_brakeHeatDetectionSensor;
//轿门锁
typedef  struct{
    char instance[512];
    int use;//0:前轿门锁    1:后轿门锁
    ST_SetInfo carDoorLockStatisticsEventConfiguration; //轿门锁统计数据事件配置
    ST_SetInfo carDoorLockOnOffStateEventConfiguration;     //轿门锁锁通断状态事件配置
} ST_carDoorLock;
//门板
typedef  struct{
    char instance[512];
    int use;//0:前门板    1:后门板
    ST_SetInfo doorPanelDetectionDataEventConfig;      //门板检测数据事件配置
    ST_SetInfo doorStatisticsEventConfig;         //门板统计数据事件配置
    ST_SetInfo doorStatusDataEventConfig; //门板状态数据事件配置
} ST_doorPanel;
//门球
typedef  struct{
    char instance[512];
    int use;//0:前门球    1:后门球
    ST_SetInfo doorBallDataSetEventConfig;       //门球数据集事件配置

} ST_doorBall;
//锁钩
typedef  struct{
    char instance[512];
    int use; //0:前门锁钩    1:后门锁钩
    ST_SetInfo lockHookDataSetEventConfiguration;          //锁钩数据集事件配置

} ST_lockHook;
//皮带
typedef  struct{
    char instance[512];
    int use;  //0:前门皮带    1:后门皮带
    ST_SetInfo beltDetectionDataEventConfiguration;           //皮带检测数据事件配置

} ST_strap;
//轿厢地坎
typedef  struct{
    char instance[512];
    int use;   //0:前门轿厢地坎    1:后门轿厢地坎
    ST_SetInfo carSillDetectionDataEventConfiguration;             //轿厢地坎检测数据事件配置

} ST_carSill;
//滑轨
typedef  struct{
    char instance[512];
    int use;   //0:前门滑轨    1:后门滑轨
    ST_SetInfo slidingRailFrictionDetectionDataEventConfiguration;             //滑轨摩檫力检测数据事件配置

} ST_slide;
//光幕
typedef  struct{
    char instance[512];
    int use;    //0:前门光幕    1:后门光幕
    ST_SetInfo specialFunctionEventConfiguration;             //特殊功能事件配置

} ST_lightCurtain;
//"同步门电机"
typedef  struct{
    char instance[512];
    int use;     //0:前门电机    1:后门电机
    ST_SetInfo doorMotorDetectionDataEventConfig;             //特殊功能事件配置

} ST_synchronousDoorMotor;
//异步门电机
typedef  struct{
    char instance[512];
    int use;     //0:前门电机    1:后门电机
    ST_SetInfo doorMotorDetectionDataEventConfig;             //特殊功能事件配置

} ST_asynchronousDoorMotor;

//厅门V1.0.0列表
typedef  struct{
    char instance[512];
    int use;     //  0:前门  1:后门
    ST_SetInfo hallDoorInspectionDataEventConfiguration;                //厅门检测数据事件配置
    ST_SetInfo hallDoorStatisticsEventConfiguration;   //厅门统计数据事件配置
} ST_hallDoorList;
//厅门锁V1.0.0列表

typedef  struct{
    char instance[512];
    int use;     //  0:前门  1:后门
    ST_SetInfo landingDoorLockOnOffDetectionEventConfiguration;                //层门锁通断检测事件配置
    ST_SetInfo landingDoorOpeningStatisticsEventConfiguration;    //开门数据统计事件配置
    ST_SetInfo landingDoorClosingStatisticsEventConfiguration; //关门数据统计事件配置
} ST_hallDoorLockList;
//厅门地坎

typedef  struct{
    char instance[512];
    int use;     //  0:前门厅门地坎  1:后门厅门地坎
    ST_SetInfo landingDoorLockOnOffDetectionEventConfiguration;                 //厅门地坎检测数据事件配置

} ST_hallSill;
typedef struct
{
    long time; //修改时间
    char elevatorid[100];//电梯ID
    char sn[100];//主控板注册码
    //上报电梯综合故障信息标志位
    int elevatorComprehensiveFaultInformationEventConfigurationflag;
    //上报机器人事件信息标志位
    int  agvInformationEventConfigurationflag;
    //控制柜标志位
    int controlCabinetStatisticsEventConfigurationflag; //上报控制柜统计数据事件配置标志位
    int controlCabinetInherentDataEventConfigurationflag;//上报控制柜固有数据事件配置标志位
    int controlCabinetTemperatrueDataEventConfigurationflag; //上报控制柜温度数据事件配置标志位
    //接触器列表
    int contactorListflag;//上报接触器列表标志位
    //nice3000new一体机
    int systemStatusEventConfigurationflag;  //上报系统状态事件配置标志位
    int  systemSignalDetectionEventConfigurationflag; //上报系统信号检测事件配置标志位
    int  controllerPasswordEventConfigurationflag;  //上报控制器密码事件配置标志位
    int  errorCodeEventConfigurationflag;//上报故障代码事件配置标志位
    int  terminalStatusEventConfigurationflag;//上报端子状态事件配置标志位
    int  AGVheartbeatEventConfigurationflag;//上报AGV心跳事件配置标志位
    //通讯接口
    int  CAN1communicationDataEventConfigurationflag; //上报CAN1通讯数据事件配置标志位
    int  SPI1communicationDataEventConfigurationflag; //上报SPI1通讯数据事件配置标志位
    int  SPI2communicationDataEventConfigurationflag;  //上报SPI2通讯数据事件配置标志位
    int  MOD1communicationDataEventConfigurationflag; //上报MOD1通讯数据事件配置标志位
    int  MOD2communicationDataEventConfigurationflag; //上报MOD2通讯数据事件配置标志位
    int  m485FirstcommunicationDataEventConfigurationflag;//上报485-1通讯数据事件配置标志位
    int  m485TwocommunicationDataEventConfigurationflag;//上报485-2通讯数据事件配置标志位
    int  serialPortcommunicationDataEventConfigurationflag;   //上报串口通讯数据事件配置标志位
    //接口板
    int  interfaceBoardStatisticalDataEventConfigurationflag; //上报接口板统计数据事件配置标志位
    int  interfaceBoardTemperatrueDataEventConfigurationflag; //上报接口板温度数据事件配置标志位
    //新国标物联网模块/第三方
    int  elevatorRemoteLockSignalEventConfigurationflag; //上报新国标物联网模块第三方电梯远程锁梯信号事件配置标志位
    //同步曳引机 异步电机
    int  motorRatedInfoEventConfigurationflag; //上报电机额定信息事件配置标志位
    //抱闸制动器
    int holdingBrakeContactorflag;  //上报抱闸制动器标志位
    //永磁体
    int  permanentMagnetDataSetEventConfigurationflag;//上报永磁体数据集事件配置标志位
    //制动器行程反馈开关
    int brakeStrokeFeedbackSwitchflag; //上报制动器行程反馈开关标志位
    //制动器热检测传感器
    int brakeHeatDetectionSensorflag;  //上报制动器热检测传感器标志位
    int brakePadWearSensorDataEventConfigurationflag; //上报刹车片磨损传感器数据事件配置标志位
    int ntcTempProtectCriticalPointEventConfigurationflag; //上报NTC保护点临界温度事件配置标志位
    //轿厢
    int  elevatorCurrentPositionInfoEventConfigflag; //上报电梯当前位置信息事件配置标志位
    int  elevatorMileageEventConfigflag;   //上报电梯运行里程事件配置标志位
    int  runDataEventConfigflag;   //上报运行数据事件配置标志位
    //轿内
    int  visionElectricVehicleEventConfigurationflag; //上报电瓶车识别事件配置标志位
    int  visionPryingDoorEventConfigurationflag; //上报扒门识别事件配置标志位
    int  visionSmokeEventConfigurationflag;  //上报烟雾识别事件配置标志位
    int  visionTrappedEventConfigurationflag;//上报困人识别事件配置标志位
    int  visionFallEventConfigurationflag;   //上报倒地识别事件配置标志位
    int  visionPersonEventConfigurationflag;    //上报人员计数事件配置标志位
    int  voiceRequestSignalEventConfigflag;//上报语音请求信号事件配置标志位
    //轿内指令板
    int  internalCallStatusEventConfigurationflag; //上报内召状态事件配置标志位
    int  frontBackDoorInternalCallRegistrationCommandEventConfigflag; //上报前后门内召登记指令事件配置标志位
    int  frontDoorInternalCallRegistrationCommandEventConfigflag;  //上报前门内召登记指令事件配置标志位
    int  backDoorInternalCallRegistrationCommandEventConfigflag;  //上报后门内召登记指令事件配置标志位
    int  mainControlPanelButtonStatisticsEventConfigflag;//上报主操纵盘按钮统计数据事件配置标志位
    int  auxiliaryControlPanelButtonStatisticsEventConfigflag; //上报辅助操纵盘按钮统计数据事件配置标志位
    int handicappedControlPanelButtonStatisticsEventConfigflag; //上报残疾人操纵盘按钮统计数据事件配置标志位
    //轿门
    int doorMachinePreMaintenanceStatusEventConfigurationflag;    //上报门机预维保状态事件配置标志位
    int doorLockShortCircuitFaultDetectionEventConfigurationflag; //上报门锁短接故障检测事件配置标志位
    //轿门锁
    int carDoorLockflag; //上报轿门锁标志位
    //门板
    int doorPanelflag; //上报门板标志位
    //门球
    int doorBallflag;   //上报门球标志位
    //锁钩
    int lockHookflag; //上报锁钩标志位
    //皮带
    int strapflag;  //上报皮带标志位
    //轿厢地坎
    int carSillflag;//上报轿厢地坎标志位
    //滑轨
    int  slideflag;     //上报滑轨标志位
    //光幕
    int lightCurtainflag;  //上报光幕标志位
    //上报同步门电机"标志位
    int synchronousDoorMotorflag;
    //上报异步门电机标志位
    int asynchronousDoorMotorflag;

    //轿顶
    int  carCarryingDataEventConfigurationflag;    //上报轿厢承载数据事件配置标志位
    //平层开关
    int  doorZoneSignalEventConfigurationflag;  //上报门区信号事件配置标志位
    //轿顶振动传感器/加速度传感器
    int accelerationDataEventConfigurationflag; //上报加速度数据事件配置标志位
    //轿顶气压传感器
    int locationDataEventConfigurationflag;   //上报位置数据事件配置标志位
    //轿顶sensor处理器
    int m232InterfaceModuleflag; //上报232接口模块标志位
    //厅外
    int frontBackUpDownCallRegistrationCommandEventConfigflag;  //上报前后上下召登记指令事件配置标志位
    int frontUpDownCallRegistrationCommandEventConfigflag; //上报前门上下召登记指令事件配置标志位
    int backUpDownCallRegistrationCommandEventConfigflag; //上报后门上下召登记指令事件配置标志位
    int handicappedFrontUpDownCallRegistrationCommandEventConfigflag; //上报残障前门上下召登记指令事件配置标志位
    int handicappedBackUpDownCallRegistrationCommandEventConfigflag;   //上报残障后门上下召登记指令事件配置标志位
    //按钮(厅外显示板)
    int frontDoorHallUpCallButtonActionsNumberEventConfigurationflag;   //上报前门外呼上召按钮动作次数事件配置标志位
    int frontDoorHallDnCallButtonActionsNumberEventConfigurationflag;   //上报前门外呼下召按钮动作次数事件配置标志位
    int backDoorHallUpCallButtonActionsNumberEventConfigurationflag;  //上报后门外呼上召按钮动作次数事件配置标志位
    int backDoorHallDnCallButtonActionsNumberEventConfigurationflag;  //上报后门外呼下召按钮动作次数事件配置标志位
    //厅门V1.0.0列表
    int  hallDoorListflag; //上报厅门V1.0.0列表标志位
    //厅门锁V1.0.0列表
    int _hallDoorLockListflag;  //上报厅门锁V1.0.0列表标志位
    //厅门地坎
    int hallSillflag;   // 上报厅门地坎标志位
    //厅门门板
    int doorInspectionDataEventConfigurationflag; //上报门板检测数据事件配置标志位
    int doorStatisticsEventConfigurationflag; //上报门板统计数据事件配置标志位
    int doorInherentDataEventConfigurationflag; //上报门板固有数据事件配置标志位
    //井道
    int elevatorSlippageDataDetectionEventConfigurationflag;  //上报电梯运行打滑量数据检测事件配置标志位
    int brakeForceDetectionSteelRopesSlipEventConfigurationflag;  //上报抱闸力检测钢丝绳打滑量事件配置标志位
    int numberOfStartsOnTheFirstFloorEventConfigurationflag; //上报物理1楼启动次数事件配置标志位
    int backToTheBaseStationSlipEventConfigurationflag;  //上报返基站打滑量事件配置标志位
    //安全回路
    int voltageDetectionEventConfigurationflag;    //电压检测事件配置
    //电梯综合故障信息
    ST_SetInfo elevatorComprehensiveFaultInformationEventConfiguration;
    //机器人事件信息
    ST_SetInfo  agvInformationEventConfiguration;
    //控制柜
    ST_SetInfo controlCabinetStatisticsEventConfiguration; //控制柜统计数据事件配置
    ST_SetInfo controlCabinetInherentDataEventConfiguration;//控制柜固有数据事件配置
    ST_SetInfo controlCabinetTemperatrueDataEventConfiguration; //控制柜温度数据事件配置
    //接触器列表
    ST_ContactorList contactorList[4];//接触器列表
    //nice3000new一体机
    ST_SetInfo systemStatusEventConfiguration;  //系统状态事件配置
    ST_SetInfo  systemSignalDetectionEventConfiguration; //系统信号检测事件配置
    ST_SetInfo  controllerPasswordEventConfiguration;  //控制器密码事件配置
    ST_SetInfo  errorCodeEventConfiguration;//故障代码事件配置
    ST_SetInfo  terminalStatusEventConfiguration;//端子状态事件配置
    ST_SetInfo  AGVheartbeatEventConfiguration;//AGV心跳事件配置
    //通讯接口
    ST_SetInfo  CAN1communicationDataEventConfiguration; //CAN1通讯数据事件配置
    ST_SetInfo  SPI1communicationDataEventConfiguration; //SPI1通讯数据事件配置
    ST_SetInfo  SPI2communicationDataEventConfiguration;  //SPI2通讯数据事件配置
    ST_SetInfo  MOD1communicationDataEventConfiguration; //MOD1通讯数据事件配置
    ST_SetInfo  MOD2communicationDataEventConfiguration; //MOD2通讯数据事件配置
    ST_SetInfo  m485FirstcommunicationDataEventConfiguration;//485-1通讯数据事件配置
    ST_SetInfo  m485TwocommunicationDataEventConfiguration;//485-2通讯数据事件配置
    ST_SetInfo  serialPortcommunicationDataEventConfiguration;   //串口通讯数据事件配置
    //接口板
    ST_SetInfo  interfaceBoardStatisticalDataEventConfiguration; //接口板统计数据事件配置
    ST_SetInfo  interfaceBoardTemperatrueDataEventConfiguration; //接口板温度数据事件配置
    //新国标物联网模块/第三方
    ST_SetInfo  elevatorRemoteLockSignalEventConfiguration; //新国标物联网模块第三方电梯远程锁梯信号事件配置
    //同步曳引机 异步电机
    ST_SetInfo  motorRatedInfoEventConfiguration; //电机额定信息事件配置
    //抱闸制动器
    ST_HoldingBrakeContactor holdingBrakeContactor[2];  //抱闸制动器
    //永磁体
    ST_SetInfo  permanentMagnetDataSetEventConfiguration;//永磁体数据集事件配置
    //制动器行程反馈开关
    ST_BrakeStrokeFeedbackSwitch brakeStrokeFeedbackSwitch[2]; //制动器行程反馈开关
    //制动器热检测传感器
    ST_brakeHeatDetectionSensor brakeHeatDetectionSensor[2];  //制动器热检测传感器
    ST_SetInfo brakePadWearSensorDataEventConfiguration; //刹车片磨损传感器数据事件配置
    ST_SetInfo ntcTempProtectCriticalPointEventConfiguration; //NTC保护点临界温度事件配置
    //轿厢
    ST_SetInfo  elevatorCurrentPositionInfoEventConfig; //电梯当前位置信息事件配置
    ST_SetInfo  elevatorMileageEventConfig;   //电梯运行里程事件配置
    ST_SetInfo  runDataEventConfig;   //运行数据事件配置
    //轿内
    ST_SetInfo  visionElectricVehicleEventConfiguration; //电瓶车识别事件配置
    ST_SetInfo  visionPryingDoorEventConfiguration; //扒门识别事件配置
    ST_SetInfo  visionSmokeEventConfiguration;  //烟雾识别事件配置
    ST_SetInfo  visionTrappedEventConfiguration;//困人识别事件配置
    ST_SetInfo  visionFallEventConfiguration;   //倒地识别事件配置
    ST_SetInfo  visionPersonEventConfiguration;    //人员计数事件配置
    ST_SetInfo  voiceRequestSignalEventConfig;//语音请求信号事件配置
    //轿内指令板
    ST_SetInfo  internalCallStatusEventConfiguration; //内召状态事件配置
    ST_SetInfo  frontBackDoorInternalCallRegistrationCommandEventConfig; //前后门内召登记指令事件配置
    ST_SetInfo  frontDoorInternalCallRegistrationCommandEventConfig;  //前门内召登记指令事件配置
    ST_SetInfo  backDoorInternalCallRegistrationCommandEventConfig;  //后门内召登记指令事件配置
    ST_SetInfo  mainControlPanelButtonStatisticsEventConfig;//主操纵盘按钮统计数据事件配置
    ST_SetInfo  auxiliaryControlPanelButtonStatisticsEventConfig; //辅助操纵盘按钮统计数据事件配置
    ST_SetInfo handicappedControlPanelButtonStatisticsEventConfig; //残疾人操纵盘按钮统计数据事件配置
    //轿门
    ST_SetInfo doorMachinePreMaintenanceStatusEventConfiguration;    //门机预维保状态事件配置
    ST_SetInfo doorLockShortCircuitFaultDetectionEventConfiguration; //门锁短接故障检测事件配置
    //轿门锁
    ST_carDoorLock carDoorLock[2]; //轿门锁
    //门板
    ST_doorPanel doorPanel[2]; //门板
    //门球
    ST_doorBall doorBall[2];   //门球
    //锁钩
    ST_lockHook lockHook[2]; //锁钩
    //皮带
    ST_strap strap[2];  //皮带
    //轿厢地坎
    ST_carSill carSill[2];//轿厢地坎
    //滑轨
    ST_slide  slide[2];     //滑轨
    //光幕
    ST_lightCurtain lightCurtain[2];  //光幕
    //"同步门电机"
    ST_synchronousDoorMotor synchronousDoorMotor[2];
    //异步门电机
    ST_asynchronousDoorMotor asynchronousDoorMotor[2];

    //轿顶
    ST_SetInfo  carCarryingDataEventConfiguration;    //轿厢承载数据事件配置
    //平层开关
    ST_SetInfo  doorZoneSignalEventConfiguration;  //门区信号事件配置
    //轿顶振动传感器/加速度传感器
    ST_SetInfo accelerationDataEventConfiguration; //加速度数据事件配置
    //轿顶气压传感器
    ST_SetInfo locationDataEventConfiguration;   //位置数据事件配置
    //轿顶sensor处理器
    ST_SetInfo m232InterfaceModule; //232接口模块
    //厅外
    ST_SetInfo frontBackUpDownCallRegistrationCommandEventConfig;  //前后上下召登记指令事件配置
    ST_SetInfo frontUpDownCallRegistrationCommandEventConfig; //前门上下召登记指令事件配置
    ST_SetInfo backUpDownCallRegistrationCommandEventConfig; //后门上下召登记指令事件配置
    ST_SetInfo handicappedFrontUpDownCallRegistrationCommandEventConfig; //残障前门上下召登记指令事件配置
    ST_SetInfo handicappedBackUpDownCallRegistrationCommandEventConfig;   //残障后门上下召登记指令事件配置
    //按钮(厅外显示板)
    ST_SetInfo frontDoorHallUpCallButtonActionsNumberEventConfiguration;   //前门外呼上召按钮动作次数事件配置
    ST_SetInfo frontDoorHallDnCallButtonActionsNumberEventConfiguration;   //前门外呼下召按钮动作次数事件配置
    ST_SetInfo backDoorHallUpCallButtonActionsNumberEventConfiguration;  //后门外呼上召按钮动作次数事件配置
    ST_SetInfo backDoorHallDnCallButtonActionsNumberEventConfiguration;  //后门外呼下召按钮动作次数事件配置
    //厅门V1.0.0列表
    ST_hallDoorList  hallDoorList[2]; //厅门V1.0.0列表
    //厅门锁V1.0.0列表
    ST_hallDoorLockList _hallDoorLockList[2];  //厅门锁V1.0.0列表
    //厅门地坎
    ST_hallSill hallSill[2];   // //厅门地坎
    //厅门门板
    ST_SetInfo doorInspectionDataEventConfiguration; //门板检测数据事件配置
    ST_SetInfo doorStatisticsEventConfiguration; //门板统计数据事件配置
    ST_SetInfo doorInherentDataEventConfiguration; //门板固有数据事件配置
    //井道
    ST_SetInfo elevatorSlippageDataDetectionEventConfiguration;  //电梯运行打滑量数据检测事件配置
    ST_SetInfo brakeForceDetectionSteelRopesSlipEventConfiguration;  //抱闸力检测钢丝绳打滑量事件配置
    ST_SetInfo numberOfStartsOnTheFirstFloorEventConfiguration; //物理1楼启动次数事件配置
    ST_SetInfo backToTheBaseStationSlipEventConfiguration;  //返基站打滑量事件配置
    //安全回路
    ST_SetInfo voltageDetectionEventConfiguration;    //电压检测事件配置

}ST_VirtualDevice;
typedef  struct
{
    long time;
    unsigned int version; //版本
    char shiqu[100];
    ST_VirtualDevice VirtualDevice[3];
}ST_VirtualDeviceALL;
#pragma pack()
extern St_Net_Ftp_Info    Net_Ftp_Info;
extern char idstrbuf[3][50];
extern int msgfd;
extern  void *zmq_pub;
extern void *zmq_ctx ;
extern int elevatorNum;
extern ST_VirtualDeviceALL VirtualDeviceALL;
extern  char sn[3][100];
#endif // HCPUBLICSTRUCT_H
