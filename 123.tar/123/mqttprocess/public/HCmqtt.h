

#ifndef HCMQTT_H
#define HCMQTT_H


#include"mqttlib/MQTTClient.h"

#define MQTT_TOPIC_SIZE     (256)		//订阅和发布主题长度
#define MQTT_BUF_SIZE       (1024*256) 	//接收后发送缓冲区大小
#define MQTT_NUM            (50)     //订阅的最多个数



#pragma pack(1)

//topic 结构体
//例 /tsl/{thingCategoryKey}/{deviceName}/thing/event/{tsl.event.identifier}/post

typedef struct {

    char Topic[1024];
}ST_MqttTopic;
typedef struct {
      ST_MqttTopic  MqttTopic[MQTT_NUM];
}ST_MqttTopicInfo;
//连接状态枚举结构体
enum  iot_ctrl_status_t
{
    IOT_STATUS_LOGIN,//登录中
    IOT_STATUS_CONNECT, //连接
    IOT_STATUS_DROP, //掉线
};
//登录信息
typedef struct {
    char MqttHost[512]; //地址
    int   MqttPORT;    //端口
    char  MqttUserName[1024];  //用户名
    char MqttPassWord[1024];   //登录密码
    char MqttClientID[512];   //客户端ID
}ST_MqttLoginInfo;
typedef struct{
    enum iot_ctrl_status_t iotstatus;
} iot_device_info_t;//连接状态结构体

#pragma pack()

extern ST_MqttTopicInfo MqttTopicInfo;
extern ST_MqttLoginInfo MqttLoginInfo;
extern ST_MqttTopicInfo MqttTopicInfoSum;

extern void *HCMmapsend_Process(void);

extern ST_MqttTopicInfo * HC_TopicRead();
extern int HCTopicNum(ST_MqttTopicInfo MqttTopicInfo);
extern int HC_MQTT_Init(ST_MqttLoginInfo  MqttLoginInfo,ST_MqttTopicInfo MqttTopicInfo);
extern int HC_MQTT_Publish(char * pubtopic,char *pbuf);
extern int HC_SubTopicRead();
extern void HC_MqttDeviceDisconnect(void);
extern void  HC_yield(ST_MqttLoginInfo  MqttLoginInfo,ST_MqttTopicInfo  MqttTopicInfo);
#endif
