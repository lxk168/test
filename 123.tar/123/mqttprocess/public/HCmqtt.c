
#include"common.h"
#include "public/HCmqtt.h"
#include "public/HCPulicAPI.h"
#include "public/HCProfileUtil.h"
#include "public/HCPublicStruct.h"
ST_MqttLoginInfo  MqttLoginInfo;
ST_MqttTopicInfo  MqttTopicInfo;
static int mqttsendfalg=1;

#define TIMEOUT     10000L
static MQTTClient client;
static MQTTClient_connectOptions conn_opts = MQTTClient_connectOptions_initializer;
static MQTTClient_message pubmsg = MQTTClient_message_initializer;
static MQTTClient_deliveryToken token;
volatile MQTTClient_deliveryToken deliveredtoken;
static char getbuf[MQTT_BUF_SIZE]={0};
ST_MqttTopicInfo MqttTopicInfoSum;
static iot_device_info_t gateway = {
    .iotstatus = IOT_STATUS_LOGIN,
};//初始化连接状态结构体
//MQTT初始化
static int SubTopicReadFlag=ERR_COMMON_FAILED;
int HC_SubTopicRead()
{
    char* topic_path = (char*)"/userdata/usr/local/subtopic.conf";
    char* topic_name = (char*)"mqtt_subtopic";
    char appnamebuf[10]={0};
    int num=0;


    for (int i=0;i<MQTT_NUM;i++) {
        memset(appnamebuf,0x0,sizeof (appnamebuf));
        sprintf(appnamebuf,"%dtopic",num);
        num++;
        HCGetProfileString(topic_path, topic_name, (char *)appnamebuf, MqttTopicInfoSum.MqttTopic[i].Topic);
        if(strlen(MqttTopicInfoSum.MqttTopic[i].Topic)==0)
            break;

    }

    return 0;

}
ST_MqttTopicInfo * HC_TopicRead()
{
    ST_MqttTopicInfo *mqttTopicInfo=&MqttTopicInfo;

    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    char *ptr=NULL;
    int topicnum=0;
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);
    sprintf(mqttTopicInfo->MqttTopic[topicnum].Topic,"/ota/device/upgrade/%s/%s",ThingCategoryKeybuf,DeviceName);
    topicnum++;
    sprintf(mqttTopicInfo->MqttTopic[topicnum].Topic,"/tls/%s/%s/thing/#",ThingCategoryKeybuf,DeviceName);
    return mqttTopicInfo;
}
void delivered(void *context, MQTTClient_deliveryToken dt)
{
    printf("Message with token value %d delivery confirmed\n", dt);
    deliveredtoken = dt;
}
//int num=1;
int msgarrvd(void *context, char *topicName, int topicLen, MQTTClient_message *message)
{

    memset(getbuf,0x0,sizeof (getbuf));
    sprintf(getbuf,"%.*s", message->payloadlen, (char*)message->payload);
    // HC_PRINT(" topicName: %s\n",topicName);
    HC_PRINT("   message: %.*s\n", message->payloadlen, (char*)message->payload);

    HC_SubTopicRead();
    for (int i=0;i<HCTopicNum(MqttTopicInfoSum);i++) {
        if(strlen(MqttTopicInfoSum.MqttTopic[i].Topic)==0)
        {
            //j++;
            break;
        }
        if(strcmp(topicName,MqttTopicInfoSum.MqttTopic[i].Topic)==0)
        {
            HC_MQTTMmap_Send(topicName,getbuf);
        }
    }



    MQTTClient_freeMessage(&message);
    MQTTClient_free(topicName);

    return 1;
}

void connlost(void *context, char *cause)
{
    HC_PRINT(" cause: %s\n", cause);

    gateway.iotstatus = IOT_STATUS_DROP;
}

int HC_MQTT_Init(ST_MqttLoginInfo  MqttLoginInfo,ST_MqttTopicInfo MqttTopicInfo)
{
    int rc;
    char hostbuf[512]={0};

    sprintf(hostbuf,"tcp://%s:%d",MqttLoginInfo.MqttHost,MqttLoginInfo.MqttPORT);
    if ((rc = MQTTClient_create(&client, hostbuf, MqttLoginInfo.MqttClientID,
                                MQTTCLIENT_PERSISTENCE_NONE, NULL)) != MQTTCLIENT_SUCCESS)
    {
        HC_PRINT("Failed to create client, return code %d\n", rc);
        goto leave;
    }
    if ((rc = MQTTClient_setCallbacks(client, NULL, connlost, msgarrvd, delivered)) != MQTTCLIENT_SUCCESS)
    {
        HC_PRINT("Failed to set callbacks, return code %d\n", rc);
        goto leave;
    }
    conn_opts.keepAliveInterval = 20;
    conn_opts.cleansession = 1;
    conn_opts.username=MqttLoginInfo.MqttUserName;
    conn_opts.password=MqttLoginInfo.MqttPassWord;

    if ((rc = MQTTClient_connect(client, &conn_opts)) != MQTTCLIENT_SUCCESS)
    {
         HC_PRINT("Failed to connect, return code %d\n", rc);
         HC_PRINT("MqttLoginInfo.MqttUserName %s\n", MqttLoginInfo.MqttUserName);
         HC_PRINT("MqttLoginInfo.MqttPassWord %s\n", MqttLoginInfo.MqttPassWord);
         HC_PRINT("MqttLoginInfo.MqttHost %s\n", MqttLoginInfo.MqttHost);
         HC_PRINT("MqttLoginInfo.MqttClientID %s\n", MqttLoginInfo.MqttClientID);
         HC_PRINT("MqttLoginInfo.MqttPORT %d\n", MqttLoginInfo.MqttPORT);

        goto leave;
    }


    for (int i=0;i<HCTopicNum(MqttTopicInfo);i++) {
        if ((rc = MQTTClient_subscribe(client, MqttTopicInfo.MqttTopic[i].Topic, 1)) != MQTTCLIENT_SUCCESS)
        {
            HC_PRINT("Failed to subscribe, return code %d\n", rc);
            goto leave;
        }
        else {
            HC_PRINT("SubTopic=%s",MqttTopicInfo.MqttTopic[i].Topic);
        }
    }
    gateway.iotstatus = IOT_STATUS_CONNECT;

    return rc;
leave:
    MQTTClient_destroy(&client);
    rc = EXIT_FAILURE;
    gateway.iotstatus = IOT_STATUS_LOGIN;
    return rc;
}

//topic 数量计数
int HCTopicNum(ST_MqttTopicInfo MqttTopicInfo)
{
    int count=0,i=0;
    for (i=0;i<MQTT_NUM;i++) {

        if(strlen(MqttTopicInfo.MqttTopic[i].Topic)!=0)
        {
            count++;
        }
        else {
            break;
        }

    }
    return count;

}


int HC_MQTT_Publish(char * pubtopic,char *pbuf)
{

    int rc = 0;
    char my_topic[1024] = {0};
    int length=0;
    length=(int)strlen(pbuf);
    strcat(my_topic, pubtopic);
    pubmsg.payload = (void *)pbuf;
    pubmsg.payloadlen =length;
    pubmsg.retained = 0;
    pubmsg.qos = 0;
    if ((rc = MQTTClient_publishMessage(client, my_topic, &pubmsg, &token)) != MQTTCLIENT_SUCCESS)
    {
        //printf("Failed to publish message, return code %d\n", rc);
        exit(EXIT_FAILURE);
    }
    rc = MQTTClient_waitForCompletion(client, token, TIMEOUT);

    return rc;
}
void HC_MqttDeviceDisconnect(void)
{
    MQTTClient_destroy(&client);
}
void  HC_yield(ST_MqttLoginInfo  MqttLoginInfo,ST_MqttTopicInfo  MqttTopicInfo)
{
    int ret;

    switch (gateway.iotstatus) {
    case IOT_STATUS_LOGIN:


        ret = HC_MQTT_Init(MqttLoginInfo,MqttTopicInfo);
        if (ret < 0) {
            HC_PRINT("mqtt connect error code %d\n", ret);
            usleep(100000);
        }
        break;
    case IOT_STATUS_DROP:
       // HC_PRINT("IOT_STATUS_DROP\n");
        if ((MQTTClient_disconnect(client, 10000)) != MQTTCLIENT_SUCCESS)
        {
            HC_PRINT("Failed to disconnect, return code\n");

        }
        MQTTClient_destroy(&client);
        usleep(100000);
        gateway.iotstatus = IOT_STATUS_LOGIN;

        break;
    default :
        break;
    }
}

