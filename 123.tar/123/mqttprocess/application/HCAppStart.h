﻿#ifndef HCAPPSTART_H
#define HCAPPSTART_H
#include "common.h"

#include "public/HCFileOperation.h"
#include"public/HCJson.h"
#include"public/HCmqtt.h"
#include "public/HCPulicAPI.h"
#include "public/HCProfileUtil.h"

#define MMAPNUM 4
extern void *HC_MmapProcess_Thread(void);
extern void HC_MQTTConnect(void);
extern int HCMqttClientMsgSend(ST_MqttMmapInfo *MqttMmapInfo);
extern void HCAppStart_Init(void);
extern int HC_ProcessCount(int Processnum);
extern void *HC_Sharedmemory_Thread(void);
extern void *HC_yeid(void);
#endif
