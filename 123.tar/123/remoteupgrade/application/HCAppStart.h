﻿#ifndef HCAPPSTART_H
#define HCAPPSTART_H
#include "common.h"
#include "public/HCFileOperation.h"
#include "public/HCPulicAPI.h"


#include"public/HCPublicStruct.h"
#include "application/HCBusiness.h"



#define REMOTEUPGRADE_PATH  "/userdata/usr/Remoteupgrade/"
#define MAPLENG 0x80000 //最大映射大小
#define APPLICATION_VERSION   "/userdata/usr/local/version/application_version.txt"
#define ALGORITHM_VERSION   "/userdata/usr/local/version/algorithm_version.txt"
#define LIBRARY_VERSION   "/userdata/usr/local/version/library_version.txt"

extern void HCAppStart_Init(void);
extern void *HC_MQTTSubProcess_Thread(void );
extern void *HCHCRemoteupgradeProcess(void);
extern int HCRemoteupgradeStart(char *data);
extern int HCtasknum(ST_Remoteupgrade_Task Remoteupgrade_Task);
extern int HCRemoteupgrade( ST_RemoteupgradeInfo RemoteupgradeInfo);
extern int HCFileMD5Check(char *filename,char*md5value);
extern int HCUnzipFileName(char *filename);
extern  int HCDeleteFileName(char *filename);
extern int HCRemoteupgradeFile(char *pathname,char *filename);
extern int HCChmod_777(char *filename);
extern int HC_UpLoadVersion(char *module,char *path);
extern void HCMqtttopicGenerate(void);
extern char * HCRemoteupgradeFileget(const char *pDataRootPath);
extern char * HCRemoteupgradeshFileget(const char *pDataRootPath);
extern int HCRemoteupgradeAndReboot(void);
extern int HCRemoteuplibrary(void);
extern int Remotealgorithm(void);
extern int HCRemoteApplication(void);
extern int HCVersionErrorInfo(void);
extern int HCshFileRemoteUpgrade(char*shfilename);
#endif
