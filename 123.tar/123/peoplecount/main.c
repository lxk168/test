#include <stdio.h>
#include "common.h"
#include  "init.h"
int main()
{
    HC_Init();
    while(1)
    {
        sleep(1);
    }
    return 0;
}
