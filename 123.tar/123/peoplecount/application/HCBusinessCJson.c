﻿#include "application/HCBusinessCJson.h"
#include"application/HCMqttSubProcess.h"

ST_MqttMmapInfo mqttMmapInfo;
#define MAXCJSONLENG (1024*50)
ST_Topic_InforMation Topic_InforMation;



void HCSubTopicInit(void)
{


    return ;
}
