﻿#include "HCAppStart.h"

#include "application/HCAnalysisTypeChange.h"
#include "application/HCBusinessCJson.h"
#include"application/HCMqttSubProcess.h"

int PVFlag=ERR_COMMON_SUCCESS;

ST_MqttUsrData MqttUsrData;
//初始化
char idbuf[3][100]={
    "671785381129224192",
    "671785381129224193",
    "671785381129224194"
};
void HCApppStart_Init(void)
{
    memset(&MqttUsrData,0x0,sizeof (ST_MqttUsrData));
    MqttUsrData=HCReadUserData();
    HC_MmapProcess_Server_Init();
    HCSubTopicInit();
    //        //视觉融合进程启动
    pthread_t t1= 0,t2= 0;
    HCStartTask();
    HC_PthreadCreate(t1,HC_DataProcess_Thread);
    HC_PthreadCreate(t2,HC_ProcessMonitor_Thread);

}

void *HC_ProcessMonitor_Thread(void)
{
    while(1)
    {

        if(ERR_COMMON_FAILED==HC_ProcessMointor("analysis_huichuan"))
        {
            PVFlag=ERR_COMMON_FAILED;
            HCStartTask();
            HC_PRINT("算法进程崩溃");

            PVFlag=ERR_COMMON_SUCCESS;
        }
        sleep(1);
    }
}
void HCStartTask(void)
{
    int i=0,j=0;
    HCReadInfor(TASK_TABLE_NAME,0,1);//查看任务列表
    HCReadInfor(VIDEO_TABLE_NAME,0,1);//查看视频列表
    HCDeleteAnalysis();
    if(ERR_COMMON_FAILED==HCAnalysisStart())
    {
        HC_PRINT("算法任务启动失败\n\r");

        return ;
    }

    //启动任务表里所有有效任务
    for (i=0;i<HCTaskNumCount(MAXTaskNum);i++) {
        if(transtasktotal.TaskNum[i].id!=0){
            mmapadresstol.MmapAdressNum[i].video_id=transtasktotal.TaskNum[i].video_id;
            //遍历有效的视频并且生成对应映射地址以(视频名_mmap.hc)形式
            for (j=0;j<MAXVideoNum;j++) {
                if((mmapadresstol.MmapAdressNum[i].video_id==transvideototal.VideoNum[j].id)&&mmapadresstol.MmapAdressNum[i].video_id!=0){
                    sprintf(mmapadresstol.MmapAdressNum[i].MmapAdress,"%s_mmap.hc",transvideototal.VideoNum[j].name);
                    HCRemoveAdress(mmapadresstol.MmapAdressNum[i].MmapAdress);

                }
            };
            if(transtasktotal.TaskNum[i].status==0){
                if(ERR_COMMON_FAILED==HCTaskStop(transtasktotal.TaskNum[i].id))
                {
                    char buf[256]={0};
                    sprintf(buf,"TaskStop failed TaskNum =%d",transtasktotal.TaskNum[i].id);
                    HC_PRINT("任务停止失败 TaskNum =%d\n\r",transtasktotal.TaskNum[i].id);

                    return ;
                }

            }
            if(ERR_COMMON_FAILED==HCTaskStart(transtasktotal.TaskNum[i].id)) {

                HC_PRINT("TaskStart failed TaskNum =%d\n\r",transtasktotal.TaskNum[i].id);
                char buf[256]={0};
                sprintf(buf,"任务启动失败 TaskNum =%d",transtasktotal.TaskNum[i].id);

                return ;
            }

        }
    }

}
int HCTaskNumCount(int TaskNum)
{
    int count=0;
    for (int i=0;i<TaskNum;i++) {
        if(transtasktotal.TaskNum[i].id!=0)
            count++;
    }
    return count;
}
char*strrpc(char*str,char*oldstr,char*newstr){

    char bstr[strlen(str)];//转换缓冲区

    memset(bstr,0,sizeof(bstr));

    for(int i=0;i<strlen(str);i++){

        if(!strncmp(str+i,oldstr,strlen(oldstr))){//查找目标字符串

            strcat(bstr,newstr);

            i+=strlen(oldstr)-1;

        }else{

            strncat(bstr,str+i,1);//保存一字节进缓冲区

        }

    }

    strcpy(str,bstr);

    return str;

}
int HCTaskStart(int id)
{
    int rec=ERR_COMMON_SUCCESS;
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"cd %s && ./framework -r %d",LocalPath,id);
    HC_LinuxSystem(pcCmdbuf,backbuf);
    usleep(1000);
    if(strncmp(backbuf,"update the task status success",30)!=0)
    {
        HC_PRINT("任务启动失败");

        rec=ERR_COMMON_FAILED;
    }

    return rec;
}
int HCRemoveAdress(char *address)
{
    int rec=ERR_COMMON_SUCCESS;
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"cd %s && rm -rf  %s",LocalPath,address);
    HC_LinuxSystem(pcCmdbuf,backbuf);
    return rec;
}
int HCAnalysisStart(void )
{

    char pcCmdbuf[256]={0};

    sprintf(pcCmdbuf,"cd %s && nohup ./analysis_huichuan &",LocalPath);
    system(pcCmdbuf);
    return ERR_COMMON_SUCCESS;
}
int HCTaskStop(int id)
{
    int rec=ERR_COMMON_SUCCESS;
    char pcCmdbuf[256]={0};
    char backbuf[512]={0};
    sprintf(pcCmdbuf,"cd %s && ./framework -e %d",LocalPath,id);
    HC_LinuxSystem(pcCmdbuf,backbuf);
    usleep(1000);
    if(strncmp(backbuf,"update the task status success",30)!=0)
        rec=ERR_COMMON_FAILED;
    return rec;
}
void HCDeleteAnalysis(void )
{
    HC_LinuxKillProcess("analysis_huichuan");
    usleep(1000);
}

