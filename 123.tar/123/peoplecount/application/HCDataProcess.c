﻿#include "HCDataProcess.h"



ST_Mmapfd Mmapfd[MAXTaskNum];
ST_AnalysisResult AnalysisResult;


//内存映射线程
void *HC_DataProcess_Thread(void)
{


    int i=0;
    char  cmp1[MAXTaskNum][BUFSIZE]={{0}};
    char  cmp2[MAXTaskNum][BUFSIZE]={{0}};
    char  Analysisbuf[MAXTaskNum][BUFSIZE]={{0}};

    char filename[256]={0};
    int ReadFd = 0;
    int WriteFd=0;

    char filenamePath[512]={0};


    for (i=0;i<HCTaskNumCount(MAXTaskNum);i++) {


        if(strlen(mmapadresstol.MmapAdressNum[i].MmapAdress)!=0)
        {
            memset(filename,0x0,sizeof (filename));
            sprintf(filename,"/userdata/usr/local/%s",mmapadresstol.MmapAdressNum[i].MmapAdress);
            ReadFd = open(filename, O_RDWR);
            if (ReadFd < 0)
            {
                HC_fileOpen(&WriteFd, filename, O_RDWR | O_CREAT);
                lseek(WriteFd, MAPLEN-1, SEEK_SET);
                write(WriteFd, "\0", 1);
                //申请映射
                Mmapfd[i].mmapfd = mmap(NULL, (size_t)MAPLEN, PROT_READ|PROT_WRITE, MAP_SHARED,WriteFd, 0);
                if ( Mmapfd[i].mmapfd == MAP_FAILED)
                {
                    HC_PRINT("mmap error\n");


                }
                close(WriteFd);
                memset(& Mmapfd[i].mmapfd, 0x0, sizeof(ST_GetData));
                munmap( Mmapfd[i].mmapfd, MAPLEN);
                ReadFd = open(filename, O_RDWR);

            }
            Mmapfd[i].mmapfd = mmap(NULL, MAPLEN, PROT_READ|PROT_WRITE, MAP_SHARED, ReadFd, 0);
            if ( Mmapfd[i].mmapfd == MAP_FAILED)
            {
                HC_PRINT("mmap error\n");

            }
            close(ReadFd);
        }
    }
    while(1)
    {

        memset(filenamePath,0x0,sizeof (filenamePath));
        for (i=0;i<HCTaskNumCount(MAXTaskNum);i++) {


            if(strlen(mmapadresstol.MmapAdressNum[i].MmapAdress)!=0){
                memset(cmp2[i],0x0,sizeof (cmp2[i]));
                memset(&Analysisbuf[i][0],0x0,BUFSIZE);

                memcpy(cmp2[i],&Mmapfd[i].mmapfd->result[0],(unsigned long)Mmapfd[i].mmapfd->json_len);
                memcpy(&Analysisbuf[i][0],&Mmapfd[i].mmapfd->result[0],(unsigned long)Mmapfd[i].mmapfd->json_len);
                if(strcmp(cmp1[i],cmp2[i])!=0&&PVFlag==ERR_COMMON_SUCCESS)
                {
                    memset(cmp1[i],0x0,sizeof (cmp1[i]));
                    strcpy(cmp1[i],cmp2[i]);

                    memset(&AnalysisResult.AnalysisDataBbox[i],0x0,sizeof (ST_AnalysisDataBbox));

                }



            }

        }



        usleep(300000);

    }
    return ERR_COMMON_SUCCESS;
}


