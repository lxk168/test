﻿
#ifndef HCBUSINESSINTERFACE_H
#define HCBUSINESSINTERFACE_H
#include "common.h"
#include "public/HCPublicStruct.h"
#include "public/HCProfileUtil.h"
#include "public/HCJson.h"
#pragma pack (1)
typedef struct
{
   char UserNamebuf[1024];
   char ThingCategoryKeybuf[1024];
   char DeviceName[1024];
}ST_MqttUsrData;
#pragma pack ()
extern int eventflag;//事件标志位
extern int HCSoundFlag;
extern ST_MqttUsrData MqttUsrData;
extern ST_AnalysisDataBbox *  HCJsonAnalysis(char *Analysisbuf);
extern ST_MqttUsrData HCReadUserData(void);

#endif



