﻿
#ifndef HCDATAPROCESS_H
#define HCDATAPROCESS_H
#include "common.h"

#include "public/HCFileOperation.h"
#include "public/HCJson.h"
#include "public/HCSqlite.h"
#include "HCBusinessInterface.h"
#include "public/HCPublicStruct.h"
#define MAPLEN 0x80000   //最大映射大小
#define PICBUFSIZ  409600
#define BUFSIZE 4096
#define MAXTaskNum   3    //同时跑的最大任务数

#pragma pack (1)
// 视觉分析的结构体

typedef struct
{
    int json_len;
    int pic_length;      //图片数据长度
    char result[BUFSIZE];    //json数据字符串
    char start[PICBUFSIZ];     //图片数据
}ST_GetData;
typedef struct
{
    ST_GetData * mmapfd;
}ST_Mmapfd;



#pragma pack()


extern ST_Mmapfd Mmapfd[MAXTaskNum];

extern void *HC_DataProcess_Thread(void);

#endif



