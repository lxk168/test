﻿#include"application/HCMqttPubProcess.h"
#include"application/HCBusinessCJson.h"
#include"application/HCBusinessTopic.h"

#include"common.h"
static char *g_display_param_addr = NULL;
static char *g_common_data_addr = NULL;
static sem_t *g_elevator_data_sem = NULL;
static char *create_shared_memory(char *name, int len);

char *create_shared_memory(char *name, int len)
{
    int fd;
    int rc;
    char *addr;

    fd = shm_open(name, O_RDONLY|O_CREAT, 0);
    if (fd == -1)
    {
        fprintf(stderr, "shm_open %s fail: [%s]\n", name, strerror(errno));
        return NULL;
    }

    addr = mmap(NULL, len, PROT_READ, MAP_SHARED, fd, 0);
    if (addr == MAP_FAILED)
    {
        return NULL;
    }

    rc = close(fd);
    if (rc == -1)
    {
        fprintf(stderr, "close %s fail", name);
        return NULL;
    }

    return addr;
}


void *HCMqttPubProcess_Thread(void)
{

    struct ST_elevator_common_data_t common_data[3];
    int i;
    memset(common_data,0x0,sizeof (struct ST_elevator_common_data_t));
    g_display_param_addr = create_shared_memory(
                SHARED_OBJ_DISPLAY_PARAM, sizeof( struct ST_elevator_display_param_t) * 3);
    if (g_display_param_addr == NULL)
    {
        return NULL;
    }

    g_common_data_addr = create_shared_memory(
                SHARED_OBJ_COMMON_DATA, sizeof(struct  ST_elevator_common_data_t) * 3);
    if (g_common_data_addr == NULL)
    {
        return NULL;
    }

    g_elevator_data_sem = sem_open(SEM_OBJ_ELEVATOR_DATA, O_RDONLY|O_CREAT, 0);
    if (g_elevator_data_sem == SEM_FAILED)
    {
        fprintf(stderr, "sem_open %s fail: [%s]\n", SEM_OBJ_ELEVATOR_DATA, strerror(errno));
        return NULL;
    }
    sem_post(g_elevator_data_sem);
    while (1)
    {
        if (sem_trywait(g_elevator_data_sem) == 0)
        {
            //            memcpy(&display_param, g_display_param_addr, sizeof(display_param));

            //            for (i = 0; i < 3; i++)
            //            {
            //                if (display_param[i].slave != 0)
            //                {
            //                    HC_PRINT("display_param slave %d, floor 1 diaplay param %04X\n",
            //                             display_param[i].slave, display_param[i].floor_display[0]);
            //                }
            //            }

            memcpy(&common_data, g_common_data_addr, sizeof(common_data));
            for (i = 0; i < 3; i++)
            {
                if (common_data[i].slave != 0)
                {
//                    HC_PRINT("common_data slave %d, service_mode code %d,fault code %d, car status %d, current floor %d\n",
//                             common_data[i].slave, common_data[i].service_mode,common_data[i].fault_code,
//                             common_data[i].car_status, common_data[i].current_floor);




                }
                usleep(50000);
            }

            sem_post(g_elevator_data_sem);
        }

        usleep(50000);
    }
}
