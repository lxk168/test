﻿#ifndef HCAPPSTART_H
#define HCAPPSTART_H
#include "common.h"
#include "public/HCFileOperation.h"
#include "public/HCPulicAPI.h"

#include "HCDataProcess.h"

#include "HCMqttSubProcess.h"
#include "public/HCSqlite.h"
#include "public/HCPublicStruct.h"


extern void HCApppStart_Init(void);
extern void HCStartTask(void);
extern int HCAnalysisStart(void);
extern int HCTaskStart(int id);
extern int HCTaskStop(int id);
extern void HCDeleteAnalysis(void );
extern void *HC_ProcessMonitor_Thread(void);
extern int HCRemoveAdress(char *address);
extern char*strrpc(char*str,char*oldstr,char*newstr);
extern int HCTaskNumCount(int TaskNum);
#endif
