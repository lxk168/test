﻿
#ifndef HCBUSINESSCJSON_H
#define HCBUSINESSCJSON_H
#include "common.h"

#include "public/HCPublicStruct.h"
#include "application/HCMqttSubProcess.h"


typedef struct
{
    char HCPersonTopic_Pub[512];//人员技术
}ST_Event_Pub_Topic;

typedef struct
{
    ST_Event_Pub_Topic Event_Pub_Topic[3];
}ST_Topic_InforMation;

extern void HCSubTopicInit(void);
extern ST_Topic_InforMation Topic_InforMation;
#endif



