﻿#include"application/HCBusinessTopic.h"
#include"public/HCProfileUtil.h"
#include"public/HCFileOperation.h"
char HCfrontDoorOpenKeepCommandTopic_Sub[3][512]={{0}};//机器人乘梯前门开关门响应Topic
char HCouterCallLiftTopic_Sub[3][512]={{0}};//机器人乘梯外呼响应Topic
char HCinnerCallLiftTopic_Sub[3][512]={{0}};//机器人乘梯内呼响应Topic
char HCfrontDoorCloseCommand_Sub[3][512]={{0}};//机器人关门响应TOPIC
char HCagvInformationEventTopic_Pub[3][512]={{0}};//机器人乘梯实时数据
char HCcomparisonTableOfFloorAndPhysicalFloorEventTopic_Pub[3][512]={{0}};//机器人乘梯楼层对照数据
char HCfrontDoorOpenKeepCommandTopic_Pub[3][512]={{0}};//开关门响应
char HCouterCallLiftTopic_Pub[3][512]={{0}};//外呼响应
char HCinnerCallLiftTopic_Pub[3][512]={{0}};//内呼响应
char HCfrontDoorCloseCommand_Pub[3][512]={{0}};//机器人关门响应TOPIC
char *HCBusinessTopicBulid(char *method)
{
    char Topicbuf[2048]={0};
    char* file_path = (char*)"/usr/local/jiqiren/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";

    char *ptr=NULL;
    char UserNamebuf[1024]={0};
    char ThingCategoryKeybuf[1024]={0};
    char DeviceName[1024]={0};
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", UserNamebuf);
    ptr=strchr(UserNamebuf,'&');
    strcat(ThingCategoryKeybuf,ptr+1);
    memcpy(DeviceName,UserNamebuf,strlen(UserNamebuf)-strlen(ThingCategoryKeybuf)-1);

    sprintf(Topicbuf,"/tsl/%s/%s/%s",ThingCategoryKeybuf,DeviceName,method);

    char *temp=Topicbuf;
    return temp;
}
