﻿#include "HCBusinessInterface.h"



ST_MqttUsrData HCReadUserData()
{
    ST_MqttUsrData MqttUsrData;
    char *ptr=NULL;
    char* file_path = (char*)"/userdata/usr/local/mqtt.conf";
    char* app_name = (char*)"mqtt_userdata";
    memset(&MqttUsrData,0x0,sizeof (ST_MqttUsrData));
    HCGetProfileString(file_path, app_name, (char*)"MqttUserName", MqttUsrData.UserNamebuf);
    ptr=strchr(MqttUsrData.UserNamebuf,'&');
    strcat(MqttUsrData.ThingCategoryKeybuf,ptr+1);
    memcpy(MqttUsrData.DeviceName,MqttUsrData.UserNamebuf,strlen(MqttUsrData.UserNamebuf)-strlen(MqttUsrData.ThingCategoryKeybuf)-1);
    return MqttUsrData;
}
//Cjson解析
ST_AnalysisDataBbox *  HCJsonAnalysis(char *Analysisbuf)
{
    char buf[1024]={0};
    ST_AnalysisDataBbox *AnalysisDataBbox=(ST_AnalysisDataBbox *)buf;
    //第一步打包JSON字符串
    cJSON* cjson = cJSON_Parse(Analysisbuf);

    //判断是否打包成功
    if(cjson == NULL){
        HC_PRINT("cjson error…\n");

        return NULL;
    }
    char *json_data = NULL;
    //获取数组对象
    cJSON* test_arr = cJSON_GetObjectItem(cjson,"other");

    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"info"));
    if(json_data!=NULL)
    {
        sprintf(AnalysisDataBbox->Bbox.info,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"info_person"));
    if(json_data!=NULL)
    {
        sprintf(AnalysisDataBbox->Bbox.info_person,"%s",json_data);

    }
    free(json_data);
    json_data = cJSON_Print(cJSON_GetObjectItem(test_arr,"info_door"));
    if(json_data!=NULL)
    {
        sprintf(AnalysisDataBbox->Bbox.info_door,"%s",json_data);

    }
    free(json_data);
    //获取数组对象
    cJSON* test_bbox = cJSON_GetObjectItem(cjson,"bbox");
    //获取数组对象个数便于循环
    int bbox_size = cJSON_GetArraySize(test_bbox);//return arr_size 2
    HC_PRINT("bbox_size=%d",bbox_size);
    //获取test_arr数组对象孩子节点
    cJSON* arr_item = test_bbox->child;//子对象
    //循环获取数组下每个字段的值
    for(int i = 0;i <=(bbox_size-1)/*0*/;++i){


        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"xmin"));
        AnalysisDataBbox->Bbox.xmin=atoi(json_data);
        free(json_data);
        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"ymin"));
        AnalysisDataBbox->Bbox.ymin=atoi(json_data);
        free(json_data);
        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"xmax"));
        AnalysisDataBbox->Bbox.xmax=atoi(json_data);
        free(json_data);
        json_data = cJSON_Print(cJSON_GetObjectItem(arr_item,"ymax"));
        AnalysisDataBbox->Bbox.ymax=atoi(json_data);
        free(json_data);
        arr_item = arr_item->next;//下一个子对象

    }
    //这里只需要释放cjson即可，因为其它的都指向它
    cJSON_Delete(cjson);

    return AnalysisDataBbox;
}
