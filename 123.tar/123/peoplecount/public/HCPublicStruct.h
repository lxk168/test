#ifndef HCPUBLICSTRUCT_H
#define HCPUBLICSTRUCT_H
#include "common.h"
#include"zmq/czmq.h"

#pragma pack (1)


typedef struct
{

    int tm_sec;            /* seconds */
    int tm_min;           /* minutes */
    int tm_hour;         /* hours */
    int tm_mday;        /* day of the month */
    int tm_mon;         /* month */
    int tm_year;          /* year */
} St_SystemTime;

// json拆解后的结构体
typedef struct
{
    int xmin;
    int ymin;
    int xmax;
    int ymax;
    char info_person[20];
    char info[20];
    char info_door[20];
}ST_AnalysisData;

typedef struct {
     int JPG_size;
    unsigned char JPG_Data[409600];
}St_Result_JPG;
typedef struct
{

    ST_AnalysisData Bbox;
}ST_AnalysisDataBbox;
typedef struct
{
  ST_AnalysisDataBbox AnalysisDataBbox[3];//3个任务
}ST_AnalysisResult;
#pragma pack()
extern ST_AnalysisResult AnalysisResult;
extern int PVFlag;
#endif // HCPUBLICSTRUCT_H
